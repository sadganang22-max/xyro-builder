import 'main.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ══════════════════════════════════════════════════════════════════
//  HELL DARKNESS PALETTE — konsisten dengan HomePage Hell
// ══════════════════════════════════════════════════════════════════
class _H {
  static const bg          = Color(0xFF050000);
  static const bgDeep      = Color(0xFF0A0000);
  static const surface     = Color(0xFF120303);
  static const card        = Color(0xFF0E0202);

  static const blood       = Color(0xFF8B0000);
  static const bloodBright = Color(0xFFFF0000);
  static const bloodDark   = Color(0xFF4A0000);

  static const ember       = Color(0xFFFF4500);
  static const flame       = Color(0xFFFF6600);
  static const flameBright = Color(0xFFFFAA00);

  static const ash         = Color(0xFF3A2A2A);
  static const textPrimary = Color(0xFFE8D5D5);
  static const textSub     = Color(0xFFB08888);
  static const textMuted   = Color(0xFF6B4040);

  static const border      = Color(0xFF2A0A0A);
  static const borderGlow  = Color(0xFF3D0F0F);

  static const danger      = Color(0xFFFF1A1A);
  static const success     = Color(0xFF00FF41);
  static const warning     = Color(0xFFFF8800);
  static const toxic       = Color(0xFF00CC33);
  static const violet      = Color(0xFF6600CC);
  static const violetBright= Color(0xFFAA00FF);
}

// ─── Rules data ───────────────────────────────────────────────────────────────
const _rules = [
  _Rule(
    title: 'Larangan Barter Akun',
    desc:  'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.',
    icon:  Icons.swap_horiz_rounded,
    color: _H.warning,
  ),
  _Rule(
    title: 'Larangan Membagikan Akun',
    desc:  'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.',
    icon:  Icons.share_rounded,
    color: Color(0xFFFF6633),
  ),
  _Rule(
    title: 'Larangan Menjual Akun',
    desc:  'Member TIDAK diperbolehkan menjual akun. Penjualan hanya boleh dilakukan oleh role yang diizinkan secara resmi.',
    icon:  Icons.sell_rounded,
    color: _H.danger,
  ),
  _Rule(
    title: 'Larangan Jual Durasi Ilegal',
    desc:  'Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.',
    icon:  Icons.timer_off_rounded,
    color: _H.violetBright,
  ),
  _Rule(
    title: 'Larangan Banting Harga',
    desc:  'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan DarkLight.',
    icon:  Icons.trending_down_rounded,
    color: _H.toxic,
  ),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc,
      required this.icon, required this.color});
}

// ─── Page ─────────────────────────────────────────────────────────────────────
class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;
  bool hasError = false;
  String errorMsg = '';

  bool   _apiOnline   = false;
  int    _pingMs      = 0;
  String _pingStatus  = 'Checking...';
  Timer? _pingTimer;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pingDotCtrl;
  late AnimationController _sanctionCtrl;
  late AnimationController _emberCtrl;

  late Animation<double> _entrance;
  late Animation<double> _pingDot;
  late Animation<double> _sanctionGlow;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 22))
      ..repeat();

    _emberCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 5))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _pingDotCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _pingDot = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pingDotCtrl, curve: Curves.easeInOut));

    _sanctionCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.2, end: 0.6)
        .animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));

    _fetchServerInfo();
    _startPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _pingDotCtrl.dispose();
    _sanctionCtrl.dispose();
    _emberCtrl.dispose();
    super.dispose();
  }

  // ─── API ────────────────────────────────────────────────────────────────────
  Future<void> _fetchServerInfo() async {
    setState(() { isLoading = true; hasError = false; });
    try {
      final res = await http.get(
        Uri.parse('http://node.zanspiwcloud.panelpublic.my.id:6067/getServerInfo?key=${widget.sessionKey}')
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200 && mounted) {
        setState(() { serverInfo = jsonDecode(res.body); isLoading = false; });
      } else {
        setState(() {
          isLoading = false;
          hasError = true;
          errorMsg = 'Server response error: ${res.statusCode}';
        });
      }
    } on TimeoutException catch (_) {
      if (mounted) setState(() {
        isLoading = false;
        hasError = true;
        errorMsg = 'Server timeout - koneksi lambat';
      });
    } catch (e) {
      if (mounted) setState(() {
        isLoading = false;
        hasError = true;
        errorMsg = 'Gagal terhubung ke server';
      });
    }
    if (mounted) _entranceCtrl.forward();
  }

  void _startPingLoop() {
    _checkPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkPing());
  }

  Future<void> _checkPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('http://node.zanspiwcloud.panelpublic.my.id:6067/ping?key=${widget.sessionKey}')
      ).timeout(const Duration(seconds: 3));
      final ms = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          _apiOnline  = true;
          _pingMs     = ms;
          _pingStatus = '${ms}ms';
        });
      } else {
        if (mounted) setState(() { _apiOnline = false; _pingMs = 0; _pingStatus = 'Offline'; });
      }
    } catch (_) {
      if (mounted) setState(() { _apiOnline = false; _pingMs = 0; _pingStatus = 'Offline'; });
    }
  }

  Color get _pingColor {
    if (!_apiOnline) return _H.danger;
    if (_pingMs < 200) return _H.success;
    if (_pingMs < 500) return _H.flameBright;
    return _H.ember;
  }

  String get _pingLabel {
    if (!_apiOnline) return 'OFFLINE';
    if (_pingMs < 200) return 'EXCELLENT';
    if (_pingMs < 500) return 'GOOD';
    return 'SLOW';
  }

  // ─── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: _H.bg,
        body: Stack(children: [
          Positioned.fill(child: _AnimatedBg(
            auroraCtrl: _bgCtrl, emberCtrl: _emberCtrl)),
          const Center(child: _DotsLoader()),
        ]),
      );
    }

    return Scaffold(
      backgroundColor: _H.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(
            auroraCtrl: _bgCtrl, emberCtrl: _emberCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 48),
                children: [
                  if (hasError) _buildErrorBanner(),
                  if (hasError) const SizedBox(height: 16),

                  _buildStatusCard(),
                  const SizedBox(height: 20),

                  _buildSectionHeader(
                    icon: Icons.gavel_rounded,
                    title: 'Peraturan Pengguna',
                    subtitle: '${_rules.length} aturan berlaku',
                  ),
                  const SizedBox(height: 14),

                  ..._rules.asMap().entries.map((e) =>
                    _StaggerItem(
                      index: e.key,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _RuleCard(rule: e.value, number: e.key + 1),
                      ),
                    )),

                  const SizedBox(height: 20),

                  _buildSanctionCard(),
                  const SizedBox(height: 24),

                  _buildFooter(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Error banner
  Widget _buildErrorBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          _H.bloodBright.withOpacity(0.15),
          _H.bloodDark.withOpacity(0.08),
        ]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _H.bloodBright.withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(color: _H.bloodBright.withOpacity(0.2), blurRadius: 20, spreadRadius: 1),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _H.bloodBright.withOpacity(0.2),
              border: Border.all(color: _H.bloodBright.withOpacity(0.5)),
            ),
            child: const Icon(Icons.error_outline, color: _H.bloodBright, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('GAGAL MEMUAT SERVER',
                    style: TextStyle(color: _H.bloodBright, fontSize: 12,
                        fontWeight: FontWeight.w900, letterSpacing: 0.5)),
                Text(errorMsg,
                    style: const TextStyle(color: _H.textSub, fontSize: 11)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _fetchServerInfo(),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_H.bloodBright, _H.bloodDark],
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(color: _H.bloodBright.withOpacity(0.5), blurRadius: 12),
                ],
              ),
              child: const Text('COBA',
                  style: TextStyle(color: Colors.white, fontSize: 11,
                      fontWeight: FontWeight.w900, letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      title: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              _H.bloodBright.withOpacity(0.4),
              _H.bloodDark.withOpacity(0.2),
            ]),
            border: Border.all(color: _H.bloodBright.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(color: _H.bloodBright.withOpacity(0.4), blurRadius: 14),
            ],
          ),
          child: const Icon(Icons.local_fire_department_rounded,
              color: _H.flameBright, size: 16),
        ),
        const SizedBox(width: 10),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [_H.textPrimary, _H.bloodBright],
          ).createShader(b),
          child: const Text('PERATURAN & INFO',
              style: TextStyle(color: Colors.white, fontSize: 15,
                  fontWeight: FontWeight.w900, letterSpacing: 1)),
        ),
      ]),
    );
  }

  // ─── Status Card ──────────────────────────────────────────────────────────
  Widget _buildStatusCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_H.card, _H.surface.withOpacity(0.8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _H.borderGlow, width: 1.2),
        boxShadow: [
          BoxShadow(color: _pingColor.withOpacity(0.15),
              blurRadius: 26, offset: const Offset(0, 6), spreadRadius: 1),
        ],
      ),
      child: Column(children: [
        Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                _pingColor.withOpacity(0.35),
                _pingColor.withOpacity(0.08),
              ]),
              border: Border.all(color: _pingColor.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(color: _pingColor.withOpacity(0.3), blurRadius: 14),
              ],
            ),
            child: Icon(Icons.router_rounded, color: _pingColor, size: 18),
          ),
          const SizedBox(width: 12),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SYSTEM STATUS', style: TextStyle(color: _H.textPrimary,
                fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1)),
            Text('Real-time server monitoring',
                style: TextStyle(color: _H.textSub, fontSize: 10)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _pingColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _pingColor.withOpacity(0.4)),
              boxShadow: [
                BoxShadow(color: _pingColor.withOpacity(0.2), blurRadius: 8),
              ],
            ),
            child: Text(_pingLabel,
                style: TextStyle(color: _pingColor, fontSize: 9,
                    fontWeight: FontWeight.w900, letterSpacing: 1)),
          ),
        ]),

        const SizedBox(height: 16),
        Container(height: 1, color: _H.border),
        const SizedBox(height: 16),

        Row(children: [
          AnimatedBuilder(
            animation: _pingDot,
            builder: (_, __) => Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _apiOnline
                    ? _H.success.withOpacity(_pingDot.value)
                    : _H.danger,
                boxShadow: _apiOnline
                    ? [BoxShadow(
                        color: _H.success.withOpacity(_pingDot.value * 0.7),
                        blurRadius: 10, spreadRadius: 1)]
                    : [BoxShadow(color: _H.danger.withOpacity(0.6), blurRadius: 8)],
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            _apiOnline ? 'API Server Online' : 'API Server Offline',
            style: TextStyle(
              color: _apiOnline ? _H.textPrimary : _H.danger,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const Spacer(),
          if (_apiOnline) ...[
            const Icon(Icons.speed_rounded, color: _H.textSub, size: 14),
            const SizedBox(width: 5),
            Text(_pingStatus,
                style: TextStyle(color: _pingColor, fontSize: 13,
                    fontWeight: FontWeight.w800)),
          ],
        ]),

        if (_apiOnline) ...[
          const SizedBox(height: 10),
          _PingBar(ms: _pingMs, color: _pingColor),
        ],
      ]),
    );
  }

  Widget _buildSectionHeader({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Container(
          width: 4, height: 22,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_H.bloodBright, _H.ember, _H.flameBright],
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _H.bloodBright.withOpacity(0.5), blurRadius: 10),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: _H.textPrimary, fontSize: 14,
              fontWeight: FontWeight.w900, letterSpacing: 0.5)),
          Text(subtitle, style: const TextStyle(color: _H.textSub, fontSize: 10)),
        ]),
        const Spacer(),
        Icon(icon, color: _H.bloodBright, size: 18),
      ]),
    );
  }

  // ─── Sanction Card ────────────────────────────────────────────────────────
  Widget _buildSanctionCard() {
    return AnimatedBuilder(
      animation: _sanctionCtrl,
      builder: (_, __) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _H.card,
                _H.bloodDark.withOpacity(0.25 + _sanctionGlow.value * 0.15),
                _H.card,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _H.bloodBright.withOpacity(0.4 + _sanctionGlow.value * 0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _H.bloodBright.withOpacity(_sanctionGlow.value * 0.3),
                blurRadius: 36, spreadRadius: 2,
              ),
              BoxShadow(
                color: _H.ember.withOpacity(_sanctionGlow.value * 0.15),
                blurRadius: 60,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(children: [
              // Header stripe api
              Container(
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      _H.ember,
                      _H.bloodBright,
                      _H.ember,
                      Colors.transparent,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(color: _H.bloodBright.withOpacity(0.6), blurRadius: 10),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(children: [
                  Container(
                    width: 64, height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        _H.bloodBright.withOpacity(0.3 + _sanctionGlow.value * 0.2),
                        _H.bloodDark.withOpacity(0.2),
                      ]),
                      border: Border.all(
                        color: _H.bloodBright.withOpacity(0.5 + _sanctionGlow.value * 0.3),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _H.bloodBright.withOpacity(_sanctionGlow.value * 0.5),
                          blurRadius: 28, spreadRadius: 3,
                        ),
                        BoxShadow(
                          color: _H.ember.withOpacity(_sanctionGlow.value * 0.25),
                          blurRadius: 44,
                        ),
                      ],
                    ),
                    child: Icon(Icons.gavel_rounded,
                        color: _H.flameBright.withOpacity(0.9 + _sanctionGlow.value * 0.1),
                        size: 30),
                  ),
                  const SizedBox(height: 14),

                  ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                      colors: [_H.bloodBright, _H.ember, _H.flameBright],
                    ).createShader(b),
                    child: const Text('SANKSI',
                        style: TextStyle(color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.w900, letterSpacing: 4)),
                  ),
                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _H.bgDeep,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _H.border),
                    ),
                    child: Column(children: [
                      const Text(
                        'Jika pengguna terbukti melanggar salah satu peraturan di atas:',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: _H.textSub, fontSize: 12, height: 1.5),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            _H.bloodBright.withOpacity(0.18),
                            _H.bloodDark.withOpacity(0.08),
                          ]),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _H.bloodBright.withOpacity(0.5), width: 1.2),
                          boxShadow: [
                            BoxShadow(color: _H.bloodBright.withOpacity(0.25),
                                blurRadius: 16, spreadRadius: 1),
                          ],
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.block_rounded, color: _H.bloodBright, size: 18),
                            SizedBox(width: 9),
                            Flexible(
                              child: Text('AKUN DIHAPUS PERMANEN',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: _H.textPrimary, fontSize: 12,
                                      fontWeight: FontWeight.w900, letterSpacing: 0.8)),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Tanpa pengembalian akun, saldo, atau kompensasi apa pun.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: _H.textSub, fontSize: 12,
                            height: 1.4),
                      ),
                    ]),
                  ),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              _H.card,
              _H.bloodDark.withOpacity(0.15),
            ]),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _H.borderGlow, width: 1.2),
            boxShadow: [
              BoxShadow(color: _H.blood.withOpacity(0.15), blurRadius: 22),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _H.bloodBright.withOpacity(0.15),
                  border: Border.all(color: _H.bloodBright.withOpacity(0.4)),
                  boxShadow: [
                    BoxShadow(color: _H.bloodBright.withOpacity(0.3), blurRadius: 10),
                  ],
                ),
                child: const Icon(Icons.shield_moon_rounded,
                    color: _H.flameBright, size: 16),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Peraturan ini dibuat untuk menjaga keamanan, kenyamanan, dan '
                  'kestabilan ekosistem DarkLight App. Dengan menggunakan '
                  'aplikasi ini, pengguna dianggap telah menyetujui seluruh '
                  'peraturan di atas.',
                  style: TextStyle(color: _H.textSub, fontSize: 12, height: 1.6,
                      fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          height: 3, width: 40,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_H.bloodDark, _H.bloodBright, _H.ember],
            ),
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _H.bloodBright.withOpacity(0.5), blurRadius: 8),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.local_fire_department_rounded,
              color: _H.bloodBright, size: 12),
          const SizedBox(width: 5),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [_H.bloodBright, _H.ember],
            ).createShader(b),
            child: const Text('DARKLIGHT',
                style: TextStyle(color: Colors.white, fontSize: 11,
                    fontWeight: FontWeight.w900, letterSpacing: 2)),
          ),
        ]),
        const SizedBox(width: 10),
        Container(
          height: 3, width: 40,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_H.ember, _H.bloodBright, _H.bloodDark],
            ),
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _H.bloodBright.withOpacity(0.5), blurRadius: 8),
            ],
          ),
        ),
      ]),
    ]);
  }
}

// ─── Rule Card ────────────────────────────────────────────────────────────────
class _RuleCard extends StatefulWidget {
  final _Rule rule;
  final int number;
  const _RuleCard({required this.rule, required this.number});

  @override
  State<_RuleCard> createState() => _RuleCardState();
}

class _RuleCardState extends State<_RuleCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.rule.color;

    return GestureDetector(
      onTap: () => setState(() => _expanded = !_expanded),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          gradient: _expanded
              ? LinearGradient(colors: [
                  color.withOpacity(0.15),
                  _H.card,
                ])
              : LinearGradient(colors: [
                  _H.card,
                  _H.surface.withOpacity(0.6),
                ]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: _expanded ? color.withOpacity(0.55) : _H.border,
            width: _expanded ? 1.5 : 1.0,
          ),
          boxShadow: _expanded
              ? [
                  BoxShadow(color: color.withOpacity(0.25), blurRadius: 22,
                      offset: const Offset(0, 4), spreadRadius: 1),
                ]
              : [
                  BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 8),
                ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    gradient: RadialGradient(colors: [
                      color.withOpacity(_expanded ? 0.35 : 0.18),
                      color.withOpacity(0.05),
                    ]),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: color.withOpacity(_expanded ? 0.65 : 0.3)),
                    boxShadow: _expanded
                        ? [BoxShadow(color: color.withOpacity(0.4), blurRadius: 16)]
                        : [],
                  ),
                  child: Icon(widget.rule.icon, color: color, size: 19),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: color.withOpacity(0.4)),
                        ),
                        child: Text('RULE ${widget.number}',
                            style: TextStyle(color: color, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 0.8)),
                      ),
                    ]),
                    const SizedBox(height: 5),
                    Text(widget.rule.title,
                        style: const TextStyle(color: _H.textPrimary, fontSize: 13,
                            fontWeight: FontWeight.w700, height: 1.2)),
                  ],
                )),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 220),
                  child: const Icon(Icons.keyboard_arrow_down_rounded,
                      color: _H.textMuted, size: 20),
                ),
              ]),
            ),

            AnimatedCrossFade(
              firstChild: const SizedBox(width: double.infinity),
              secondChild: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _H.bgDeep,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.25)),
                  ),
                  child: Text(widget.rule.desc,
                      style: const TextStyle(color: _H.textSub, fontSize: 13,
                          height: 1.6)),
                ),
              ),
              crossFadeState: _expanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 250),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Ping Bar ─────────────────────────────────────────────────────────────────
class _PingBar extends StatelessWidget {
  final int ms;
  final Color color;
  const _PingBar({required this.ms, required this.color});

  @override
  Widget build(BuildContext context) {
    final pct = (ms / 1000).clamp(0.0, 1.0);
    return Row(children: [
      const Text('LATENCY', style: TextStyle(color: _H.textMuted, fontSize: 9,
          fontWeight: FontWeight.w800, letterSpacing: 1)),
      const SizedBox(width: 8),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: Stack(children: [
            Container(height: 4, color: _H.border),
            AnimatedContainer(
              duration: const Duration(milliseconds: 500),
              height: 4,
              width: (MediaQuery.of(context).size.width - 80) * pct,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.6)],
                ),
                borderRadius: BorderRadius.circular(3),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.6), blurRadius: 8, spreadRadius: 1),
                ],
              ),
            ),
          ]),
        ),
      ),
      const SizedBox(width: 8),
      Text('${ms}ms', style: TextStyle(color: color, fontSize: 10,
          fontWeight: FontWeight.w800)),
    ]);
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 80).clamp(0, 500)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 16 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Dots Loader ──────────────────────────────────────────────────────────────
class _DotsLoader extends StatefulWidget {
  const _DotsLoader();

  @override
  State<_DotsLoader> createState() => _DotsLoaderState();
}

class _DotsLoaderState extends State<_DotsLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0);
          final s = math.sin(t * math.pi);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Transform.scale(
              scale: 0.4 + s * 0.6,
              child: Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _H.bloodBright.withOpacity(0.4 + s * 0.6),
                    _H.bloodDark.withOpacity(0.3),
                  ]),
                  boxShadow: [
                    BoxShadow(color: _H.bloodBright.withOpacity(0.5 + s * 0.4),
                        blurRadius: 10, spreadRadius: 1),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Animated Background (Hell) ───────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController auroraCtrl;
  final AnimationController emberCtrl;
  const _AnimatedBg({required this.auroraCtrl, required this.emberCtrl});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([auroraCtrl, emberCtrl]),
      builder: (_, __) => CustomPaint(
        painter: _BgPainter(auroraCtrl.value, emberCtrl.value),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  final double emberT;
  _BgPainter(this.t, this.emberT);

  @override
  void paint(Canvas canvas, Size size) {
    final a  = t * 2 * math.pi;
    final cx = size.width / 2;

    // ═══ 1. BACKGROUND NERAKA ═══
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..shader = const LinearGradient(
        colors: [
          Color(0xFF000000),
          Color(0xFF0A0000),
          Color(0xFF1A0000),
          Color(0xFF0A0000),
          Color(0xFF000000),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    // ═══ 2. BLOB API BERGERAK ═══
    void fireBlob(double ox, double oy, double r, Color c, double opacity) {
      canvas.drawCircle(Offset(ox, oy), r,
        Paint()..shader = RadialGradient(
          colors: [
            c.withOpacity(opacity),
            c.withOpacity(opacity * 0.35),
            Colors.transparent,
          ],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Rect.fromCircle(center: Offset(ox, oy), radius: r)));
    }

    fireBlob(
      cx + math.cos(a) * 60,
      size.height * 0.28 + math.sin(a) * 32,
      270,
      _H.bloodBright,
      0.11 + 0.04 * math.sin(a * 2),
    );

    fireBlob(
      cx - math.cos(a * 0.8) * 70,
      size.height * 0.78,
      230,
      _H.ember,
      0.09,
    );

    fireBlob(
      cx + math.sin(a * 1.3) * 110,
      size.height * 0.52 + math.cos(a * 0.9) * 45,
      160,
      _H.violet,
      0.07,
    );

    // ═══ 3. BARA API NAIK ═══
    final rng = math.Random(42);
    for (int i = 0; i < 26; i++) {
      final baseX = rng.nextDouble() * size.width;
      final baseY = rng.nextDouble() * size.height;
      final phase = (emberT + rng.nextDouble()) % 1.0;
      final ey    = (baseY - phase * size.height * 1.2) % size.height;
      final ex    = baseX + math.sin(phase * 6.28 + i) * 18;
      final er    = 1.5 + rng.nextDouble() * 2.5;
      final eOp   = (1.0 - phase) * 0.85;

      final c = i % 3 == 0
          ? _H.ember
          : (i % 3 == 1 ? _H.flame : _H.bloodBright);

      canvas.drawCircle(
        Offset(ex, ey), er,
        Paint()
          ..color = c.withOpacity(eOp)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }

    // ═══ 4. GRID ABU ═══
    final grid = Paint()
      ..color = _H.blood.withOpacity(0.04)
      ..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // ═══ 5. VIGNETTE NERAKA ═══
    final vignette = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          Colors.transparent,
          Colors.black.withOpacity(0.75),
          Colors.black.withOpacity(0.95),
        ],
        stops: const [0.0, 0.55, 0.85, 1.0],
        radius: 0.85,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignette);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t || old.emberT != emberT;
}