// ═══════════════════════════════════════════════════════════════════════════
//  THANKS TO PAGE — HELL ELEGANCE BRUTAL (ppp.jpg + disko + spider + glitch)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';

// ═══════════════════════════════════════════════════════════════════════════
// CONFIG DATA
// ═══════════════════════════════════════════════════════════════════════════
final List<Map<String, String>> thanksToList = [
  {
    "name": "🦠⃟ᴠͥɪͣᴘͫ CRIMINAL",
    "role": "Developer",
    "photo": "https://files.catbox.moe/k2ksno.png",
    "telegram": "XakatalZueu",
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _E {
  static const bg         = Color(0xFF020004);
  static const bgDeep     = Color(0xFF050108);
  static const surface    = Color(0xFF0A0310);
  static const surfaceAlt = Color(0xFF100418);
  static const card       = Color(0xFF080210);

  static const crimson    = Color(0xFF8B1526);
  static const crimsonUp  = Color(0xFFC41E3A);
  static const maroon     = Color(0xFF4A0A14);
  static const burgundy   = Color(0xFF2A0510);

  static const gold       = Color(0xFFB8860B);
  static const goldBright = Color(0xFFE5B94D);
  static const goldGlow   = Color(0xFFF4D03F);

  static const neonRed    = Color(0xFFFF2040);
  static const neonGold   = Color(0xFFFFD700);

  static const textPrimary = Color(0xFFF5EDE5);
  static const textSub     = Color(0xFFB8A090);
  static const textMuted   = Color(0xFF6B5650);

  static const border     = Color(0xFF2A1418);
  static const borderGlow = Color(0xFF3D1E24);

  static const danger  = Color(0xFFE5384A);
  static const success = Color(0xFF50C878);
  static const warning = Color(0xFFE09540);

  static const disco1  = Color(0xFFFF3366);
  static const disco2  = Color(0xFFFFAA00);
  static const disco3  = Color(0xFFFF00CC);
  static const disco4  = Color(0xFF00FFFF);
  static const disco5  = Color(0xFFAA00FF);
  static const disco6  = Color(0xFF00FF66);

  static Color discoColor(double p) {
    final colors = [disco1, disco2, disco3, disco4, disco5, disco6];
    final idx = (p * colors.length).floor() % colors.length;
    final nextIdx = (idx + 1) % colors.length;
    final t = (p * colors.length) % 1.0;
    return Color.lerp(colors[idx], colors[nextIdx], t) ?? colors[idx];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class ThanksToPage extends StatefulWidget {
  final String? role;
  final dynamic expiredDate;
  const ThanksToPage({super.key, this.role, this.expiredDate});

  @override
  State<ThanksToPage> createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage> with TickerProviderStateMixin {
  late AnimationController _entranceCtrl;
  late AnimationController _bgCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _discoCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _webCtrl;
  late AnimationController _glitchCtrl;
  late AnimationController _floatCtrl;

  late Animation<double> _fade, _scan, _disco, _pulse, _glitch, _float;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _bgCtrl       = AnimationController(vsync: this, duration: const Duration(seconds: 30))..repeat();
    _scanCtrl     = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
    _discoCtrl    = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _pulseCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _webCtrl      = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
    _glitchCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 3500))..repeat();
    _floatCtrl    = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);

    _fade   = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide  = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));
    _scan   = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _scanCtrl, curve: Curves.linear));
    _disco  = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _discoCtrl, curve: Curves.linear));
    _pulse  = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _glitch = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _glitchCtrl, curve: Curves.linear));
    _float  = Tween<double>(begin: -6.0, end: 6.0).animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    _bgCtrl.dispose();
    _scanCtrl.dispose();
    _discoCtrl.dispose();
    _pulseCtrl.dispose();
    _webCtrl.dispose();
    _glitchCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _E.bg,
      body: Stack(children: [
        // ═══ BACKGROUND ppp.jpg FULL ═══
        Positioned.fill(
          child: Image.asset(
            'assets/images/ppp.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_E.bg, _E.bgDeep, _E.surface],
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _E.bg.withOpacity(0.82),
                  _E.bgDeep.withOpacity(0.72),
                  _E.bg.withOpacity(0.92),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        // Holo overlay — radar + hex + glitch
        AnimatedBuilder(
          animation: Listenable.merge([_bgCtrl, _discoCtrl, _glitchCtrl]),
          builder: (_, __) => CustomPaint(
            painter: _HoloBgPainter(_bgCtrl.value, _disco.value, _glitch.value),
            child: const SizedBox.expand(),
          ),
        ),
        // Scan line
        AnimatedBuilder(
          animation: _scan,
          builder: (_, __) => Positioned(
            top: _scan.value * MediaQuery.of(context).size.height,
            left: 0, right: 0,
            child: Container(
              height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent, _E.gold.withOpacity(.15),
                  _E.crimsonUp.withOpacity(.35), _E.gold.withOpacity(.15),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
        ),
        // Vertical scan line
        AnimatedBuilder(
          animation: _scan,
          builder: (_, __) => Positioned(
            top: 0, bottom: 0,
            left: MediaQuery.of(context).size.width * (1 - _scan.value),
            child: Container(
              width: 1.5,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    _E.crimsonUp.withOpacity(.25),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ),
        // ═══ CONTENT ═══
        SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Column(children: [
                _buildAppBar(),
                const SizedBox(height: 14),
                _buildHeaderCard(),
                const SizedBox(height: 20),
                Expanded(child: _buildListView()),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // APPBAR
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildAppBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    child: AnimatedBuilder(
      animation: _discoCtrl,
      builder: (_, __) {
        final dc = _E.discoColor(_disco.value);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, bottomRight: true)),
            Row(children: [
              // Back button
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(
                      colors: [_E.crimsonUp, _E.maroon],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _E.goldBright.withOpacity(0.5)),
                    boxShadow: [BoxShadow(color: _E.crimson.withOpacity(0.5), blurRadius: 10)],
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: _E.goldBright, size: 16),
                ),
              ),
              const SizedBox(width: 12),
              // Title
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [_E.goldGlow, _E.crimsonUp],
                  ).createShader(b),
                  child: const Text('THANKS TO', style: TextStyle(
                    fontFamily: 'Ganang', fontSize: 18, fontWeight: FontWeight.w900,
                    color: Colors.white, letterSpacing: 2,
                    shadows: [Shadow(color: _E.neonGold, blurRadius: 12)])),
                ),
                Row(children: [
                  AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Container(
                      width: 5, height: 5,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: _E.success,
                        boxShadow: [BoxShadow(color: _E.success.withOpacity(0.5 + 0.4 * _pulse.value), blurRadius: 6)],
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Text('${thanksToList.length} MEMBERS', style: const TextStyle(
                    fontFamily: 'ShareTechMono', fontSize: 9,
                    color: _E.textSub, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
                ]),
              ])),
              // Star icon animated
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(colors: [
                      _E.goldBright.withOpacity(0.5 + 0.3 * _pulse.value),
                      _E.gold.withOpacity(0.2),
                    ]),
                    border: Border.all(color: _E.goldBright.withOpacity(0.7), width: 1.2),
                    boxShadow: [BoxShadow(color: _E.goldBright.withOpacity(0.5 * _pulse.value), blurRadius: 14)],
                  ),
                  child: const Icon(Icons.auto_awesome_rounded, color: _E.goldBright, size: 18),
                ),
              ),
            ]),
          ]),
        );
      },
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // HEADER CARD
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: AnimatedBuilder(
      animation: _discoCtrl,
      builder: (_, __) {
        final dc = _E.discoColor((_disco.value + 0.3) % 1.0);
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.2), dc.withOpacity(0.04)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.4), blurRadius: 24, spreadRadius: 2),
              BoxShadow(color: _E.goldBright.withOpacity(0.15), blurRadius: 40),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, bottomRight: true)),
            Row(children: [
              AnimatedBuilder(
                animation: _floatCtrl,
                builder: (_, child) => Transform.translate(
                  offset: Offset(0, _float.value),
                  child: child,
                ),
                child: Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [_E.crimsonUp, _E.crimson, _E.maroon],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _E.goldBright.withOpacity(0.6), width: 2),
                    boxShadow: [
                      BoxShadow(color: _E.crimson.withOpacity(0.6), blurRadius: 20, spreadRadius: 2),
                      BoxShadow(color: _E.goldBright.withOpacity(0.3), blurRadius: 32),
                    ],
                  ),
                  child: const Icon(Icons.people_alt_rounded, color: _E.goldBright, size: 24),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('SPECIAL APPRECIATION', style: TextStyle(
                  fontFamily: 'Ganang', fontSize: 12,
                  fontWeight: FontWeight.w900, color: _E.textPrimary,
                  letterSpacing: 1.5)),
                const SizedBox(height: 4),
                Text('Tap name to chat on Telegram', style: TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 9,
                  color: _E.textSub.withOpacity(0.9), letterSpacing: 0.5)),
              ])),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _E.goldBright.withOpacity(0.15),
                  border: Border.all(color: _E.goldBright.withOpacity(0.5)),
                  boxShadow: [BoxShadow(color: _E.goldBright.withOpacity(0.2), blurRadius: 10)],
                ),
                child: Text('${thanksToList.length} MEMBER', style: const TextStyle(
                  fontFamily: 'Orbitron', fontSize: 8,
                  color: _E.goldBright, fontWeight: FontWeight.w900,
                  letterSpacing: 1)),
              ),
            ]),
          ]),
        );
      },
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // LIST
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildListView() => ListView.builder(
    physics: const BouncingScrollPhysics(),
    padding: const EdgeInsets.symmetric(horizontal: 14),
    itemCount: thanksToList.length,
    itemBuilder: (context, index) {
      final person = thanksToList[index];
      return TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 500 + (index * 100)),
        curve: Curves.easeOutCubic,
        builder: (_, v, child) => Opacity(
          opacity: v,
          child: Transform.translate(offset: Offset(0, 20 * (1 - v)), child: child),
        ),
        child: _buildBrutalCard(
          name: person['name']!,
          role: person['role']!,
          photo: person['photo']!,
          telegram: person['telegram']!,
          index: index,
        ),
      );
    },
  );

  // ══════════════════════════════════════════════════════════════════════════
  // BRUTAL CARD
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildBrutalCard({
    required String name,
    required String role,
    required String photo,
    required String telegram,
    required int index,
  }) {
    return AnimatedBuilder(
      animation: Listenable.merge([_discoCtrl, _webCtrl, _glitchCtrl]),
      builder: (context, _) {
        final dc = _E.discoColor((_disco.value + index * 0.15) % 1.0);

        return GestureDetector(
          onTap: () => _openTelegram(telegram),
          child: Container(
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.black.withOpacity(0.45),
              gradient: LinearGradient(
                colors: [dc.withOpacity(0.25), dc.withOpacity(0.05)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              border: Border.all(color: _E.goldBright.withOpacity(0.6), width: 1.5),
              boxShadow: [
                BoxShadow(color: dc.withOpacity(0.5), blurRadius: 24, spreadRadius: 2),
                BoxShadow(color: _E.goldBright.withOpacity(0.2), blurRadius: 40),
                BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 12, offset: const Offset(0, 6)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(children: [
                // ═══ SPIDER WEB BACKGROUND ═══
                Positioned.fill(
                  child: CustomPaint(
                    painter: _SpiderWebPainter(
                      progress: _webCtrl.value,
                      color: dc,
                      opacity: 0.25,
                    ),
                  ),
                ),
                // ═══ GLITCH LINES ═══
                Positioned.fill(
                  child: CustomPaint(
                    painter: _GlitchPainter(progress: _glitch.value, color: dc),
                  ),
                ),
                // ═══ CORNER BRACKETS ═══
                Positioned(top: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, topLeft: true)),
                Positioned(top: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, topRight: true)),
                Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, bottomLeft: true)),
                Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, bottomRight: true)),
                // ═══ CONTENT ═══
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    // Avatar dengan pulse glow
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) => Container(
                        width: 64, height: 64,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_E.crimsonUp, _E.crimson, _E.maroon],
                            begin: Alignment.topLeft, end: Alignment.bottomRight,
                          ),
                          border: Border.all(
                            color: _E.goldBright.withOpacity(0.6 + 0.3 * _pulse.value),
                            width: 2.5,
                          ),
                          boxShadow: [
                            BoxShadow(color: dc.withOpacity(0.6 * _pulse.value), blurRadius: 20, spreadRadius: 3),
                            BoxShadow(color: _E.goldBright.withOpacity(0.3 * _pulse.value), blurRadius: 32),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3),
                          child: ClipOval(
                            child: Image.network(
                              photo,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                decoration: const BoxDecoration(
                                  gradient: RadialGradient(colors: [_E.crimsonUp, _E.maroon]),
                                ),
                                child: const Icon(Icons.person_rounded,
                                    color: _E.goldBright, size: 30),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    // Name + Role
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Flexible(
                            child: Text(name,
                              style: const TextStyle(
                                fontFamily: 'Ganang', fontSize: 15,
                                fontWeight: FontWeight.w900, color: _E.textPrimary,
                                letterSpacing: 0.5,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(colors: [
                                _E.goldBright,
                                _E.gold.withOpacity(0.3),
                              ]),
                              boxShadow: [
                                BoxShadow(color: _E.goldBright.withOpacity(0.5), blurRadius: 8),
                              ],
                            ),
                            child: const Icon(Icons.verified_rounded,
                                color: _E.bg, size: 12),
                          ),
                        ]),
                        const SizedBox(height: 8),
                        // Role badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                              colors: [dc.withOpacity(0.3), dc.withOpacity(0.1)],
                            ),
                            border: Border.all(color: dc.withOpacity(0.6), width: 1),
                            boxShadow: [BoxShadow(color: dc.withOpacity(0.3), blurRadius: 10)],
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.star_rounded, color: _E.goldBright, size: 12),
                            const SizedBox(width: 4),
                            Text(role,
                              style: TextStyle(
                                fontFamily: 'Ganang', fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: _E.goldBright.withOpacity(0.95),
                                letterSpacing: 0.5)),
                          ]),
                        ),
                      ],
                    )),
                    const SizedBox(width: 10),
                    // Telegram button animated
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) => Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: LinearGradient(
                            colors: [dc, dc.withOpacity(0.6)],
                            begin: Alignment.topLeft, end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: _E.goldBright.withOpacity(0.6), width: 1.2),
                          boxShadow: [
                            BoxShadow(color: dc.withOpacity(0.5 + 0.3 * _pulse.value),
                                blurRadius: 16, spreadRadius: 2),
                          ],
                        ),
                        child: const Icon(Icons.telegram, color: Colors.white, size: 22),
                      ),
                    ),
                  ]),
                ),
              ]),
            ),
          ),
        );
      },
    );
  }

  Widget _corner(Color c, double size, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) {
    return SizedBox(
      width: size, height: size,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TELEGRAM OPENER
  // ══════════════════════════════════════════════════════════════════════════
  Future<void> _openTelegram(String username) async {
    String cleanUsername = username.replaceAll('@', '').trim();

    if (cleanUsername.isEmpty) {
      _showErrorSnackbar('Username Telegram kosong');
      return;
    }

    try {
      final tgUrl = Uri.parse('tg://resolve?domain=$cleanUsername');
      final launched = await launchUrl(tgUrl, mode: LaunchMode.externalApplication);
      if (launched) return;
    } catch (_) {}

    try {
      final tmeUrl = Uri.parse('https://t.me/$cleanUsername');
      final launched = await launchUrl(tmeUrl, mode: LaunchMode.externalApplication);
      if (launched) return;
    } catch (_) {}

    try {
      final telegramMeUrl = Uri.parse('https://telegram.me/$cleanUsername');
      await launchUrl(telegramMeUrl, mode: LaunchMode.externalApplication);
      return;
    } catch (_) {}

    _showErrorSnackbar('Gagal membuka @$cleanUsername');
  }

  void _showErrorSnackbar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.error_outline, color: _E.goldBright, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(message, style: const TextStyle(
            fontFamily: 'ShareTechMono', fontSize: 12, color: _E.textPrimary))),
        ]),
        backgroundColor: _E.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _E.danger.withOpacity(0.6), width: 1.2),
        ),
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SPIDER WEB PAINTER
// ═══════════════════════════════════════════════════════════════════════════
class _SpiderWebPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double opacity;
  _SpiderWebPainter({required this.progress, required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final center = Offset(cx, cy);

    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    const radialCount = 8;
    for (int i = 0; i < radialCount; i++) {
      final angle = (i / radialCount) * 2 * math.pi;
      final endX = cx + math.cos(angle) * size.width * 0.6;
      final endY = cy + math.sin(angle) * size.height * 0.8;
      canvas.drawLine(center, Offset(endX, endY), paint);
    }

    const ringCount = 4;
    for (int r = 1; r <= ringCount; r++) {
      final radius = (r / ringCount) * size.width * 0.45;
      final path = Path();

      for (int i = 0; i <= radialCount; i++) {
        final idx = i % radialCount;
        final angle = (idx / radialCount) * 2 * math.pi + (progress * 0.5);
        final nextAngle = ((idx + 1) % radialCount) / radialCount * 2 * math.pi + (progress * 0.5);
        final midAngle = (angle + nextAngle) / 2;
        final midRadius = radius * 0.85;

        final px = cx + math.cos(angle) * radius;
        final py = cy + math.sin(angle) * radius;

        if (i == 0) {
          path.moveTo(px, py);
        } else {
          final mx = cx + math.cos(midAngle) * midRadius;
          final my = cy + math.sin(midAngle) * midRadius;
          path.quadraticBezierTo(mx, my, px, py);
        }
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_SpiderWebPainter o) => o.progress != progress || o.color != color;
}

// ═══════════════════════════════════════════════════════════════════════════
// GLITCH PAINTER — garis horizontal acak untuk efek glitch
// ═══════════════════════════════════════════════════════════════════════════
class _GlitchPainter extends CustomPainter {
  final double progress;
  final Color color;
  _GlitchPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random((progress * 1000).floor());
    final linePaint = Paint()..strokeWidth = 1.2;

    for (int i = 0; i < 3; i++) {
      if (rng.nextDouble() > 0.6) {
        final y = rng.nextDouble() * size.height;
        final x1 = rng.nextDouble() * size.width;
        final w = rng.nextDouble() * size.width * 0.4;
        linePaint.color = (rng.nextBool() ? color : _E.goldBright).withOpacity(0.3);
        canvas.drawLine(Offset(x1, y), Offset(x1 + w, y), linePaint);
      }
    }
  }

  @override
  bool shouldRepaint(_GlitchPainter o) => o.progress != progress;
}

// ═══════════════════════════════════════════════════════════════════════════
// CORNER PAINTER
// ═══════════════════════════════════════════════════════════════════════════
class _CornerPainter extends CustomPainter {
  final Color color;
  final double width;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  _CornerPainter(this.color, this.width, {this.topLeft=false, this.topRight=false, this.bottomLeft=false, this.bottomRight=false});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 0.5;
    if (topLeft) {
      canvas.drawLine(Offset.zero, Offset(size.width*len, 0), p);
      canvas.drawLine(Offset.zero, Offset(0, size.height*len), p);
    }
    if (topRight) {
      canvas.drawLine(Offset(size.width, 0), Offset(size.width*(1-len), 0), p);
      canvas.drawLine(Offset(size.width, 0), Offset(size.width, size.height*len), p);
    }
    if (bottomLeft) {
      canvas.drawLine(Offset(0, size.height), Offset(size.width*len, size.height), p);
      canvas.drawLine(Offset(0, size.height), Offset(0, size.height*(1-len)), p);
    }
    if (bottomRight) {
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width*(1-len), size.height), p);
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height*(1-len)), p);
    }
  }

  @override
  bool shouldRepaint(_CornerPainter o) => o.color != color;
}

// ═══════════════════════════════════════════════════════════════════════════
// HOLO BG PAINTER — radar + hex + scan lines + glitch overlay
// ═══════════════════════════════════════════════════════════════════════════
class _HoloBgPainter extends CustomPainter {
  final double t;
  final double disco;
  final double glitch;
  _HoloBgPainter(this.t, this.disco, this.glitch);

  @override
  void paint(Canvas canvas, Size size) {
    final angle = t * 2 * math.pi;

    // Radar rings
    final cxRadar = size.width / 2;
    final cyRadar = size.height * 0.35;
    final radarPaint = Paint()
      ..color = _E.goldBright.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (double r = 60; r < size.width; r += 60) {
      canvas.drawCircle(Offset(cxRadar, cyRadar), r, radarPaint);
    }

    // Radar sweep
    final sweepPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          _E.crimsonUp.withOpacity(0.0),
          _E.crimsonUp.withOpacity(0.15),
          _E.crimsonUp.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
        transform: GradientRotation(angle),
      ).createShader(Rect.fromCircle(center: Offset(cxRadar, cyRadar), radius: 320));
    canvas.drawCircle(Offset(cxRadar, cyRadar), 320, sweepPaint);

    // Hex grid
    final hexPaint = Paint()
      ..color = _E.gold.withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6;

    const hexSize = 30.0;
    final hexH = hexSize * math.sqrt(3);
    for (double y = 0; y < size.height + hexH; y += hexH * 0.5) {
      for (double x = 0; x < size.width + hexSize * 2; x += hexSize * 1.5) {
        final offsetX = (y / (hexH * 0.5)).round().isEven ? 0.0 : hexSize * 0.75;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final a2 = math.pi / 180 * (60 * i - 30);
          final px = x + offsetX + hexSize * math.cos(a2);
          final py = y + hexSize * math.sin(a2);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, hexPaint);
      }
    }

    // Scan lines (CRT)
    final scanPaint = Paint()
      ..color = _E.crimson.withOpacity(0.03)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), scanPaint);
    }

    // Vignette
    final vignette = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          Colors.transparent,
          Colors.black.withOpacity(0.65),
          Colors.black.withOpacity(0.92),
        ],
        stops: const [0.0, 0.55, 0.85, 1.0],
        radius: 0.88,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignette);
  }

  @override
  bool shouldRepaint(_HoloBgPainter o) => o.t != t || o.disco != disco || o.glitch != glitch;
}