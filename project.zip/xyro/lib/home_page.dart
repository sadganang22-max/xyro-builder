// ═══════════════════════════════════════════════════════════════════════════
//  HOME PAGE — COMPACT STICKY (B/W/R + HOLD EXECUTE + ADD SENDER)
//  PART 1/2
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';

const _baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══ GLOBAL SENDER ACCESS ═══
bool _canGlobal(String r) {
  final l = r.toLowerCase();
  return l == 'owner' || l == 'vip' || l == 'pemula';
}

class HomePage extends StatefulWidget {
  final String username, password, sessionKey, role, expiredDate;
  final List<Map<String, dynamic>> listBug;
  final bool isActive;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    this.isActive = true,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  final _targetCtrl = TextEditingController();
  final _saveNameCtrl = TextEditingController();
  final _savePhoneCtrl = TextEditingController();
  final _addSenderCtrl = TextEditingController();

  String _selectedBugId = '';
  String _bugMode = 'number';
  bool _isSending = false;
  String? _responseMsg;

  String _senderMode = 'global';
  List<String> _privateSenders = [];
  int _globalCount = 0;
  String? _selectedSender;
  bool _loadingPrivate = false;
  bool _loadingGlobal = false;

  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  static const _holdDuration = Duration(milliseconds: 1500);
  late AnimationController _holdCtrl;
  bool _holding = false;

  List<Map<String, String>> _savedContacts = [];
  static const _prefsKey = 'xyro_saved_contacts_v1';

  List<Map<String, dynamic>> get _filteredBugs => widget.listBug
      .where((b) => (b['type']?.toString().toLowerCase() ?? '') == _bugMode)
      .toList();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _holdCtrl = AnimationController(vsync: this, duration: _holdDuration);
    _holdCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted) _onHoldComplete();
    });
    final f = _filteredBugs;
    if (f.isNotEmpty) _selectedBugId = f[0]['bug_id'] ?? '';
    if (widget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    }
    _loadSavedContacts();
    _loadPrivateSenders();
    if (_canGlobal(widget.role)) {
      _loadGlobalCount();
    } else {
      _senderMode = 'private';
    }
  }

  @override
  void didUpdateWidget(covariant HomePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !_videoReady && !_videoInitializing) {
      _initVideo();
    } else if (!widget.isActive && _vCtrl != null) {
      final c = _vCtrl;
      _vCtrl = null;
      _videoReady = false;
      if (c != null) {
        try { c.pause(); } catch (_) {}
        try { c.dispose(); } catch (_) {}
      }
    }
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (widget.isActive && !c.value.isPlaying) {
        c.setVolume(0).catchError((_) {});
        c.setLooping(true).catchError((_) {});
        c.play().catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _targetCtrl.dispose();
    _saveNameCtrl.dispose();
    _savePhoneCtrl.dispose();
    _addSenderCtrl.dispose();
    _holdCtrl.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  // ── SAVED CONTACTS ──
  Future<void> _loadSavedContacts() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_prefsKey);
    if (raw == null) return;
    try {
      final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
      if (mounted) {
        setState(() {
          _savedContacts = list
              .map((e) =>
                  e.map((k, v) => MapEntry(k.toString(), v.toString())))
              .toList();
        });
      }
    } catch (_) {}
  }

  Future<void> _persistContacts() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_prefsKey, jsonEncode(_savedContacts));
  }

  Future<void> _addContact(String name, String phone) async {
    final num = _formatPhone(phone);
    if (num == null) {
      _showAlert('NOMOR SALAH', 'Gunakan format: +62812xxxxxxxx');
      return;
    }
    setState(() {
      _savedContacts.add({
        'name': name.trim().isEmpty ? num : name.trim(),
        'phone': num,
      });
    });
    await _persistContacts();
    if (mounted) _snack('Kontak tersimpan');
  }

  Future<void> _removeContact(int i) async {
    setState(() => _savedContacts.removeAt(i));
    await _persistContacts();
    if (mounted) _snack('Kontak dihapus');
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(m, style: const TextStyle(color: Colors.white)),
      backgroundColor: Colors.black.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _C.red.withOpacity(0.5))),
    ));
  }

  // ── NETWORK ──
  Future<void> _loadPrivateSenders() async {
    setState(() => _loadingPrivate = true);
    try {
      final r = await http
          .get(Uri.parse('$_baseUrl/mySender?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['connections'] != null && mounted) {
        final list = List<Map<String, dynamic>>.from(d['connections']);
        setState(() {
          _privateSenders = list
              .map((e) =>
                  e['sessionName']?.toString() ??
                  e['id']?.toString() ??
                  'Unknown')
              .toList();
        });
      }
    } catch (_) {}
    finally { if (mounted) setState(() => _loadingPrivate = false); }
  }

  Future<void> _loadGlobalCount() async {
    if (!_canGlobal(widget.role)) return;
    setState(() => _loadingGlobal = true);
    try {
      final r = await http
          .get(Uri.parse('$_baseUrl/getActiveSenders?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['senders'] != null && mounted) {
        final list = List<String>.from(d['senders']);
        setState(() => _globalCount = list.length);
      }
    } catch (_) {}
    finally { if (mounted) setState(() => _loadingGlobal = false); }
  }

  Future<void> _addSenderFromHome(String number) async {
    final num = number.trim();
    if (num.isEmpty) {
      _showAlert('NOMOR KOSONG', 'Masukkan nomor WA dulu');
      return;
    }
    try {
      final res = await http.get(Uri.parse(
          '$_baseUrl/getPairing?key=${widget.sessionKey}&number=$num'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _showPairingCodeDialog(num, data['pairingCode'] ?? '-');
        } else {
          _showAlert('GAGAL',
              data['message'] ?? 'Tidak bisa generate pairing code');
        }
      } else {
        _showAlert('GAGAL', 'Server error ${res.statusCode}');
      }
    } catch (_) {
      _showAlert('GAGAL', 'Koneksi error');
    }
    _loadPrivateSenders();
  }

  void _showAddSenderDialog() {
    _addSenderCtrl.clear();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(children: [
                const Icon(Icons.person_add_alt_1_rounded,
                    color: _C.red, size: 22),
                const SizedBox(width: 10),
                const Text('TAMBAH SENDER',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1)),
              ]),
              const SizedBox(height: 8),
              const Text('Pairing nomor WA baru',
                  style: TextStyle(fontSize: 11, color: _C.muted)),
              const SizedBox(height: 16),
              TextField(
                controller: _addSenderCtrl,
                keyboardType: TextInputType.phone,
                style: const TextStyle(fontSize: 14, color: Colors.white),
                decoration: InputDecoration(
                  hintText: '628xxx',
                  hintStyle: const TextStyle(color: _C.muted, fontSize: 13),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _C.red, width: 1.5),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                    child: _SecondaryBtn(
                        label: 'BATAL',
                        onTap: () => Navigator.pop(ctx))),
                const SizedBox(width: 10),
                Expanded(
                  child: _PrimaryBtn(
                    label: 'CONNECT',
                    onTap: () {
                      final num = _addSenderCtrl.text.trim();
                      if (num.isEmpty) {
                        _snack('Masukkan nomor dulu');
                        return;
                      }
                      Navigator.pop(ctx);
                      _addSenderFromHome(num);
                    },
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: _C.red, width: 1.5),
              ),
              child: const Icon(Icons.phonelink_lock_rounded,
                  color: _C.red, size: 30),
            ),
            const SizedBox(height: 14),
            const Text('KODE PAIRING',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(height: 4),
            Text('Nomor: $number',
                style: const TextStyle(fontSize: 11, color: _C.muted)),
            const SizedBox(height: 18),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 18),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.red.withOpacity(0.6), width: 1.5),
              ),
              child: Text(code,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                      color: _C.red,
                      letterSpacing: 8)),
            ),
            const SizedBox(height: 18),
            _PrimaryBtn(
              label: 'SELESAI & REFRESH',
              onTap: () {
                Navigator.pop(ctx);
                _loadPrivateSenders();
              },
            ),
          ]),
        ),
      ),
    );
  }

  // ── HOLD EXECUTE ──
  void _onHoldDown() {
    if (_isSending) return;
    HapticFeedback.selectionClick();
    setState(() => _holding = true);
    _holdCtrl.forward(from: 0);
  }

  void _onHoldUp() {
    if (_isSending) return;
    if (_holdCtrl.value < 1.0) {
      _holdCtrl.stop();
      _holdCtrl.animateBack(0.0,
          duration: const Duration(milliseconds: 250));
      setState(() => _holding = false);
    }
  }

  void _onHoldComplete() {
    HapticFeedback.heavyImpact();
    setState(() => _holding = false);
    _sendBug();
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_bugMode == 'number' && _formatPhone(raw) == null) {
      _showAlert('NOMOR SALAH', 'Gunakan format: +62812xxxxxxxx');
      _resetHold();
      return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _showAlert('LINK SALAH', 'Link grup WA tidak valid.');
      _resetHold();
      return;
    }
    if (_selectedBugId.isEmpty) {
      _showAlert('BELUM PILIH', 'Pilih bug terlebih dahulu.');
      _resetHold();
      return;
    }
    if (_senderMode == 'private') {
      if (_privateSenders.isEmpty) {
        _showAlert('BELUM PAIRING', 'Pairing nomor dulu via tombol ADD.');
        _resetHold();
        return;
      }
      if (_selectedSender == null) {
        _showAlert('BELUM PILIH', 'Pilih nomor sender kamu dulu.');
        _resetHold();
        return;
      }
    } else if (_globalCount == 0) {
      _showAlert('GLOBAL KOSONG', 'Belum ada sender global aktif.');
      _resetHold();
      return;
    }

    setState(() => _isSending = true);
    HapticFeedback.mediumImpact();
    try {
      final enc = Uri.encodeComponent(raw);
      String url =
          '$_baseUrl/sendBug?key=${widget.sessionKey}&target=$enc&bug=$_selectedBugId';
      if (_senderMode == 'global') {
        url += '&senderMode=global';
      } else if (_selectedSender != null) {
        url += '&sender=${Uri.encodeComponent(_selectedSender!)}';
      }
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
      final d = jsonDecode(res.body);
      if (d['valid'] == false) {
        _setResp('error', 'Sesi habis. Login ulang.');
      } else if (d['cooldown'] == true) {
        _setResp('warning', 'Tunggu ${d['wait'] ?? 0} detik.');
      } else if (d['sended'] == true) {
        HapticFeedback.lightImpact();
        final t = _bugMode == 'group' ? 'TARGET GRUP' : raw;
        _targetCtrl.clear();
        setState(() => _responseMsg = null);
        if (mounted) _showSuccessDialog(t);
      } else {
        _setResp('error', d['message'] ?? 'Server maintenance.');
      }
    } catch (e) {
      _setResp('error',
          e.toString().contains('Timeout') ? 'Waktu habis!' : 'Koneksi error!');
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
        _resetHold();
      }
    }
  }

  void _resetHold() {
    _holdCtrl.value = 0;
    if (mounted) setState(() => _holding = false);
  }

  void _setResp(String t, String m) {
    if (!mounted) return;
    setState(() => _responseMsg = '$t|$m');
  }

  String? _formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool _validGroup(String s) =>
      s.startsWith('https://') && s.contains('chat.whatsapp.com');

  // ── DIALOGS ──
  void _showSuccessDialog(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: _C.red, width: 2),
              ),
              child: const Icon(Icons.check, color: _C.red, size: 40),
            ),
            const SizedBox(height: 18),
            const Text('TRANSMISSION SUCCESS',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Text(target,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: _C.muted)),
            const SizedBox(height: 22),
            _PrimaryBtn(label: 'CLOSE', onTap: () => Navigator.pop(ctx)),
          ]),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.warning_amber_rounded, color: _C.red, size: 44),
            const SizedBox(height: 16),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Colors.white)),
            const SizedBox(height: 8),
            Text(msg,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: _C.muted)),
            const SizedBox(height: 22),
            _PrimaryBtn(label: 'OK', onTap: () => Navigator.pop(ctx)),
          ]),
        ),
      ),
    );
  }

  void _showSaveContactDialog() {
    _saveNameCtrl.clear();
    _savePhoneCtrl.text = _targetCtrl.text.trim();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              const Icon(Icons.bookmark_add_rounded, color: _C.red, size: 22),
              const SizedBox(width: 10),
              const Text('SIMPAN KONTAK',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1)),
            ]),
            const SizedBox(height: 18),
            _glassInput(_saveNameCtrl, 'Nama (opsional)', Icons.person_outline),
            const SizedBox(height: 10),
            _glassInput(_savePhoneCtrl, '+62812xxxxxxxx', Icons.phone_android,
                keyboard: TextInputType.phone),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(
                  child: _SecondaryBtn(
                      label: 'BATAL', onTap: () => Navigator.pop(ctx))),
              const SizedBox(width: 10),
              Expanded(
                child: _PrimaryBtn(
                  label: 'SIMPAN',
                  onTap: () async {
                    await _addContact(_saveNameCtrl.text, _savePhoneCtrl.text);
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _glassInput(TextEditingController c, String hint, IconData icon,
      {TextInputType? keyboard}) {
    return TextField(
      controller: c,
      keyboardType: keyboard,
      style: const TextStyle(fontSize: 14, color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: _C.muted, fontSize: 13),
        prefixIcon: Icon(icon, color: _C.muted, size: 18),
        filled: true,
        fillColor: Colors.white.withOpacity(0.05),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _C.red, width: 1.5),
        ),
      ),
    );
  }
    // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          bottom: false,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 140),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeader(),
                const SizedBox(height: 14),
                _buildBanner(),
                const SizedBox(height: 16),
                _buildBigControlCard(),
                const SizedBox(height: 14),
                _buildHoldExecuteButton(),
                if (_responseMsg != null) ...[
                  const SizedBox(height: 12),
                  _buildResultBanner(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ HEADER — TARGET ATTACK ═══
  Widget _buildHeader() {
    return _GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: _C.red.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.red.withOpacity(0.5)),
          ),
          child: const Icon(Icons.bolt_rounded, color: _C.red, size: 22),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('TARGET ATTACK',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              SizedBox(height: 2),
              Text('Kirim bug ke target',
                  style: TextStyle(fontSize: 10, color: _C.muted)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: _C.red,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(widget.role.toUpperCase(),
              style: const TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1)),
        ),
      ]),
    );
  }

  // ═══ BANNER — 140px clean ═══
  Widget _buildBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 140,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Stack(fit: StackFit.expand, children: [
          Image.asset(
            'assets/images/banner.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A0000), Color(0xFF000000)],
                ),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.1),
                  Colors.black.withOpacity(0.85),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.red,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('LIVE FEED',
                      style: TextStyle(
                          fontSize: 9,
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5)),
                ),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('XYRO',
                        style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 3,
                            height: 0.9)),
                    SizedBox(height: 3),
                    Text('[ V2090 // VIRTUAL RAT ]',
                        style: TextStyle(
                            fontSize: 9,
                            color: _C.muted,
                            letterSpacing: 2)),
                  ],
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  // ═══ BIG CONTROL CARD — SEMUA DALAM 1 ═══
  Widget _buildBigControlCard() {
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── MODE ──
          const Text('MODE',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: _C.muted,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: _modeBtn(Icons.smartphone, 'NUMBER',
                  _bugMode == 'number', () {
                setState(() {
                  _bugMode = 'number';
                  final f = _filteredBugs;
                  _selectedBugId = f.isNotEmpty ? (f[0]['bug_id'] ?? '') : '';
                });
              }),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _modeBtn(Icons.group, 'GROUP', _bugMode == 'group', () {
                setState(() {
                  _bugMode = 'group';
                  final f = _filteredBugs;
                  _selectedBugId = f.isNotEmpty ? (f[0]['bug_id'] ?? '') : '';
                });
              }),
            ),
          ]),

          const SizedBox(height: 14),
          _divider(),

          // ── TARGET ──
          const SizedBox(height: 14),
          const Text('TARGET',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: _C.muted,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _targetCtrl,
                style: const TextStyle(
                    fontSize: 14, color: Colors.white, letterSpacing: 0.5),
                keyboardType: _bugMode == 'number'
                    ? TextInputType.phone
                    : TextInputType.url,
                decoration: InputDecoration(
                  hintText: _bugMode == 'number'
                      ? '+62812xxxxxxxx'
                      : 'https://chat.whatsapp.com/...',
                  hintStyle: const TextStyle(color: _C.muted, fontSize: 12),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: _C.red, width: 1.5),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _showSaveContactDialog,
              child: Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.bookmark_add_rounded,
                    color: _C.red, size: 20),
              ),
            ),
          ]),

          // Saved contacts chips (compact, kalau ada)
          if (_savedContacts.isNotEmpty) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 38,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _savedContacts.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (_, i) {
                  final c = _savedContacts[i];
                  return GestureDetector(
                    onTap: () {
                      _targetCtrl.text = c['phone'] ?? '';
                      HapticFeedback.selectionClick();
                    },
                    onLongPress: () => _removeContact(i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(20),
                        border:
                            Border.all(color: Colors.white.withOpacity(0.12)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.person_rounded,
                            size: 12, color: _C.red),
                        const SizedBox(width: 4),
                        Text(c['name'] ?? '-',
                            style: const TextStyle(
                                fontSize: 11,
                                color: Colors.white,
                                fontWeight: FontWeight.w700)),
                      ]),
                    ),
                  );
                },
              ),
            ),
          ],

          const SizedBox(height: 14),
          _divider(),

          // ── PAYLOAD ──
          const SizedBox(height: 14),
          const Text('PAYLOAD',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: _C.muted,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          _buildPayloadDropdown(),

          const SizedBox(height: 14),
          _divider(),

          // ── SENDER ──
          const SizedBox(height: 14),
          const Text('SENDER',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: _C.muted,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          _buildSenderSection(),
        ],
      ),
    );
  }

  Widget _divider() => Container(height: 1, color: Colors.white.withOpacity(0.06));

  // ═══ MODE BTN ═══
  Widget _modeBtn(IconData i, String l, bool a, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: a ? _C.red.withOpacity(0.18) : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: a ? _C.red : Colors.white.withOpacity(0.1),
              width: a ? 1.5 : 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(i, color: a ? _C.red : _C.muted, size: 16),
            const SizedBox(width: 6),
            Text(l,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: a ? _C.red : _C.muted,
                    letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  // ═══ PAYLOAD DROPDOWN ═══
  Widget _buildPayloadDropdown() {
    final bugs = _filteredBugs;
    if (bugs.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Center(
          child: Text('NO ${_bugMode.toUpperCase()} DATA',
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  color: _C.red,
                  letterSpacing: 1)),
        ),
      );
    }

    final validIds = bugs.map((b) => b['bug_id']?.toString() ?? '').toList();
    if (!validIds.contains(_selectedBugId)) {
      _selectedBugId = validIds.first;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedBugId,
          isExpanded: true,
          dropdownColor: const Color(0xFF0A0A0A),
          icon: const Icon(Icons.keyboard_arrow_down_rounded,
              color: _C.red, size: 22),
          style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 0.5),
          hint: const Text('PILIH PAYLOAD',
              style: TextStyle(color: _C.muted, fontSize: 12)),
          items: bugs.map((b) {
            final id = b['bug_id']?.toString() ?? '';
            final name = (b['bug_name'] ?? 'Bug').toString();
            return DropdownMenuItem<String>(
              value: id,
              child: Row(children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                      color: _C.red, shape: BoxShape.circle),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(name.toUpperCase(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0.5)),
                ),
              ]),
            );
          }).toList(),
          onChanged: (v) {
            if (v == null) return;
            HapticFeedback.selectionClick();
            setState(() => _selectedBugId = v);
          },
        ),
      ),
    );
  }

  // ═══ SENDER SECTION ═══
  Widget _buildSenderSection() {
    if (!_canGlobal(widget.role)) return _buildPrivateSenderList();
    return Column(children: [
      _buildSenderModeToggle(),
      const SizedBox(height: 10),
      _senderMode == 'global'
          ? _buildGlobalSenderCard()
          : _buildPrivateSenderList(),
    ]);
  }

  Widget _buildSenderModeToggle() => Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(children: [
          Expanded(child: _senderModeBtn('GLOBAL', Icons.public)),
          const SizedBox(width: 3),
          Expanded(child: _senderModeBtn('PRIVATE', Icons.person)),
        ]),
      );

  Widget _senderModeBtn(String label, IconData icon) {
    final active = _senderMode == label.toLowerCase();
    return GestureDetector(
      onTap: () => setState(() {
        _senderMode = label.toLowerCase();
        _selectedSender = null;
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: active ? _C.red.withOpacity(0.18) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: active ? _C.red : _C.muted, size: 14),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: active ? _C.red : _C.muted,
                    letterSpacing: 1.2)),
          ],
        ),
      ),
    );
  }

  // ═══ GLOBAL SENDER ═══
  Widget _buildGlobalSenderCard() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _C.red.withOpacity(0.4), width: 1),
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.red.withOpacity(0.5)),
            ),
            child: const Icon(Icons.shuffle, color: _C.red, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('AUTO RANDOM',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1)),
                const SizedBox(height: 2),
                Text(_globalCount == 0
                        ? 'No active nodes'
                        : '$_globalCount nodes ready',
                    style: const TextStyle(
                        fontSize: 10, color: _C.muted)),
              ],
            ),
          ),
          GestureDetector(
            onTap: _loadGlobalCount,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(8),
              ),
              child: _loadingGlobal
                  ? const SizedBox(
                      width: 12,
                      height: 12,
                      child: CircularProgressIndicator(
                          color: _C.red, strokeWidth: 2))
                  : const Icon(Icons.refresh, color: _C.red, size: 14),
            ),
          ),
        ]),
      );

  // ═══ PRIVATE SENDER LIST ═══
  Widget _buildPrivateSenderList() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('SENDER KAMU',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1)),
                Row(children: [
                  GestureDetector(
                    onTap: _showAddSenderDialog,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.red,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Row(children: [
                        Icon(Icons.add, color: Colors.black, size: 12),
                        SizedBox(width: 3),
                        Text('ADD',
                            style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                color: Colors.black,
                                letterSpacing: 1)),
                      ]),
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: _loadPrivateSenders,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: _loadingPrivate
                          ? const SizedBox(
                              width: 10,
                              height: 10,
                              child: CircularProgressIndicator(
                                  color: _C.red, strokeWidth: 1.5))
                          : const Icon(Icons.refresh,
                              color: _C.red, size: 12),
                    ),
                  ),
                ]),
              ],
            ),
            const SizedBox(height: 10),
            if (_privateSenders.isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: Text('BELUM ADA SENDER - TAP ADD',
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: _C.muted,
                          letterSpacing: 1)),
                ),
              )
            else
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 150),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: _privateSenders.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (_, i) {
                    final nomor = _privateSenders[i];
                    final isSelected = _selectedSender == nomor;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedSender = nomor),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 9, horizontal: 10),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? _C.red.withOpacity(0.12)
                              : Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: isSelected
                                  ? _C.red
                                  : Colors.white.withOpacity(0.1),
                              width: isSelected ? 1.5 : 1),
                        ),
                        child: Row(children: [
                          Icon(Icons.circle,
                              color: isSelected ? _C.red : _C.muted,
                              size: 8),
                          const SizedBox(width: 10),
                          Expanded(
                              child: Text(nomor,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: isSelected
                                          ? _C.red
                                          : Colors.white))),
                          if (isSelected)
                            const Text('ACTIVE',
                                style: TextStyle(
                                    fontSize: 8,
                                    color: _C.red,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1)),
                        ]),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      );

  // ═══ HOLD EXECUTE ═══
  Widget _buildHoldExecuteButton() {
    return AnimatedBuilder(
      animation: _holdCtrl,
      builder: (_, __) {
        final p = _holdCtrl.value;
        final done = _isSending;
        final accent = _isSending ? _C.muted : _C.red;

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => _onHoldDown(),
          onTapUp: (_) => _onHoldUp(),
          onTapCancel: _onHoldUp,
          onLongPressStart: (_) => _onHoldDown(),
          onLongPressEnd: (_) => _onHoldUp(),
          child: Container(
            height: 80,
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.05 + p * 0.15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: accent.withOpacity(0.4 + p * 0.6), width: 2),
              boxShadow: [
                BoxShadow(
                  color: _C.red.withOpacity(0.15 + p * 0.35),
                  blurRadius: 10 + p * 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: p,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: LinearGradient(
                          colors: [
                            _C.red.withOpacity(0.35),
                            _C.red.withOpacity(0.15),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        done ? Icons.hourglass_top_rounded : Icons.bolt,
                        color: done ? _C.muted : _C.red,
                        size: 30,
                      ),
                      const SizedBox(width: 12),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            done
                                ? 'TRANSMITTING...'
                                : (_holding
                                    ? 'ARMING... ${(p * 100).toInt()}%'
                                    : 'HOLD TO EXECUTE'),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: done ? _C.muted : _C.red,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            done
                                ? 'MOHON TUNGGU'
                                : (_holding
                                    ? 'TAHAN SAMPAI SELESAI'
                                    : 'TAHAN 1.5 DETIK UNTUK KIRIM'),
                            style: const TextStyle(
                              fontSize: 9,
                              color: _C.muted,
                              letterSpacing: 1.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: 3,
                    color: Colors.white.withOpacity(0.05),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: p,
                      child: Container(color: _C.red),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══ RESULT BANNER ═══
  Widget _buildResultBanner() {
    final parts = _responseMsg!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';
    final color = type == 'error' ? _C.red : _C.text;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Row(children: [
        Icon(
            type == 'success' ? Icons.check_circle : Icons.error,
            color: color,
            size: 18),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: color))),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// WIDGET PENDUKUNG
// ═══════════════════════════════════════════════════════════════════════════

class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

class _SecondaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _SecondaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}