// ═══════════════════════════════════════════════════════════════════════════
//  CHANGE PASSWORD PAGE — HELL ELEGANCE BRUTAL
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';

const String baseUrl = "http://www.rexylegal.rxpedia.web.id:2060";

// ═══════════════════════════════════════════════════════════════════════════
// PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _E {
  static const bg         = Color(0xFF020004);
  static const bgDeep     = Color(0xFF050108);
  static const surface    = Color(0xFF0A0310);
  static const surfaceAlt = Color(0xFF100418);
  static const card       = Color(0xFF080210);

  static const crimson    = Color(0xFF8B1526);
  static const crimsonUp  = Color(0xFFC41E3A);
  static const maroon     = Color(0xFF4A0A14);
  static const burgundy   = Color(0xFF2A0510);

  static const gold       = Color(0xFFB8860B);
  static const goldBright = Color(0xFFE5B94D);
  static const goldGlow   = Color(0xFFF4D03F);

  static const neonGold   = Color(0xFFFFD700);

  static const textPrimary = Color(0xFFF5EDE5);
  static const textSub     = Color(0xFFB8A090);
  static const textMuted   = Color(0xFF6B5650);

  static const border     = Color(0xFF2A1418);
  static const borderGlow = Color(0xFF3D1E24);

  static const danger  = Color(0xFFE5384A);
  static const success = Color(0xFF50C878);
  static const warning = Color(0xFFE09540);

  static const cyan         = crimsonUp;
  static const cyanDim      = crimson;
  static const electric     = goldBright;
  static const violet       = maroon;
  static const violetBright = crimsonUp;
  static const violetGlow   = goldBright;
  static const azure        = goldBright;
  static const cyanGrad     = LinearGradient(colors: [crimsonUp, maroon]);

  static const disco1  = Color(0xFFFF3366);
  static const disco2  = Color(0xFFFFAA00);
  static const disco3  = Color(0xFFFF00CC);
  static const disco4  = Color(0xFF00FFFF);
  static const disco5  = Color(0xFFAA00FF);
  static const disco6  = Color(0xFF00FF66);

  static Color discoColor(double p) {
    final colors = [disco1, disco2, disco3, disco4, disco5, disco6];
    final idx = (p * colors.length).floor() % colors.length;
    final nextIdx = (idx + 1) % colors.length;
    final t = (p * colors.length) % 1.0;
    return Color.lerp(colors[idx], colors[nextIdx], t) ?? colors[idx];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage>
    with TickerProviderStateMixin {
  final oldPassCtrl     = TextEditingController();
  final newPassCtrl     = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading       = false;
  bool _obscureOld     = true;
  bool _obscureNew     = true;
  bool _obscureConfirm = true;

  double _strength = 0;
  String _strengthLabel = '';
  Color  _strengthColor = _E.textMuted;

  // Animations
  late AnimationController _bgCtrl, _scanCtrl, _discoCtrl, _glitchCtrl, _webCtrl, _holoCtrl;
  late AnimationController _entranceCtrl, _iconCtrl, _pulseCtrl, _shakeCtrl;
  late Animation<double> _scan, _disco, _glitch, _holo, _pulse;
  late Animation<double> _iconRotate, _iconScale, _formFade, _shake;
  late Animation<Offset> _formSlide;

  final _oldFocus     = FocusNode();
  final _newFocus     = FocusNode();
  final _confirmFocus = FocusNode();

  @override
  void initState() {
    super.initState();

    _bgCtrl    = AnimationController(vsync:this, duration:const Duration(seconds:30))..repeat();
    _scanCtrl  = AnimationController(vsync:this, duration:const Duration(seconds:6))..repeat();
    _discoCtrl = AnimationController(vsync:this, duration:const Duration(seconds:10))..repeat();
    _glitchCtrl= AnimationController(vsync:this, duration:const Duration(milliseconds:3500))..repeat();
    _webCtrl   = AnimationController(vsync:this, duration:const Duration(seconds:8))..repeat();
    _holoCtrl  = AnimationController(vsync:this, duration:const Duration(seconds:3))..repeat(reverse:true);
    _pulseCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:1800))..repeat(reverse:true);

    _scan   = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_scanCtrl, curve:Curves.linear));
    _disco  = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_discoCtrl, curve:Curves.linear));
    _glitch = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_glitchCtrl, curve:Curves.linear));
    _holo   = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_holoCtrl, curve:Curves.easeInOut));
    _pulse  = Tween<double>(begin:0.5, end:1.0).animate(CurvedAnimation(parent:_pulseCtrl, curve:Curves.easeInOut));

    _entranceCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:900));
    _formSlide = Tween<Offset>(begin:const Offset(0,0.06), end:Offset.zero)
        .animate(CurvedAnimation(parent:_entranceCtrl, curve:Curves.easeOutCubic));
    _formFade = CurvedAnimation(parent:_entranceCtrl, curve:Curves.easeOut);

    _iconCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:1200));
    _iconRotate = Tween<double>(begin:-0.15, end:0.0)
        .animate(CurvedAnimation(parent:_iconCtrl, curve:Curves.elasticOut));
    _iconScale = Tween<double>(begin:0.4, end:1.0)
        .animate(CurvedAnimation(parent:_iconCtrl, curve:Curves.easeOutBack));

    _shakeCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin:0.0, end:-10.0), weight:1),
      TweenSequenceItem(tween: Tween(begin:-10.0, end:10.0), weight:2),
      TweenSequenceItem(tween: Tween(begin:10.0, end:-8.0), weight:2),
      TweenSequenceItem(tween: Tween(begin:-8.0, end:8.0), weight:2),
      TweenSequenceItem(tween: Tween(begin:8.0, end:0.0), weight:1),
    ]).animate(CurvedAnimation(parent:_shakeCtrl, curve:Curves.easeInOut));

    _entranceCtrl.forward();
    _iconCtrl.forward();

    newPassCtrl.addListener(_evalStrength);
  }

  @override
  void dispose() {
    _bgCtrl.dispose(); _scanCtrl.dispose(); _discoCtrl.dispose();
    _glitchCtrl.dispose(); _webCtrl.dispose(); _holoCtrl.dispose();
    _pulseCtrl.dispose();
    _entranceCtrl.dispose(); _iconCtrl.dispose(); _shakeCtrl.dispose();
    oldPassCtrl.dispose(); newPassCtrl.dispose(); confirmPassCtrl.dispose();
    _oldFocus.dispose(); _newFocus.dispose(); _confirmFocus.dispose();
    super.dispose();
  }

  void _evalStrength() {
    final p = newPassCtrl.text;
    double s = 0;
    if (p.length >= 8)  s += 0.25;
    if (p.length >= 12) s += 0.15;
    if (RegExp(r'[A-Z]').hasMatch(p)) s += 0.2;
    if (RegExp(r'[0-9]').hasMatch(p)) s += 0.2;
    if (RegExp(r'[!@#\$%^&*]').hasMatch(p)) s += 0.2;

    String label;
    Color color;
    if (p.isEmpty)    { s = 0; label = '';        color = _E.textMuted; }
    else if (s < 0.4) {        label = 'LEMAH';   color = _E.danger; }
    else if (s < 0.7) {        label = 'SEDANG';  color = _E.warning; }
    else              {        label = 'KUAT';    color = _E.success; }

    setState(() {
      _strength      = s;
      _strengthLabel = label;
      _strengthColor = color;
    });
  }

  Future<void> _changePassword() async {
    final oldPass     = oldPassCtrl.text.trim();
    final newPass     = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _shakeCtrl.forward(from:0);
      _showResult('Semua field harus diisi.', success: false);
      return;
    }
    if (newPass != confirmPass) {
      _shakeCtrl.forward(from:0);
      _showResult('Password baru tidak cocok dengan konfirmasi.', success: false);
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.post(
        Uri.parse("http://www.rexylegal.rxpedia.web.id:2060/changepass"),
        body: {
          "username":   widget.username,
          "oldPass":    oldPass,
          "newPass":    newPass,
          "sessionKey": widget.sessionKey,
        },
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showResult('Password berhasil diubah!', success: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _shakeCtrl.forward(from:0);
        _showResult(data['message'] ?? 'Gagal mengubah password', success: false);
      }
    } catch (e) {
      _shakeCtrl.forward(from:0);
      _showResult('Koneksi error.', success: false);
    }
    setState(() => isLoading = false);
  }

  void _showResult(String msg, {required bool success}) {
    final color = success ? _E.success : _E.danger;
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.92),
      transitionDuration: const Duration(milliseconds:340),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: _HoloFrame(
          color: color,
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    color.withOpacity(0.7),
                    color.withOpacity(0.2),
                  ]),
                  border: Border.all(color: color.withOpacity(0.6), width: 1.5),
                  boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 20)],
                ),
                child: Icon(
                  success ? Icons.check_rounded : Icons.close_rounded,
                  color: color, size: 28,
                ),
              ),
              const SizedBox(height: 16),
              ShaderMask(
                shaderCallback: (b) => LinearGradient(
                  colors: [color, _E.goldBright],
                ).createShader(b),
                child: Text(
                  success ? 'BERHASIL' : 'GAGAL',
                  style: const TextStyle(
                    fontFamily: 'Ganang', color: Colors.white,
                    fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 2),
                ),
              ),
              const SizedBox(height: 10),
              Text(msg, textAlign: TextAlign.center, style: const TextStyle(
                fontFamily: 'ShareTechMono',
                color: _E.textSub, fontSize: 12, height: 1.5)),
              const SizedBox(height: 22),
              _GradBtn(label: 'OK', fullWidth: true, onTap: () => Navigator.pop(ctx)),
            ]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _E.bg,
      body: Stack(children: [
        // ppp.jpg background
        Positioned.fill(
          child: Image.asset(
            'assets/images/ppp.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: _E.bg),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _E.bg.withOpacity(0.85),
                  _E.bgDeep.withOpacity(0.75),
                  _E.bg.withOpacity(0.92),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        // Holo overlay
        AnimatedBuilder(
          animation: Listenable.merge([_bgCtrl, _discoCtrl, _glitchCtrl]),
          builder: (_, __) => CustomPaint(
            painter: _HoloBgPainter(_bgCtrl.value, _disco.value, _glitch.value),
            child: const SizedBox.expand(),
          ),
        ),
        // Scan line
        AnimatedBuilder(animation:_scan, builder:(_,__)=>Positioned(
          top: _scan.value * MediaQuery.of(context).size.height,
          left:0, right:0,
          child: Container(
            height:1.5,
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[
                Colors.transparent, _E.gold.withOpacity(.12),
                _E.crimsonUp.withOpacity(.3), _E.gold.withOpacity(.12),
                Colors.transparent,
              ]),
            ),
          ),
        )),
        // Content
        SafeArea(
          child: Column(children: [
            _buildAppBar(),
            Expanded(
              child: FadeTransition(
                opacity: _formFade,
                child: SlideTransition(
                  position: _formSlide,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(14, 8, 14, 40),
                    child: Column(children: [
                      const SizedBox(height: 12),
                      _buildHeroIcon(),
                      const SizedBox(height: 24),
                      _buildInfoCard(),
                      const SizedBox(height: 20),
                      AnimatedBuilder(
                        animation: _shake,
                        builder: (_, child) => Transform.translate(
                          offset: Offset(_shake.value, 0),
                          child: child,
                        ),
                        child: _buildForm(),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildAppBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    child: AnimatedBuilder(
      animation: _discoCtrl,
      builder: (_, __) {
        final dc = _E.discoColor(_disco.value);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright, 12, 1.5, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright, 12, 1.5, bottomRight: true)),
            Row(children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(
                      colors: [_E.crimsonUp, _E.maroon],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _E.goldBright.withOpacity(0.5)),
                    boxShadow: [BoxShadow(color: _E.crimson.withOpacity(0.4), blurRadius: 10)],
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded, color: _E.goldBright, size: 16),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                      colors: [_E.goldGlow, _E.crimsonUp],
                    ).createShader(b),
                    child: const Text('GANTI PASSWORD', style: TextStyle(
                      fontFamily: 'Ganang', fontSize: 14, fontWeight: FontWeight.w900,
                      color: Colors.white, letterSpacing: 2)),
                  ),
                  const Text('Account Security Update', style: TextStyle(
                    fontFamily: 'ShareTechMono', fontSize: 8, color: _E.textSub)),
                ],
              )),
            ]),
          ]),
        );
      },
    ),
  );

  Widget _buildHeroIcon() => AnimatedBuilder(
    animation: _iconCtrl,
    builder: (_, __) => Transform.scale(
      scale: _iconScale.value,
      child: Transform.rotate(
        angle: _iconRotate.value,
        child: _HeroIconWidget(
          pulseCtrl: _pulseCtrl,
          glowCtrl: _holoCtrl,
        ),
      ),
    ),
  );

  Widget _buildInfoCard() => AnimatedBuilder(
    animation: _discoCtrl,
    builder: (_, __) {
      final dc = _E.discoColor((_disco.value + 0.3) % 1.0);
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.black.withOpacity(0.4),
          gradient: LinearGradient(
            colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: _E.goldBright.withOpacity(0.4), width: 1.2),
          boxShadow: [BoxShadow(color: dc.withOpacity(0.2), blurRadius: 14)],
        ),
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(
            painter: _GlitchPainter(progress: _glitch.value, color: dc),
          )),
          Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_E.crimsonUp, _E.maroon],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: _E.goldBright.withOpacity(0.5)),
                boxShadow: [BoxShadow(color: _E.crimson.withOpacity(0.4), blurRadius: 8)],
              ),
              child: const Icon(Icons.person_outline_rounded,
                color: _E.goldBright, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('AKUN', style: TextStyle(
                  fontFamily: 'Orbitron', color: _E.textSub,
                  fontSize: 8, letterSpacing: 2, fontWeight: FontWeight.w700)),
                Text(
                  widget.username,
                  style: const TextStyle(
                    fontFamily: 'Ganang', color: _E.textPrimary,
                    fontSize: 14, fontWeight: FontWeight.w800),
                ),
              ],
            )),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: _E.success.withOpacity(0.15),
                border: Border.all(color: _E.success.withOpacity(0.5)),
                boxShadow: [BoxShadow(color: _E.success.withOpacity(0.2), blurRadius: 8)],
              ),
              child: const Text('AKTIF', style: TextStyle(
                fontFamily: 'Orbitron', color: _E.success,
                fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
            ),
          ]),
        ]),
      );
    },
  );

  Widget _buildForm() => AnimatedBuilder(
    animation: _discoCtrl,
    builder: (_, __) {
      final dc = _E.discoColor((_disco.value + 0.6) % 1.0);
      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.black.withOpacity(0.4),
          gradient: LinearGradient(
            colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
          boxShadow: [
            BoxShadow(color: dc.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
            BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 6)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(children: [
            Positioned.fill(child: CustomPaint(
              painter: _SpiderWebPainter(
                progress: _webCtrl.value, color: dc, opacity: 0.1),
            )),
            Positioned.fill(child: CustomPaint(
              painter: _GlitchPainter(progress: _glitch.value, color: dc),
            )),
            Positioned(top: 4, left: 4, child: _corner(_E.goldBright.withOpacity(0.6), 10, 1.3, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_E.goldBright.withOpacity(0.6), 10, 1.3, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright.withOpacity(0.6), 10, 1.3, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright.withOpacity(0.6), 10, 1.3, bottomRight: true)),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Section header
                  Row(children: [
                    Container(
                      width: 4, height: 18,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [_E.crimsonUp, _E.goldBright],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [BoxShadow(color: _E.goldBright.withOpacity(0.6), blurRadius: 6)],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text('PERBARUI KEAMANAN', style: TextStyle(
                      fontFamily: 'Ganang', color: _E.textPrimary,
                      fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  ]),
                  const SizedBox(height: 4),
                  const Padding(
                    padding: EdgeInsets.only(left: 14),
                    child: Text('Masukkan password lama & baru', style: TextStyle(
                      fontFamily: 'ShareTechMono', color: _E.textSub, fontSize: 10)),
                  ),

                  const SizedBox(height: 20),

                  _PasswordField(
                    controller: oldPassCtrl,
                    focusNode: _oldFocus,
                    hint: 'Password Lama',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscureOld,
                    onToggle: () => setState(() => _obscureOld = !_obscureOld),
                    nextFocus: _newFocus,
                  ),

                  const SizedBox(height: 12),

                  _PasswordField(
                    controller: newPassCtrl,
                    focusNode: _newFocus,
                    hint: 'Password Baru',
                    icon: Icons.vpn_key_outlined,
                    obscure: _obscureNew,
                    onToggle: () => setState(() => _obscureNew = !_obscureNew),
                    nextFocus: _confirmFocus,
                  ),

                  if (newPassCtrl.text.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    _StrengthBar(
                      strength: _strength,
                      label: _strengthLabel,
                      color: _strengthColor,
                    ),
                  ],

                  const SizedBox(height: 12),

                  _PasswordField(
                    controller: confirmPassCtrl,
                    focusNode: _confirmFocus,
                    hint: 'Konfirmasi Password',
                    icon: Icons.enhanced_encryption_outlined,
                    obscure: _obscureConfirm,
                    onToggle: () => setState(() => _obscureConfirm = !_obscureConfirm),
                    isLast: true,
                    onSubmit: _changePassword,
                    matchState: confirmPassCtrl.text.isEmpty
                        ? null
                        : confirmPassCtrl.text == newPassCtrl.text,
                  ),

                  const SizedBox(height: 24),

                  _SubmitButton(
                    isLoading: isLoading,
                    onTap: _changePassword,
                  ),

                  const SizedBox(height: 14),

                  _buildTips(),
                ],
              ),
            ),
          ]),
        ),
      );
    },
  );

  Widget _buildTips() => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      color: Colors.black.withOpacity(0.3),
      border: Border.all(color: _E.goldBright.withOpacity(0.25)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(children: [
          Icon(Icons.shield_outlined, color: _E.goldBright, size: 12),
          SizedBox(width: 6),
          Text('TIPS KEAMANAN', style: TextStyle(
            fontFamily: 'Orbitron', color: _E.textSub,
            fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        ]),
        const SizedBox(height: 8),
        ...[
          'Minimal 8 karakter',
          'Kombinasi huruf besar, angka & simbol',
          'Hindari tanggal lahir atau nama',
        ].map((t) => Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Icon(Icons.circle, color: _E.textMuted, size: 5),
              ),
              const SizedBox(width: 8),
              Text(t, style: const TextStyle(
                fontFamily: 'ShareTechMono',
                color: _E.textMuted, fontSize: 10, height: 1.4)),
            ],
          ),
        )),
      ],
    ),
  );

  Widget _corner(Color c, double size, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) {
    return SizedBox(
      width: size, height: size,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// HERO ICON
// ═══════════════════════════════════════════════════════════════════════════
class _HeroIconWidget extends StatelessWidget {
  final AnimationController pulseCtrl, glowCtrl;
  const _HeroIconWidget({required this.pulseCtrl, required this.glowCtrl});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([pulseCtrl, glowCtrl]),
      builder: (_, __) {
        final p = Tween<double>(begin: 0.5, end: 1.0).evaluate(CurvedAnimation(parent: pulseCtrl, curve: Curves.easeInOut));
        final g = Tween<double>(begin: 0.3, end: 1.0).evaluate(CurvedAnimation(parent: glowCtrl, curve: Curves.easeInOut));

        return Column(children: [
          Stack(alignment: Alignment.center, children: [
            Container(
              width: 110, height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _E.goldBright.withOpacity(g * 0.3),
                  width: 1,
                ),
              ),
            ),
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _E.goldBright.withOpacity(g * 0.5),
                  width: 1.2,
                ),
              ),
            ),
            Container(
              width: 70, height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [_E.crimsonUp, _E.crimson, _E.maroon],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: _E.goldBright.withOpacity(0.6), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _E.crimson.withOpacity(p * 0.6),
                    blurRadius: 30, spreadRadius: 4,
                  ),
                  BoxShadow(
                    color: _E.goldBright.withOpacity(p * 0.3),
                    blurRadius: 44,
                  ),
                ],
              ),
              child: const Icon(Icons.lock_reset_rounded,
                color: _E.goldBright, size: 32),
            ),
          ]),
          const SizedBox(height: 16),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [_E.goldGlow, _E.crimsonUp],
            ).createShader(b),
            child: const Text('KEAMANAN AKUN', style: TextStyle(
              fontFamily: 'Ganang', color: Colors.white,
              fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ),
          const SizedBox(height: 4),
          const Text('Perbarui password secara berkala', style: TextStyle(
            fontFamily: 'ShareTechMono', color: _E.textSub, fontSize: 11)),
        ]);
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PASSWORD FIELD
// ═══════════════════════════════════════════════════════════════════════════
class _PasswordField extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hint;
  final IconData icon;
  final bool obscure;
  final VoidCallback onToggle;
  final FocusNode? nextFocus;
  final bool isLast;
  final VoidCallback? onSubmit;
  final bool? matchState;

  const _PasswordField({
    required this.controller,
    required this.focusNode,
    required this.hint,
    required this.icon,
    required this.obscure,
    required this.onToggle,
    this.nextFocus,
    this.isLast = false,
    this.onSubmit,
    this.matchState,
  });

  @override
  State<_PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<_PasswordField> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(() {
      setState(() => _focused = widget.focusNode.hasFocus);
    });
  }

  @override
  Widget build(BuildContext context) {
    Color borderColor;
    if (widget.matchState == true) {
      borderColor = _E.success;
    } else if (widget.matchState == false) {
      borderColor = _E.danger;
    } else if (_focused) {
      borderColor = _E.goldBright;
    } else {
      borderColor = _E.border;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: borderColor,
          width: _focused ? 1.5 : 1.2,
        ),
        boxShadow: _focused
            ? [BoxShadow(
                color: _E.goldBright.withOpacity(0.2),
                blurRadius: 14,
                offset: const Offset(0, 4),
              )]
            : [],
      ),
      child: TextField(
        controller: widget.controller,
        focusNode: widget.focusNode,
        obscureText: widget.obscure,
        textInputAction: widget.isLast ? TextInputAction.done : TextInputAction.next,
        onSubmitted: (_) {
          if (widget.nextFocus != null) {
            FocusScope.of(context).requestFocus(widget.nextFocus);
          } else {
            widget.onSubmit?.call();
          }
        },
        style: const TextStyle(
          fontFamily: 'ShareTechMono',
          color: _E.textPrimary, fontSize: 13, fontWeight: FontWeight.w600),
        cursorColor: _E.goldBright,
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: const TextStyle(
            fontFamily: 'ShareTechMono',
            color: _E.textMuted, fontSize: 12),
          prefixIcon: Icon(
            widget.icon,
            color: _focused ? _E.goldBright : _E.textSub,
            size: 18,
          ),
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.matchState != null)
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Icon(
                    widget.matchState!
                        ? Icons.check_circle_rounded
                        : Icons.cancel_rounded,
                    color: widget.matchState! ? _E.success : _E.danger,
                    size: 16,
                  ),
                ),
              IconButton(
                icon: Icon(
                  widget.obscure
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: _E.textSub, size: 18,
                ),
                onPressed: widget.onToggle,
                splashRadius: 18,
              ),
            ],
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// STRENGTH BAR
// ═══════════════════════════════════════════════════════════════════════════
class _StrengthBar extends StatelessWidget {
  final double strength;
  final String label;
  final Color color;

  const _StrengthBar({
    required this.strength,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: Stack(children: [
            Container(height: 4, color: _E.border),
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: 4,
              width: MediaQuery.of(context).size.width * strength * 0.65,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [color, color.withOpacity(0.6)]),
                borderRadius: BorderRadius.circular(4),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.5), blurRadius: 6, spreadRadius: 1),
                ],
              ),
            ),
          ]),
        ),
      ),
      const SizedBox(width: 10),
      AnimatedSwitcher(
        duration: const Duration(milliseconds: 200),
        child: Text(
          label,
          key: ValueKey(label),
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: color, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1),
        ),
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SUBMIT BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _SubmitButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;

  const _SubmitButton({required this.isLoading, required this.onTap});

  @override
  State<_SubmitButton> createState() => _SubmitButtonState();
}

class _SubmitButtonState extends State<_SubmitButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 54,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_E.crimsonUp, _E.crimson, _E.maroon],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: _down || widget.isLoading ? [] : [
              BoxShadow(color: _E.crimson.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 6)),
              BoxShadow(color: _E.goldBright.withOpacity(0.2), blurRadius: 30),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_E.goldBright, 8, 1.2, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_E.goldBright, 8, 1.2, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_E.goldBright, 8, 1.2, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_E.goldBright, 8, 1.2, bottomRight: true)),
            Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: widget.isLoading
                  ? const SizedBox(
                      key: ValueKey('loading'),
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5, color: _E.goldBright),
                    )
                  : const Row(
                      key: ValueKey('label'),
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock_reset_rounded, color: _E.goldBright, size: 18),
                        SizedBox(width: 10),
                        Text('PERBARUI PASSWORD', style: TextStyle(
                          fontFamily: 'Ganang',
                          color: _E.textPrimary,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          letterSpacing: 1.5,
                        )),
                      ],
                    ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _corner(Color c, double size, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) {
    return SizedBox(
      width: size, height: size,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GRADIENT BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _GradBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      height: 46,
      width: fullWidth ? double.infinity : null,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_E.crimsonUp, _E.maroon],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _E.goldBright.withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(color: _E.crimson.withOpacity(0.4), blurRadius: 14, offset: const Offset(0, 4)),
        ],
      ),
      child: Center(
        child: Text(label, style: const TextStyle(
          fontFamily: 'Ganang',
          color: _E.goldBright,
          fontWeight: FontWeight.w900,
          fontSize: 13,
          letterSpacing: 1.5,
        )),
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _SpiderWebPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double opacity;
  _SpiderWebPainter({required this.progress, required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const radialCount = 8;
    for (int i = 0; i < radialCount; i++) {
      final angle = (i / radialCount) * 2 * math.pi;
      final endX = cx + math.cos(angle) * size.width * 0.6;
      final endY = cy + math.sin(angle) * size.height * 0.7;
      canvas.drawLine(Offset(cx, cy), Offset(endX, endY), paint);
    }

    const ringCount = 4;
    for (int r = 1; r <= ringCount; r++) {
      final radius = (r / ringCount) * size.width * 0.45;
      final path = Path();
      for (int i = 0; i <= radialCount; i++) {
        final idx = i % radialCount;
        final angle = (idx / radialCount) * 2 * math.pi + (progress * 0.5);
        final nextAngle = ((idx + 1) % radialCount) / radialCount * 2 * math.pi + (progress * 0.5);
        final midAngle = (angle + nextAngle) / 2;
        final midRadius = radius * 0.85;
        final px = cx + math.cos(angle) * radius;
        final py = cy + math.sin(angle) * radius;
        if (i == 0) {
          path.moveTo(px, py);
        } else {
          final mx = cx + math.cos(midAngle) * midRadius;
          final my = cy + math.sin(midAngle) * midRadius;
          path.quadraticBezierTo(mx, my, px, py);
        }
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_SpiderWebPainter o) => o.progress != progress || o.color != color;
}

class _GlitchPainter extends CustomPainter {
  final double progress;
  final Color color;
  _GlitchPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random((progress * 1000).floor());
    final linePaint = Paint()..strokeWidth = 1;

    for (int i = 0; i < 2; i++) {
      if (rng.nextDouble() > 0.7) {
        final y = rng.nextDouble() * size.height;
        final x1 = rng.nextDouble() * size.width;
        final w = rng.nextDouble() * size.width * 0.3;
        linePaint.color = (rng.nextBool() ? color : _E.goldBright).withOpacity(0.2);
        canvas.drawLine(Offset(x1, y), Offset(x1 + w, y), linePaint);
      }
    }
  }

  @override
  bool shouldRepaint(_GlitchPainter o) => o.progress != progress;
}

class _CornerPainter extends CustomPainter {
  final Color color;
  final double width;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  _CornerPainter(this.color, this.width, {this.topLeft=false, this.topRight=false, this.bottomLeft=false, this.bottomRight=false});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 0.5;
    if (topLeft) {
      canvas.drawLine(Offset.zero, Offset(size.width*len, 0), p);
      canvas.drawLine(Offset.zero, Offset(0, size.height*len), p);
    }
    if (topRight) {
      canvas.drawLine(Offset(size.width, 0), Offset(size.width*(1-len), 0), p);
      canvas.drawLine(Offset(size.width, 0), Offset(size.width, size.height*len), p);
    }
    if (bottomLeft) {
      canvas.drawLine(Offset(0, size.height), Offset(size.width*len, size.height), p);
      canvas.drawLine(Offset(0, size.height), Offset(0, size.height*(1-len)), p);
    }
    if (bottomRight) {
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width*(1-len), size.height), p);
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height*(1-len)), p);
    }
  }

  @override
  bool shouldRepaint(_CornerPainter o) => o.color != color;
}

class _HoloFrame extends StatelessWidget {
  final Widget child;
  final Color color;
  const _HoloFrame({required this.child, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16),
      color: Colors.black.withOpacity(0.4),
      gradient: LinearGradient(
        colors: [_E.card.withOpacity(0.6), _E.surface.withOpacity(0.4)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      border: Border.all(color: color.withOpacity(0.6), width: 1.5),
      boxShadow: [
        BoxShadow(color: color.withOpacity(0.3), blurRadius: 24, spreadRadius: 1),
        BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 12, offset: const Offset(0, 6)),
      ],
    ),
    child: Stack(children: [
      child,
      Positioned(top: 4, left: 4, child: _c(color, 12, 1.5, topLeft: true)),
      Positioned(top: 4, right: 4, child: _c(color, 12, 1.5, topRight: true)),
      Positioned(bottom: 4, left: 4, child: _c(color, 12, 1.5, bottomLeft: true)),
      Positioned(bottom: 4, right: 4, child: _c(color, 12, 1.5, bottomRight: true)),
    ]),
  );

  Widget _c(Color c, double s, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) =>
    SizedBox(width: s, height: s,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)));
}

class _HoloBgPainter extends CustomPainter {
  final double t;
  final double disco;
  final double glitch;
  _HoloBgPainter(this.t, this.disco, this.glitch);

  @override
  void paint(Canvas canvas, Size size) {
    final angle = t * 2 * math.pi;

    final cxRadar = size.width / 2;
    final cyRadar = size.height * 0.3;
    final radarPaint = Paint()
      ..color = _E.goldBright.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (double r = 60; r < size.width; r += 60) {
      canvas.drawCircle(Offset(cxRadar, cyRadar), r, radarPaint);
    }

    final sweepPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          _E.crimsonUp.withOpacity(0.0),
          _E.crimsonUp.withOpacity(0.15),
          _E.crimsonUp.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
        transform: GradientRotation(angle),
      ).createShader(Rect.fromCircle(center: Offset(cxRadar, cyRadar), radius: 320));
    canvas.drawCircle(Offset(cxRadar, cyRadar), 320, sweepPaint);

    final hexPaint = Paint()
      ..color = _E.gold.withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6;

    const hexSize = 30.0;
    final hexH = hexSize * math.sqrt(3);
    for (double y = 0; y < size.height + hexH; y += hexH * 0.5) {
      for (double x = 0; x < size.width + hexSize * 2; x += hexSize * 1.5) {
        final offsetX = (y / (hexH * 0.5)).round().isEven ? 0.0 : hexSize * 0.75;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final a2 = math.pi / 180 * (60 * i - 30);
          final px = x + offsetX + hexSize * math.cos(a2);
          final py = y + hexSize * math.sin(a2);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, hexPaint);
      }
    }

    final scanPaint = Paint()
      ..color = _E.crimson.withOpacity(0.03)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), scanPaint);
    }

    final vignette = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          Colors.transparent,
          Colors.black.withOpacity(0.65),
          Colors.black.withOpacity(0.92),
        ],
        stops: const [0.0, 0.55, 0.85, 1.0],
        radius: 0.88,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignette);
  }

  @override
  bool shouldRepaint(_HoloBgPainter o) => o.t != t || o.disco != disco || o.glitch != glitch;
}