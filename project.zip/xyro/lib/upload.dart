import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'main.dart';

const String kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

class UploadPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const UploadPage({super.key, required this.sessionKey, required this.username});
  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  final _versionCtrl = TextEditingController();
  final _msgCtrl = TextEditingController();
  final _urlCtrl = TextEditingController(text: 'https://t.me/channel_lo');
  
  bool _wajib = true;
  bool _maintenance = false; // <-- STATE MAINTENANCE
  bool _loading = false;

  Future<void> _simpan() async {
    if (_versionCtrl.text.isEmpty) return _alert('Error', 'Versi wajib diisi!');
    setState(() => _loading = true);
    try {
      final res = await http.post(Uri.parse('$kBase/setUpdateInfo'), body: {
        'key': widget.sessionKey,
        'version': _versionCtrl.text,
        'message': _msgCtrl.text,
        'url': _urlCtrl.text,
        'wajib': _wajib.toString(),
        'maintenance': _maintenance.toString(), // <-- KIRIM STATUS MAINTENANCE
      });
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert('Sukses', 'Update & Maintenance berhasil diubah!', success: true);
      } else {
        _alert('Gagal', data['message']);
      }
    } catch (e) {
      _alert('Error', e.toString());
    }
    setState(() => _loading = false);
  }

  void _alert(String title, String msg, {bool success = false}) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(title, style: TextStyle(fontFamily: 'Bangers', color: success ? AppColors.success : AppColors.danger)),
      content: Text(msg, style: const TextStyle(fontFamily: 'Comic Neue', fontWeight: FontWeight.bold)),
      actions: [TextButton(onPressed: () => Navigator.pop(_), child: const Text('OK'))]
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('SET UPDATE'), backgroundColor: AppColors.gold),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(controller: _versionCtrl, decoration: const InputDecoration(labelText: 'Versi Baru (Cth: 9.5.1)', filled: true, fillColor: Colors.white)),
              const SizedBox(height: 16),
              TextField(controller: _msgCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'Pesan Update', filled: true, fillColor: Colors.white)),
              const SizedBox(height: 16),
              TextField(controller: _urlCtrl, decoration: const InputDecoration(labelText: 'Link Telegram / Download', filled: true, fillColor: Colors.white)),
              const SizedBox(height: 16),
              
              // SWITCH WAJIB UPDATE
              SwitchListTile(
                title: const Text('Wajib Update?', style: TextStyle(fontFamily: 'Bangers', fontSize: 20)),
                value: _wajib,
                onChanged: (v) => setState(() => _wajib = v),
                activeColor: AppColors.success,
              ),

              // SWITCH MAINTENANCE (BARU)
              SwitchListTile(
                title: const Text('Mode Maintenance?', style: TextStyle(fontFamily: 'Bangers', fontSize: 20, color: AppColors.danger)),
                subtitle: const Text('Cuma role PEMULA yang bisa login', style: TextStyle(fontFamily: 'Comic Neue', fontSize: 12)),
                value: _maintenance,
                onChanged: (v) => setState(() => _maintenance = v),
                activeColor: AppColors.danger,
              ),

              const SizedBox(height: 24),
              GestureDetector(
                onTap: _loading ? null : _simpan,
                child: Container(
                  width: double.infinity, padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: _loading ? Colors.grey : AppColors.success, border: Border.all(color: AppColors.border, width: 4)),
                  child: Center(child: _loading ? const CircularProgressIndicator(color: Colors.white) : const Text('SIMPAN SEMUA', style: TextStyle(fontFamily: 'Bangers', fontSize: 24, color: Colors.white))),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}