// ═══════════════════════════════════════════════════════════════════════════
//  LANDING PAGE — TACTICAL HUD + FINGERPRINT HOLD (FAKE 1.5s)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';
import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  // ── Animasi HUD ──
  late AnimationController _spinSlowCtrl;
  late AnimationController _spinFastCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _glitchCtrl;

  // ── Fingerprint Hold ──
  static const _holdDuration = Duration(milliseconds: 1500);
  late AnimationController _fingerCtrl;
  bool _fingerHolding = false;
  bool _fingerSuccess = false;
  Timer? _fingerTimer;

  // ── Log Terminal ──
  final List<String> _logs = [];
  final List<String> _logQueue = [
    ">_ INITIALIZING UI...",
    ">_ ENCRYPTION ACTIVE [OK]",
    ">_ BYPASSING FIREWALL...",
    ">_ VERIFYING DEVICE ID... [OK]",
    ">_ SECURE CHANNEL ESTABLISHED",
    ">_ SCANNING BIOMETRIC SENSOR...",
    ">_ AWAITING FINGERPRINT...",
  ];
  Timer? _logTimer;
  int _currentLogIdx = 0;

  @override
  void initState() {
    super.initState();

    _spinSlowCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 20))
          ..repeat();
    _spinFastCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 8))
          ..repeat();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _glitchCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 3000))
      ..repeat(reverse: true);

    // Controller progress sidik jari (0 → 1 selama 1.5s)
    _fingerCtrl = AnimationController(vsync: this, duration: _holdDuration);

    _fingerCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted) {
        _onFingerComplete();
      }
    });

    _startLogs();
  }

  void _startLogs() {
    setState(() {
      _logs.add(_logQueue[0]);
      _logs.add(_logQueue[1]);
      _currentLogIdx = 2;
    });

    _logTimer = Timer.periodic(const Duration(milliseconds: 1800), (timer) {
      if (!mounted) return;
      setState(() {
        if (_currentLogIdx < _logQueue.length) {
          _logs.add(_logQueue[_currentLogIdx]);
          if (_logs.length > 3) _logs.removeAt(0);
          _currentLogIdx++;
        } else {
          _logs.clear();
          _logs.add(_logQueue[0]);
          _logs.add(_logQueue[1]);
          _currentLogIdx = 2;
        }
      });
    });
  }

  // ── FINGERPRINT HOLD LOGIC ──
  void _onFingerDown() {
    if (_fingerSuccess) return;
    HapticFeedback.selectionClick();
    setState(() => _fingerHolding = true);
    _fingerTimer?.cancel();
    _fingerCtrl.forward(from: 0);
  }

  void _onFingerUp() {
    if (_fingerSuccess) return;
    // Kalau belum selesai → reset
    if (_fingerCtrl.value < 1.0) {
      _fingerCtrl.stop();
      _fingerCtrl.animateBack(0.0,
          duration: const Duration(milliseconds: 250));
      setState(() => _fingerHolding = false);
    }
  }

  void _onFingerComplete() {
    HapticFeedback.heavyImpact();
    setState(() {
      _fingerHolding = false;
      _fingerSuccess = true;
    });
    // Update log
    if (mounted) {
      setState(() {
        _logs.clear();
        _logs.add('>_ BIOMETRIC MATCH [OK]');
        _logs.add('>_ ACCESS GRANTED');
      });
    }
    // Delay dikit biar animasi sukses keliatan
    _fingerTimer = Timer(const Duration(milliseconds: 650), () {
      if (mounted) _goLogin();
    });
  }

  void _goLogin() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => const LoginPage(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _spinSlowCtrl.dispose();
    _spinFastCtrl.dispose();
    _pulseCtrl.dispose();
    _glitchCtrl.dispose();
    _fingerCtrl.dispose();
    _fingerTimer?.cancel();
    _logTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          // BACKGROUND GRID
          Positioned.fill(
              child: CustomPaint(painter: _BackgroundGridPainter())),

          // SCANNING LINE
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _spinFastCtrl,
              builder: (_, __) {
                final screenHeight = MediaQuery.of(context).size.height;
                final scanY = (_spinFastCtrl.value * screenHeight * 1.5) - 100;
                return Positioned(
                  top: scanY.clamp(0.0, screenHeight),
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 80,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          AppColors.blood.withOpacity(0.05),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // KONTEN
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  _buildTopBar(),
                  Expanded(child: _buildHudArea()),
                  _buildBottomSection(),
                  const SizedBox(height: 16),
                  const Text(
                    'PROPERTY OF XYRO TACTICAL CORPS\nUNAUTHORIZED DISTRIBUTION IS PROHIBITED',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 8,
                        color: AppColors.textMuted,
                        letterSpacing: 1,
                        height: 1.5),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(
            bottom:
                BorderSide(color: AppColors.border, width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('NET.SECURE // 0x8F2A',
              style: TextStyle(
                  fontSize: 9,
                  color: AppColors.textMuted,
                  letterSpacing: 1)),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: AppColors.blood.withOpacity(_pulseCtrl.value),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: AppColors.blood,
                          blurRadius: _pulseCtrl.value * 5),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                const Text('LIVE UPLINK',
                    style: TextStyle(
                        fontSize: 9,
                        color: AppColors.blood,
                        letterSpacing: 1)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHudArea() {
    return Stack(
      alignment: Alignment.center,
      children: [
        const Positioned(
          left: 0,
          top: 100,
          child: _SideDataText(
              text: 'LAT: 6.2088 S\nLON: 106.8456 E\nENC: AES-256\nPING: 12ms'),
        ),
        const Positioned(
          right: 0,
          top: 100,
          child: _SideDataText(
              text: 'CPU: 84%\nRAM: OK\nSEC: ACTIVE\nSYS: V.2090'),
        ),

        // RING LUAR
        AnimatedBuilder(
          animation: _spinSlowCtrl,
          builder: (_, __) => Transform.rotate(
            angle: _spinSlowCtrl.value * math.pi * 2,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: AppColors.borderBright, width: 1),
              ),
              child: Stack(
                children: [
                  Align(
                      alignment: Alignment.topCenter,
                      child: _dot(AppColors.blood)),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: _dot(AppColors.blood)),
                ],
              ),
            ),
          ),
        ),

        // RING TENGAH
        AnimatedBuilder(
          animation: _spinFastCtrl,
          builder: (_, __) => Transform.rotate(
            angle: -_spinFastCtrl.value * math.pi * 2,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border(
                  top:
                      const BorderSide(color: AppColors.cyan, width: 2),
                  bottom:
                      const BorderSide(color: AppColors.cyan, width: 2),
                  left: BorderSide(
                      color: AppColors.cyan.withOpacity(0.2), width: 2),
                  right: BorderSide(
                      color: AppColors.cyan.withOpacity(0.2), width: 2),
                ),
              ),
            ),
          ),
        ),

        // RING CORE / PULSE
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.blood, width: 1),
              color: AppColors.blood.withOpacity(0.05 * _pulseCtrl.value),
              boxShadow: [
                BoxShadow(
                  color:
                      AppColors.blood.withOpacity(0.2 * _pulseCtrl.value),
                  blurRadius: 20,
                  spreadRadius: 5,
                )
              ],
            ),
          ),
        ),

        // LOGO TENGAH (GLITCH)
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _glitchCtrl,
              builder: (_, __) {
                final dx = (math.sin(_glitchCtrl.value * math.pi * 10) * 2);
                return Stack(
                  children: [
                    Transform.translate(
                      offset: Offset(-dx, 0),
                      child: const Text('XYRO',
                          style: TextStyle(
                            fontSize: 76,
                            fontWeight: FontWeight.w900,
                            color: AppColors.blood,
                            height: 0.9,
                            shadows: [
                              Shadow(color: AppColors.blood, blurRadius: 10)
                            ],
                          )),
                    ),
                    Transform.translate(
                      offset: Offset(dx, 0),
                      child: const Text('XYRO',
                          style: TextStyle(
                            fontSize: 76,
                            fontWeight: FontWeight.w900,
                            color: AppColors.cyan,
                            height: 0.9,
                            shadows: [
                              Shadow(color: AppColors.cyan, blurRadius: 10)
                            ],
                          )),
                    ),
                    const Text('XYRO',
                        style: TextStyle(
                          fontSize: 76,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          height: 0.9,
                          shadows: [
                            Shadow(color: Colors.white, blurRadius: 5)
                          ],
                        )),
                  ],
                );
              },
            ),
            const SizedBox(height: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: AppColors.cyan.withOpacity(0.1),
                border:
                    Border.all(color: AppColors.cyan.withOpacity(0.3)),
              ),
              child: const Text('TACTICAL OPS',
                  style: TextStyle(
                      fontSize: 10,
                      color: AppColors.cyan,
                      letterSpacing: 4,
                      fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _dot(Color color) => Container(
        width: 6,
        height: 6,
        decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: color, blurRadius: 8)]),
      );

  // ─── BOTTOM SECTION (LOG + FINGERPRINT) ───
  Widget _buildBottomSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderBright, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Terminal Log
          SizedBox(
            height: 50,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: _logs.map((log) {
                final isOk = log.contains('OK') ||
                    log.contains('GRANTED');
                final isDeny = log.contains('DENIED') ||
                    log.contains('[X]');
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(log,
                      style: TextStyle(
                        fontSize: 9,
                        color: isDeny
                            ? AppColors.blood
                            : (isOk
                                ? AppColors.toxic
                                : AppColors.textMuted),
                      )),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 12),

          // Barcode Fake
          SizedBox(
            height: 20,
            child: Row(
              children: List.generate(20, (i) {
                final isThick = i % 3 == 0;
                return Container(
                  width: isThick ? 4 : 2,
                  margin: const EdgeInsets.only(right: 2),
                  color: AppColors.text.withOpacity(0.3),
                );
              }),
            ),
          ),

          const SizedBox(height: 18),

          // ═══ FINGERPRINT HOLD AREA ═══
          _buildFingerprintArea(),
        ],
      ),
    );
  }

  // ═══ FINGERPRINT HOLD WIDGET ═══
  Widget _buildFingerprintArea() {
    return AnimatedBuilder(
      animation: _fingerCtrl,
      builder: (_, __) {
        final p = _fingerCtrl.value; // 0.0 → 1.0
        final isDone = _fingerSuccess;
        final accent = isDone ? AppColors.toxic : AppColors.blood;

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => _onFingerDown(),
          onTapUp: (_) => _onFingerUp(),
          onTapCancel: _onFingerUp,
          onLongPressStart: (_) => _onFingerDown(),
          onLongPressEnd: (_) => _onFingerUp(),
          child: Container(
            height: 84,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.05 + p * 0.15),
              border: Border.all(
                  color: accent.withOpacity(0.4 + p * 0.6),
                  width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.15 + p * 0.35),
                  blurRadius: 10 + p * 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Stack(
              children: [
                // Progress fill dari kiri
                Positioned.fill(
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: p,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            accent.withOpacity(0.35),
                            accent.withOpacity(0.15),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Konten
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isDone
                            ? Icons.check_circle_rounded
                            : Icons.fingerprint_rounded,
                        color: isDone ? AppColors.toxic : AppColors.blood,
                        size: 34,
                      ),
                      const SizedBox(width: 14),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isDone
                                ? 'ACCESS GRANTED'
                                : (_fingerHolding
                                    ? 'VERIFYING... ${(p * 100).toInt()}%'
                                    : 'HOLD TO VERIFY'),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: isDone
                                  ? AppColors.toxic
                                  : AppColors.blood,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            isDone
                                ? 'REDIRECTING...'
                                : (_fingerHolding
                                    ? 'TAHAN SAMPAI SELESAI'
                                    : 'TAHAN SIDIK JARI 1.5 DETIK'),
                            style: const TextStyle(
                              fontSize: 9,
                              color: AppColors.textMuted,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Progress bar tipis di bawah
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: 2,
                    color: Colors.white.withOpacity(0.05),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: p,
                      child: Container(color: accent),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class _SideDataText extends StatelessWidget {
  final String text;
  const _SideDataText({required this.text});

  @override
  Widget build(BuildContext context) {
    return RotatedBox(
      quarterTurns: 3,
      child: Text(text,
          style: const TextStyle(
              fontSize: 8,
              color: AppColors.textMuted,
              letterSpacing: 1.5,
              height: 1.5)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class _BackgroundGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.blood.withOpacity(0.03)
      ..strokeWidth = 1;

    for (double i = 0; i < size.width; i += 20) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }
    for (double i = 0; i < size.height; i += 20) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}