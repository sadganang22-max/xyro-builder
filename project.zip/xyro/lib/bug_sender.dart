// ═══════════════════════════════════════════════════════════════════════════
//  BUG SENDER PAGE — GLASS BLACK + VIDEO BG + B/W/R
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with WidgetsBindingObserver {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    _fetchSenders();
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  // ═══ API ═══
  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final res = await http.get(
        Uri.parse(
            "http://www.rexylegal.rxpedia.web.id:2060/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          setState(() => senderList = data["connections"] ?? []);
        } else {
          setState(() =>
              errorMessage = data["message"] ?? "Failed to fetch");
        }
      } else {
        setState(() => errorMessage = "Server error: ${res.statusCode}");
      }
    } catch (e) {
      setState(() => errorMessage = "Connection failed");
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "http://www.rexylegal.rxpedia.web.id:2060/getPairing?key=${widget.sessionKey}&number=$number"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode']);
        } else {
          _toast(data['message'] ?? "Failed to generate pairing code",
              error: true);
        }
      } else {
        _toast("Server error: ${res.statusCode}", error: true);
      }
    } catch (_) {
      _toast("Connection failed", error: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  Future<void> _deleteSender(String senderId) async {
    setState(() => isLoading = true);
    try {
      final res = await http.delete(Uri.parse(
          "http://www.rexylegal.rxpedia.web.id:2060/deleteSender?key=${widget.sessionKey}&id=$senderId"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          _toast("Sender deleted successfully");
          _fetchSenders();
        } else {
          _toast(data["message"] ?? "Failed", error: true);
        }
      } else {
        _toast("Server error: ${res.statusCode}", error: true);
      }
    } catch (_) {
      _toast("Connection failed", error: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  void _toast(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(error ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white, size: 20),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w700))),
      ]),
      backgroundColor: error ? _C.red : Colors.black.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: _C.red.withOpacity(0.5)),
      ),
      duration: const Duration(seconds: 3),
    ));
  }

  // ═══ DIALOGS ═══
  void _showAddSenderDialog() {
    final phoneCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('TAMBAH SENDER',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              const SizedBox(height: 6),
              const Text('Pairing nomor WA baru',
                  style: TextStyle(fontSize: 12, color: _C.muted)),
              const SizedBox(height: 18),
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                style: const TextStyle(
                    fontSize: 15, color: Colors.white, letterSpacing: 0.5),
                decoration: InputDecoration(
                  hintText: '628xxx',
                  hintStyle:
                      const TextStyle(color: _C.muted, fontSize: 13),
                  labelText: 'Nomor WhatsApp',
                  labelStyle:
                      const TextStyle(color: _C.muted, fontSize: 12),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.12)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        const BorderSide(color: _C.red, width: 1.5),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                    child: _SecondaryBtn(
                        label: 'BATAL',
                        onTap: () => Navigator.pop(ctx))),
                const SizedBox(width: 10),
                Expanded(
                  child: _PrimaryBtn(
                    label: 'CONNECT',
                    onTap: () {
                      final num = phoneCtrl.text.trim();
                      if (num.isEmpty) {
                        _toast('Masukkan nomor telepon', error: true);
                        return;
                      }
                      Navigator.pop(ctx);
                      _addSender(num);
                    },
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.red, width: 1.5),
                ),
                child: const Icon(Icons.phonelink_lock_rounded,
                    color: _C.red, size: 32),
              ),
              const SizedBox(height: 16),
              const Text('KODE PAIRING',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              const SizedBox(height: 6),
              Text('Nomor: $number',
                  style:
                      const TextStyle(fontSize: 12, color: _C.muted)),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: _C.red.withOpacity(0.6), width: 1.5),
                ),
                child: Text(
                  code,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 38,
                      fontWeight: FontWeight.w900,
                      color: _C.red,
                      letterSpacing: 8),
                ),
              ),
              const SizedBox(height: 20),
              _PrimaryBtn(
                label: 'SELESAI & REFRESH',
                onTap: () {
                  Navigator.pop(ctx);
                  _fetchSenders();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showDeleteConfirm(Map<String, dynamic> sender) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.delete_forever_rounded,
                  color: _C.red, size: 50),
              const SizedBox(height: 14),
              const Text('HAPUS SENDER?',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Text(
                "Sender '${sender['sessionName'] ?? sender['id']}' akan dihapus.",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: _C.muted),
              ),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                    child: _SecondaryBtn(
                        label: 'BATAL',
                        onTap: () => Navigator.pop(ctx, false))),
                const SizedBox(width: 10),
                Expanded(
                    child: _PrimaryBtn(
                        label: 'HAPUS',
                        onTap: () => Navigator.pop(ctx, true))),
              ]),
            ],
          ),
        ),
      ),
    );
    if (confirmed == true) _deleteSender(sender['id']);
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ CARD ═══
  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: _GlassCard(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: _C.red, width: 1.5),
              ),
              child: const Center(
                  child: FaIcon(FontAwesomeIcons.whatsapp,
                      color: _C.red, size: 24)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 4),
                  Row(children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                          color: _C.red, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    const Text('CONNECTED',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: _C.red,
                            letterSpacing: 1.5)),
                  ]),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 14),
          Container(height: 1, color: Colors.white.withOpacity(0.08)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
                child: _SecondaryBtn(
                    label: 'REFRESH', onTap: _refreshSenders)),
            const SizedBox(width: 10),
            Expanded(
                child: _PrimaryBtn(
                    label: 'HAPUS',
                    onTap: () => _showDeleteConfirm(sender))),
          ]),
        ]),
      ),
    );
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(children: [
            _buildTopBar(),
            Expanded(
              child: isLoading && senderList.isEmpty
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: _C.red, strokeWidth: 2))
                  : RefreshIndicator(
                      color: _C.red,
                      backgroundColor: Colors.black,
                      onRefresh: _refreshSenders,
                      child: senderList.isEmpty
                          ? ListView(
                              physics:
                                  const AlwaysScrollableScrollPhysics(),
                              children: [
                                const SizedBox(height: 80),
                                Center(
                                  child: Column(children: [
                                    Icon(FontAwesomeIcons.whatsapp,
                                        size: 70, color: _C.muted),
                                    const SizedBox(height: 18),
                                    const Text('BELUM ADA SENDER',
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w900,
                                            color: Colors.white,
                                            letterSpacing: 1.5)),
                                    const SizedBox(height: 8),
                                    const Text(
                                        'Pairing nomor WA dulu buat mulai kirim',
                                        style: TextStyle(
                                            fontSize: 11,
                                            color: _C.muted)),
                                    const SizedBox(height: 24),
                                    GestureDetector(
                                      onTap: _showAddSenderDialog,
                                      child: Container(
                                        padding: const EdgeInsets
                                            .symmetric(
                                            horizontal: 24, vertical: 14),
                                        decoration: BoxDecoration(
                                          color: _C.red,
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          boxShadow: [
                                            BoxShadow(
                                                color: _C.red
                                                    .withOpacity(0.4),
                                                blurRadius: 16,
                                                offset:
                                                    const Offset(0, 6)),
                                          ],
                                        ),
                                        child: const Text('TAMBAH SENDER',
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight:
                                                    FontWeight.w900,
                                                color: Colors.black,
                                                letterSpacing: 1.5)),
                                      ),
                                    ),
                                  ]),
                                ),
                              ],
                            )
                          : ListView.builder(
                              padding:
                                  const EdgeInsets.fromLTRB(20, 8, 20, 100),
                              itemCount: senderList.length,
                              itemBuilder: (ctx, i) => _buildSenderCard(
                                  Map<String, dynamic>.from(senderList[i]),
                                  i),
                            ),
                    ),
            ),
          ]),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: _C.red,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        onPressed: _showAddSenderDialog,
        child: const Icon(Icons.add, color: Colors.black, size: 28),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('BUG SENDER',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('KELOLA SENDER WA KAMU',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.red.withOpacity(0.5)),
            ),
            child: Text('${senderList.length}',
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: _C.red,
                    letterSpacing: 1)),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

class _SecondaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _SecondaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}