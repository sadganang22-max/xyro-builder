// ═══════════════════════════════════════════════════════════════════════════
//  PEMULA PAGE — GLASS BLACK + VIDEO BG + B/W/R (No api_config)
//  PART 1/2
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'acc.dart';

const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══════════════════════════════════════════════════════════════════════════
class PemulaPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const PemulaPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<PemulaPage> createState() => _PemulaPageState();
}

class _PemulaPageState extends State<PemulaPage>
    with WidgetsBindingObserver {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
    'member',
    'vip',
    'reseller',
    'admin',
    'owner'
  ];
  final List<String> filterRoles = [
    'member',
    'vip',
    'reseller',
    'admin',
    'owner'
  ];

  String selectedFilterRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();
  final checkRoleController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    _fetchUsers();
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    checkRoleController.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/listUsers?key=${widget.sessionKey}')).timeout(
          const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.', error: true);
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.", error: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedFilterRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList
        .sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.", error: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/deleteUser?key=${widget.sessionKey}&username=$username'))
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.', error: true);
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.", error: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.", error: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$baseUrl/userAdd?key=${widget.sessionKey}&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun ${newUserRole.toUpperCase()} berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.', error: true);
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.", error: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.", error: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$baseUrl/editUser?key=${widget.sessionKey}&username=$u&addDays=$d');
      final res = await http.get(url).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.', error: true);
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.", error: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _checkRole() async {
    final username = checkRoleController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username terlebih dahulu.", error: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/checkRole?key=${widget.sessionKey}&username=${Uri.encodeComponent(username)}'))
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['found'] == true) {
        final user = data['user'] as Map<String, dynamic>;
        _showRoleResultDialog(user);
      } else {
        _alert("Tidak Ditemukan",
            data['message'] ?? 'User "$username" tidak ada.',
            error: true);
      }
    } catch (_) {
      _alert("Koneksi Error", "Gagal cek role.", error: true);
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _showRoleResultDialog(Map<String, dynamic> user) {
    final role = (user['role']?.toString() ?? 'member').toLowerCase();
    final roleIcon = _getRoleIcon(role);

    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.red.withOpacity(0.12),
                  border: Border.all(color: _C.red, width: 2),
                ),
                child: Icon(roleIcon, color: _C.red, size: 32),
              ),
              const SizedBox(height: 16),
              Text(user['username']?.toString() ?? '-',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      letterSpacing: 1)),
              const SizedBox(height: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: Text(role.toUpperCase(),
                    style: const TextStyle(
                        color: _C.red,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 2)),
              ),
              const SizedBox(height: 20),
              _resultRow(Icons.calendar_today_rounded, 'Expired',
                  user['expiredDate']?.toString() ?? '-'),
              const SizedBox(height: 10),
              _resultRow(Icons.info_outline_rounded, 'Status',
                  (user['status']?.toString() ?? 'active').toUpperCase()),
              const SizedBox(height: 24),
              _PrimaryBtn(label: 'TUTUP', onTap: () => Navigator.pop(ctx)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _resultRow(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.red, size: 16),
          const SizedBox(width: 10),
          Text(label,
              style: const TextStyle(
                  color: _C.muted,
                  fontWeight: FontWeight.w600,
                  fontSize: 11)),
          const Spacer(),
          Expanded(
            child: Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 12)),
          ),
        ],
      ),
    );
  }

  void _alert(String title, String message, {bool error = false}) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.red.withOpacity(0.12),
                  border: Border.all(color: _C.red, width: 2),
                ),
                child: Icon(
                  error ? Icons.error_rounded : Icons.check_circle_rounded,
                  color: _C.red,
                  size: 32,
                ),
              ),
              const SizedBox(height: 16),
              Text(title.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _C.muted, fontSize: 13, height: 1.5)),
              const SizedBox(height: 20),
              _PrimaryBtn(label: 'OK', onTap: () => Navigator.pop(ctx)),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getRoleIcon(String? role) {
    switch ((role ?? 'member').toLowerCase()) {
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      case 'vip':
        return Icons.star_rounded;
      default:
        return Icons.person_rounded;
    }
  }
    // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: isLoading && fullUserList.isEmpty
              ? const Center(
                  child: CircularProgressIndicator(
                      color: _C.red, strokeWidth: 2))
              : SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildAppBar(),
                      const SizedBox(height: 16),
                      _buildCheckRoleCard(),
                      const SizedBox(height: 16),
                      _buildActionGrid(),
                      const SizedBox(height: 16),
                      _buildFilterCard(),
                      const SizedBox(height: 12),
                      if (isLoading && fullUserList.isNotEmpty)
                        const Center(
                            child: Padding(
                                padding: EdgeInsets.all(20),
                                child: CircularProgressIndicator(
                                    color: _C.red, strokeWidth: 2))),
                      if (filteredList.isEmpty && !isLoading)
                        _buildEmptyState(),
                      ..._getCurrentPageData()
                          .map((e) => _buildUserItem(e))
                          .toList(),
                      const SizedBox(height: 16),
                      Center(child: _buildPagination()),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildAppBar() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.12)),
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: Colors.white, size: 24),
          ),
        ),
        const SizedBox(width: 14),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('PEMULA CONSOLE',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              SizedBox(height: 2),
              Text('KELOLA AKUN MEMBER',
                  style: TextStyle(
                      fontSize: 10,
                      color: _C.muted,
                      letterSpacing: 1.5)),
            ],
          ),
        ),
        GestureDetector(
          onTap: _fetchUsers,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.red.withOpacity(0.5)),
            ),
            child: const Icon(Icons.refresh_rounded,
                color: _C.red, size: 22),
          ),
        ),
      ],
    );
  }

  // ═══ CHECK ROLE CARD ═══
  Widget _buildCheckRoleCard() {
    return _GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.search_rounded,
                    color: _C.red, size: 18),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text('CEK ROLE USER',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.5)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: Colors.white.withOpacity(0.12)),
                  ),
                  child: TextField(
                    controller: checkRoleController,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600),
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _checkRole(),
                    decoration: const InputDecoration(
                      hintText: 'Ketik username...',
                      hintStyle: TextStyle(color: _C.muted, fontSize: 12),
                      prefixIcon: Icon(Icons.person_search_rounded,
                          color: _C.muted, size: 18),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _checkRole,
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: _C.red,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: _C.red.withOpacity(0.4),
                          blurRadius: 12,
                          offset: const Offset(0, 4)),
                    ],
                  ),
                  child: const Icon(Icons.search_rounded,
                      color: Colors.black, size: 22),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══ ACTION GRID ═══
  Widget _buildActionGrid() {
    return Column(
      children: [
        Row(
          children: [
            _actionCard('ACC AKUN', Icons.verified_user_rounded, _openAccPage),
            const SizedBox(width: 10),
            _actionCard('CREATE', Icons.person_add_rounded,
                _showCreateAccountPopup),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _actionCard(
                'EXTEND', Icons.timer_rounded, _showExtendDurationPopup),
            const SizedBox(width: 10),
            _actionCard('DELETE', Icons.person_remove_rounded,
                _showDeleteAccountPopup),
          ],
        ),
      ],
    );
  }

  void _openAccPage() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (ctx) => AccPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: 'pemula',
        ),
      ),
    ).then((_) => _fetchUsers());
  }

  Widget _actionCard(String label, IconData icon, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.mediumImpact();
          onTap();
        },
        child: _GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.red.withOpacity(0.12),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: Icon(icon, color: _C.red, size: 22),
              ),
              const SizedBox(height: 8),
              Text(label,
                  style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 0.8)),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ FILTER ═══
  Widget _buildFilterCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedFilterRole,
          isExpanded: true,
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Colors.white),
          icon: const Icon(Icons.arrow_drop_down,
              color: _C.red, size: 24),
          items: filterRoles.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(_getRoleIcon(role), color: _C.red, size: 16),
                  const SizedBox(width: 8),
                  Text(role.toUpperCase(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 13)),
                ],
              ),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) {
              setState(() {
                selectedFilterRole = val;
                _filterAndPaginate();
              });
            }
          },
        ),
      ),
    );
  }

  // ═══ USER ITEM ═══
  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: _GlassCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: _C.red.withOpacity(0.5)),
              ),
              child:
                  Icon(_getRoleIcon(user['role']), color: _C.red, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'] ?? '-',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _C.red.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                          border:
                              Border.all(color: _C.red.withOpacity(0.5)),
                        ),
                        child: Text(
                            (user['role'] ?? 'member').toUpperCase(),
                            style: const TextStyle(
                                fontSize: 9,
                                color: _C.red,
                                fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text('EXP ${user['expiredDate'] ?? '-'}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: _C.muted,
                                fontSize: 10,
                                fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                deleteController.text = user['username'] ?? '';
                _showDeleteAccountPopup();
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.delete_outline_rounded,
                    color: _C.red, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.red.withOpacity(0.1),
              border: Border.all(color: _C.red.withOpacity(0.4), width: 2),
            ),
            child: const Icon(Icons.person_off_outlined,
                color: _C.red, size: 32),
          ),
          const SizedBox(height: 14),
          Text("Belum ada user '${selectedFilterRole.toUpperCase()}'",
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? _C.red : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: isSelected
                      ? _C.red
                      : Colors.white.withOpacity(0.12),
                  width: 1.5),
            ),
            child: Text("$page",
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: isSelected ? Colors.black : Colors.white)),
          ),
        );
      }),
    );
  }

  Widget _buildInput(String label, TextEditingController controller,
      IconData icon, TextInputType type) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w800,
                fontSize: 11,
                letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: TextField(
            controller: controller,
            keyboardType: type,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: 'Masukkan $label...',
              hintStyle:
                  const TextStyle(color: _C.muted, fontSize: 13),
              prefixIcon: Icon(icon, color: _C.muted, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 14),
            ),
          ),
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  Widget _popupShell(
      String title, IconData icon, List<Widget> children) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: _GlassCard(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.red.withOpacity(0.12),
                  border:
                      Border.all(color: _C.red.withOpacity(0.6), width: 2),
                ),
                child: Icon(icon, color: _C.red, size: 28),
              ),
              const SizedBox(height: 12),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.5)),
              const SizedBox(height: 20),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return _popupShell('CREATE ACCOUNT', Icons.person_add_rounded, [
            _buildInput('Username', createUsernameController,
                Icons.person_rounded, TextInputType.text),
            _buildInput('Password', createPasswordController,
                Icons.lock_rounded, TextInputType.text),
            _buildInput('Durasi (Hari)', createDayController,
                Icons.calendar_month_rounded, TextInputType.number),
            const Text('ROLE',
                style: TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.w800,
                    fontSize: 11,
                    letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: newUserRole,
                  isExpanded: true,
                  dropdownColor: const Color(0xFF0A0A0A),
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 13),
                  icon: const Icon(Icons.arrow_drop_down,
                      color: _C.red, size: 24),
                  items: roleOptions.map((role) {
                    return DropdownMenuItem(
                        value: role,
                        child: Text(role.toUpperCase(),
                            style:
                                const TextStyle(color: Colors.white)));
                  }).toList(),
                  onChanged: (val) =>
                      setModalState(() => newUserRole = val ?? 'member'),
                ),
              ),
            ),
            const SizedBox(height: 20),
            _PrimaryBtn(
              label: 'CREATE',
              onTap: () {
                Navigator.pop(ctx);
                _createAccount();
              },
            ),
          ]);
        },
      ),
    );
  }

  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      builder: (ctx) => _popupShell('ADD DURATION', Icons.timer_rounded, [
        _buildInput('Username', editUsernameController,
            Icons.person_search_rounded, TextInputType.text),
        _buildInput('Tambah Hari', editDayController,
            Icons.calendar_month_rounded, TextInputType.number),
        const SizedBox(height: 8),
        _PrimaryBtn(
          label: 'TAMBAH',
          onTap: () {
            Navigator.pop(ctx);
            _editUser();
          },
        ),
      ]),
    );
  }

  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      builder: (ctx) =>
          _popupShell('DELETE ACCOUNT', Icons.person_remove_rounded, [
        _buildInput('Username', deleteController, Icons.person_rounded,
            TextInputType.text),
        const SizedBox(height: 8),
        _PrimaryBtn(
          label: 'HAPUS',
          onTap: () {
            Navigator.pop(ctx);
            _deleteUser();
          },
        ),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PRIMARY BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: _C.red.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}