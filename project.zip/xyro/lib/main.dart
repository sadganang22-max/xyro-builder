import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';

// ═══════════════════════════════════════════════════════════════
//  ROUTE OBSERVER
// ═══════════════════════════════════════════════════════════════
final RouteObserver<ModalRoute<void>> dashboardRouteObserver =
    RouteObserver<ModalRoute<void>>();

// ═══════════════════════════════════════════════════════════════
//  TACTICAL COLOR SYSTEM (FULL ALIAS COMPATIBILITY)
// ═══════════════════════════════════════════════════════════════
class AppColors {
  // BASE
  static const bg        = Color(0xFF050505); 
  static const bgDeep    = Color(0xFF000000); 
  static const surface   = Color(0xFF0A0A0A); 
  static const surfaceAlt= Color(0xFF111111); 
  static const card      = Color(0xFF0A0A0A); 
  static const cardHover = Color(0xFF151515);
  static const border    = Color(0xFF222222);
  static const borderBright = Color(0xFF444444);
  static const borderGlow = Color(0xFFFF003C);
  static const borderActive = Color(0xFFFF003C);
  static const borderDim = Color(0xFF151515);

  // ACCENTS
  static const blood     = Color(0xFFFF003C); 
  static const toxic     = Color(0xFF39FF14); 
  static const cyan      = Color(0xFF00E5FF); 
  static const warning   = Color(0xFFFFB000); 
  static const azure     = Color(0xFF00E5FF); 
  
  // TEXT
  static const text      = Color(0xFFE0E0E0);
  static const textPrimary = Color(0xFFE0E0E0); 
  static const textSub   = Color(0xFFA0A0A0);   
  static const textMuted = Color(0xFF666666);
  static const textDim   = Color(0xFF444444);

  // ALIASES (BIAR FILE LU YANG LAIN GAK ERROR)
  static const gold      = warning;
  static const goldDim   = Color(0xFFCC8E00); 
  static const goldSoft  = Color(0x33FFB000);
  static const violet    = blood;
  static const violetBright = blood;
  static const violetGlow = blood;
  static const danger    = blood;
  static const dangerDim = Color(0xFFCC0030);
  static const success   = toxic;
  static const successDim= Color(0xFF2ECC11);
  static const cyanDim   = Color(0xFF00B3C6);
  static const cyanDark  = Color(0xFF008999);
  static const primary   = blood;
  static const primaryDim= Color(0xFFCC0030);
  static const electric  = cyan;
  static const indigo    = blood;

  // GRADIENTS
  static const LinearGradient cyanGrad = LinearGradient(
    colors: [Color(0xFF00E5FF), Color(0xFFFF003C)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient heroGrad = LinearGradient(
    colors: [Color(0xFF050505), Color(0xFF0A0A0A)],
    begin: Alignment.topCenter, end: Alignment.bottomCenter,
  );
  static const LinearGradient violetGrad = LinearGradient(
    colors: [Color(0xFFFF003C), Color(0xFFCC0030)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient glowGrad = LinearGradient(
    colors: [Color(0xFF00E5FF), Color(0xFFFF003C)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient neonGrad = LinearGradient(
    colors: [Color(0xFF39FF14), Color(0xFF00E5FF)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
}

// ═══════════════════════════════════════════════════════════════
//  THEME
// ═══════════════════════════════════════════════════════════════
class AppTheme {
  static ThemeData build() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bg,
    fontFamily: 'ShareTechMono', // Pastikan font ini ada di pubspec.yaml
    colorScheme: const ColorScheme.dark(
      primary: AppColors.blood,
      onPrimary: Colors.black,
      secondary: AppColors.toxic,
      onSecondary: Colors.black,
      surface: AppColors.surface,
      onSurface: AppColors.text,
      error: AppColors.blood,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      foregroundColor: AppColors.text,
      elevation: 0,
      centerTitle: false,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
    ),
    dialogTheme: const DialogThemeData(
      backgroundColor: AppColors.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ),
    inputDecorationTheme: const InputDecorationTheme(
      filled: true,
      fillColor: Colors.black,
      border: OutlineInputBorder(borderRadius: BorderRadius.zero),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.zero),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.zero),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════
//  SHARED WIDGETS
// ═══════════════════════════════════════════════════════════════
class NeonButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final double? width;
  final Color? color;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.width,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final baseColor = color ?? AppColors.blood;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: width,
        height: 50,
        decoration: BoxDecoration(
          color: baseColor,
          border: Border.all(color: baseColor, width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 20, color: Colors.black),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: const TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.black,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  ROUTE BUILDER
// ═══════════════════════════════════════════════════════════════
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;
  switch (settings.name) {
    case '/':
      page = LandingPage();
      break;
    case '/login':
      page = const LoginPage();
      break;
    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );
      break;
    case '/home':
      page = HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );
      break;
    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
      break;
    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
      break;
    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;
    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return MaterialPageRoute(builder: (_) => page);
}

// ═══════════════════════════════════════════════════════════════
//  404 PAGE
// ═══════════════════════════════════════════════════════════════
class _NotFoundPage extends StatelessWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '404',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize:   80,
                fontWeight: FontWeight.bold,
                color:      AppColors.blood,
              ),
            ),
            const Text(
              'HALAMAN TIDAK ADA',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize:   16,
                fontWeight: FontWeight.bold,
                color:      AppColors.text,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 30),
            NeonButton(
              label: 'KEMBALI',
              onTap: () => Navigator.of(context)
                  .pushNamedAndRemoveUntil('/', (_) => false),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  ENTRY POINT
// ═══════════════════════════════════════════════════════════════
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.bg,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const _XyroApp());
}

// ═══════════════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════════════
class _XyroApp extends StatelessWidget {
  const _XyroApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:           'XYRO Tactical',
      theme:           AppTheme.build(),
      initialRoute:    '/',
      onGenerateRoute: _generateRoute,
      navigatorObservers: [dashboardRouteObserver],
    );
  }
}