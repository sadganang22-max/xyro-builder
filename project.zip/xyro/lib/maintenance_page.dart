// lib/maintenance_page.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';

class MaintenancePage extends StatelessWidget {
  final String message;

  const MaintenancePage({
    super.key, 
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // Biar user gak bisa back
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Ikon Konstruksi
                  Container(
                    padding: const EdgeInsets.all(30),
                    decoration: BoxDecoration(
                      color: AppColors.warning,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.border, width: 6),
                      boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(8, 8))],
                    ),
                    child: const Icon(Icons.construction_rounded, color: Colors.white, size: 80),
                  ),
                  const SizedBox(height: 30),

                  // Judul
                  const Text('SEDANG MAINTENANCE', textAlign: TextAlign.center, style: TextStyle(
                    fontFamily: 'Bangers', fontSize: 36, color: AppColors.warning, letterSpacing: 2,
                    shadows: [Shadow(color: AppColors.border, offset: Offset(4, 4))],
                  )),
                  
                  const SizedBox(height: 16),

                  // Pesan dari Server
                  Text(message, textAlign: TextAlign.center, style: const TextStyle(
                    fontFamily: 'Comic Neue', fontWeight: FontWeight.bold, 
                    fontSize: 16, color: AppColors.textSub, height: 1.5,
                  )),

                  const SizedBox(height: 40),

                  // Tombol Hubungi Admin
                  GestureDetector(
                    onTap: () => launchUrl(Uri.parse('https://t.me/Criminalbug'), mode: LaunchMode.externalApplication),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.cyan,
                        border: Border.all(color: AppColors.border, width: 4),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(5, 5))],
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.telegram, color: Colors.white, size: 24),
                          SizedBox(width: 8),
                          Text('HUBUNGI ADMIN', style: TextStyle(
                            fontFamily: 'Bangers', fontSize: 20, color: Colors.white, letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}