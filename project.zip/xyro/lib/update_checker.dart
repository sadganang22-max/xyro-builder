// lib/update_checker.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';

// GANTI URL INI SESUAI SERVER LO
const String kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

class UpdateChecker {
  /// Return true kalau di-redirect ke Force Update
  /// Return false kalau aman (gak ada update / update opsional)
  static Future<bool> checkAndReturn(BuildContext context) async {
    try {
      final pkg = await PackageInfo.fromPlatform();
      final currentVersion = pkg.version;
      debugPrint('🔍 [Update] Current: $currentVersion');

      final res = await http.get(
        Uri.parse('$kBase/getLatestApk?t=${DateTime.now().millisecondsSinceEpoch}'),
      ).timeout(const Duration(seconds: 10));

      debugPrint('📡 [Update] Status: ${res.statusCode}');
      debugPrint('📦 [Update] Body: ${res.body}');

      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      if (data['valid'] != true) return false;

      final latestVersion = data['version']?.toString() ?? '0.0.0';
      final downloadUrl = data['url']?.toString() ?? '';
      final changelog = data['changelog']?.toString() ?? '-';
      final forceUpdate = data['force'] == true;

      debugPrint('🆕 [Update] Latest: $latestVersion | Force: $forceUpdate');

      if (_isNewerVersion(latestVersion, currentVersion)) {
        debugPrint('✅ [Update] UPDATE DETECTED!');
        if (!context.mounted) return false;

        if (forceUpdate) {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => ForceUpdatePage(
              currentVersion: currentVersion,
              latestVersion: latestVersion,
              downloadUrl: downloadUrl,
              changelog: changelog,
            )),
            (route) => false,
          );
          return true;
        } else {
          _showOptionalUpdateDialog(
            context,
            currentVersion: currentVersion,
            latestVersion: latestVersion,
            downloadUrl: downloadUrl,
            changelog: changelog,
          );
          return false;
        }
      }
      debugPrint('✅ [Update] App is up to date');
      return false;
    } catch (e) {
      debugPrint('❌ [Update] Error: $e');
      return false;
    }
  }

  static bool _isNewerVersion(String latest, String current) {
    latest = latest.trim();
    current = current.trim();
    if (latest == current) return false;

    final l = latest.split('.').map((e) => int.tryParse(e.replaceAll(RegExp(r'[^\d]'), '')) ?? 0).toList();
    final c = current.split('.').map((e) => int.tryParse(e.replaceAll(RegExp(r'[^\d]'), '')) ?? 0).toList();

    for (int i = 0; i < 3; i++) {
      final lv = i < l.length ? l[i] : 0;
      final cv = i < c.length ? c[i] : 0;
      if (lv > cv) return true;
      if (lv < cv) return false;
    }
    return false;
  }

  static void _showOptionalUpdateDialog(BuildContext context, {
    required String currentVersion,
    required String latestVersion,
    required String downloadUrl,
    required String changelog,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: AppColors.border, width: 5),
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(8, 8))],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.cyan,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.border, width: 4),
                ),
                child: const Icon(Icons.system_update_rounded, color: Colors.white, size: 50),
              ),
              const SizedBox(height: 20),
              const Text('UPDATE TERSEDIA', style: TextStyle(
                fontFamily: 'Bangers', fontSize: 28, color: AppColors.textPrimary, letterSpacing: 2)),
              const SizedBox(height: 8),
              Text('Versi terbaru: $latestVersion\nVersi kamu: $currentVersion',
                textAlign: TextAlign.center,
                style: const TextStyle(fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
                  fontSize: 14, color: AppColors.textSub),
              ),
              const SizedBox(height: 16),
              if (changelog.isNotEmpty && changelog != '-')
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.bgDeep,
                    border: Border.all(color: AppColors.border, width: 3),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(changelog, style: const TextStyle(
                    fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
                    fontSize: 12, color: AppColors.textSub),
                  ),
                ),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.pop(ctx),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: AppColors.border, width: 3),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(3, 3))],
                    ),
                    child: const Center(child: Text('NANTI', style: TextStyle(
                      fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary))),
                  ),
                )),
                const SizedBox(width: 12),
                Expanded(child: GestureDetector(
                  onTap: () async {
                    if (downloadUrl.isNotEmpty) {
                      final uri = Uri.parse(downloadUrl);
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      }
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.success,
                      border: Border.all(color: AppColors.border, width: 3),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(3, 3))],
                    ),
                    child: const Center(child: Text('DOWNLOAD', style: TextStyle(
                      fontFamily: 'Bangers', fontSize: 18, color: Colors.white))),
                  ),
                )),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// FORCE UPDATE PAGE (Halaman Wajib Update)
// ═══════════════════════════════════════════════════════════════════════════
class ForceUpdatePage extends StatelessWidget {
  final String currentVersion;
  final String latestVersion;
  final String downloadUrl;
  final String changelog;

  const ForceUpdatePage({
    super.key,
    required this.currentVersion,
    required this.latestVersion,
    required this.downloadUrl,
    required this.changelog,
  });

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(30),
                    decoration: BoxDecoration(
                      color: AppColors.danger,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.border, width: 6),
                      boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(8, 8))],
                    ),
                    child: const Icon(Icons.system_update_rounded, color: Colors.white, size: 80),
                  ),
                  const SizedBox(height: 30),
                  const Text('WAJIB UPDATE!', style: TextStyle(
                    fontFamily: 'Bangers', fontSize: 40, color: AppColors.danger, letterSpacing: 3,
                    shadows: [Shadow(color: AppColors.border, offset: Offset(4, 4))],
                  )),
                  const SizedBox(height: 16),
                  const Text('Versi aplikasi kamu sudah usang.\nSilakan update dulu buat lanjut.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
                      fontSize: 16, color: AppColors.textSub, height: 1.5),
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: AppColors.border, width: 4),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(6, 6))],
                    ),
                    child: Column(
                      children: [
                        _rowInfo('Versi Lama', currentVersion, AppColors.textMuted),
                        const SizedBox(height: 10),
                        _rowInfo('Versi Baru', latestVersion, AppColors.success),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (changelog.isNotEmpty && changelog != '-')
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.gold,
                        border: Border.all(color: AppColors.border, width: 4),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(6, 6))],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('APA YANG BARU?', style: TextStyle(
                            fontFamily: 'Bangers', fontSize: 20, color: AppColors.textPrimary, letterSpacing: 1)),
                          const SizedBox(height: 8),
                          Text(changelog, style: const TextStyle(
                            fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
                            fontSize: 14, color: AppColors.textPrimary, height: 1.5)),
                        ],
                      ),
                    ),
                  const SizedBox(height: 30),
                  GestureDetector(
                    onTap: () async {
                      if (downloadUrl.isNotEmpty) {
                        final uri = Uri.parse(downloadUrl);
                        if (await canLaunchUrl(uri)) {
                          await launchUrl(uri, mode: LaunchMode.externalApplication);
                        }
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: BoxDecoration(
                        color: AppColors.success,
                        border: Border.all(color: AppColors.border, width: 5),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(6, 6))],
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.download_rounded, color: Colors.white, size: 32),
                          SizedBox(width: 12),
                          Text('DOWNLOAD APK BARU', style: TextStyle(
                            fontFamily: 'Bangers', fontSize: 24, color: Colors.white, letterSpacing: 2)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text('Tutup aplikasi lalu install APK baru.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
                      fontSize: 13, color: AppColors.textMuted),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _rowInfo(String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(
          fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: color,
            border: Border.all(color: AppColors.border, width: 2),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(value, style: const TextStyle(
            fontFamily: 'Bangers', fontSize: 16, color: Colors.white, letterSpacing: 1)),
        ),
      ],
    );
  }
}