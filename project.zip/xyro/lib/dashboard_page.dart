// ═══════════════════════════════════════════════════════════════════════════
//  DASHBOARD — FINAL (Video BG + 4 Widget + Quick Access)
//  PART 1/3
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import 'main.dart';
import 'login_page.dart';
import 'home_page.dart';
import 'profile_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'riwayat_page.dart';
import 'contact_page.dart';
import 'pemula_page.dart';
import 'devices_page.dart';
import 'acc.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══ HELPER ROLE ═══
bool _isPemula(String r) => r.toLowerCase() == 'pemula';
bool _canSeller(String r) => [
      'owner',
      'high owner',
      'admin',
      'high admin',
      'reseller',
      'seller'
    ].contains(r.toLowerCase());
bool _canAdmin(String r) =>
    ['owner', 'high owner', 'admin', 'high admin'].contains(r.toLowerCase());
bool _canOwner(String r) =>
    ['owner', 'high owner'].contains(r.toLowerCase());

class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver {
  int _navIndex = 0;

  // CLOCK
  late Timer _clockTimer;
  String _timeStr = '00:00:00';
  String _dateStr = '';

  // WEATHER
  String? _weatherTemp;
  String? _weatherLabel;
  String? _weatherCity;
  IconData _weatherIcon = Icons.cloud_rounded;
  Timer? _weatherTimer;

  // 4 WIDGET STATS
  int _onlineUsers = 0;
  int _connectCount = 0;
  int _totalDevices = 0;
  int _batteryPercent = 0;
  Timer? _statsTimer;
  final _rnd = math.Random();

  // VIDEO BG
  VideoPlayerController? _bgCtrl;
  bool _bgReady = false;
  bool _bgInitializing = false;
  int _bgRetry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startClock();
    _loadWeather();
    _weatherTimer = Timer.periodic(
        const Duration(minutes: 10), (_) => _loadWeather());

    // Init random stats + total devices
    _initStats();
    _loadTotalDevices();
    _statsTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _updateStats();
      _loadTotalDevices();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => _initBg());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _bgCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) {
        c.setVolume(0).catchError((_) {});
        c.setLooping(true).catchError((_) {});
        c.play().catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  // ═══ VIDEO BG ═══
  Future<void> _initBg() async {
    if (_bgInitializing) return;
    _bgInitializing = true;
    try {
      final old = _bgCtrl;
      _bgCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _bgInitializing = false; return; }
      setState(() { _bgCtrl = c; _bgReady = true; });
    } catch (_) {
      _bgInitializing = false;
      if (!mounted) return;
      if (_bgRetry < 3) {
        _bgRetry++;
        Future.delayed(Duration(milliseconds: 400 * _bgRetry), () {
          if (mounted) _initBg();
        });
      }
      return;
    }
    _bgInitializing = false;
  }

  // ═══ CLOCK ═══
  void _startClock() {
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) _updateClock();
    });
  }

  void _updateClock() {
    final now = DateTime.now();
    const days = [
      'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
    ];
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    setState(() {
      _timeStr =
          "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
      _dateStr =
          '${days[now.weekday - 1]}, ${now.day} ${months[now.month - 1]} ${now.year}';
    });
  }

  // ═══ WEATHER ═══
  Future<void> _loadWeather() async {
    try {
      final url = Uri.parse(
          'https://api.open-meteo.com/v1/forecast?latitude=-6.2&longitude=106.8&current_weather=true');
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      final cw = data['current_weather'];
      if (cw == null) return;
      final temp = (cw['temperature'] as num?)?.round();
      final code = (cw['weathercode'] as num?)?.toInt() ?? 0;
      final info = _weatherInfo(code);
      if (!mounted) return;
      setState(() {
        _weatherTemp = temp != null ? '$temp°C' : '--';
        _weatherLabel = info.$1;
        _weatherIcon = info.$2;
        _weatherCity = 'Jakarta';
      });
    } catch (_) {}
  }

  (String, IconData) _weatherInfo(int code) {
    if (code == 0) return ('Cerah', Icons.wb_sunny_rounded);
    if (code >= 1 && code <= 3) return ('Berawan', Icons.cloud_rounded);
    if (code == 45 || code == 48) return ('Berkabut', Icons.foggy);
    if (code >= 51 && code <= 67) return ('Hujan', Icons.grain_rounded);
    if (code >= 71 && code <= 77) return ('Salju', Icons.ac_unit_rounded);
    if (code >= 80 && code <= 82) {
      return ('Hujan Lebat', Icons.water_drop_rounded);
    }
    if (code >= 95) return ('Badai', Icons.thunderstorm_rounded);
    return ('Cuaca', Icons.cloud_rounded);
  }

  // ═══ RANDOM STATS (Online + Connect + Battery) ═══
  void _initStats() {
    _onlineUsers = 100 + _rnd.nextInt(900); // 100-999
    _connectCount = 10 + _rnd.nextInt(90); // 10-99
    _batteryPercent = 60 + _rnd.nextInt(40); // 60-99
  }

  void _updateStats() {
    if (!mounted) return;
    setState(() {
      // Naik/turun sedikit biar keliatan live
      _onlineUsers = (_onlineUsers + _rnd.nextInt(21) - 10).clamp(100, 999);
      _connectCount = (_connectCount + _rnd.nextInt(9) - 4).clamp(10, 99);
      _batteryPercent = 60 + _rnd.nextInt(40);
    });
  }

  // ═══ TOTAL DEVICES (Firebase) ═══
  Future<void> _loadTotalDevices() async {
    try {
      final res = await http.get(Uri.parse(
          'https://naxrat-v3-default-rtdb.firebaseio.com/devices.json'
      )).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() => _totalDevices = 0);
        return;
      }
      final adminId = widget.username;
      int count = 0;
      (data as Map<String, dynamic>).forEach((id, raw) {
        final d = raw as Map<String, dynamic>;
        if (d['admin_id'] == adminId || d['parent'] == adminId) {
          count++;
        }
      });
      if (mounted) setState(() => _totalDevices = count);
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _clockTimer.cancel();
    _weatherTimer?.cancel();
    _statsTimer?.cancel();
    final c = _bgCtrl;
    _bgCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _doLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      drawer: _buildDrawer(),
      extendBody: true,
      body: _bgVideo(
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: _navIndex,
            children: [
              _buildDashboardTab(),
              HomePage(
                username: widget.username,
                password: widget.password,
                listBug: widget.listBug,
                role: widget.role,
                expiredDate: widget.expiredDate,
                sessionKey: widget.sessionKey,
                isActive: _navIndex == 1,
              ),
              ToolsPage(
                sessionKey: widget.sessionKey,
                userRole: widget.role,
                listDoos: widget.listDoos,
                isActive: _navIndex == 2,
              ),
              DevicesPage(
                username: widget.username,
                sessionKey: widget.sessionKey,
                isActive: _navIndex == 3,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _bgCtrl;
    final ready = _bgReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }
  // ═══ DASHBOARD TAB ═══
Widget _buildDashboardTab() {
  return SingleChildScrollView(
    physics: const BouncingScrollPhysics(),
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildHeader(),
        const SizedBox(height: 16),
        _buildBanner(),
        const SizedBox(height: 14),
        _buildClockWeatherRow(),
        const SizedBox(height: 10),
        _buildStatsRow1(),
        const SizedBox(height: 10),
        _buildStatsRow2(),
        const SizedBox(height: 24),
        _buildSectionTitle('QUICK ACCESS'),
        const SizedBox(height: 12),
        _buildQuickActions(),
      ],
    ),
  );
}

// ═══ HEADER ═══
Widget _buildHeader() {
  return _glass(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    child: Row(
      children: [
        Builder(
          builder: (ctx) => GestureDetector(
            onTap: () => Scaffold.of(ctx).openDrawer(),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.menu_rounded,
                  color: Colors.white, size: 22),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.red.withOpacity(0.15),
            border: Border.all(color: _C.red, width: 1.5),
          ),
          child: const Icon(Icons.person, color: _C.red, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.username.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1)),
              const SizedBox(height: 4),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _C.red,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(widget.role.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          color: Colors.black,
                          letterSpacing: 1)),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('• ${widget.expiredDate}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 10, color: _C.muted)),
                ),
              ]),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: _C.red.withOpacity(0.15),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _C.red.withOpacity(0.5)),
          ),
          child: Row(children: [
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                  color: _C.red, shape: BoxShape.circle),
            ),
            const SizedBox(width: 6),
            const Text('LIVE',
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: _C.red,
                    letterSpacing: 1)),
          ]),
        ),
      ],
    ),
  );
}

// ═══ BANNER (clean) ═══
Widget _buildBanner() {
  return ClipRRect(
    borderRadius: BorderRadius.circular(18),
    child: Container(
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Stack(fit: StackFit.expand, children: [
        Image.asset(
          'assets/images/banner.jpg',
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF1A0000), Color(0xFF000000)],
              ),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.1),
                Colors.black.withOpacity(0.85),
              ],
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.all(18),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Text('XYRO',
                    style: TextStyle(
                        fontSize: 38,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 3,
                        height: 0.9)),
                SizedBox(width: 6),
                Text('//',
                    style: TextStyle(
                        fontSize: 38,
                        fontWeight: FontWeight.w900,
                        color: _C.red,
                        height: 0.9)),
              ]),
              SizedBox(height: 4),
              Text('[ TACTICAL OPS v2.0 ]',
                  style: TextStyle(
                      fontSize: 9,
                      color: _C.muted,
                      letterSpacing: 2)),
            ],
          ),
        ),
      ]),
    ),
  );
}

// ═══ CLOCK + WEATHER ROW ═══
Widget _buildClockWeatherRow() {
  return Row(
    children: [
      Expanded(
        child: _glass(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.access_time_rounded,
                    color: _C.red, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_timeStr,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 1.5,
                            height: 1)),
                    const SizedBox(height: 3),
                    Text(_dateStr,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 9,
                            color: _C.muted,
                            letterSpacing: 0.3)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: _glass(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: Icon(_weatherIcon, color: _C.red, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_weatherTemp ?? '--',
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 1,
                            height: 1)),
                    const SizedBox(height: 3),
                    Text(
                        '${_weatherLabel ?? "..."} • ${_weatherCity ?? "-"}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 9,
                            color: _C.muted,
                            letterSpacing: 0.3)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}

// ═══ STATS ROW 1 — ONLINE + CONNECT ═══
Widget _buildStatsRow1() {
  return Row(
    children: [
      Expanded(
        child: _statCard(
          label: 'ONLINE USER',
          value: '$_onlineUsers',
          icon: Icons.circle,
          dotColor: const Color(0xFF22C55E), // hijau
          iconColor: const Color(0xFF22C55E),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: _statCard(
          label: 'CONNECT',
          value: '$_connectCount',
          icon: Icons.circle,
          dotColor: _C.red,
          iconColor: _C.red,
        ),
      ),
    ],
  );
}

// ═══ STATS ROW 2 — DEVICES + BATTERY ═══
Widget _buildStatsRow2() {
  return Row(
    children: [
      Expanded(
        child: _statCard(
          label: 'TOTAL DEVICES',
          value: '$_totalDevices',
          icon: Icons.phone_android_rounded,
          iconColor: _C.red,
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: _statCard(
          label: 'BATTERY',
          value: '$_batteryPercent%',
          icon: Icons.battery_full_rounded,
          iconColor: _C.red,
        ),
      ),
    ],
  );
}

Widget _statCard({
  required String label,
  required String value,
  required IconData icon,
  required Color iconColor,
  Color? dotColor,
}) {
  return _glass(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: iconColor.withOpacity(0.5)),
          ),
          child: Icon(icon,
              color: dotColor ?? iconColor,
              size: dotColor != null ? 12 : 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: _C.muted,
                      letterSpacing: 1)),
              const SizedBox(height: 3),
              Text(value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 0.5,
                      height: 1)),
            ],
          ),
        ),
      ],
    ),
  );
}

// ═══ SECTION TITLE ═══
Widget _buildSectionTitle(String title) {
  return Row(
    children: [
      Text(title,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            letterSpacing: 2,
          )),
      const SizedBox(width: 10),
      Expanded(
        child: Container(
          height: 1,
          color: Colors.white.withOpacity(0.15),
        ),
      ),
    ],
  );
}

// ═══ QUICK ACTIONS ═══
Widget _buildQuickActions() {
  return GridView.count(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    crossAxisCount: 2,
    crossAxisSpacing: 12,
    mainAxisSpacing: 12,
    childAspectRatio: 1.25,
    children: [
      _qaBtn(Icons.bolt_rounded, 'ATTACK', () {
        setState(() => _navIndex = 1);
      }),
      _qaBtn(Icons.build_rounded, 'TOOLS', () {
        setState(() => _navIndex = 2);
      }),
      _qaBtn(Icons.phone_android_rounded, 'RAT', () {
        setState(() => _navIndex = 3);
      }),
      _qaBtn(Icons.chat_rounded, 'SENDER', () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BugSenderPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
              role: widget.role,
            ),
          ),
        );
      }),
    ],
  );
}

Widget _qaBtn(IconData icon, String label, VoidCallback onTap) {
  return GestureDetector(
    onTap: () {
      HapticFeedback.lightImpact();
      onTap();
    },
    child: _glass(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.red.withOpacity(0.6)),
            ),
            child: Icon(icon, color: _C.red, size: 28),
          ),
          const SizedBox(height: 12),
          Text(label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 1.5,
              )),
        ],
      ),
    ),
  );
}
  // ═══ BOTTOM NAV ═══
  Widget _buildBottomNav() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            height: 72,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.55),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              children: [
                _navItem(Icons.grid_view_rounded, 'HOME', 0),
                _navItem(Icons.bolt_rounded, 'ATTACK', 1),
                _navItem(Icons.build_rounded, 'TOOLS', 2),
                _navItem(Icons.phone_android_rounded, 'RAT', 3),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int index) {
    final active = _navIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _navIndex = index);
        },
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: active ? _C.red : Colors.white.withOpacity(0.4),
              size: 24,
            ),
            if (active) ...[
              const SizedBox(height: 4),
              Text(label,
                  style: const TextStyle(
                    fontSize: 9,
                    color: _C.red,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  )),
            ],
          ],
        ),
      ),
    );
  }

  // ═══ GLASS CARD ═══
  Widget _glass({
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(20),
    double radius = 18,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  // ═══ DRAWER ═══
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.92),
          border: Border(
              right: BorderSide(color: Colors.white.withOpacity(0.08))),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ─── HEADER DRAWER ───
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                child: _glass(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.red.withOpacity(0.15),
                          border: Border.all(color: _C.red, width: 1.5),
                        ),
                        child: const Icon(Icons.person,
                            color: _C.red, size: 26),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.username.toUpperCase(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: 1)),
                            const SizedBox(height: 5),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: _C.red,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(widget.role.toUpperCase(),
                                  style: const TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.black,
                                      letterSpacing: 1)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ─── MENU LIST ───
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    _drawerSection('PANEL AKSES'),

                    if (_isPemula(widget.role))
                      _drawerItem(Icons.school_rounded, 'PEMULA PANEL', () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => PemulaPage(
                                    sessionKey: widget.sessionKey,
                                    username: widget.username)));
                      }),

                    if (_isPemula(widget.role))
                      _drawerItem(
                          Icons.verified_user_rounded, 'ACC AKUN', () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => AccPage(
                                    sessionKey: widget.sessionKey,
                                    username: widget.username,
                                    role: widget.role)));
                      }),

                    if (_canSeller(widget.role))
                      _drawerItem(Icons.storefront_rounded, 'SELLER PANEL',
                          () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    SellerPage(keyToken: widget.sessionKey)));
                      }),

                    if (_canAdmin(widget.role))
                      _drawerItem(Icons.admin_panel_settings_rounded,
                          'ADMIN PANEL', () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    AdminPage(sessionKey: widget.sessionKey)));
                      }),

                    if (_canOwner(widget.role))
                      _drawerItem(Icons.workspace_premium_rounded,
                          'OWNER PANEL', () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => OwnerPage(
                                    sessionKey: widget.sessionKey,
                                    username: widget.username)));
                      }),

                    const SizedBox(height: 20),
                    _drawerSection('MENU'),

                    _drawerItem(Icons.person_rounded, 'Profil Saya', () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ProfilePage(
                                  username: widget.username,
                                  password: widget.password,
                                  role: widget.role,
                                  expiredDate: widget.expiredDate,
                                  sessionKey: widget.sessionKey)));
                    }),

                    _drawerItem(Icons.history_rounded, 'Riwayat Log', () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => RiwayatPage(
                                  sessionKey: widget.sessionKey,
                                  role: widget.role)));
                    }),

                    _drawerItem(Icons.headset_mic_rounded, 'Hubungi Support',
                        () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const ContactPage()));
                    }),
                  ],
                ),
              ),

              // ─── LOGOUT ───
              Padding(
                padding: const EdgeInsets.all(20),
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    _doLogout();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: _C.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.red.withOpacity(0.6)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.logout_rounded, color: _C.red, size: 18),
                        SizedBox(width: 8),
                        Text('LOGOUT',
                            style: TextStyle(
                                color: _C.red,
                                fontWeight: FontWeight.w900,
                                fontSize: 12,
                                letterSpacing: 1.5)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _drawerSection(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 4),
      child: Text(title,
          style: TextStyle(
              fontSize: 11,
              color: Colors.white.withOpacity(0.5),
              letterSpacing: 2,
              fontWeight: FontWeight.w800)),
    );
  }

  Widget _drawerItem(IconData icon, String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 12),
              Text(label,
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: 0.5)),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}