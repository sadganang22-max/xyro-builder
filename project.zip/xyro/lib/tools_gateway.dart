// ═══════════════════════════════════════════════════════════════════════════
//  TOOLS PAGE — TACTICAL ARSENAL (GLASS BLACK + VIDEO BG + ISACTIVE)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'all_quran.dart';
import 'pantun.dart';
import 'kata_kata.dart';
import 'puisi.dart';
import 'main.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══════════════════════════════════════════════════════════════════════════
class _ToolCategory {
  final String id, title, subtitle, count;
  final IconData icon;
  final Color accent;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.count,
  });
}

final _categories = [
  _ToolCategory(
      id: 'ddos',
      title: 'DDoS',
      subtitle: 'Attack',
      icon: Icons.bolt_rounded,
      accent: _C.red,
      count: '2'),
  _ToolCategory(
      id: 'network',
      title: 'Network',
      subtitle: 'WiFi',
      icon: Icons.wifi_tethering_rounded,
      accent: _C.red,
      count: '3'),
  _ToolCategory(
      id: 'osint',
      title: 'OSINT',
      subtitle: 'Info',
      icon: Icons.travel_explore_rounded,
      accent: _C.red,
      count: '3'),
  _ToolCategory(
      id: 'downloader',
      title: 'Download',
      subtitle: 'Sosmed',
      icon: Icons.cloud_download_rounded,
      accent: _C.red,
      count: '2'),
  _ToolCategory(
      id: 'utilities',
      title: 'Utility',
      subtitle: 'Extra',
      icon: Icons.construction_rounded,
      accent: _C.red,
      count: '3'),
  _ToolCategory(
      id: 'quran',
      title: 'Al-Quran',
      subtitle: 'Surat',
      icon: Icons.menu_book_rounded,
      accent: _C.red,
      count: '114'),
  _ToolCategory(
      id: 'pantun',
      title: 'Pantun',
      subtitle: 'Lucu',
      icon: Icons.auto_stories_rounded,
      accent: _C.red,
      count: '30'),
  _ToolCategory(
      id: 'katakata',
      title: 'Kata',
      subtitle: 'Bijak',
      icon: Icons.format_quote_rounded,
      accent: _C.red,
      count: '53'),
  _ToolCategory(
      id: 'puisi',
      title: 'Puisi',
      subtitle: 'Cinta',
      icon: Icons.menu_book_rounded,
      accent: _C.red,
      count: '30'),
];

// ═══════════════════════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey, userRole;
  final List<Map<String, dynamic>> listDoos;
  final bool isActive;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    this.isActive = true,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with WidgetsBindingObserver {
  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    }
  }

  @override
  void didUpdateWidget(covariant ToolsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !_videoReady && !_videoInitializing) {
      _initVideo();
    } else if (!widget.isActive && _vCtrl != null) {
      final c = _vCtrl;
      _vCtrl = null;
      _videoReady = false;
      if (c != null) {
        try { c.pause(); } catch (_) {}
        try { c.dispose(); } catch (_) {}
      }
    }
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (widget.isActive && !c.value.isPlaying) {
        c.setVolume(0).catchError((_) {});
        c.setLooping(true).catchError((_) {});
        c.play().catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          bottom: false,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 140),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeader(),
                const SizedBox(height: 26),
                _buildSectionTitle('MODULES'),
                const SizedBox(height: 14),
                _buildCategoryGrid(),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ HEADER ═══
  Widget _buildHeader() {
    return _GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.red, width: 1.5),
            ),
            child: const Icon(Icons.build_rounded, color: _C.red, size: 26),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TOOLS ARSENAL',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 2)),
                SizedBox(height: 4),
                Text('SELECT MODULE TO EXECUTE',
                    style: TextStyle(
                        fontSize: 11,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ SECTION TITLE ═══
  Widget _buildSectionTitle(String t) => Row(children: [
        const Text('//',
            style: TextStyle(
                fontWeight: FontWeight.w900,
                color: _C.red,
                fontSize: 16)),
        const SizedBox(width: 8),
        Text(t,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 2)),
        const SizedBox(width: 12),
        Expanded(
            child: Container(height: 1, color: Colors.white.withOpacity(0.1))),
      ]);

  // ═══ CATEGORY GRID ═══
  Widget _buildCategoryGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 1.05,
      ),
      itemCount: _categories.length,
      itemBuilder: (_, i) {
        final cat = _categories[i];
        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            _onCategoryTap(cat.id);
          },
          child: _GlassCard(
            padding: const EdgeInsets.all(16),
            child: Stack(
              children: [
                Positioned(
                  right: -14,
                  bottom: -14,
                  child: Icon(cat.icon,
                      size: 90, color: _C.red.withOpacity(0.06)),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: _C.red.withOpacity(0.14),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: _C.red.withOpacity(0.6), width: 1),
                          ),
                          child: Icon(cat.icon, color: _C.red, size: 22),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.1)),
                          ),
                          child: Text(cat.count,
                              style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: _C.muted)),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(cat.title.toUpperCase(),
                            style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: 1)),
                        const SizedBox(height: 2),
                        Text(cat.subtitle.toUpperCase(),
                            style: const TextStyle(
                                fontSize: 10,
                                color: _C.muted,
                                letterSpacing: 1.5)),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══ AKSI KLIK KATEGORI ═══
  void _onCategoryTap(String id) {
    switch (id) {
      case 'ddos':
        _showSheet(_ddosItems(), 'DDoS PANEL');
        break;
      case 'network':
        _showSheet(_networkItems(), 'NETWORK WIFI');
        break;
      case 'osint':
        _showSheet(_osintItems(), 'OSINT');
        break;
      case 'downloader':
        _showSheet(_downloaderItems(), 'DOWNLOADER');
        break;
      case 'utilities':
        _showSheet(_utilityItems(), 'UTILITY');
        break;
      case 'quran':
        Navigator.push(context, _slideRoute(const AllQuranPage()));
        break;
      case 'pantun':
        Navigator.push(context, _slideRoute(const PantunPage()));
        break;
      case 'katakata':
        Navigator.push(context, _slideRoute(const KataKataPage()));
        break;
      case 'puisi':
        Navigator.push(context, _slideRoute(const PuisiPage()));
        break;
    }
  }

  // ═══ ITEM LISTS ═══
  List<_ToolItem> _ddosItems() => [
        _ToolItem(
            icon: Icons.bolt_rounded,
            label: 'Attack Panel',
            desc: 'Mulai serangan DDoS',
            onTap: () => Navigator.push(
                context,
                _slideRoute(AttackPanel(
                    sessionKey: widget.sessionKey,
                    listDoos: widget.listDoos)))),
        _ToolItem(
            icon: Icons.dns_rounded,
            label: 'Manage Server',
            desc: 'Kontrol server',
            onTap: () => Navigator.push(context,
                _slideRoute(ManageServerPage(keyToken: widget.sessionKey)))),
      ];

  List<_ToolItem> _networkItems() => [
        _ToolItem(
            icon: Icons.newspaper_outlined,
            label: 'Spam NGL',
            desc: 'Kirim pesan massal',
            onTap: () => Navigator.push(context, _slideRoute(NglPage()))),
        _ToolItem(
            icon: Icons.wifi_off_rounded,
            label: 'WiFi Killer (Int)',
            desc: 'Serang jaringan internal',
            onTap: () =>
                Navigator.push(context, _slideRoute(WifiKillerPage()))),
        if (widget.userRole == 'vip' || widget.userRole == 'owner')
          _ToolItem(
              icon: Icons.router_rounded,
              label: 'WiFi Killer (Ext)',
              desc: 'Serang jaringan eksternal',
              onTap: () => Navigator.push(context,
                  _slideRoute(WifiInternalPage(sessionKey: widget.sessionKey)))),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: Icons.badge_outlined,
            label: 'NIK Detail',
            desc: 'Cek data NIK',
            onTap: () =>
                Navigator.push(context, _slideRoute(const DomainOsintPage()))),
        _ToolItem(
            icon: Icons.person_search_rounded,
            label: 'Phone Lookup',
            desc: 'Lacak nomor HP',
            onTap: () {}),
        _ToolItem(
            icon: Icons.alternate_email_rounded,
            label: 'Email OSINT',
            desc: 'Cek email',
            onTap: () {}),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: Icons.video_library_rounded,
            label: 'TikTok DL',
            desc: 'Simpan video TikTok',
            onTap: () => Navigator.push(
                context, _slideRoute(const TiktokDownloaderPage()))),
        _ToolItem(
            icon: Icons.camera_alt_rounded,
            label: 'Instagram DL',
            desc: 'Simpan foto & video IG',
            onTap: () => Navigator.push(
                context, _slideRoute(const InstagramDownloaderPage()))),
      ];

  List<_ToolItem> _utilityItems() => [
        _ToolItem(
            icon: Icons.qr_code_2_rounded,
            label: 'QR Generator',
            desc: 'Buat QR Code',
            onTap: () => Navigator.push(
                context, _slideRoute(const QrGeneratorPage()))),
        _ToolItem(
            icon: Icons.security_rounded,
            label: 'IP Scanner',
            desc: 'Scan IP',
            onTap: () {}),
        _ToolItem(
            icon: Icons.network_check_rounded,
            label: 'Port Scanner',
            desc: 'Scan port terbuka',
            onTap: () {}),
      ];

  // ═══ BOTTOM SHEET ═══
  void _showSheet(List<_ToolItem> items, String title) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.72),
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.85),
              border: Border(
                  top: BorderSide(
                      color: Colors.white.withOpacity(0.12), width: 1)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  const Icon(Icons.terminal, color: _C.red, size: 22),
                  const SizedBox(width: 10),
                  Text(title,
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 2)),
                ]),
                const SizedBox(height: 18),
                Flexible(
                  child: ListView.separated(
                    padding: const EdgeInsets.only(bottom: 12),
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (ctx, i) {
                      final it = items[i];
                      return GestureDetector(
                        onTap: () {
                          Navigator.pop(ctx);
                          it.onTap();
                        },
                        child: _GlassCard(
                          padding: const EdgeInsets.all(16),
                          child: Row(children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _C.red.withOpacity(0.14),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: _C.red.withOpacity(0.6), width: 1),
                              ),
                              child:
                                  Icon(it.icon, color: _C.red, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(it.label.toUpperCase(),
                                      style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.white,
                                          letterSpacing: 1)),
                                  const SizedBox(height: 3),
                                  Text(it.desc,
                                      style: const TextStyle(
                                          fontSize: 11, color: _C.muted)),
                                ],
                              ),
                            ),
                            const Icon(Icons.arrow_forward_ios,
                                color: _C.muted, size: 14),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DATA MODEL
// ═══════════════════════════════════════════════════════════════════════════
class _ToolItem {
  final IconData icon;
  final String label, desc;
  final VoidCallback onTap;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.desc = '',
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SLIDE ROUTE
// ═══════════════════════════════════════════════════════════════════════════
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );