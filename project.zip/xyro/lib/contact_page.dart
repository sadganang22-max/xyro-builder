// ═══════════════════════════════════════════════════════════════════════════
//  CONTACT PAGE — GLASS BLACK + VIDEO BG + B/W/R
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══ CONTACT DATA ═══
class _Contact {
  final String label, handle, badge;
  final IconData icon;
  final String url;
  const _Contact({
    required this.label,
    required this.handle,
    required this.icon,
    required this.url,
    this.badge = 'ONLINE',
  });
}

const _contacts = [
  _Contact(
    label: 'Telegram',
    handle: '@Criminalbug',
    icon: FontAwesomeIcons.telegram,
    url: 'https://t.me/Criminalbug',
    badge: 'FAST',
  ),
  _Contact(
    label: 'WhatsApp',
    handle: '62813xxxxxxx',
    icon: FontAwesomeIcons.whatsapp,
    url: 'https://wa.me/6282xxx',
    badge: 'BOT',
  ),
  _Contact(
    label: 'TikTok',
    handle: '@hanzzz.207',
    icon: FontAwesomeIcons.tiktok,
    url: 'https://www.tiktok.com/@hanzz7?_r=1&_t=ZS-95Xu8Hv3naq',
    badge: 'MEDIA',
  ),
];

// ═══════════════════════════════════════════════════════════════════════════
class ContactPage extends StatefulWidget {
  const ContactPage({super.key});
  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage>
    with WidgetsBindingObserver {
  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Tidak dapat membuka link',
              style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.black.withOpacity(0.9),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: _C.red.withOpacity(0.5)),
          ),
        ));
      }
    }
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(children: [
            _buildTopBar(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 40),
                child: Column(children: [
                  _buildHero(),
                  const SizedBox(height: 22),
                  _buildSectionTitle('CHANNELS'),
                  const SizedBox(height: 12),
                  _buildContactList(),
                  const SizedBox(height: 22),
                  _buildSectionTitle('STATUS'),
                  const SizedBox(height: 12),
                  _buildStatusRow(),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SUPPORT HUB',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('HUBUNGI KAMI 24/7',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.red.withOpacity(0.5)),
            ),
            child: Row(children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                    color: _C.red, shape: BoxShape.circle),
              ),
              const SizedBox(width: 6),
              const Text('ONLINE',
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: _C.red,
                      letterSpacing: 1)),
            ]),
          ),
        ],
      ),
    );
  }

  // ═══ HERO ═══
  Widget _buildHero() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Stack(fit: StackFit.expand, children: [
          Image.asset(
            'assets/images/ppp.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A0000), Color(0xFF000000)],
                ),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.85),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.red,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('SUPPORT ACTIVE',
                      style: TextStyle(
                          fontSize: 9,
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5)),
                ),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('CONTACT US',
                        style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 4,
                            height: 0.9)),
                    SizedBox(height: 4),
                    Text('[ 24/7 · FAST · RELIABLE ]',
                        style: TextStyle(
                            fontSize: 10,
                            color: _C.muted,
                            letterSpacing: 2)),
                  ],
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  // ═══ SECTION TITLE ═══
  Widget _buildSectionTitle(String title) => Row(children: [
        const Text('//',
            style: TextStyle(
                fontWeight: FontWeight.w900,
                color: _C.red,
                fontSize: 14)),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 2)),
        const SizedBox(width: 10),
        Expanded(
            child:
                Container(height: 1, color: Colors.white.withOpacity(0.1))),
      ]);

  // ═══ CONTACT LIST ═══
  Widget _buildContactList() {
    return Column(children: [
      for (int i = 0; i < _contacts.length; i++) ...[
        _ContactCard(
          contact: _contacts[i],
          onTap: () => _launch(_contacts[i].url),
        ),
        if (i < _contacts.length - 1) const SizedBox(height: 10),
      ],
    ]);
  }

  // ═══ STATUS ROW ═══
  Widget _buildStatusRow() {
    return Row(children: [
      Expanded(
          child: _statusCard(
              icon: Icons.bolt_rounded, label: 'FAST', value: '< 5 min')),
      const SizedBox(width: 10),
      Expanded(
          child: _statusCard(
              icon: Icons.shield_rounded, label: 'SECURE', value: 'E2E')),
      const SizedBox(width: 10),
      Expanded(
          child: _statusCard(
              icon: Icons.access_time_rounded,
              label: 'HOURS',
              value: '24/7')),
    ]);
  }

  Widget _statusCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return _GlassCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.red.withOpacity(0.15),
            border: Border.all(color: _C.red.withOpacity(0.5), width: 1.2),
          ),
          child: Icon(icon, color: _C.red, size: 15),
        ),
        const SizedBox(height: 8),
        Text(value,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w900,
                color: _C.red,
                letterSpacing: 1)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(
                fontSize: 7,
                color: _C.muted,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w800),
            textAlign: TextAlign.center),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CONTACT CARD
// ═══════════════════════════════════════════════════════════════════════════
class _ContactCard extends StatefulWidget {
  final _Contact contact;
  final VoidCallback onTap;
  const _ContactCard({required this.contact, required this.onTap});

  @override
  State<_ContactCard> createState() => _ContactCardState();
}

class _ContactCardState extends State<_ContactCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final c = widget.contact;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: _GlassCard(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: _C.red.withOpacity(_pressed ? 0.3 : 0.15),
                border: Border.all(
                    color: _C.red.withOpacity(_pressed ? 0.9 : 0.6),
                    width: 1.5),
              ),
              child: Center(
                  child: FaIcon(c.icon, color: _C.red, size: 24)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(children: [
                    Text(c.label,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 0.5)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: _C.red.withOpacity(0.15),
                        border:
                            Border.all(color: _C.red.withOpacity(0.5)),
                      ),
                      child: Text(c.badge,
                          style: const TextStyle(
                              fontSize: 8,
                              color: _C.red,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1)),
                    ),
                  ]),
                  const SizedBox(height: 4),
                  Text(c.handle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 12, color: _C.muted)),
                ],
              ),
            ),
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(9),
                color: _pressed
                    ? _C.red.withOpacity(0.25)
                    : Colors.white.withOpacity(0.05),
                border: Border.all(
                    color: _pressed
                        ? _C.red.withOpacity(0.7)
                        : Colors.white.withOpacity(0.1)),
              ),
              child: Icon(Icons.arrow_forward_ios_rounded,
                  color: _pressed ? _C.red : _C.muted, size: 14),
            ),
          ]),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}