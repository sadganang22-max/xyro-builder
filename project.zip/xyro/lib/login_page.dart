// ═══════════════════════════════════════════════════════════════════════════
//  LOGIN PAGE — TACTICAL OPS (GLASS BLACK + VIDEO BG)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';
import 'splash.dart';

const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with WidgetsBindingObserver {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _obscurePass = true;
  String? _androidId;
  String? _errorMsg;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initVideo();
    _getDeviceId();
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized && !v.isPlaying &&
            v.position >= v.duration && v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      if (mounted) setState(() => _videoReady = false);
    } finally {
      _videoInitializing = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (s == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (s == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    userCtrl.dispose();
    passCtrl.dispose();
    _vCtrl?.dispose();
    super.dispose();
  }

  Future<void> _getDeviceId() async {
    try {
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      if (mounted) setState(() => _androidId = android.id);
      await _tryAutoLogin();
    } catch (_) {
      await _tryAutoLogin();
    }
  }

  Future<void> _tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');
    if (savedUser == null || savedPass == null || savedKey == null) return;
    try {
      final aid = _androidId ?? 'unknown';
      final res = await http.get(Uri.parse(
          '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$aid&key=$savedKey'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => SplashScreen(
                      username: savedUser,
                      password: savedPass,
                      role: data['role'] ?? 'member',
                      expiredDate: data['expiredDate'] ?? '-',
                      sessionKey: data['key'] ?? savedKey,
                      listBug: _parseList(data['listBug']),
                      listDoos: _parseList(data['listDDoS']),
                      news: _parseList(data['news']),
                    )));
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();

  Future<void> _doLogin() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    try {
      final resp = await http.post(
        Uri.parse('$baseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': _androidId ?? 'unknown',
        },
      ).timeout(const Duration(seconds: 12));

      final data = jsonDecode(resp.body);

      if (data['expired'] == true) {
        setState(() =>
            _errorMsg = 'AKSES EXPIRED. SILAKAN PERPANJANG.');
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') ||
            msg.contains('device') ||
            msg.contains('another')) {
          setState(() =>
              _errorMsg = 'AKUN TERDETEKSI DI PERANGKAT LAIN.');
        } else {
          setState(() =>
              _errorMsg = 'AKSES DITOLAK. USERNAME ATAU PASSWORD SALAH.');
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key', data['key'] ?? '');

        if (!mounted) return;
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => SplashScreen(
                      username: username,
                      password: password,
                      role: data['role'] ?? 'member',
                      expiredDate: data['expiredDate'] ?? '-',
                      sessionKey: data['key'] ?? '',
                      listBug: _parseList(data['listBug']),
                      listDoos: _parseList(data['listDDoS']),
                      news: _parseList(data['news']),
                    )));
      }
    } catch (e) {
      setState(() => _errorMsg = 'KONEKSI GAGAL. PERIKSA JARINGAN.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: _buildLoginCard(),
            ),
          ),
        ),
      ),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0F),
                  Color(0xFF15121C),
                  Color(0xFF0A0A0F),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: ClipRect(child: _CoverVideo(controller: c)),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ LOGIN CARD ═══
  Widget _buildLoginCard() {
    return _GlassCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ─── HEADER ───
          Container(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 22),
            decoration: BoxDecoration(
              border: Border(
                  bottom:
                      BorderSide(color: Colors.white.withOpacity(0.08))),
            ),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.blood.withOpacity(0.12),
                    border: Border.all(
                        color: AppColors.blood.withOpacity(0.8), width: 2),
                  ),
                  child: const Icon(Icons.lock_rounded,
                      color: AppColors.blood, size: 34),
                ),
                const SizedBox(height: 18),
                const Text('SYS.AUTHENTICATION',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 2.5)),
                const SizedBox(height: 6),
                const Text('ENTER CREDENTIALS TO ACCESS SYSTEM',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 10,
                        color: AppColors.textMuted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),

          // ─── FORM ───
          Padding(
            padding: const EdgeInsets.all(22),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (_errorMsg != null) ...[
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.blood.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: AppColors.blood.withOpacity(0.6)),
                      ),
                      child: Row(children: [
                        const Icon(Icons.warning_amber_rounded,
                            color: AppColors.blood, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                            child: Text(_errorMsg!,
                                style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.blood,
                                    height: 1.4))),
                      ]),
                    ),
                    const SizedBox(height: 18),
                  ],

                  _TacticalField(
                    controller: userCtrl,
                    label: 'OPERATOR ID',
                    hint: 'Masukkan username...',
                    icon: Icons.person_rounded,
                    focusColor: AppColors.cyan,
                    validator: (v) =>
                        (v == null || v.isEmpty) ? 'USERNAME WAJIB DIISI' : null,
                  ),
                  const SizedBox(height: 18),

                  _TacticalField(
                    controller: passCtrl,
                    label: 'ACCESS KEY',
                    hint: 'Masukkan password...',
                    icon: Icons.vpn_key_rounded,
                    focusColor: AppColors.blood,
                    obscure: _obscurePass,
                    suffix: IconButton(
                      icon: Icon(
                        _obscurePass
                            ? Icons.visibility_off_rounded
                            : Icons.visibility_rounded,
                        color: AppColors.textMuted,
                        size: 20,
                      ),
                      onPressed: () =>
                          setState(() => _obscurePass = !_obscurePass),
                    ),
                    validator: (v) =>
                        (v == null || v.isEmpty) ? 'PASSWORD WAJIB DIISI' : null,
                    onSubmit: (_) => _doLogin(),
                  ),
                  const SizedBox(height: 26),

                  // TOMBOL LOGIN
                  GestureDetector(
                    onTap: _isLoading ? null : _doLogin,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      height: 58,
                      decoration: BoxDecoration(
                        color: _isLoading
                            ? Colors.white.withOpacity(0.06)
                            : AppColors.blood,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: _isLoading
                                ? Colors.white.withOpacity(0.12)
                                : AppColors.blood,
                            width: 1.5),
                        boxShadow: _isLoading
                            ? []
                            : [
                                BoxShadow(
                                    color: AppColors.blood.withOpacity(0.4),
                                    blurRadius: 18,
                                    offset: const Offset(0, 6)),
                              ],
                      ),
                      child: Center(
                        child: _isLoading
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                    color: AppColors.textMuted,
                                    strokeWidth: 3))
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.bolt,
                                      color: Colors.black, size: 22),
                                  SizedBox(width: 8),
                                  Text('EXECUTE LOGIN',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.black,
                                          letterSpacing: 2)),
                                ],
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ─── FOOTER ───
          Container(
            padding:
                const EdgeInsets.symmetric(vertical: 22, horizontal: 22),
            decoration: BoxDecoration(
              border: Border(
                  top: BorderSide(color: Colors.white.withOpacity(0.08))),
            ),
            child: Column(
              children: [
                const Text('NO ACCESS CREDENTIALS?',
                    style: TextStyle(
                        fontSize: 10,
                        color: AppColors.textMuted,
                        letterSpacing: 1.5)),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: () => _launch('https://t.me/Criminalbug'),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 22, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.cyan.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppColors.cyan.withOpacity(0.6)),
                    ),
                    child: const Text('[ REQUEST ACCESS ]',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.cyan,
                            letterSpacing: 1.5)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// TACTICAL FIELD (glass input)
// ═══════════════════════════════════════════════════════════════════════════
class _TacticalField extends StatefulWidget {
  final TextEditingController controller;
  final String label, hint;
  final IconData icon;
  final Color focusColor;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;
  final void Function(String)? onSubmit;

  const _TacticalField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    required this.focusColor,
    this.obscure = false,
    this.suffix,
    this.validator,
    this.onSubmit,
  });

  @override
  State<_TacticalField> createState() => _TacticalFieldState();
}

class _TacticalFieldState extends State<_TacticalField> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.label,
            style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textMuted,
                letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Focus(
          onFocusChange: (f) => setState(() => _focused = f),
          child: TextFormField(
            controller: widget.controller,
            obscureText: widget.obscure,
            onFieldSubmitted: widget.onSubmit,
            style: const TextStyle(fontSize: 15, color: Colors.white),
            decoration: InputDecoration(
              hintText: widget.hint,
              hintStyle: const TextStyle(
                  fontSize: 14, color: Color(0xFF444444)),
              prefixIcon: Icon(widget.icon,
                  color: _focused ? widget.focusColor : AppColors.textMuted,
                  size: 20),
              suffixIcon: widget.suffix,
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 18),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.12)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: widget.focusColor, width: 1.5),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    BorderSide(color: AppColors.blood.withOpacity(0.7)),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    const BorderSide(color: AppColors.blood, width: 1.5),
              ),
              errorStyle: const TextStyle(
                  color: AppColors.blood, fontSize: 10, letterSpacing: 1),
            ),
            validator: widget.validator,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}