// ═══════════════════════════════════════════════════════════════════════════
//  ACC PAGE — GLASS BLACK + VIDEO BG + B/W/R
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'main.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

class AccConfig {
  static const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';
}

class AccPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const AccPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<AccPage> createState() => _AccPageState();
}

class _AccPageState extends State<AccPage>
    with WidgetsBindingObserver {
  int _pageIndex = 0;

  List<Map<String, dynamic>> _pendingList = [];
  List<Map<String, dynamic>> _historyList = [];
  List<Map<String, dynamic>> _filteredPending = [];
  bool _loading = true;
  String? _error;
  String _searchQuery = '';

  final TextEditingController _searchCtrl = TextEditingController();
  Timer? _autoRefreshTimer;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _searchCtrl.addListener(() {
      setState(() {
        _searchQuery = _searchCtrl.text.toLowerCase();
        _applyFilter();
      });
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());

    _loadPending();
    _loadHistory();

    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _loadPending();
        _loadHistory();
      }
    });
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _autoRefreshTimer?.cancel();
    _searchCtrl.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      _filteredPending = List.from(_pendingList);
    } else {
      _filteredPending = _pendingList.where((u) {
        final name = (u['username'] ?? '').toString().toLowerCase();
        return name.contains(_searchQuery);
      }).toList();
    }
  }

  Future<void> _loadPending() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final url = Uri.parse(
          '${AccConfig.baseUrl}/pemula/pending?key=${widget.sessionKey}');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        if (!mounted) return;
        setState(() {
          _pendingList =
              List<Map<String, dynamic>>.from(data['pending'] ?? []);
          _loading = false;
        });
        _applyFilter();
      } else {
        if (!mounted) return;
        setState(() {
          _error = data['message'] ?? 'Gagal load pending';
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Koneksi error: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadHistory() async {
    try {
      final url = Uri.parse(
          '${AccConfig.baseUrl}/pemula/history?key=${widget.sessionKey}');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _historyList =
              List<Map<String, dynamic>>.from(data['history'] ?? []);
        });
      }
    } catch (_) {}
  }

  Future<void> _accUser(String username) async {
    HapticFeedback.mediumImpact();
    final ok = await _showConfirm(
      title: 'SETUJUI AKSES',
      subtitle: 'Setujui akun "$username"?',
      confirmLabel: 'SETUJUI',
    );
    if (ok != true) return;
    try {
      final url = Uri.parse(
          '${AccConfig.baseUrl}/pemula/acc?key=${widget.sessionKey}&username=$username');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _snack('AKUN $username DISETUJUI');
        _loadPending();
        _loadHistory();
      } else {
        _snack(data['message'] ?? 'Gagal menyetujui');
      }
    } catch (e) {
      _snack('Error: $e');
    }
  }

  Future<void> _rejectUser(String username) async {
    HapticFeedback.mediumImpact();
    final ok = await _showConfirm(
      title: 'TOLAK AKUN',
      subtitle: 'Hapus akun "$username" dari daftar?',
      confirmLabel: 'TOLAK',
    );
    if (ok != true) return;
    try {
      final url = Uri.parse(
          '${AccConfig.baseUrl}/pemula/reject?key=${widget.sessionKey}&username=$username');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _snack('AKUN $username DITOLAK');
        _loadPending();
        _loadHistory();
      } else {
        _snack(data['message'] ?? 'Gagal menolak');
      }
    } catch (e) {
      _snack('Error: $e');
    }
  }

  Future<bool?> _showConfirm({
    required String title,
    required String subtitle,
    required String confirmLabel,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GlassCard(
          padding: const EdgeInsets.all(22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(height: 10),
            Text(subtitle,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 12, color: _C.muted)),
            const SizedBox(height: 22),
            Row(children: [
              Expanded(
                child: _SecondaryBtn(
                    label: 'BATAL', onTap: () => Navigator.pop(ctx, false)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _PrimaryBtn(
                    label: confirmLabel,
                    onTap: () => Navigator.pop(ctx, true)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.black.withOpacity(0.9),
        content: Row(children: [
          const Icon(Icons.check_circle_outline, color: _C.red, size: 20),
          const SizedBox(width: 8),
          Expanded(
              child: Text(msg,
                  style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1))),
        ]),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _C.red.withOpacity(0.5)),
        ),
        duration: const Duration(seconds: 2),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(children: [
            _buildTopBar(),
            _buildPageSwitcher(),
            if (_pageIndex == 0) _buildSearchBar(),
            Expanded(
              child:
                  _pageIndex == 0 ? _buildPendingPage() : _buildHistoryPage(),
            ),
          ]),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ACCESS CONTROL',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('KELOLA PENGAJUAN AKUN',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageSwitcher() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
        child: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Row(children: [
            Expanded(
                child: _pageBtn(0, 'PENDING', _pendingList.length)),
            const SizedBox(width: 4),
            Expanded(
                child: _pageBtn(1, 'HISTORY', _historyList.length)),
          ]),
        ),
      );

  Widget _pageBtn(int index, String label, int count) {
    final active = _pageIndex == index;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _pageIndex = index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: active
              ? _C.red.withOpacity(0.18)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: active ? _C.red.withOpacity(0.6) : Colors.transparent,
              width: 1),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(label,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: active ? _C.red : _C.muted,
                  letterSpacing: 1.5)),
          if (count > 0) ...[
            const SizedBox(width: 6),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: active
                    ? _C.red.withOpacity(0.3)
                    : Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('$count',
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: active ? _C.red : _C.muted)),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _buildSearchBar() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: TextField(
            controller: _searchCtrl,
            style:
                const TextStyle(fontSize: 14, color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Cari username...',
              hintStyle:
                  const TextStyle(color: _C.muted, fontSize: 13),
              prefixIcon: const Icon(Icons.search_rounded,
                  color: _C.muted, size: 20),
              suffixIcon: _searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.close_rounded,
                          color: _C.muted, size: 20),
                      onPressed: () => _searchCtrl.clear(),
                    )
                  : null,
              filled: true,
              fillColor: Colors.transparent,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
      );

  Widget _buildPendingPage() {
    if (_loading) return _buildLoader();
    if (_error != null) return _buildError();
    if (_filteredPending.isEmpty) {
      return _emptyState('TIDAK ADA PENGAJUAN', Icons.shield_outlined);
    }
    return RefreshIndicator(
      onRefresh: _loadPending,
      color: _C.red,
      backgroundColor: Colors.black,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: _filteredPending.length,
        itemBuilder: (ctx, i) => _buildPendingCard(_filteredPending[i]),
      ),
    );
  }

  Widget _buildPendingCard(Map<String, dynamic> user) {
    final username = user['username'] ?? '-';
    final role = user['role'] ?? 'member';
    final expired = user['expiredDate'] ?? '-';
    final createdBy = user['createdBy'] ?? 'unknown';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: _GlassCard(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: _C.red, width: 1.5),
                ),
                child: Center(
                    child: Text(
                        username.toString().isNotEmpty
                            ? username[0].toUpperCase()
                            : '?',
                        style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            color: _C.red))),
              ),
              const SizedBox(width: 14),
              Expanded(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 1)),
                  const SizedBox(height: 4),
                  Text('Role: ${role.toUpperCase()}',
                      style: const TextStyle(
                          fontSize: 11, color: _C.muted)),
                ],
              )),
            ]),
            const SizedBox(height: 14),
            Container(
                height: 1, color: Colors.white.withOpacity(0.08)),
            const SizedBox(height: 12),
            _infoRow('EXP', expired, Icons.calendar_month_rounded),
            _infoRow('BY', createdBy, Icons.person_rounded),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                  child: _SecondaryBtn(
                      label: 'TOLAK', onTap: () => _rejectUser(username))),
              const SizedBox(width: 12),
              Expanded(
                  child: _PrimaryBtn(
                      label: 'SETUJUI',
                      onTap: () => _accUser(username))),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(children: [
        Icon(icon, size: 14, color: _C.muted),
        const SizedBox(width: 8),
        Text('$label: ',
            style:
                const TextStyle(fontSize: 11, color: _C.muted)),
        Expanded(
            child: Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Colors.white))),
      ]),
    );
  }

  Widget _buildHistoryPage() {
    if (_historyList.isEmpty) {
      return _emptyState('BELUM ADA RIWAYAT', Icons.history_rounded);
    }
    return RefreshIndicator(
      onRefresh: _loadHistory,
      color: _C.red,
      backgroundColor: Colors.black,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: _historyList.length,
        itemBuilder: (ctx, i) {
          final item = _historyList[i];
          final isAcc = item['action'] == 'acc';
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            child: _GlassCard(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _C.red.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: _C.red.withOpacity(0.6), width: 1),
                  ),
                  child: Icon(
                      isAcc
                          ? Icons.check_rounded
                          : Icons.close_rounded,
                      color: _C.red,
                      size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['username'] ?? '-',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 1)),
                    const SizedBox(height: 3),
                    Text(isAcc ? 'DISETUJUI' : 'DITOLAK',
                        style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: _C.red,
                            letterSpacing: 1.5)),
                  ],
                )),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoader() => const Center(
        child: CircularProgressIndicator(color: _C.red, strokeWidth: 2),
      );

  Widget _buildError() => Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: _C.red, size: 56),
                const SizedBox(height: 16),
                Text(_error ?? 'Unknown error',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 13,
                        color: Colors.white,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: _loadPending,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                    decoration: BoxDecoration(
                      color: _C.red,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text('COBA LAGI',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                            letterSpacing: 1.5)),
                  ),
                ),
              ]),
        ),
      );

  Widget _emptyState(String title, IconData icon) => Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _C.muted, size: 64),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
            ]),
      );
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

class _SecondaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _SecondaryBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}