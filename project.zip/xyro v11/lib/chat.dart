// lib/chat.dart
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

const String kFont = 'Ganang';
const String _kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class ChatHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amethyst = Color(0xFFA78BFA);
  static const rose     = Color(0xFFF472B6);
  static const amber    = Color(0xFFFBBF24);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════
class ChatMessage {
  final String id;
  final String from;
  final String role;
  final String type;
  final String content;
  final String mime;
  final int timestamp;
  final bool fromMe;

  ChatMessage({
    required this.id,
    required this.from,
    required this.role,
    required this.type,
    required this.content,
    required this.mime,
    required this.timestamp,
    required this.fromMe,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j, String myUsername) {
    final from = j['from']?.toString() ?? 'unknown';
    return ChatMessage(
      id: j['id']?.toString() ??
          DateTime.now().microsecondsSinceEpoch.toString(),
      from: from,
      role: j['role']?.toString() ?? 'member',
      type: j['type']?.toString() ?? 'text',
      content: j['content']?.toString() ?? '',
      mime: j['mime']?.toString() ?? '',
      timestamp: j['timestamp'] is int
          ? j['timestamp']
          : (j['timestamp'] is num
              ? (j['timestamp'] as num).toInt()
              : DateTime.now().millisecondsSinceEpoch),
      fromMe: from == myUsername,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// CHAT PAGE
// ═══════════════════════════════════════════════════════════════
class ChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();
  final ImagePicker _picker = ImagePicker();

  final List<ChatMessage> _messages = [];
  final Set<String> _onlineUsers = {};
  final Map<String, String> _onlineRoles = {};

  Timer? _pollTimer;
  Timer? _onlineTimer;

  int _lastTs = 0;
  bool _loading = true;
  bool _sending = false;
  bool _uploadingMedia = false;
  bool _showEmoji = false;

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _startPolling();
    _startOnlinePolling();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _onlineTimer?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _loadInitial() async {
    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/messages?key=${Uri.encodeComponent(widget.sessionKey)}&limit=100',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final list = (data['messages'] as List?) ?? [];
        setState(() {
          _messages.clear();
          for (final m in list) {
            _messages.add(ChatMessage.fromJson(
              Map<String, dynamic>.from(m),
              widget.username,
            ));
          }
          _lastTs = data['serverTime'] is int
              ? data['serverTime']
              : (data['serverTime'] is num
                  ? (data['serverTime'] as num).toInt()
                  : DateTime.now().millisecondsSinceEpoch);
          _loading = false;
        });
        _scrollToBottom(instant: true);
      } else {
        setState(() => _loading = false);
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (!mounted) return;
      try {
        final res = await http.get(Uri.parse(
          '$_kBase/chat/messages?key=${Uri.encodeComponent(widget.sessionKey)}'
          '&since=$_lastTs&limit=100',
        ));
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final list = (data['messages'] as List?) ?? [];
          if (list.isNotEmpty) {
            setState(() {
              for (final m in list) {
                final msg = ChatMessage.fromJson(
                  Map<String, dynamic>.from(m),
                  widget.username,
                );
                if (!_messages.any((x) => x.id == msg.id)) {
                  _messages.add(msg);
                }
              }
              _lastTs = data['serverTime'] is int
                  ? data['serverTime']
                  : (data['serverTime'] is num
                      ? (data['serverTime'] as num).toInt()
                      : DateTime.now().millisecondsSinceEpoch);
            });
            _scrollToBottom();
          }
        }
      } catch (_) {}
    });
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      if (!mounted) return;
      try {
        final res = await http.get(Uri.parse(
          '$_kBase/chat/online?key=${Uri.encodeComponent(widget.sessionKey)}',
        ));
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final list = (data['online'] as List?) ?? [];
          setState(() {
            _onlineUsers.clear();
            _onlineRoles.clear();
            for (final u in list) {
              final name = u['username']?.toString();
              final role = u['role']?.toString() ?? 'member';
              if (name != null) {
                _onlineUsers.add(name);
                _onlineRoles[name] = role;
              }
            }
          });
        }
      } catch (_) {}
    });
  }

  Future<void> _sendText() async {
    final txt = _msgCtrl.text.trim();
    if (txt.isEmpty || _sending) return;

    HapticFeedback.selectionClick();
    setState(() => _sending = true);

    final optimistic = ChatMessage(
      id: 'local_${DateTime.now().microsecondsSinceEpoch}',
      from: widget.username,
      role: widget.role,
      type: 'text',
      content: txt,
      mime: '',
      timestamp: DateTime.now().millisecondsSinceEpoch,
      fromMe: true,
    );
    setState(() {
      _messages.add(optimistic);
      _msgCtrl.clear();
    });
    _scrollToBottom();

    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/send'
        '?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&text=${Uri.encodeComponent(txt)}',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] != true) {
        _snack(data['message']?.toString() ?? 'Gagal kirim');
        setState(() => _messages.removeWhere((m) => m.id == optimistic.id));
      } else {
        final serverMsg = data['message'];
        if (serverMsg is Map) {
          final real = ChatMessage.fromJson(
            Map<String, dynamic>.from(serverMsg),
            widget.username,
          );
          setState(() {
            final idx = _messages.indexWhere((m) => m.id == optimistic.id);
            if (idx != -1) _messages[idx] = real;
          });
        }
      }
    } catch (e) {
      _snack('Error: $e');
      setState(() => _messages.removeWhere((m) => m.id == optimistic.id));
    } finally {
      if (mounted) setState(() => _sending = false);
    }

    _focusNode.requestFocus();
  }

  Future<void> _pickMedia({required bool isVideo}) async {
    if (_uploadingMedia) return;

    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: isVideo ? 50 : 70,
      );
      if (file == null) return;

      final bytes = await file.readAsBytes();
      final sizeMb = bytes.length / (1024 * 1024);

      if (sizeMb > 4.5) {
        _snack('File terlalu besar (max 4.5MB)');
        return;
      }

      HapticFeedback.selectionClick();
      setState(() => _uploadingMedia = true);

      final base64Str = base64Encode(bytes);
      final mime =
          file.mimeType ?? (isVideo ? 'video/mp4' : 'image/jpeg');

      final res = await http.post(
        Uri.parse('$_kBase/chat/send-media'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': isVideo ? 'video' : 'image',
          'mime': mime,
          'content': base64Str,
        }),
      );

      final data = jsonDecode(res.body);
      if (data['success'] != true) {
        _snack(data['message']?.toString() ?? 'Gagal kirim');
      } else {
        _snack('${isVideo ? "Video" : "Foto"} terkirim');
        final serverMsg = data['message'];
        if (serverMsg is Map) {
          final real = ChatMessage.fromJson(
            Map<String, dynamic>.from(serverMsg),
            widget.username,
          );
          setState(() => _messages.add(real));
          _scrollToBottom();
        }
      }
    } catch (e) {
      _snack('Gagal kirim: $e');
    } finally {
      if (mounted) setState(() => _uploadingMedia = false);
    }
  }

  void _scrollToBottom({bool instant = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        if (instant) {
          _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
        } else {
          _scrollCtrl.animateTo(
            _scrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      }
    });
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: ChatHx.ivory,
            fontFamily: kFont,
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
        backgroundColor: ChatHx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1,
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(int ms) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return ChatHx.ivory; // putih
      case 'admin':
        return ChatHx.terra;
      case 'moderator':
        return ChatHx.amber;
      case 'partner':
        return ChatHx.amethyst;
      case 'reseller':
        return ChatHx.slate;
      case 'vip':
        return ChatHx.jade;
      case 'premium':
        return ChatHx.amethyst;
      default:
        return ChatHx.ash;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ChatHx.bg,
      extendBodyBehindAppBar: true,
      extendBody: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),  // atas: hitam murni
              Color(0xFF0A0A0A),  // bawah: hitam sedikit terang
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: _loading
                    ? _loadingState()
                    : _messages.isEmpty
                        ? _emptyState()
                        : ListView.builder(
                            controller: _scrollCtrl,
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                            itemCount: _messages.length,
                            itemBuilder: (_, i) {
                              final m = _messages[i];
                              final prev =
                                  i > 0 ? _messages[i - 1] : null;
                              final showHeader =
                                  prev == null || prev.from != m.from;
                              return _buildMessage(m, showHeader);
                            },
                          ),
              ),
              if (_showEmoji) _buildEmojiPicker(),
              _buildInputBar(),
            ],
          ),
        ),
      ),
    );
  }

  // ============ APPBAR ============
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: ChatHx.bg,
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: ChatHx.surfaceHi,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new,
                color: ChatHx.ivory,
                size: 16,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: ChatHx.jade,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            "GLOBAL CHAT",
            style: TextStyle(
              color: ChatHx.ivory,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              fontFamily: kFont,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 3,
            ),
            decoration: BoxDecoration(
              color: ChatHx.ivory,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              '${_onlineUsers.length}',
              style: const TextStyle(
                color: ChatHx.bg,
                fontFamily: kFont,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              _showOnlineSheet();
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: ChatHx.surfaceHi,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.people_alt_outlined,
                color: ChatHx.ivory,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============ STATES ============
  Widget _loadingState() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 2.0,
              color: ChatHx.ivory,
            ),
          ),
          SizedBox(height: 12),
          Text(
            'Memuat chat...',
            style: TextStyle(
              color: ChatHx.ash,
              fontFamily: kFont,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: ChatHx.surfaceHi,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 1,
              ),
            ),
            child: const Icon(
              Icons.forum_outlined,
              color: ChatHx.ivory,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Belum ada pesan',
            style: TextStyle(
              color: ChatHx.ivory,
              fontFamily: kFont,
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Mulai obrolan global!',
            style: TextStyle(
              color: ChatHx.ash,
              fontFamily: kFont,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ============ MESSAGE BUBBLE ============
  Widget _buildMessage(ChatMessage m, bool showHeader) {
    final fromMe = m.fromMe;
    final roleColor = _roleColor(m.role);

    return Padding(
      padding: EdgeInsets.only(
        top: showHeader ? 10 : 2,
        bottom: 2,
      ),
      child: Row(
        mainAxisAlignment:
            fromMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!fromMe) ...[
            _avatar(m.from, roleColor, 34),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: fromMe
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                if (showHeader && !fromMe)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4, left: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          m.from,
                          style: const TextStyle(
                            color: ChatHx.ivory,
                            fontFamily: kFont,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(width: 6),
                        _roleBadge(m.role),
                      ],
                    ),
                  ),
                GestureDetector(
                  onLongPress: () {
                    HapticFeedback.mediumImpact();
                    _showMessageOptions(m);
                  },
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth:
                          MediaQuery.of(context).size.width * 0.7,
                    ),
                    padding: m.type == 'text'
                        ? const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          )
                        : const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      // ✅ fromMe → PUTIH, else → #141414
                      color: fromMe ? ChatHx.ivory : ChatHx.surfaceHi,
                      border: Border.all(
                        color: fromMe
                            ? Colors.white
                            : Colors.white.withOpacity(0.08),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(14),
                        topRight: const Radius.circular(14),
                        bottomLeft: Radius.circular(fromMe ? 14 : 4),
                        bottomRight: Radius.circular(fromMe ? 4 : 14),
                      ),
                    ),
                    child: _bubbleContent(m, fromMe),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: 3,
                    left: 6,
                    right: 6,
                  ),
                  child: Text(
                    _formatTime(m.timestamp),
                    style: const TextStyle(
                      color: ChatHx.ash2,
                      fontFamily: kFont,
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (fromMe) ...[
            const SizedBox(width: 8),
            _avatar(m.from, roleColor, 34),
          ],
        ],
      ),
    );
  }

  Widget _bubbleContent(ChatMessage m, bool fromMe) {
    switch (m.type) {
      case 'image':
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: _buildBase64Media(m.content, false),
        );
      case 'video':
        return Stack(
          alignment: Alignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: _buildBase64Media(m.content, true),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withOpacity(0.5),
              ),
              child: const Icon(
                Icons.play_arrow_rounded,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        );
      default:
        return Text(
          m.content,
          style: TextStyle(
            // ✅ text hitam kalau bubble putih
            color: fromMe ? ChatHx.bg : ChatHx.ivory,
            fontFamily: kFont,
            fontSize: 13,
            fontWeight: FontWeight.w700,
            height: 1.4,
          ),
        );
    }
  }

  Widget _buildBase64Media(String base64Str, bool isVideo) {
    try {
      final bytes = base64Decode(base64Str);
      if (isVideo) {
        return Container(
          width: 200,
          height: 200,
          color: Colors.black26,
          child: const Icon(
            Icons.videocam_rounded,
            color: Colors.white54,
            size: 60,
          ),
        );
      }
      return Image.memory(
        Uint8List.fromList(bytes),
        width: 200,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: 200,
          height: 100,
          color: ChatHx.surfaceHi2,
          child: const Icon(
            Icons.broken_image,
            color: ChatHx.ash2,
          ),
        ),
      );
    } catch (_) {
      return Container(
        padding: const EdgeInsets.all(8),
        color: ChatHx.surfaceHi2,
        child: const Text(
          '[media rusak]',
          style: TextStyle(
            color: ChatHx.ash,
            fontFamily: kFont,
            fontWeight: FontWeight.w600,
          ),
        ),
      );
    }
  }

  Widget _avatar(String username, Color color, double size) {
    final initial =
        username.isNotEmpty ? username[0].toUpperCase() : '?';

    // Kalau owner, pakai putih + text hitam biar konsisten
    final isOwner = color == ChatHx.ivory;
    final bg = isOwner ? ChatHx.ivory : color.withOpacity(0.18);
    final border = isOwner ? ChatHx.ivory : color.withOpacity(0.5);
    final textColor = isOwner ? ChatHx.bg : color;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: bg,
        border: Border.all(color: border, width: 1),
      ),
      alignment: Alignment.center,
      child: Text(
        initial,
        style: TextStyle(
          color: textColor,
          fontFamily: kFont,
          fontWeight: FontWeight.w900,
          fontSize: size * 0.45,
        ),
      ),
    );
  }

  Widget _roleBadge(String role) {
    final c = _roleColor(role);
    final isWhite = c == ChatHx.ivory;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isWhite ? ChatHx.ivory : c.withOpacity(0.15),
        border: Border.all(
          color: isWhite ? ChatHx.ivory : c.withOpacity(0.4),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          color: isWhite ? ChatHx.bg : c,
          fontFamily: kFont,
          fontSize: 8,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ============ INPUT BAR ============
  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: ChatHx.bg,
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          _iconBtn(
            icon: _showEmoji
                ? Icons.keyboard_rounded
                : Icons.emoji_emotions_outlined,
            color: ChatHx.amber,
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _showEmoji = !_showEmoji);
              if (!_showEmoji) _focusNode.requestFocus();
            },
          ),
          const SizedBox(width: 6),
          _iconBtn(
            icon: Icons.image_rounded,
            color: ChatHx.slate,
            onTap: _uploadingMedia
                ? null
                : () => _pickMedia(isVideo: false),
          ),
          const SizedBox(width: 6),
          _iconBtn(
            icon: Icons.videocam_rounded,
            color: ChatHx.jade,
            onTap: _uploadingMedia
                ? null
                : () => _pickMedia(isVideo: true),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: ChatHx.surfaceHi,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: TextField(
                controller: _msgCtrl,
                focusNode: _focusNode,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendText(),
                style: const TextStyle(
                  color: ChatHx.ivory,
                  fontFamily: kFont,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 4,
                minLines: 1,
                cursorColor: ChatHx.ivory,
                decoration: const InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: TextStyle(
                    color: ChatHx.ash2,
                    fontFamily: kFont,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sending ? null : _sendText,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: ChatHx.ivory,
                borderRadius: BorderRadius.circular(14),
              ),
              child: _sending
                  ? const Center(
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: ChatHx.bg,
                        ),
                      ),
                    )
                  : const Icon(
                      Icons.send_rounded,
                      color: ChatHx.bg,
                      size: 20,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _iconBtn({
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          border: Border.all(
            color: color.withOpacity(0.4),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: color, size: 20),
      ),
    );
  }

  // ============ EMOJI PICKER ============
  Widget _buildEmojiPicker() {
    const emojis = [
      '😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃',
      '😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙',
      '🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫',
      '🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬',
      '😮‍💨','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕',
      '🤢','🤮','🥵','🥶','😵','🤯','🤠','🥳','🥺','😢',
      '😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤',
      '😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹',
      '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔',
      '❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️',
      '👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👈','👉',
      '👆','👇','☝️','✋','🤚','🖐','🖖','👋','🤝','🙏',
      '💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🦷',
      '🔥','💯','✨','⭐','🌟','💫','⚡','☄️','💥','🌪',
      '🌈','☀️','🌤','⛅','🌥','☁️','🌦','🌧','⛈','🌩',
      '🎉','🎊','🎈','🎁','🎀','🎂','🍰','🧁','🍕','🍔',
      '🍟','🌭','🍿','🥤','🍺','🍻','🥂','🍷','🍸','🍹',
      '⚽','🏀','🏈','⚾','🎾','🏐','🏉','🎱','🏓','🏸',
      '🚗','🚕','🚙','🚌','🚎','🏎','🚓','🚑','🚒','🚐',
    ];

    return Container(
      height: 200,
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: ChatHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 8,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
        ),
        itemCount: emojis.length,
        itemBuilder: (_, i) {
          return GestureDetector(
            onTap: () {
              _msgCtrl.text += emojis[i];
              _msgCtrl.selection = TextSelection.fromPosition(
                TextPosition(offset: _msgCtrl.text.length),
              );
            },
            child: Container(
              alignment: Alignment.center,
              child: Text(
                emojis[i],
                style: const TextStyle(fontSize: 20),
              ),
            ),
          );
        },
      ),
    );
  }

  // ============ MESSAGE OPTIONS ============
  void _showMessageOptions(ChatMessage m) {
    showModalBottomSheet(
      context: context,
      backgroundColor: ChatHx.bgAlt,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 4,
              margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: ChatHx.ash2,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            if (m.type == 'text')
              ListTile(
                leading: const Icon(
                  Icons.copy_rounded,
                  color: ChatHx.ivory,
                ),
                title: const Text(
                  'Copy teks',
                  style: TextStyle(
                    color: ChatHx.ivory,
                    fontFamily: kFont,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                onTap: () {
                  HapticFeedback.selectionClick();
                  Clipboard.setData(ClipboardData(text: m.content));
                  Navigator.pop(context);
                  _snack('Pesan dicopy');
                },
              ),
            if (m.fromMe || widget.role == 'owner')
              ListTile(
                leading: const Icon(
                  Icons.delete_rounded,
                  color: ChatHx.terra,
                ),
                title: const Text(
                  'Hapus',
                  style: TextStyle(
                    color: ChatHx.ivory,
                    fontFamily: kFont,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                onTap: () async {
                  HapticFeedback.mediumImpact();
                  Navigator.pop(context);
                  await _deleteMessage(m);
                },
              ),
            ListTile(
              leading: const Icon(
                Icons.info_outline_rounded,
                color: ChatHx.ash,
              ),
              title: const Text(
                'Info',
                style: TextStyle(
                  color: ChatHx.ivory,
                  fontFamily: kFont,
                  fontWeight: FontWeight.w700,
                ),
              ),
              onTap: () {
                HapticFeedback.selectionClick();
                Navigator.pop(context);
                _snack('Dari: ${m.from} | Role: ${m.role}');
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteMessage(ChatMessage m) async {
    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/delete?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&messageId=${Uri.encodeComponent(m.id)}',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() => _messages.removeWhere((x) => x.id == m.id));
        _snack('Pesan dihapus');
      } else {
        _snack(data['message']?.toString() ?? 'Gagal hapus');
      }
    } catch (e) {
      _snack('Error: $e');
    }
  }

  // ============ ONLINE USERS SHEET ============
  void _showOnlineSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: ChatHx.bgAlt,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.people_alt_rounded, color: ChatHx.ivory),
                const SizedBox(width: 8),
                Text(
                  'Online (${_onlineUsers.length})',
                  style: const TextStyle(
                    color: ChatHx.ivory,
                    fontFamily: kFont,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_onlineUsers.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Tidak ada user online',
                  style: TextStyle(
                    color: ChatHx.ash,
                    fontFamily: kFont,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              )
            else
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: _onlineUsers.map((u) {
                    final role = _onlineRoles[u] ?? 'member';
                    final c = _roleColor(role);
                    return ListTile(
                      dense: true,
                      leading: _avatar(u, c, 32),
                      title: Text(
                        u,
                        style: const TextStyle(
                          color: ChatHx.ivory,
                          fontFamily: kFont,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      trailing: _roleBadge(role),
                    );
                  }).toList(),
                ),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}