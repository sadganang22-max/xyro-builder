// lib/quran.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String kFontFamily = 'Ganang';
const String kArabicFont = 'Amiri'; // font arab, install di pubspec.yaml
const String kBaseApi = 'https://equran.id/api/v2';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class QuranHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);

  static const jade   = Color(0xFF6EE7B7);
  static const terra  = Color(0xFFFF7A9A);
  static const amber  = Color(0xFFFFD58A);
  static const slate  = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
}

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════
class SurahModel {
  final int nomor;
  final String nama;
  final String namaLatin;
  final int jumlahAyat;
  final String tempatTurun;
  final String arti;
  final String deskripsi;
  final String audioFull;

  SurahModel({
    required this.nomor,
    required this.nama,
    required this.namaLatin,
    required this.jumlahAyat,
    required this.tempatTurun,
    required this.arti,
    required this.deskripsi,
    required this.audioFull,
  });

  factory SurahModel.fromJson(Map<String, dynamic> j) {
    return SurahModel(
      nomor: (j['nomor'] as num?)?.toInt() ?? 0,
      nama: j['nama']?.toString() ?? '',
      namaLatin: j['namaLatin']?.toString() ?? '',
      jumlahAyat: (j['jumlahAyat'] as num?)?.toInt() ?? 0,
      tempatTurun: j['tempatTurun']?.toString() ?? '',
      arti: j['arti']?.toString() ?? '',
      deskripsi: j['deskripsi']?.toString() ?? '',
      audioFull: j['audioFull'] is Map
          ? (j['audioFull']['05']?.toString() ?? '')
          : '',
    );
  }
}

class AyatModel {
  final int nomorAyat;
  final String teksArab;
  final String teksLatin;
  final String teksIndonesia;
  final String audio;

  AyatModel({
    required this.nomorAyat,
    required this.teksArab,
    required this.teksLatin,
    required this.teksIndonesia,
    required this.audio,
  });

  factory AyatModel.fromJson(Map<String, dynamic> j) {
    return AyatModel(
      nomorAyat: (j['nomorAyat'] as num?)?.toInt() ?? 0,
      teksArab: j['teksArab']?.toString() ?? '',
      teksLatin: j['teksLatin']?.toString() ?? '',
      teksIndonesia: j['teksIndonesia']?.toString() ?? '',
      audio: j['audio'] is Map
          ? (j['audio']['05']?.toString() ??
              j['audio']['01']?.toString() ??
              '')
          : '',
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// HALAMAN LIST SURAH (home quran)
// ═══════════════════════════════════════════════════════════════
class QuranPage extends StatefulWidget {
  const QuranPage({super.key});

  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage> {
  List<SurahModel> _surahList = [];
  List<SurahModel> _filtered = [];
  bool _loading = true;
  String? _error;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _loadSurah();
  }

  Future<void> _loadSurah() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final res = await http
          .get(Uri.parse('$kBaseApi/surat'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        setState(() {
          _error = 'Server error: HTTP ${res.statusCode}';
          _loading = false;
        });
        return;
      }

      final data = jsonDecode(res.body);
      if (data['code'] != 200) {
        setState(() {
          _error = data['message']?.toString() ?? 'Gagal memuat data';
          _loading = false;
        });
        return;
      }

      final list = (data['data'] as List? ?? []);
      final surahs = list
          .map((e) => SurahModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();

      setState(() {
        _surahList = surahs;
        _filtered = surahs;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Koneksi gagal: $e';
        _loading = false;
      });
    }
  }

  void _search(String q) {
    setState(() {
      _query = q;
      if (q.isEmpty) {
        _filtered = _surahList;
      } else {
        final lower = q.toLowerCase();
        _filtered = _surahList.where((s) {
          return s.namaLatin.toLowerCase().contains(lower) ||
              s.arti.toLowerCase().contains(lower) ||
              s.nomor.toString() == lower;
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: QuranHx.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: QuranHx.pinkLight, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Al-Qur\'an ♡',
          style: TextStyle(
            color: QuranHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildSearchBar(),
              Expanded(child: _buildBody()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: QuranHx.surfaceHi,
        border: Border.all(color: QuranHx.pink.withOpacity(0.3), width: 1.2),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: QuranHx.pink.withOpacity(0.2),
            blurRadius: 18,
            spreadRadius: 1,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [QuranHx.pinkLight, QuranHx.pinkDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: QuranHx.pink.withOpacity(0.5),
                  blurRadius: 14,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Icon(
              Icons.menu_book_rounded,
              color: Colors.white,
              size: 26,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Al-Qur\'an Al-Karim',
                  style: TextStyle(
                    color: QuranHx.ivory,
                    fontFamily: kFontFamily,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.4,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '114 Surah · Lengkap',
                  style: TextStyle(
                    color: QuranHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: QuranHx.pink.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: QuranHx.pink.withOpacity(0.5),
                width: 1,
              ),
            ),
            child: const Text(
              '114',
              style: TextStyle(
                color: QuranHx.pinkLight,
                fontFamily: kFontFamily,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      height: 50,
      decoration: BoxDecoration(
        color: QuranHx.surfaceHi,
        border: Border.all(color: QuranHx.pink.withOpacity(0.3), width: 1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        onChanged: _search,
        style: const TextStyle(
          color: QuranHx.ivory,
          fontFamily: kFontFamily,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: QuranHx.pink,
        decoration: InputDecoration(
          hintText: 'Cari surah (contoh: Al-Fatihah, 1)...',
          hintStyle: TextStyle(
            color: QuranHx.ash2,
            fontFamily: kFontFamily,
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon: const Icon(Icons.search_rounded,
              color: QuranHx.pinkLight, size: 20),
          suffixIcon: _query.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.close_rounded,
                      color: QuranHx.pinkLight, size: 18),
                  onPressed: () => _search(''),
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: QuranHx.pinkLight),
      );
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: QuranHx.terra.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: QuranHx.terra.withOpacity(0.5),
                    width: 1,
                  ),
                ),
                child: const Icon(Icons.error_rounded,
                    color: QuranHx.terra, size: 32),
              ),
              const SizedBox(height: 16),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: QuranHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _loadSurah,
                icon: const Icon(Icons.refresh_rounded,
                    color: Colors.white, size: 16),
                label: const Text(
                  'RETRY',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: QuranHx.pink,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (_filtered.isEmpty) {
      return const Center(
        child: Text(
          'Surah tidak ditemukan',
          style: TextStyle(
            color: QuranHx.ash,
            fontFamily: kFontFamily,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 30),
      physics: const BouncingScrollPhysics(),
      itemCount: _filtered.length,
      itemBuilder: (_, i) => _buildSurahCard(_filtered[i]),
    );
  }

  Widget _buildSurahCard(SurahModel s) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          HapticFeedback.selectionClick();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => SurahDetailPage(surah: s),
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: QuranHx.surfaceHi,
            border: Border.all(color: QuranHx.pink.withOpacity(0.25), width: 1),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: QuranHx.pink.withOpacity(0.1),
                blurRadius: 10,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              // Nomor surah
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      QuranHx.pinkLight.withOpacity(0.9),
                      QuranHx.pinkDeep.withOpacity(0.9),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: QuranHx.pink.withOpacity(0.4),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                alignment: Alignment.center,
                child: Text(
                  '${s.nomor}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: kFontFamily,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      s.namaLatin,
                      style: const TextStyle(
                        color: QuranHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          s.tempatTurun == 'Mekah'
                              ? Icons.location_city_rounded
                              : Icons.mosque_rounded,
                          color: QuranHx.pinkLight,
                          size: 11,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${s.tempatTurun} · ${s.jumlahAyat} ayat',
                          style: const TextStyle(
                            color: QuranHx.ash,
                            fontFamily: kFontFamily,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Nama Arab
              Text(
                s.nama,
                style: const TextStyle(
                  fontFamily: kArabicFont,
                  color: QuranHx.pinkLight,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// HALAMAN DETAIL SURAH
// ═══════════════════════════════════════════════════════════════
class SurahDetailPage extends StatefulWidget {
  final SurahModel surah;

  const SurahDetailPage({super.key, required this.surah});

  @override
  State<SurahDetailPage> createState() => _SurahDetailPageState();
}

class _SurahDetailPageState extends State<SurahDetailPage> {
  List<AyatModel> _ayat = [];
  bool _loading = true;
  String? _error;

  // Audio player
  final AudioPlayer _audio = AudioPlayer();
  int? _playingAyat;
  bool _isPlaying = false;
  StreamSubscription? _stateSub;
  StreamSubscription? _completeSub;

  // Bookmark (last read)
  int _lastReadAyat = 0;

  @override
  void initState() {
    super.initState();
    _loadAyat();
    _loadLastRead();
    _setupAudio();
  }

  @override
  void dispose() {
    _audio.dispose();
    _stateSub?.cancel();
    _completeSub?.cancel();
    super.dispose();
  }

  void _setupAudio() {
    _stateSub = _audio.onPlayerStateChanged.listen((s) {
      if (!mounted) return;
      setState(() => _isPlaying = s == PlayerState.playing);
    });
    _completeSub = _audio.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() {
        _isPlaying = false;
        _playingAyat = null;
      });
    });
  }

  Future<void> _loadAyat() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final res = await http
          .get(Uri.parse('$kBaseApi/surat/${widget.surah.nomor}'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        setState(() {
          _error = 'Server error: HTTP ${res.statusCode}';
          _loading = false;
        });
        return;
      }

      final data = jsonDecode(res.body);
      if (data['code'] != 200) {
        setState(() {
          _error = data['message']?.toString() ?? 'Gagal memuat ayat';
          _loading = false;
        });
        return;
      }

      final ayatList = (data['data']?['ayat'] as List? ?? []);
      final list = ayatList
          .map((e) => AyatModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();

      setState(() {
        _ayat = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Koneksi gagal: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadLastRead() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'quran_last_read_${widget.surah.nomor}';
      final val = prefs.getInt(key) ?? 0;
      if (mounted) {
        setState(() => _lastReadAyat = val);
      }
    } catch (_) {}
  }

  Future<void> _saveLastRead(int ayat) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'quran_last_read_${widget.surah.nomor}';
      await prefs.setInt(key, ayat);
      if (mounted) {
        setState(() => _lastReadAyat = ayat);
      }
    } catch (_) {}
  }

  Future<void> _playAyat(AyatModel a) async {
    if (a.audio.isEmpty) {
      _snack('Audio tidak tersedia');
      return;
    }

    HapticFeedback.selectionClick();

    // Kalau sama → toggle pause/play
    if (_playingAyat == a.nomorAyat && _isPlaying) {
      await _audio.pause();
      return;
    }

    // Kalau ayat sama tapi paused → resume
    if (_playingAyat == a.nomorAyat && !_isPlaying) {
      await _audio.resume();
      return;
    }

    // Ayat beda → play baru
    try {
      await _audio.stop();
      await _audio.play(UrlSource(a.audio));
      setState(() => _playingAyat = a.nomorAyat);
      await _saveLastRead(a.nomorAyat);
    } catch (e) {
      _snack('Gagal memutar audio');
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: QuranHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
        backgroundColor: QuranHx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: QuranHx.pink.withOpacity(0.4), width: 1),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: QuranHx.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: QuranHx.pinkLight, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          children: [
            Text(
              widget.surah.namaLatin,
              style: const TextStyle(
                color: QuranHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 15,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
            Text(
              '${widget.surah.tempatTurun} · ${widget.surah.jumlahAyat} ayat',
              style: const TextStyle(
                color: QuranHx.ash,
                fontFamily: kFontFamily,
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(color: QuranHx.pinkLight),
                )
              : _error != null
                  ? _buildErrorState()
                  : _buildAyatList(),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: QuranHx.terra.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(
                  color: QuranHx.terra.withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: const Icon(Icons.error_rounded,
                  color: QuranHx.terra, size: 32),
            ),
            const SizedBox(height: 16),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: QuranHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loadAyat,
              icon: const Icon(Icons.refresh_rounded,
                  color: Colors.white, size: 16),
              label: const Text(
                'RETRY',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: kFontFamily,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: QuranHx.pink,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAyatList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
      physics: const BouncingScrollPhysics(),
      itemCount: _ayat.length + 1, // +1 untuk header bismillah
      itemBuilder: (_, i) {
        if (i == 0) return _buildBismillahHeader();
        final ayat = _ayat[i - 1];
        return _buildAyatCard(ayat);
      },
    );
  }

  Widget _buildBismillahHeader() {
    // Bismillah tidak perlu ditampilkan untuk surah At-Taubah (9)
    // dan Al-Fatihah (1) karena sudah jadi ayat
    if (widget.surah.nomor == 9 || widget.surah.nomor == 1) {
      return const SizedBox(height: 8);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: QuranHx.surfaceHi,
        border: Border.all(color: QuranHx.pink.withOpacity(0.3), width: 1.2),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: QuranHx.pink.withOpacity(0.15),
            blurRadius: 14,
            spreadRadius: 1,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: const Column(
        children: [
          Text(
            'بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ',
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: kArabicFont,
              color: QuranHx.pinkLight,
              fontSize: 26,
              fontWeight: FontWeight.w700,
              height: 1.8,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Dengan nama Allah Yang Maha Pengasih, Maha Penyayang',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: QuranHx.ash,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAyatCard(AyatModel a) {
    final isPlayingThis = _playingAyat == a.nomorAyat && _isPlaying;
    final isBookmarked = _lastReadAyat == a.nomorAyat;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: QuranHx.surfaceHi,
        border: Border.all(
          color: isPlayingThis
              ? QuranHx.pink.withOpacity(0.6)
              : QuranHx.pink.withOpacity(0.2),
          width: isPlayingThis ? 1.4 : 1,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: isPlayingThis
            ? [
                BoxShadow(
                  color: QuranHx.pink.withOpacity(0.3),
                  blurRadius: 16,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header: nomor + audio button
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: QuranHx.pink.withOpacity(0.15),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 30, height: 30,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isPlayingThis
                          ? [QuranHx.pink, QuranHx.pinkDeep]
                          : [
                              QuranHx.pink.withOpacity(0.3),
                              QuranHx.pinkDeep.withOpacity(0.3),
                            ],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '${a.nomorAyat}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: kFontFamily,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                if (isBookmarked)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: QuranHx.amber.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: QuranHx.amber.withOpacity(0.5),
                        width: 1,
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.bookmark_rounded,
                            color: QuranHx.amber, size: 10),
                        SizedBox(width: 3),
                        Text(
                          'TERAKHIR',
                          style: TextStyle(
                            color: QuranHx.amber,
                            fontFamily: kFontFamily,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                const Spacer(),
                // Audio button
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => _playAyat(a),
                    borderRadius: BorderRadius.circular(8),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isPlayingThis
                            ? QuranHx.pink.withOpacity(0.2)
                            : QuranHx.pink.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isPlayingThis
                              ? QuranHx.pink.withOpacity(0.6)
                              : QuranHx.pink.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Icon(
                        isPlayingThis
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        color: QuranHx.pinkLight,
                        size: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                // Copy button
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () async {
                      final txt =
                          '${a.teksArab}\n\n${a.teksLatin}\n\n${a.teksIndonesia}\n\n(QS. ${widget.surah.namaLatin}: ${a.nomorAyat})';
                      await Clipboard.setData(ClipboardData(text: txt));
                      _snack('Ayat disalin');
                    },
                    borderRadius: BorderRadius.circular(8),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranHx.slate.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: QuranHx.slate.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.copy_rounded,
                        color: QuranHx.slate,
                        size: 16,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Konten ayat
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Arab
                Text(
                  a.teksArab,
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontFamily: kArabicFont,
                    color: QuranHx.ivory,
                    fontSize: 22,
                    fontWeight: FontWeight.w500,
                    height: 2.0,
                  ),
                ),
                const SizedBox(height: 12),
                // Divider
                Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        QuranHx.pink.withOpacity(0.0),
                        QuranHx.pink.withOpacity(0.4),
                        QuranHx.pink.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // Latin
                Text(
                  a.teksLatin,
                  style: TextStyle(
                    color: QuranHx.pinkLight.withOpacity(0.9),
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    fontStyle: FontStyle.italic,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 10),
                // Terjemahan
                Text(
                  a.teksIndonesia,
                  style: const TextStyle(
                    color: QuranHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}