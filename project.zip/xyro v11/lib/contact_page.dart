// lib/contact_page.dart
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'widgets/custom_popup.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class ContactHx {
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  // Brand colors (tetap vibrant untuk icon)
  static const telegram  = Color(0xFF229ED9);
  static const whatsapp  = Color(0xFF25D366);
  static const tiktok    = Color(0xFFFFFFFF);
  static const instagram = Color(0xFFE4405F);

  static const line = Color(0x1AFFFFFF);
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.show(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: ContactHx.ash,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ContactHx.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => Navigator.pop(context),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                decoration: BoxDecoration(
                  color: ContactHx.surfaceHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new,
                  color: ContactHx.ivory,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: const Text(
          "Customer Service",
          style: TextStyle(
            color: ContactHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w900,
            fontSize: 15,
            letterSpacing: 1.8,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),
              Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Header Icon
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: ContactHx.surfaceHi,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 1,
                      ),
                    ),
                    child: const Icon(
                      Icons.support_agent_rounded,
                      size: 60,
                      color: ContactHx.ivory,
                    ),
                  ),
                  const SizedBox(height: 24),

                  const Text(
                    "Need Help?",
                    style: TextStyle(
                      color: ContactHx.ivory,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Hubungi kami melalui platform sosial media di bawah ini.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: ContactHx.ash,
                      fontSize: 13,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w500,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 40),

                  // Grid Buttons
                  Row(
                    children: [
                      Expanded(
                        child: _buildContactButton(
                          context: context,
                          label: "Telegram",
                          icon: FontAwesomeIcons.telegram,
                          color: ContactHx.telegram,
                          // ⚠️ GANTI dengan username Telegram kamu
                          url: "https://t.me/Kenzbro",
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildContactButton(
                          context: context,
                          label: "WhatsApp",
                          icon: FontAwesomeIcons.whatsapp,
                          color: ContactHx.whatsapp,
                          // ⚠️ GANTI dengan nomor WA kamu (format internasional tanpa +)
                          url: "https://wa.me/6281234567890",
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildContactButton(
                          context: context,
                          label: "TikTok",
                          icon: FontAwesomeIcons.tiktok,
                          color: ContactHx.tiktok,
                          // ⚠️ GANTI dengan username TikTok kamu
                          url: "https://www.tiktok.com/@kenzbro",
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildContactButton(
                          context: context,
                          label: "Instagram",
                          icon: FontAwesomeIcons.instagram,
                          color: ContactHx.instagram,
                          // ⚠️ GANTI dengan username IG kamu
                          url: "https://www.instagram.com/kenzbro",
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(context, url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        decoration: BoxDecoration(
          color: ContactHx.surfaceHi,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(
                  color: color.withOpacity(0.4),
                  width: 1,
                ),
              ),
              child: FaIcon(
                icon,
                color: color,
                size: 26,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: const TextStyle(
                color: ContactHx.ivory,
                fontSize: 13,
                fontWeight: FontWeight.w800,
                fontFamily: kFontFamily,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}