// lib/splash_video_page.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class SplashHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // PINK FAMILY
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  // Aksen
  static const jade     = Color(0xFF6EE7B7);
  static const amethyst = Color(0xFFC4A5FF);
  static const amber    = Color(0xFFFFD58A);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
  static const lineSoft = Color(0x0DFF6FA5);
}

class SplashVideoPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final String? uid;

  const SplashVideoPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    this.uid,
  });

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _brandController;
  late AnimationController _pulseController;
  late AnimationController _sparkleController;
  late AnimationController _creditsController;

  bool _fadeOutStarted = false;

  // ── CREDITS DATA ──
  final List<Map<String, String>> _credits = [
    {
      'label': 'Developed by',
      'name': 'Dev Ganang',
      'emoji': '💖',
      'role': 'Lead Developer',
    },
    {
      'label': 'Special thanks',
      'name': 'Xyro Team',
      'emoji': '🌸',
      'role': 'Core Contributors',
    },
    {
      'label': 'Powered by',
      'name': 'Naxrat System',
      'emoji': '✨',
      'role': 'Infrastructure',
    },
  ];

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _brandController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _creditsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _sparkleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _videoController =
        VideoPlayerController.asset("assets/videos/splash.mp4")
          ..initialize().then((_) {
            if (!mounted) return;
            setState(() {});
            _videoController.setLooping(false);
            _videoController.setVolume(1.0);
            _videoController.play();

            _brandController.forward();
            Future.delayed(const Duration(milliseconds: 400), () {
              if (mounted) _creditsController.forward();
            });

            _videoController.addListener(() {
              final position = _videoController.value.position;
              final duration = _videoController.value.duration;

              if (duration != null &&
                  position >= duration - const Duration(seconds: 1) &&
                  !_fadeOutStarted) {
                _fadeOutStarted = true;
                _fadeController.forward();
              }

              if (position >= duration) {
                _navigateToDashboard();
              }
            });
          }).catchError((error) {
            debugPrint("Splash video error: $error");
            _brandController.forward();
            _creditsController.forward();
            Future.delayed(const Duration(seconds: 3), () {
              if (mounted) _navigateToDashboard();
            });
          });
  }

  void _navigateToDashboard() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          uid: widget.uid,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _brandController.dispose();
    _pulseController.dispose();
    _sparkleController.dispose();
    _creditsController.dispose();
    super.dispose();
  }

  Widget _hudCorner(bool flipX, bool flipY, {double size = 24}) {
    const double thick = 2;
    return Transform.scale(
      scaleX: flipX ? -1 : 1,
      scaleY: flipY ? -1 : 1,
      child: SizedBox(
        width: size, height: size,
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 0,
              child: Container(
                width: size, height: thick,
                decoration: BoxDecoration(
                  color: SplashHx.pinkLight.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [
                    BoxShadow(
                      color: SplashHx.pink.withOpacity(0.7),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 0, left: 0,
              child: Container(
                width: thick, height: size,
                decoration: BoxDecoration(
                  color: SplashHx.pinkLight.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [
                    BoxShadow(
                      color: SplashHx.pink.withOpacity(0.7),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SplashHx.bg,
      body: Stack(
        children: [
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            const Center(
              child: SizedBox(
                width: 32, height: 32,
                child: CircularProgressIndicator(
                  color: SplashHx.pinkLight,
                  strokeWidth: 2.0,
                ),
              ),
            ),

          // Overlay gradient gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    SplashHx.bg.withOpacity(0.4),
                    SplashHx.bg.withOpacity(0.6),
                    SplashHx.bg.withOpacity(0.85),
                  ],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
            ),
          ),

          // Radial vignette
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.1,
                    colors: [
                      Colors.transparent,
                      SplashHx.bg.withOpacity(0.6),
                    ],
                    stops: const [0.5, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // HUD corners pink
          Positioned(top: 60, left: 22, child: _hudCorner(false, false, size: 28)),
          Positioned(top: 60, right: 22, child: _hudCorner(true, false, size: 28)),
          Positioned(bottom: 60, left: 22, child: _hudCorner(false, true, size: 28)),
          Positioned(bottom: 60, right: 22, child: _hudCorner(true, true, size: 28)),

          // Top pill
          Positioned(
            top: 62,
            left: 0, right: 0,
            child: AnimatedBuilder(
              animation: _brandController,
              builder: (context, _) {
                final t = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: t,
                  child: Transform.translate(
                    offset: Offset(0, -10 * (1 - t)),
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: SplashHx.surfaceHi,
                          border: Border.all(
                            color: SplashHx.pink.withOpacity(0.3),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(100),
                          boxShadow: [
                            BoxShadow(
                              color: SplashHx.pink.withOpacity(0.2),
                              blurRadius: 12,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedBuilder(
                              animation: _pulseController,
                              builder: (_, __) {
                                final v = 0.5 + 0.5 * _pulseController.value;
                                return Container(
                                  width: 7, height: 7,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: SplashHx.pink.withOpacity(v),
                                    boxShadow: [
                                      BoxShadow(
                                        color: SplashHx.pink.withOpacity(v),
                                        blurRadius: 8,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "NAXRAT SYSTEM",
                              style: TextStyle(
                                color: SplashHx.ivory,
                                fontFamily: kFontFamily,
                                fontSize: 9.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 3.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // ── THANK YOU CREDITS CARD ──
          Positioned(
            bottom: 100,
            left: 20, right: 20,
            child: AnimatedBuilder(
              animation:
                  Listenable.merge([_brandController, _creditsController]),
              builder: (context, _) {
                final brandT = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: brandT,
                  child: Transform.translate(
                    offset: Offset(0, 40 * (1 - brandT)),
                    child: _buildCreditsCard(),
                  ),
                );
              },
            ),
          ),

          // Skip button
          Positioned(
            top: 56, right: 22,
            child: AnimatedBuilder(
              animation: _brandController,
              builder: (context, _) {
                final t = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: t,
                  child: Transform.translate(
                    offset: Offset(20 * (1 - t), 0),
                    child: _buildSkipButton(),
                  ),
                );
              },
            ),
          ),

          if (_fadeOutStarted)
            Positioned.fill(
              child: FadeTransition(
                opacity:
                    _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(color: SplashHx.bg),
              ),
            ),
        ],
      ),
    );
  }

  // ═══ CREDITS CARD (thank you to Dev Ganang) ═══
  Widget _buildCreditsCard() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
      decoration: BoxDecoration(
        color: SplashHx.surfaceHi.withOpacity(0.95),
        border: Border.all(
          color: SplashHx.pink.withOpacity(0.4),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: SplashHx.pink.withOpacity(0.35),
            blurRadius: 30,
            spreadRadius: 3,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Top logo + brand
          AnimatedBuilder(
            animation:
                Listenable.merge([_pulseController, _sparkleController]),
            builder: (context, _) {
              final pulse = _pulseController.value;
              return SizedBox(
                width: 74, height: 74,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Transform.rotate(
                      angle: _sparkleController.value * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(74, 74),
                        painter: _SparkleRingPainter(),
                      ),
                    ),
                    Container(
                      width: 54 + (14 * pulse),
                      height: 54 + (14 * pulse),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: SplashHx.pink.withOpacity(
                            0.6 - 0.4 * pulse,
                          ),
                          width: 1.2,
                        ),
                      ),
                    ),
                    Container(
                      width: 54, height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [SplashHx.pinkLight, SplashHx.pinkDeep],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: SplashHx.pink.withOpacity(0.6),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Center(
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                            width: 48, height: 48,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.favorite_rounded,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 12),

          // Brand name
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [SplashHx.pinkLight, SplashHx.pinkDeep],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              "XYRO ♡",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 3.0,
                fontFamily: kFontFamily,
              ),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            "P R E M I U M   S Y S T E M",
            style: TextStyle(
              color: SplashHx.ash,
              fontFamily: kFontFamily,
              fontSize: 9,
              fontWeight: FontWeight.w800,
              letterSpacing: 3.2,
            ),
          ),

          const SizedBox(height: 18),

          // Divider
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  SplashHx.pink.withOpacity(0.0),
                  SplashHx.pink.withOpacity(0.4),
                  SplashHx.pink.withOpacity(0.0),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // "Thank you to" header
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.favorite_rounded,
                  color: SplashHx.pinkLight, size: 12),
              const SizedBox(width: 8),
              const Text(
                "THANK YOU TO",
                style: TextStyle(
                  color: SplashHx.pinkLight,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3.0,
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.favorite_rounded,
                  color: SplashHx.pinkLight, size: 12),
            ],
          ),
          const SizedBox(height: 14),

          // Credits list — staggered fade in
          ...List.generate(_credits.length, (index) {
            return _buildCreditItem(index);
          }),
        ],
      ),
    );
  }

  Widget _buildCreditItem(int index) {
    final credit = _credits[index];
    const int total = 3;

    // staggered delay per item
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _creditsController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(20 * (1 - t), 0),
            child: Padding(
              padding: EdgeInsets.only(
                bottom: index < _credits.length - 1 ? 12 : 0,
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: SplashHx.surfaceHi2,
                  border: Border.all(
                    color: SplashHx.pink.withOpacity(0.25),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    // Emoji avatar
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: SplashHx.pink.withOpacity(0.15),
                        border: Border.all(
                          color: SplashHx.pink.withOpacity(0.4),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Center(
                        child: Text(
                          credit['emoji'] ?? '♡',
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Label + name
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (credit['label'] ?? '').toUpperCase(),
                            style: const TextStyle(
                              color: SplashHx.ash,
                              fontFamily: kFontFamily,
                              fontSize: 8,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.6,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            credit['name'] ?? '',
                            style: const TextStyle(
                              color: SplashHx.ivory,
                              fontFamily: kFontFamily,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Role badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: SplashHx.pink.withOpacity(0.15),
                        border: Border.all(
                          color: SplashHx.pink.withOpacity(0.4),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text(
                        credit['role'] ?? '',
                        style: const TextStyle(
                          color: SplashHx.pinkLight,
                          fontFamily: kFontFamily,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSkipButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        _navigateToDashboard();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [SplashHx.pinkLight, SplashHx.pinkDeep],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: SplashHx.pink.withOpacity(0.6),
              blurRadius: 14,
              spreadRadius: 1,
            ),
          ],
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.skip_next_rounded,
              color: Colors.white,
              size: 17,
            ),
            SizedBox(width: 6),
            Text(
              "SKIP",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 11,
                letterSpacing: 2.2,
                fontFamily: kFontFamily,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SPARKLE RING PAINTER — PINK stars
// ═══════════════════════════════════════════════════════════════
class _SparkleRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    for (int i = 0; i < 4; i++) {
      final angle = (i / 4) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final sparklePaint = Paint()
        ..color = SplashHx.pinkLight.withOpacity(0.7)
        ..style = PaintingStyle.fill;

      _drawStar(canvas, Offset(x, y), 5, sparklePaint);
    }
  }

  void _drawStar(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx + size * 0.3, center.dy - size * 0.3);
    path.lineTo(center.dx + size, center.dy);
    path.lineTo(center.dx + size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx, center.dy + size);
    path.lineTo(center.dx - size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx - size, center.dy);
    path.lineTo(center.dx - size * 0.3, center.dy - size * 0.3);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparkleRingPainter old) => false;
}