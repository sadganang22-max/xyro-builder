// lib/splash_video_page.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class SplashHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class SplashVideoPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final String? uid;

  const SplashVideoPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    this.uid,
  });

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _brandController;
  late AnimationController _pulseController;
  late AnimationController _sparkleController;

  bool _fadeOutStarted = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _brandController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _sparkleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _videoController =
        VideoPlayerController.asset("assets/videos/splash.mp4")
          ..initialize().then((_) {
            if (!mounted) return;
            setState(() {});
            _videoController.setLooping(false);
            _videoController.setVolume(1.0);
            _videoController.play();

            _brandController.forward();

            _videoController.addListener(() {
              final position = _videoController.value.position;
              final duration = _videoController.value.duration;

              if (duration != null &&
                  position >= duration - const Duration(seconds: 1) &&
                  !_fadeOutStarted) {
                _fadeOutStarted = true;
                _fadeController.forward();
              }

              if (position >= duration) {
                _navigateToDashboard();
              }
            });
          }).catchError((error) {
            debugPrint("Splash video error: $error");
            _brandController.forward();
            Future.delayed(const Duration(seconds: 2), () {
              if (mounted) _navigateToDashboard();
            });
          });
  }

  void _navigateToDashboard() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          uid: widget.uid,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _brandController.dispose();
    _pulseController.dispose();
    _sparkleController.dispose();
    super.dispose();
  }

  Widget _hudCorner(bool flipX, bool flipY, {double size = 24}) {
    const double thick = 2;
    return Transform.scale(
      scaleX: flipX ? -1 : 1,
      scaleY: flipY ? -1 : 1,
      child: SizedBox(
        width: size, height: size,
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 0,
              child: Container(
                width: size, height: thick,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Positioned(
              top: 0, left: 0,
              child: Container(
                width: thick, height: size,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SplashHx.bg,
      body: Stack(
        children: [
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            const Center(
              child: SizedBox(
                width: 32, height: 32,
                child: CircularProgressIndicator(
                  color: SplashHx.ivory,
                  strokeWidth: 2.0,
                ),
              ),
            ),

          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.black.withOpacity(0.5),
                    Colors.black.withOpacity(0.75),
                  ],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
            ),
          ),

          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.1,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.5),
                    ],
                    stops: const [0.55, 1.0],
                  ),
                ),
              ),
            ),
          ),

          Positioned(
            top: 60, left: 22,
            child: _hudCorner(false, false, size: 28),
          ),
          Positioned(
            top: 60, right: 22,
            child: _hudCorner(true, false, size: 28),
          ),
          Positioned(
            bottom: 60, left: 22,
            child: _hudCorner(false, true, size: 28),
          ),
          Positioned(
            bottom: 60, right: 22,
            child: _hudCorner(true, true, size: 28),
          ),

          // Top pill — putih subtle
          Positioned(
            top: 62,
            left: 0, right: 0,
            child: AnimatedBuilder(
              animation: _brandController,
              builder: (context, _) {
                final t = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: t,
                  child: Transform.translate(
                    offset: Offset(0, -10 * (1 - t)),
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: SplashHx.surfaceHi,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.08),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(100),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedBuilder(
                              animation: _pulseController,
                              builder: (_, __) {
                                final v = 0.5 + 0.5 * _pulseController.value;
                                return Container(
                                  width: 7, height: 7,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: SplashHx.ivory.withOpacity(v),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "NAXRAT SYSTEM",
                              style: TextStyle(
                                color: SplashHx.ivory,
                                fontFamily: kFontFamily,
                                fontSize: 9.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 3.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Brand card bottom
          Positioned(
            bottom: 110,
            left: 24, right: 24,
            child: AnimatedBuilder(
              animation: _brandController,
              builder: (context, _) {
                final t = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: t,
                  child: Transform.translate(
                    offset: Offset(0, 40 * (1 - t)),
                    child: _buildBrandCard(),
                  ),
                );
              },
            ),
          ),

          // Skip button
          Positioned(
            top: 56, right: 22,
            child: AnimatedBuilder(
              animation: _brandController,
              builder: (context, _) {
                final t = Curves.easeOutCubic
                    .transform(_brandController.value);
                return Opacity(
                  opacity: t,
                  child: Transform.translate(
                    offset: Offset(20 * (1 - t), 0),
                    child: _buildSkipButton(),
                  ),
                );
              },
            ),
          ),

          if (_fadeOutStarted)
            Positioned.fill(
              child: FadeTransition(
                opacity:
                    _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(color: SplashHx.bg),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBrandCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        color: SplashHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation:
                Listenable.merge([_pulseController, _sparkleController]),
            builder: (context, _) {
              final pulse = _pulseController.value;
              return SizedBox(
                width: 74, height: 74,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Transform.rotate(
                      angle: _sparkleController.value * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(74, 74),
                        painter: _SparkleRingPainter(),
                      ),
                    ),
                    Container(
                      width: 54 + (14 * pulse),
                      height: 54 + (14 * pulse),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withOpacity(
                            0.3 - 0.2 * pulse,
                          ),
                          width: 1,
                        ),
                      ),
                    ),
                    // Center white circle + logo
                    Container(
                      width: 52, height: 52,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: SplashHx.ivory,
                      ),
                      child: Center(
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                            width: 46, height: 46,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.shield_rounded,
                              color: SplashHx.bg,
                              size: 22,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 14),
          const Text(
            "show x xyro",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: SplashHx.ivory,
              letterSpacing: 2.4,
              fontFamily: kFontFamily,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "P R E M I U M   S Y S T E M",
            style: TextStyle(
              color: SplashHx.ash,
              fontFamily: kFontFamily,
              fontSize: 9,
              fontWeight: FontWeight.w800,
              letterSpacing: 3.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkipButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        _navigateToDashboard();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: SplashHx.ivory,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(
              Icons.skip_next_rounded,
              color: SplashHx.bg,
              size: 17,
            ),
            SizedBox(width: 6),
            Text(
              "SKIP",
              style: TextStyle(
                color: SplashHx.bg,
                fontWeight: FontWeight.w900,
                fontSize: 11,
                letterSpacing: 2.2,
                fontFamily: kFontFamily,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SparkleRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    for (int i = 0; i < 4; i++) {
      final angle = (i / 4) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final sparklePaint = Paint()
        ..color = Colors.white.withOpacity(0.6)
        ..style = PaintingStyle.fill;

      _drawStar(canvas, Offset(x, y), 5, sparklePaint);
    }
  }

  void _drawStar(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx + size * 0.3, center.dy - size * 0.3);
    path.lineTo(center.dx + size, center.dy);
    path.lineTo(center.dx + size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx, center.dy + size);
    path.lineTo(center.dx - size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx - size, center.dy);
    path.lineTo(center.dx - size * 0.3, center.dy - size * 0.3);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparkleRingPainter old) => false;
}