// lib/tools_gateway.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class Tk {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  // ── CARD ──
  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // ── PINK FAMILY ──
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  // ── Per-category accents (cute pastel) ──
  static const terra    = Color(0xFFFF7A9A);  // Attack
  static const amber    = Color(0xFFFFD58A);  // OSINT
  static const slate    = Color(0xFF93C5FD);  // Network
  static const amethyst = Color(0xFFC4A5FF);  // Downloader
  static const jade     = Color(0xFF6EE7B7);  // Utilities
  static const rose     = Color(0xFFFF9EC4);  // Watch
  static const purple   = Color(0xFFC4A5FF);

  // ── TEXT ──
  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
  static const lineSoft = Color(0x0DFF6FA5);

  // aliases
  static const goldLight = pinkLight;
  static const gold = pink;
  static const goldMid = pinkSoft;
  static const goldDeep = pinkDeep;
  static const crimsonLight = pinkLight;
  static const crimson = pink;
  static const crimsonMid = pinkSoft;
  static const crimsonDeep = pinkDeep;
  static const champagne = amber;
  static const champagneDeep = Color(0xFFD4A56A);
}

class ToolItem {
  final String id;
  final IconData icon;
  final String label;
  final String category;
  final bool isVipOnly;
  final VoidCallback onTap;

  ToolItem({
    required this.id,
    required this.icon,
    required this.label,
    required this.category,
    this.isVipOnly = false,
    required this.onTap,
  });
}

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  late AnimationController _pulse;
  late AnimationController _entrance;

  bool get _isVip =>
      widget.userRole == 'vip' || widget.userRole == 'owner';

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _pulse.dispose();
    _entrance.dispose();
    super.dispose();
  }

  List<ToolItem> _getAllTools(BuildContext context) {
    return [
      ToolItem(
        id: "ddos_panel",
        icon: Icons.flash_on_rounded,
        label: "DDoS Panel",
        category: "Attack",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
              builder: (_) => AttackPanel(
                sessionKey: widget.sessionKey,
                listDoos: widget.listDoos,
              ),
            )),
      ),
      ToolItem(
        id: "manage_server",
        icon: Icons.dns_rounded,
        label: "Manage Server",
        category: "Attack",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
              builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
            )),
      ),
      ToolItem(
        id: "nik_check",
        icon: Icons.badge_rounded,
        label: "NIK Check",
        category: "OSINT",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const NikCheckerPage())),
      ),
      ToolItem(
        id: "domain_osint",
        icon: Icons.language_rounded,
        label: "Domain OSINT",
        category: "OSINT",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const DomainOsintPage())),
      ),
      ToolItem(
        id: "spam_ngl",
        icon: Icons.newspaper_rounded,
        label: "Spam NGL",
        category: "Network",
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => NglPage())),
      ),
      ToolItem(
        id: "wifi_internal",
        icon: Icons.wifi_off_rounded,
        label: "WiFi Killer (Internal)",
        category: "Network",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => WifiKillerPage())),
      ),
      if (_isVip)
        ToolItem(
          id: "wifi_external",
          icon: Icons.router_rounded,
          label: "WiFi Killer (External)",
          category: "Network",
          isVipOnly: true,
          onTap: () => Navigator.push(context,
              MaterialPageRoute(
                builder: (_) =>
                    WifiInternalPage(sessionKey: widget.sessionKey),
              )),
        ),
      ToolItem(
        id: "tiktok",
        icon: Icons.videocam_rounded,
        label: "TikTok Downloader",
        category: "Downloader",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const TiktokDownloaderPage())),
      ),
      ToolItem(
        id: "instagram",
        icon: Icons.camera_alt_rounded,
        label: "Instagram Downloader",
        category: "Downloader",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
                builder: (_) => const InstagramDownloaderPage())),
      ),
      ToolItem(
        id: "qr_gen",
        icon: Icons.qr_code_rounded,
        label: "QR Generator",
        category: "Utilities",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const QrGeneratorPage())),
      ),
      ToolItem(
        id: "anime",
        icon: Icons.live_tv_rounded,
        label: "Anime Streaming",
        category: "Watch",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const HomeAnimePage())),
      ),
    ];
  }

  List<String> get _quickAccessIds =>
      ["ddos_panel", "nik_check", "domain_osint", "tiktok"];

  Color _categoryColor(String cat) {
    switch (cat) {
      case "Attack":
        return Tk.terra;
      case "OSINT":
        return Tk.amber;
      case "Network":
        return Tk.slate;
      case "Downloader":
        return Tk.amethyst;
      case "Utilities":
        return Tk.jade;
      case "Watch":
        return Tk.rose;
      default:
        return Tk.pink;
    }
  }

  List<ToolItem> _filterTools(List<ToolItem> tools) {
    if (_searchQuery.isEmpty) return tools;
    return tools
        .where((t) =>
            t.label.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  Map<String, List<ToolItem>> _groupByCategory(List<ToolItem> tools) {
    final Map<String, List<ToolItem>> grouped = {};
    for (var tool in tools) {
      grouped.putIfAbsent(tool.category, () => []).add(tool);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    final allTools = _getAllTools(context);
    final filteredTools = _filterTools(allTools);
    final grouped = _groupByCategory(filteredTools);
    final categoryOrder = [
      "Attack",
      "OSINT",
      "Network",
      "Downloader",
      "Utilities",
      "Watch"
    ];

    int entryIdx = 0;

    return Scaffold(
      backgroundColor: Tk.bg,
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1A0E14),
              Color(0xFF241318),
            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // HEADER
              SliverToBoxAdapter(
                child: _staggered(
                  index: entryIdx++,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 90, 20, 18),
                    child: _buildHeader(allTools.length),
                  ),
                ),
              ),

              // SEARCH
              SliverToBoxAdapter(
                child: _staggered(
                  index: entryIdx++,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                    child: _buildSearchBar(),
                  ),
                ),
              ),

              // QUICK ACCESS
              if (_searchQuery.isEmpty)
                SliverToBoxAdapter(
                  child: _staggered(
                    index: entryIdx++,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
                      child: _buildQuickAccess(allTools),
                    ),
                  ),
                ),

              // EMPTY / LIST
              if (filteredTools.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: _buildEmptyState(),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final category = categoryOrder[index];
                        final tools = grouped[category] ?? [];
                        if (tools.isEmpty) return const SizedBox.shrink();
                        return _staggered(
                          index: entryIdx++,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildSectionHeader(
                                category,
                                tools.length,
                                _categoryColor(category),
                              ),
                              _buildToolGrid(tools),
                              const SizedBox(height: 18),
                            ],
                          ),
                        );
                      },
                      childCount: categoryOrder.length,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 12;
    final double start = (index / total) * 0.55;
    final double end = (start + 0.45).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══ HEADER — pink cute ═══
  Widget _buildHeader(int totalTools) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                return Container(
                  width: 3,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Tk.pink.withOpacity(
                      0.6 + 0.4 * _pulse.value,
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "TOOLS GATEWAY ♡",
              style: TextStyle(
                color: Tk.ivory,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.6,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "Premium",
          style: TextStyle(
            color: Tk.ivory,
            fontFamily: kFontFamily,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.6,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        // "Toolkit" gradient pink
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Tk.pinkLight, Tk.pinkDeep],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
          child: const Text(
            "Toolkit",
            style: TextStyle(
              color: Colors.white,
              fontFamily: kFontFamily,
              fontSize: 34,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.2,
              height: 1.05,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            // TOOLS COUNT badge — gradient pink
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 5,
              ),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Tk.pinkLight, Tk.pinkDeep],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(7),
                boxShadow: [
                  BoxShadow(
                    color: Tk.pink.withOpacity(0.5),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Text(
                "$totalTools TOOLS",
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: kFontFamily,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ),
            // ONLINE badge — jade subtle
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 5,
              ),
              decoration: BoxDecoration(
                color: Tk.jade.withOpacity(0.15),
                border: Border.all(
                  color: Tk.jade.withOpacity(0.5),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(7),
                boxShadow: [
                  BoxShadow(
                    color: Tk.jade.withOpacity(0.25),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: Tk.jade,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Tk.jade.withOpacity(0.8),
                          blurRadius: 6,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Text(
                    "ONLINE",
                    style: TextStyle(
                      color: Tk.jade,
                      fontFamily: kFontFamily,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ═══ SEARCH — pink border ═══
  Widget _buildSearchBar() {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        color: Tk.surfaceHi,
        border: Border.all(
          color: Tk.pink.withOpacity(0.3),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Tk.pink.withOpacity(0.15),
            blurRadius: 12,
            spreadRadius: 1,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: TextField(
        controller: _searchController,
        onChanged: (value) => setState(() => _searchQuery = value),
        style: const TextStyle(
          color: Tk.ivory,
          fontFamily: kFontFamily,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
        ),
        cursorColor: Tk.pink,
        decoration: InputDecoration(
          hintText: "Search tools...",
          hintStyle: const TextStyle(
            color: Tk.ash2,
            fontFamily: kFontFamily,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon:
              const Icon(Icons.search_rounded, color: Tk.pinkLight, size: 20),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.close_rounded,
                      color: Tk.pinkLight, size: 18),
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    _searchController.clear();
                    setState(() => _searchQuery = "");
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  // ═══ QUICK ACCESS ═══
  Widget _buildQuickAccess(List<ToolItem> allTools) {
    final quickTools = allTools
        .where((t) => _quickAccessIds.contains(t.id))
        .take(4)
        .toList();
    if (quickTools.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          child: Row(
            children: [
              const Icon(Icons.bolt_rounded, color: Tk.pinkLight, size: 16),
              const SizedBox(width: 8),
              const Text(
                "QUICK ACCESS",
                style: TextStyle(
                  color: Tk.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.4,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Tk.pink.withOpacity(0.5),
                        Tk.pink.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.75,
          ),
          itemCount: quickTools.length,
          itemBuilder: (context, index) =>
              _buildQuickAccessCard(quickTools[index]),
        ),
      ],
    );
  }

  Widget _buildQuickAccessCard(ToolItem tool) {
    final accent = _categoryColor(tool.category);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          HapticFeedback.mediumImpact();
          tool.onTap();
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Tk.surfaceHi,
            border: Border.all(
              color: accent.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.2),
                blurRadius: 12,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.18),
                  border: Border.all(
                    color: accent.withOpacity(0.55),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.35),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(tool.icon, color: accent, size: 17),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  tool.label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Tk.ivory,
                    fontFamily: kFontFamily,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ SECTION HEADER ═══
  Widget _buildSectionHeader(String title, int count, Color accent) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 12),
      child: Row(
        children: [
          const Icon(Icons.favorite_rounded, color: Tk.pink, size: 12),
          const SizedBox(width: 8),
          Text(
            title.toUpperCase(),
            style: const TextStyle(
              color: Tk.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.2,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.18),
              border: Border.all(
                color: accent.withOpacity(0.5),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              "$count",
              style: TextStyle(
                color: accent,
                fontFamily: kFontFamily,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    accent.withOpacity(0.5),
                    accent.withOpacity(0.0),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ TOOL GRID — 2 KOLOM ═══
  Widget _buildToolGrid(List<ToolItem> tools) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.15,
      ),
      itemCount: tools.length,
      itemBuilder: (context, index) => _buildToolCard(tools[index]),
    );
  }

  // ═══ TOOL CARD — pink cute ═══
  Widget _buildToolCard(ToolItem tool) {
    final accent = _categoryColor(tool.category);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          HapticFeedback.mediumImpact();
          tool.onTap();
        },
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Tk.surfaceHi,
            border: Border.all(
              color: accent.withOpacity(0.35),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.18),
                blurRadius: 14,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // VIP badge — gradient pink
              if (tool.isVipOnly)
                Positioned(
                  top: 0, right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7, vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Tk.pinkLight, Tk.pinkDeep],
                      ),
                      borderRadius: BorderRadius.circular(6),
                      boxShadow: [
                        BoxShadow(
                          color: Tk.pink.withOpacity(0.5),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: const Text(
                      "VIP ♡",
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: kFontFamily,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ),
                ),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Icon
                  Container(
                    width: 46, height: 46,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.18),
                      border: Border.all(
                        color: accent.withOpacity(0.55),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.35),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(tool.icon, color: accent, size: 22),
                  ),
                  const Spacer(),

                  // Label
                  Text(
                    tool.label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Tk.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 6),

                  // Category + arrow
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          tool.category.toUpperCase(),
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 8.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        width: 24, height: 24,
                        decoration: BoxDecoration(
                          color: accent.withOpacity(0.15),
                          border: Border.all(
                            color: accent.withOpacity(0.5),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(7),
                        ),
                        child: Icon(
                          Icons.chevron_right_rounded,
                          color: accent,
                          size: 14,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ EMPTY ═══
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 84, height: 84,
              decoration: BoxDecoration(
                color: Tk.surfaceHi,
                border: Border.all(
                  color: Tk.pink.withOpacity(0.3),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Tk.pink.withOpacity(0.2),
                    blurRadius: 14,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.search_off_rounded,
                color: Tk.pinkLight,
                size: 38,
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              "No tools found",
              style: TextStyle(
                color: Tk.ivory,
                fontFamily: kFontFamily,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Try a different keyword",
              style: TextStyle(
                color: Tk.ash,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}