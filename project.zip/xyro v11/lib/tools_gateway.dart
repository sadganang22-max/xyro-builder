// lib/tools_gateway.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class Tk {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);  // hitam murni
  static const bgAlt = Color(0xFF0A0A0A);  // hitam hampir pekat

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);  // hitam card
  static const surfaceHi2 = Color(0xFF1C1C1C); // hitam inner card

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);  // putih keabuan
  static const gold      = Color(0xFFFFFFFF);  // putih
  static const goldMid   = Color(0xFFD0D0D0);  // grey terang
  static const goldDeep  = Color(0xFF808080);  // grey

  // ── Per-category accents (muted, classy) ──
  static const terra    = Color(0xFFF87171);  // Attack — merah
  static const amber    = Color(0xFFFBBF24);  // OSINT — kuning
  static const slate    = Color(0xFF60A5FA);  // Network — biru
  static const amethyst = Color(0xFFA78BFA);  // Downloader — ungu
  static const jade     = Color(0xFF4ADE80);  // Utilities — hijau
  static const rose     = Color(0xFFF472B6);  // Watch — pink
  static const purple   = Color(0xFFA78BFA);  // alias amethyst

  // Aliases biar backward-compatible
  static const crimsonLight = goldLight;
  static const crimson = gold;
  static const crimsonMid = goldMid;
  static const crimsonDeep = goldDeep;
  static const champagne = amber;
  static const champagneDeep = Color(0xFF9E7A5A);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);  // putih
  static const ash   = Color(0xFF9CA3AF);  // grey
  static const ash2  = Color(0xFF4B5563);  // grey gelap

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class ToolItem {
  final String id;
  final IconData icon;
  final String label;
  final String category;
  final bool isVipOnly;
  final VoidCallback onTap;

  ToolItem({
    required this.id,
    required this.icon,
    required this.label,
    required this.category,
    this.isVipOnly = false,
    required this.onTap,
  });
}

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  late AnimationController _pulse;
  late AnimationController _entrance;

  bool get _isVip =>
      widget.userRole == 'vip' || widget.userRole == 'owner';

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _pulse.dispose();
    _entrance.dispose();
    super.dispose();
  }

  List<ToolItem> _getAllTools(BuildContext context) {
    return [
      ToolItem(
        id: "ddos_panel",
        icon: Icons.flash_on_rounded,
        label: "DDoS Panel",
        category: "Attack",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
              builder: (_) => AttackPanel(
                sessionKey: widget.sessionKey,
                listDoos: widget.listDoos,
              ),
            )),
      ),
      ToolItem(
        id: "manage_server",
        icon: Icons.dns_rounded,
        label: "Manage Server",
        category: "Attack",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
              builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
            )),
      ),
      ToolItem(
        id: "nik_check",
        icon: Icons.badge_outlined,
        label: "NIK Check",
        category: "OSINT",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const NikCheckerPage())),
      ),
      ToolItem(
        id: "domain_osint",
        icon: Icons.language_rounded,
        label: "Domain OSINT",
        category: "OSINT",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const DomainOsintPage())),
      ),
      ToolItem(
        id: "spam_ngl",
        icon: Icons.newspaper_rounded,
        label: "Spam NGL",
        category: "Network",
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => NglPage())),
      ),
      ToolItem(
        id: "wifi_internal",
        icon: Icons.wifi_off_rounded,
        label: "WiFi Killer (Internal)",
        category: "Network",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => WifiKillerPage())),
      ),
      if (_isVip)
        ToolItem(
          id: "wifi_external",
          icon: Icons.router_rounded,
          label: "WiFi Killer (External)",
          category: "Network",
          isVipOnly: true,
          onTap: () => Navigator.push(context,
              MaterialPageRoute(
                builder: (_) =>
                    WifiInternalPage(sessionKey: widget.sessionKey),
              )),
        ),
      ToolItem(
        id: "tiktok",
        icon: Icons.videocam_rounded,
        label: "TikTok Downloader",
        category: "Downloader",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const TiktokDownloaderPage())),
      ),
      ToolItem(
        id: "instagram",
        icon: Icons.camera_alt_rounded,
        label: "Instagram Downloader",
        category: "Downloader",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
                builder: (_) => const InstagramDownloaderPage())),
      ),
      ToolItem(
        id: "qr_gen",
        icon: Icons.qr_code_rounded,
        label: "QR Generator",
        category: "Utilities",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const QrGeneratorPage())),
      ),
      ToolItem(
        id: "anime",
        icon: Icons.live_tv_rounded,
        label: "Anime Streaming",
        category: "Watch",
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const HomeAnimePage())),
      ),
    ];
  }

  List<String> get _quickAccessIds =>
      ["ddos_panel", "nik_check", "domain_osint", "tiktok"];

  Color _categoryColor(String cat) {
    switch (cat) {
      case "Attack":
        return Tk.terra;
      case "OSINT":
        return Tk.amber;
      case "Network":
        return Tk.slate;
      case "Downloader":
        return Tk.amethyst;
      case "Utilities":
        return Tk.jade;
      case "Watch":
        return Tk.rose;
      default:
        return Tk.gold;
    }
  }

  List<ToolItem> _filterTools(List<ToolItem> tools) {
    if (_searchQuery.isEmpty) return tools;
    return tools
        .where((t) =>
            t.label.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  Map<String, List<ToolItem>> _groupByCategory(List<ToolItem> tools) {
    final Map<String, List<ToolItem>> grouped = {};
    for (var tool in tools) {
      grouped.putIfAbsent(tool.category, () => []).add(tool);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    final allTools = _getAllTools(context);
    final filteredTools = _filterTools(allTools);
    final grouped = _groupByCategory(filteredTools);
    final categoryOrder = [
      "Attack",
      "OSINT",
      "Network",
      "Downloader",
      "Utilities",
      "Watch"
    ];

    int entryIdx = 0;

    return Scaffold(
      backgroundColor: Tk.bg,
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),  // atas: hitam murni
              Color(0xFF0A0A0A),  // bawah: hitam sedikit terang
            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // HEADER
              SliverToBoxAdapter(
                child: _staggered(
                  index: entryIdx++,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 90, 20, 18),
                    child: _buildHeader(allTools.length),
                  ),
                ),
              ),

              // SEARCH
              SliverToBoxAdapter(
                child: _staggered(
                  index: entryIdx++,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                    child: _buildSearchBar(),
                  ),
                ),
              ),

              // QUICK ACCESS
              if (_searchQuery.isEmpty)
                SliverToBoxAdapter(
                  child: _staggered(
                    index: entryIdx++,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
                      child: _buildQuickAccess(allTools),
                    ),
                  ),
                ),

              // EMPTY / LIST
              if (filteredTools.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: _buildEmptyState(),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final category = categoryOrder[index];
                        final tools = grouped[category] ?? [];
                        if (tools.isEmpty) return const SizedBox.shrink();
                        return _staggered(
                          index: entryIdx++,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildSectionHeader(
                                category,
                                tools.length,
                                _categoryColor(category),
                              ),
                              _buildToolGrid(tools),
                              const SizedBox(height: 18),
                            ],
                          ),
                        );
                      },
                      childCount: categoryOrder.length,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 12;
    final double start = (index / total) * 0.55;
    final double end = (start + 0.45).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══ HEADER ═══
  Widget _buildHeader(int totalTools) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                return Container(
                  width: 3,
                  height: 12,
                  color: Tk.ivory.withOpacity(
                    0.6 + 0.4 * _pulse.value,
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "TOOLS GATEWAY",
              style: TextStyle(
                color: Tk.ivory,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "Premium",
          style: TextStyle(
            color: Tk.ivory,
            fontFamily: kFontFamily,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.6,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          "Toolkit",
          style: TextStyle(
            color: Tk.ivory,
            fontFamily: kFontFamily,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: -1.2,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            // TOOLS COUNT badge — putih + text hitam
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 5,
              ),
              decoration: BoxDecoration(
                color: Tk.ivory,
                borderRadius: BorderRadius.circular(7),
              ),
              child: Text(
                "$totalTools TOOLS",
                style: const TextStyle(
                  color: Tk.bg,
                  fontFamily: kFontFamily,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ),
            // ONLINE badge — hijau subtle
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 5,
              ),
              decoration: BoxDecoration(
                color: Tk.jade.withOpacity(0.12),
                border: Border.all(
                  color: Tk.jade.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Tk.jade,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Text(
                    "ONLINE",
                    style: TextStyle(
                      color: Tk.jade,
                      fontFamily: kFontFamily,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ═══ SEARCH ═══
  Widget _buildSearchBar() {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        color: Tk.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: TextField(
        controller: _searchController,
        onChanged: (value) => setState(() => _searchQuery = value),
        style: const TextStyle(
          color: Tk.ivory,
          fontFamily: kFontFamily,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
        ),
        cursorColor: Tk.ivory,
        decoration: InputDecoration(
          hintText: "Search tools...",
          hintStyle: const TextStyle(
            color: Tk.ash2,
            fontFamily: kFontFamily,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon:
              const Icon(Icons.search_rounded, color: Tk.ash, size: 20),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.close_rounded,
                      color: Tk.ash, size: 18),
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    _searchController.clear();
                    setState(() => _searchQuery = "");
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  // ═══ QUICK ACCESS ═══
  Widget _buildQuickAccess(List<ToolItem> allTools) {
    final quickTools = allTools
        .where((t) => _quickAccessIds.contains(t.id))
        .take(4)
        .toList();
    if (quickTools.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          child: Row(
            children: [
              const Icon(Icons.bolt_rounded, color: Tk.ivory, size: 16),
              const SizedBox(width: 8),
              const Text(
                "QUICK ACCESS",
                style: TextStyle(
                  color: Tk.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.4,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  color: Colors.white.withOpacity(0.08),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.75,
          ),
          itemCount: quickTools.length,
          itemBuilder: (context, index) =>
              _buildQuickAccessCard(quickTools[index]),
        ),
      ],
    );
  }

  Widget _buildQuickAccessCard(ToolItem tool) {
    final accent = _categoryColor(tool.category);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          HapticFeedback.mediumImpact();
          tool.onTap();
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Tk.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  border: Border.all(
                    color: accent.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(tool.icon, color: accent, size: 17),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  tool.label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Tk.ivory,
                    fontFamily: kFontFamily,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ SECTION HEADER ═══
  Widget _buildSectionHeader(String title, int count, Color accent) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 12),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 12,
            color: accent,
          ),
          const SizedBox(width: 10),
          Text(
            title.toUpperCase(),
            style: const TextStyle(
              color: Tk.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.2,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.12),
              border: Border.all(
                color: accent.withOpacity(0.4),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              "$count",
              style: TextStyle(
                color: accent,
                fontFamily: kFontFamily,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              height: 1,
              color: accent.withOpacity(0.2),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ TOOL GRID — 2 KOLOM ═══
  Widget _buildToolGrid(List<ToolItem> tools) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.15,
      ),
      itemCount: tools.length,
      itemBuilder: (context, index) => _buildToolCard(tools[index]),
    );
  }

  // ═══ TOOL CARD ═══
  Widget _buildToolCard(ToolItem tool) {
    final accent = _categoryColor(tool.category);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          HapticFeedback.mediumImpact();
          tool.onTap();
        },
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Tk.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // VIP badge pojok kanan atas — putih + text hitam
              if (tool.isVipOnly)
                Positioned(
                  top: 0, right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: Tk.ivory,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: const Text(
                      "VIP",
                      style: TextStyle(
                        color: Tk.bg,
                        fontFamily: kFontFamily,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ),
                ),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Icon
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.12),
                      border: Border.all(
                        color: accent.withOpacity(0.4),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(tool.icon, color: accent, size: 20),
                  ),
                  const Spacer(),

                  // Label
                  Text(
                    tool.label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Tk.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 6),

                  // Category + arrow
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          tool.category.toUpperCase(),
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 8.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        width: 22, height: 22,
                        decoration: BoxDecoration(
                          color: accent.withOpacity(0.1),
                          border: Border.all(
                            color: accent.withOpacity(0.4),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Icon(
                          Icons.arrow_forward_rounded,
                          color: accent,
                          size: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ EMPTY ═══
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 84, height: 84,
              decoration: BoxDecoration(
                color: Tk.surfaceHi,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.search_off_rounded,
                color: Tk.ash,
                size: 38,
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              "No tools found",
              style: TextStyle(
                color: Tk.ivory,
                fontFamily: kFontFamily,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Try a different keyword",
              style: TextStyle(
                color: Tk.ash,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}