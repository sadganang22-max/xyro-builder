// lib/cek_band_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
const Color _bg      = Color(0xFF000000);
const Color _bgCard  = Color(0xFF141414);
const Color _bgSurf  = Color(0xFF1C1C1C);
const Color _border  = Color(0x1AFFFFFF);
const Color _textL   = Color(0xFFFFFFFF);
const Color _textM   = Color(0xFF9CA3AF);
const Color _textDim = Color(0xFF4B5563);
const Color _success = Color(0xFFFFFFFF);
const Color _danger  = Color(0xFFFFFFFF);
const Color _warn    = Color(0xFFFFFFFF);

const String kFontFamily = 'Ganang';
const String _baseUrl = "http://www.rexylegal.rxpedia.web.id:2060";

class CekBandPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const CekBandPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<CekBandPage> createState() => _CekBandPageState();
}

class _CekBandPageState extends State<CekBandPage>
    with TickerProviderStateMixin {
  final TextEditingController _phoneCtrl = TextEditingController();
  bool _isChecking = false;
  Map<String, dynamic>? _result;
  String? _errorMsg;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // ── VIDEO BANNER ──
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.2, end: 0.9)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
        
    _initVideo();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _phoneCtrl.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0); // ✅ Suara nyala
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();
      if (!mounted) return;
      setState(() {
        _videoController = controller;
        _videoReady = true;
      });
    } catch (e) {
      debugPrint('Video error: $e');
    }
  }

  String _normalize(String raw) {
    String n = raw.trim().replaceAll(RegExp(r'[\s\-]'), '');
    if (n.startsWith('0')) n = '62${n.substring(1)}';
    if (n.startsWith('+')) n = n.substring(1);
    return n;
  }

  Future<void> _check() async {
    final raw = _phoneCtrl.text.trim();
    if (raw.isEmpty) {
      _snack('Masukkan nomor WA dulu', isErr: true);
      return;
    }
    final number = _normalize(raw);
    if (!RegExp(r'^\d{10,15}$').hasMatch(number)) {
      _snack('Format nomor tidak valid. Contoh: 628123456789', isErr: true);
      return;
    }

    setState(() {
      _isChecking = true;
      _result = null;
      _errorMsg = null;
    });

    String? finalError;
    for (int attempt = 1; attempt <= 3; attempt++) {
      try {
        final resp = await http
            .get(Uri.parse(
                '$_baseUrl/checkBan?key=${widget.sessionKey}&number=$number'))
            .timeout(const Duration(seconds: 20));

        if (resp.statusCode == 200) {
          final data = jsonDecode(resp.body);
          if (data['valid'] == true) {
            final note = data['note']?.toString() ?? '';
            if (note == 'no_sender') {
              setState(() => _errorMsg =
                  'Tidak ada sender aktif. Tambahkan sender WA di menu Sender Nodes dulu.');
              return;
            }
            setState(() => _result = data);
            return;
          } else {
            final errMsg = data['error'] ?? data['message'] ?? 'Cek gagal';
            if (errMsg.toString().toLowerCase().contains('rate limit') ||
                errMsg.toString().toLowerCase().contains('tunggu')) {
              setState(() => _errorMsg = errMsg.toString());
              return;
            }
            finalError = errMsg.toString();
            if (attempt < 3) {
              await Future.delayed(const Duration(seconds: 2));
              continue;
            }
          }
        } else if (resp.statusCode == 429) {
          setState(() => _errorMsg = 'Rate limit — tunggu sebentar lalu coba lagi');
          return;
        } else if (resp.statusCode == 404) {
          setState(() => _errorMsg =
              'Fitur belum aktif. Replace index.js di server dengan index_v12_patch.js lalu restart.');
          return;
        } else if (resp.statusCode == 401) {
          setState(() => _errorMsg = 'Session expired — silakan login ulang');
          return;
        } else {
          try {
            final d = jsonDecode(resp.body);
            finalError = d['error'] ?? d['message'] ?? 'Server error: ${resp.statusCode}';
          } catch (_) {
            finalError = 'Server error: ${resp.statusCode}';
          }
          if (attempt < 3) {
            await Future.delayed(const Duration(seconds: 2));
            continue;
          }
        }
      } on TimeoutException {
        finalError = 'Server tidak merespons (timeout). Coba lagi.';
        if (attempt < 3) {
          await Future.delayed(const Duration(seconds: 2));
          continue;
        }
      } on Exception catch (e) {
        finalError = 'Koneksi gagal: $e';
        if (attempt < 3) {
          await Future.delayed(const Duration(seconds: 2));
          continue;
        }
      }
      break;
    }

    if (mounted) setState(() => _errorMsg = finalError ?? 'Cek gagal setelah 3 percobaan');
  }

  void _snack(String msg, {bool isErr = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(
          isErr ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
          color: _textL,
          size: 18,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(msg,
              style: const TextStyle(
                  color: _textL,
                  fontWeight: FontWeight.w700,
                  fontSize: 13)),
        ),
      ]),
      backgroundColor: _bgCard,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: _textL.withOpacity(0.15)),
      ),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      duration: const Duration(seconds: 3),
    ));
  }

  // ═══════════════════════════════════════════════════════════
  // EFEK HUD & SCANLINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 14, double thickness = 1.5}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 10, left: 10, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 10, right: 10, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 10, left: 10, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 10, right: 10, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: size, height: thickness, color: _textL.withOpacity(0.6)),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: thickness, height: size, color: _textL.withOpacity(0.6)),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.15,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.white.withOpacity(0.4), Colors.transparent],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 160,
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(
                color: _bgSurf,
                child: const Center(
                  child: SizedBox(
                    width: 22, height: 22,
                    child: CircularProgressIndicator(color: _textL, strokeWidth: 2.0),
                  ),
                ),
              ),

            // Overlay gradient
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, _bg.withOpacity(0.25), _bg.withOpacity(0.65)],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // EFEK HUD & SCANLINE
            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            // Badge WA BAN CHECKER
            Positioned(
              top: 12, right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: _textL, borderRadius: BorderRadius.circular(6)),
                child: const Text(
                  'WA CHECKER',
                  style: TextStyle(
                    color: _bg,
                    fontSize: 9,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
            ),

            // Text Overlay
            Positioned(
              left: 18, right: 18, bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'CEK STATUS BAND',
                    style: TextStyle(
                      color: _textL,
                      fontFamily: kFontFamily,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Deteksi nomor WhatsApp yang diblokir',
                    style: TextStyle(
                      color: _textL.withOpacity(0.65),
                      fontFamily: kFontFamily,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(children: [
          // ── Header ──
          Container(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
            decoration: BoxDecoration(
              color: _bg,
              border: Border(bottom: BorderSide(color: _border, width: 1)),
            ),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                    color: _bgSurf,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _border)),
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new, color: _textL, size: 16),
                  padding: EdgeInsets.zero,
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Cek Band',
                      style: TextStyle(
                          color: _textL,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                          letterSpacing: -0.6)),
                  const SizedBox(height: 3),
                  Row(children: [
                    Container(width: 4, height: 4, decoration: const BoxDecoration(color: _textL, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    const Text('WA Ban Checker',
                        style: TextStyle(color: _textM, fontFamily: kFontFamily, fontSize: 11, fontWeight: FontWeight.w600)),
                  ]),
                ]),
              ),
            ]),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                // ✅ BANNER VIDEO DENGAN HUD
                _buildVideoBanner(),

                // ── Input Card ──
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: _bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _border),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _bgSurf,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _border),
                        ),
                        child: const Icon(Icons.phone_iphone, color: _textL, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('Nomor Target',
                              style: TextStyle(color: _textL, fontFamily: kFontFamily, fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: -0.3)),
                          const Text('Masukkan nomor WA yang ingin dicek',
                              style: TextStyle(color: _textDim, fontFamily: kFontFamily, fontSize: 11)),
                        ]),
                      ),
                    ]),
                    const SizedBox(height: 16),

                    Container(
                      decoration: BoxDecoration(
                        color: _bgSurf,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _border),
                      ),
                      child: TextField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        cursorColor: _textL,
                        style: const TextStyle(color: _textL, fontSize: 15, fontFamily: kFontFamily, fontWeight: FontWeight.w600, letterSpacing: 0.5),
                        decoration: InputDecoration(
                          labelText: 'Nomor WA',
                          labelStyle: const TextStyle(color: _textDim, fontFamily: kFontFamily, fontSize: 11),
                          hintText: '628xxxxxxxxx',
                          hintStyle: TextStyle(color: _textDim.withOpacity(0.4), fontFamily: kFontFamily, fontSize: 14),
                          prefixIcon: Container(
                            margin: const EdgeInsets.all(10),
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: _bg,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _border),
                            ),
                            child: const Icon(Icons.tag, color: _textL, size: 15),
                          ),
                          suffixIcon: _phoneCtrl.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.clear, color: _textDim, size: 16),
                                  onPressed: () {
                                    _phoneCtrl.clear();
                                    setState(() { _result = null; _errorMsg = null; });
                                  },
                                )
                              : null,
                          filled: true,
                          fillColor: Colors.transparent,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 18),
                        ),
                        onChanged: (_) => setState(() {}),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9\+\-\s]'))
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // ── Tombol Cek ──
                    Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        color: _textL,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: _isChecking ? null : _check,
                          child: Center(
                            child: _isChecking
                                ? const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _bg, strokeWidth: 2)),
                                      SizedBox(width: 10),
                                      Text('Mengecek...', style: TextStyle(color: _bg, fontFamily: kFontFamily, fontWeight: FontWeight.w800, fontSize: 13)),
                                    ],
                                  )
                                : const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.search_rounded, color: _bg, size: 18),
                                      SizedBox(width: 8),
                                      Text('CEK SEKARANG', style: TextStyle(color: _bg, fontFamily: kFontFamily, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.5)),
                                    ],
                                  ),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),

                const SizedBox(height: 16),

                // ── Error State ──
                if (_errorMsg != null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _textL.withOpacity(0.3)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.error_outline_rounded, color: _textL, size: 20),
                      const SizedBox(width: 12),
                      Expanded(child: Text(_errorMsg!, style: const TextStyle(color: _textL, fontFamily: kFontFamily, fontSize: 13, fontWeight: FontWeight.w600))),
                    ]),
                  ),

                // ── Result Card ──
                if (_result != null) ...[
                  _buildResultCard(_result!),
                ],

                const SizedBox(height: 20),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildResultCard(Map<String, dynamic> data) {
    final isBanned = data['banned'] == true;
    final number   = data['number']?.toString() ?? _phoneCtrl.text;
    final status   = data['status']?.toString() ?? (isBanned ? 'banned' : 'active');
    final reason   = data['reason']?.toString();
    final checkedAt = data['checkedAt']?.toString();
    final statusLower = status.toLowerCase();

    final note   = data['note']?.toString() ?? '';
    final method = data['method']?.toString() ?? '';
    final isApproximate = note.contains('approximate') || method.contains('fallback');

    Color statusColor = _textL; // Full White
    IconData statusIcon;
    String statusLabel;
    
    if (statusLower == 'banned' || isBanned) {
      statusIcon  = Icons.block_rounded;
      statusLabel = 'KENA BAN';
    } else if (statusLower == 'warning' || statusLower == 'restricted') {
      statusIcon  = Icons.warning_amber_rounded;
      statusLabel = 'PEMBATASAN';
    } else if (statusLower == 'unknown') {
      statusIcon  = Icons.help_outline_rounded;
      statusLabel = isApproximate ? 'KEMUNGKINAN AMAN' : 'TIDAK DIKETAHUI';
    } else {
      statusIcon  = Icons.check_circle_rounded;
      statusLabel = 'AMAN';
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _textL.withOpacity(0.2)),
      ),
      child: Column(children: [
        // ── Status Header ──
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
          decoration: BoxDecoration(
            color: _bgSurf,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            border: Border(bottom: BorderSide(color: _border, width: 1)),
          ),
          child: Column(children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _bg,
                  border: Border.all(color: _textL.withOpacity(_pulseAnim.value * 0.6 + 0.1), width: 2),
                ),
                child: Icon(statusIcon, color: _textL, size: 36),
              ),
            ),
            const SizedBox(height: 14),
            Text(statusLabel,
                style: const TextStyle(color: _textL, fontFamily: kFontFamily, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: _bg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _border),
              ),
              child: Text(number, style: const TextStyle(color: _textM, fontFamily: kFontFamily, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 1.0)),
            ),
          ]),
        ),

        // ── Detail Info ──
        Padding(
          padding: const EdgeInsets.all(18),
          child: Column(children: [
            if (isApproximate) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: _bg,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _border),
                ),
                child: const Row(children: [
                  Icon(Icons.info_outline, color: _textL, size: 13),
                  SizedBox(width: 8),
                  Expanded(child: Text(
                    'Hasil perkiraan (tanpa sender aktif). Tambah sender untuk akurasi 100%.',
                    style: TextStyle(color: _textL, fontFamily: kFontFamily, fontSize: 11, fontWeight: FontWeight.w600),
                  )),
                ]),
              ),
            ],
            if (reason != null && reason.isNotEmpty) ...[
              _infoRow(Icons.info_outline_rounded, 'Alasan', reason),
              const SizedBox(height: 12),
            ],
            _infoRow(Icons.shield_outlined, 'Status',
                isBanned ? 'Akun Diblokir WhatsApp' : (statusLower == 'unknown' ? 'Perlu Sender untuk Konfirmasi' : 'Akun Aktif & Normal')),
            if (checkedAt != null) ...[
              const SizedBox(height: 12),
              _infoRow(Icons.access_time_rounded, 'Dicek pada', checkedAt),
            ],
          ]),
        ),

        // ── Copy button ──
        Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16), color: _border),
        Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
            onTap: () {
              Clipboard.setData(ClipboardData(
                  text: 'Nomor: $number\nStatus: $statusLabel\n${reason != null ? "Alasan: $reason" : ""}'));
              _snack('Hasil disalin ke clipboard');
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.copy_all_rounded, color: _textM, size: 15),
                const SizedBox(width: 8),
                const Text('Salin Hasil', style: TextStyle(color: _textM, fontFamily: kFontFamily, fontWeight: FontWeight.w700, fontSize: 12)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _bgSurf,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _border),
        ),
        child: const Icon(Icons.info_outline, color: _textL, size: 14), // Pakai icon default biar aman
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: _textDim, fontFamily: kFontFamily, fontSize: 10, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Text(value, style: const TextStyle(color: _textL, fontFamily: kFontFamily, fontSize: 13, fontWeight: FontWeight.w700)),
        ]),
      ),
    ]);
  }
}