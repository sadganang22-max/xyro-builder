// lib/owner_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart'; // Buat ambil AppColors

const String kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  int _mode = 0;

  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _dayCtrl = TextEditingController();
  final _editUserCtrl = TextEditingController();
  final _editDayCtrl = TextEditingController();
  final _delUserCtrl = TextEditingController();

  String _newRole = 'member';
  final List<String> _roleOptions = ['member', 'vip', 'reseller', 'admin'];

  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  bool _isSubmitting = false;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _dayCtrl.dispose();
    _editUserCtrl.dispose();
    _editDayCtrl.dispose();
    _delUserCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    HapticFeedback.mediumImpact();
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (picked == null) return;
      setState(() => _imageFile = File(picked.path));
    } catch (_) {}
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    final color = error ? AppColors.danger : AppColors.success;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      content: Row(
        children: [
          Icon(error ? Icons.error_outline : Icons.check_circle_outline, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontFamily: 'Bangers',
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: AppColors.border, width: 3),
      ),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  Future<void> _submitCreate() async {
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    final day = _dayCtrl.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }
    if (_imageFile == null) {
      _snack('Bukti foto wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final pendingRes = await http.get(Uri.parse(
        '$kBase/createAccountPending'
        '?key=${widget.sessionKey}'
        '&newUser=${Uri.encodeComponent(username)}'
        '&pass=${Uri.encodeComponent(password)}'
        '&day=${Uri.encodeComponent(day)}'
        '&role=${Uri.encodeComponent(_newRole)}',
      )).timeout(const Duration(seconds: 20));

      final pendingData = jsonDecode(pendingRes.body);
      if (pendingData['valid'] != true || pendingData['created'] != true) {
        _snack(pendingData['message'] ?? 'Gagal buat akun', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      final bytes = await _imageFile!.readAsBytes();
      final base64Image = base64Encode(bytes);

      final botRes = await http.post(
        Uri.parse('$kBase/sendPendingToBot'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': username,
          'password': password,
          'day': day,
          'role': _newRole,
          'image': base64Image,
        }),
      ).timeout(const Duration(seconds: 30));

      final botData = jsonDecode(botRes.body);
      if (botData['valid'] != true || botData['sent'] != true) {
        _snack(botData['message'] ?? 'Gagal kirim ke bot', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      HapticFeedback.heavyImpact();
      _snack('BUKTI TERKIRIM KE OWNER. MENUNGGU ACC.', error: false);

      _userCtrl.clear();
      _passCtrl.clear();
      _dayCtrl.clear();
      setState(() {
        _imageFile = null;
        _newRole = 'member';
        _isSubmitting = false;
      });
    } catch (e) {
      _snack('Error: $e', error: true);
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitAddDurasi() async {
    final u = _editUserCtrl.text.trim();
    final d = _editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/editUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}'
        '&addDays=${Uri.encodeComponent(d)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        HapticFeedback.heavyImpact();
        _snack('DURASI BERHASIL DITAMBAH $d HARI', error: false);
        _editUserCtrl.clear();
        _editDayCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal tambah durasi', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitHapus() async {
    final u = _delUserCtrl.text.trim();
    if (u.isEmpty) {
      _snack('Username wajib diisi', error: true);
      return;
    }

    HapticFeedback.heavyImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/deleteUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        HapticFeedback.heavyImpact();
        _snack('USER BERHASIL DIHAPUS', error: false);
        _delUserCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal hapus', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('OWNER PANEL'),
        backgroundColor: AppColors.violet,
        shape: const Border(
          bottom: BorderSide(color: AppColors.border, width: 4),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              _buildTabsRow(),
              const SizedBox(height: 20),

              if (_mode == 0)
                _formCreate()
              else if (_mode == 1)
                _formAddDurasi()
              else
                _formHapus(),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ HEADER KOMIK ═══
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: AppColors.border, width: 4),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(6, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('FULL ACCESS CONSOLE', style: TextStyle(
            fontFamily: 'Bangers', fontSize: 28, color: AppColors.textPrimary, letterSpacing: 1.5)),
          const SizedBox(height: 4),
          Text('Welcome, ${widget.username}', style: const TextStyle(
            fontFamily: 'Comic Neue', fontWeight: FontWeight.bold,
            fontSize: 13, color: AppColors.textSub)),
        ],
      ),
    );
  }

  // ═══ TABS ROW ═══
  Widget _buildTabsRow() {
    return Row(
      children: [
        Expanded(child: _tab('CREATE', Icons.person_add_rounded, AppColors.success, 0)),
        const SizedBox(width: 10),
        Expanded(child: _tab('EXTEND', Icons.timer_rounded, AppColors.cyan, 1)),
        const SizedBox(width: 10),
        Expanded(child: _tab('DELETE', Icons.person_remove_rounded, AppColors.danger, 2)),
      ],
    );
  }

  Widget _tab(String label, IconData icon, Color color, int index) {
    final active = _mode == index;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _mode = index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: active ? color : Colors.white,
          border: Border.all(color: AppColors.border, width: 3),
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(4, 4))],
        ),
        child: Column(
          children: [
            Icon(icon, color: active ? Colors.white : AppColors.textPrimary, size: 24),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(
              fontFamily: 'Bangers', fontSize: 16,
              color: active ? Colors.white : AppColors.textPrimary, letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  // ═══ INPUT FORM ═══
  Widget _input({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    bool obscure = false,
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(
          fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary, letterSpacing: 1)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: obscure,
          keyboardType: type,
          style: const TextStyle(
            fontFamily: 'Bangers', fontSize: 20, color: AppColors.textPrimary),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(fontFamily: 'Bangers', color: AppColors.textMuted),
            prefixIcon: Icon(icon, color: AppColors.textPrimary, size: 22),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.border, width: 3),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.border, width: 3),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.violet, width: 3),
            ),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  // ═══ CARD WRAPPER ═══
  Widget _card(Widget child) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: AppColors.border, width: 4),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(6, 6))],
      ),
      child: child,
    );
  }

  // ═══ FORM CREATE ═══
  Widget _formCreate() {
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(label: 'USERNAME', hint: 'superuser', controller: _userCtrl, icon: Icons.person_rounded),
          _input(label: 'PASSWORD', hint: 'minimal 4 karakter', controller: _passCtrl, icon: Icons.lock_rounded, obscure: true),
          _input(label: 'DURASI (HARI)', hint: '30', controller: _dayCtrl, icon: Icons.calendar_month_rounded, type: TextInputType.number),

          // Role Dropdown
          const Text('ROLE', style: TextStyle(
            fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary, letterSpacing: 1)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: AppColors.border, width: 3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _newRole,
                isExpanded: true,
                dropdownColor: Colors.white,
                style: const TextStyle(fontFamily: 'Bangers', fontSize: 20, color: AppColors.textPrimary),
                icon: const Icon(Icons.arrow_drop_down, color: AppColors.textPrimary, size: 28),
                items: _roleOptions.map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role.toUpperCase()),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _newRole = val ?? 'member'),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Photo Picker
          const Text('BUKTI FOTO', style: TextStyle(
            fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary, letterSpacing: 1)),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.bgDeep,
                border: Border.all(color: AppColors.border, width: 3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(_imageFile != null ? Icons.check_circle_rounded : Icons.image_rounded, 
                      color: _imageFile != null ? AppColors.success : AppColors.textPrimary, size: 24),
                  const SizedBox(width: 10),
                  Text(_imageFile != null ? 'FOTO TERPILIH' : 'PILIH FOTO',
                    style: const TextStyle(fontFamily: 'Bangers', fontSize: 18, color: AppColors.textPrimary)),
                ],
              ),
            ),
          ),

          if (_imageFile != null) ...[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(_imageFile!, height: 150, fit: BoxFit.cover),
            ),
          ],

          const SizedBox(height: 24),
          _submitBtn('KIRIM KE BOT', AppColors.violet, _isSubmitting ? null : _submitCreate),
        ],
      ),
    );
  }

  // ═══ FORM EXTEND ═══
  Widget _formAddDurasi() {
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(label: 'USERNAME TARGET', hint: 'superuser', controller: _editUserCtrl, icon: Icons.person_search_rounded),
          _input(label: 'TAMBAH HARI', hint: '30', controller: _editDayCtrl, icon: Icons.calendar_month_rounded, type: TextInputType.number),
          const SizedBox(height: 24),
          _submitBtn('TAMBAH DURASI', AppColors.cyan, _isSubmitting ? null : _submitAddDurasi),
        ],
      ),
    );
  }

  // ═══ FORM DELETE ═══
  Widget _formHapus() {
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(label: 'USERNAME TARGET', hint: 'superuser', controller: _delUserCtrl, icon: Icons.person_remove_rounded),
          const SizedBox(height: 24),
          _submitBtn('HAPUS AKUN', AppColors.danger, _isSubmitting ? null : _submitHapus),
        ],
      ),
    );
  }

  // ═══ SUBMIT BUTTON ═══
  Widget _submitBtn(String label, Color color, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: color,
          border: Border.all(color: AppColors.border, width: 4),
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [BoxShadow(color: AppColors.border, offset: Offset(5, 5))],
        ),
        child: Center(
          child: _isSubmitting
              ? const CircularProgressIndicator(color: Colors.white)
              : Text(label, style: const TextStyle(
                  fontFamily: 'Bangers', fontSize: 22, color: Colors.white, letterSpacing: 2)),
        ),
      ),
    );
  }
}