// lib/anime.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'theme.dart';

const String kFontFamily = 'Ganang';

// ============================================================
// MODELS
// ============================================================
class AnimeModel {
  final String title;
  final String image;
  final String link;
  final String? upload;
  final String? duration;
  final List<String>? genres;

  AnimeModel({
    required this.title,
    required this.image,
    required this.link,
    this.upload,
    this.duration,
    this.genres,
  });

  factory AnimeModel.fromLatest(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['image'] ?? '',
      link: json['link'] ?? '',
      upload: json['upload'],
    );
  }

  factory AnimeModel.fromRelease(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }

  factory AnimeModel.fromSearch(Map<String, dynamic> json) {
    return AnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }
}

class AnimeDetailModel {
  final String title;
  final String info;
  final String image;
  final String synopsis;
  final String genre;
  final String anime;
  final String producers;
  final String duration;
  final String size;
  final String stream;
  final List<AnimeDownloadOption> downloads;

  AnimeDetailModel({
    required this.title,
    required this.info,
    required this.image,
    required this.synopsis,
    required this.genre,
    required this.anime,
    required this.producers,
    required this.duration,
    required this.size,
    required this.stream,
    required this.downloads,
  });

  factory AnimeDetailModel.fromJson(Map<String, dynamic> json) {
    return AnimeDetailModel(
      title: json['title'] ?? '',
      info: json['info'] ?? '',
      image: json['img'] ?? '',
      synopsis: json['sinopsis'] ?? '',
      genre: json['genre'] ?? '',
      anime: json['anime'] ?? '',
      producers: json['producers'] ?? '',
      duration: json['duration'] ?? '',
      size: json['size'] ?? '',
      stream: json['stream'] ?? '',
      downloads: (json['download'] as List<dynamic>?)
              ?.map((e) => AnimeDownloadOption.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class AnimeDownloadOption {
  final String type;
  final String title;
  final List<AnimeDownloadLink> links;

  AnimeDownloadOption({
    required this.type,
    required this.title,
    required this.links,
  });

  factory AnimeDownloadOption.fromJson(Map<String, dynamic> json) {
    return AnimeDownloadOption(
      type: json['type'] ?? '',
      title: json['title'] ?? '',
      links: (json['links'] as List<dynamic>?)
              ?.map((e) => AnimeDownloadLink.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class AnimeDownloadLink {
  final String name;
  final String url;

  AnimeDownloadLink({
    required this.name,
    required this.url,
  });

  factory AnimeDownloadLink.fromJson(Map<String, dynamic> json) {
    return AnimeDownloadLink(
      name: json['name'] ?? '',
      url: json['link'] ?? '',
    );
  }
}

// ============================================================
// SERVICES
// ============================================================
class AnimeApiService {
  static const String baseUrl = 'https://www.sankavollerei.com/anime/neko';

  static Future<List<AnimeModel>> getLatestAnime() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/latest'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final results = jsonData['results'] as List<dynamic>;
        return results.map((e) => AnimeModel.fromLatest(e)).toList();
      }
      throw Exception('Failed to load latest anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<AnimeModel>> getReleaseAnime(int page) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/release/$page'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => AnimeModel.fromRelease(e)).toList();
      }
      throw Exception('Failed to load release anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<AnimeModel>> searchAnime(String query) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/search/$query'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => AnimeModel.fromSearch(e)).toList();
      }
      throw Exception('Failed to search anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<AnimeDetailModel> getAnimeDetail(String url) async {
    try {
      final encodedUrl = Uri.encodeComponent(url);
      final response =
          await http.get(Uri.parse('$baseUrl/get?url=$encodedUrl'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return AnimeDetailModel.fromJson(jsonData['data']);
      }
      throw Exception('Failed to load anime detail');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

// Helper launch URL (rename biar tidak bentrok dengan package url_launcher)
class AnimeUrlLauncher {
  static Future<void> launch(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      throw Exception('Could not launch $url');
    }
  }
}

// ============================================================
// WIDGETS
// ============================================================
class AnimeVideoCard extends StatelessWidget {
  final AnimeModel anime;
  final bool isLatest;

  const AnimeVideoCard({
    super.key,
    required this.anime,
    this.isLatest = true,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AnimeDetailPage(url: anime.link),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: p.surfaceAlt,
          border: Border.all(
            color: Colors.white.withOpacity(0.7),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  ClipRect(
                    child: Image.network(
                      anime.image,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: p.bg,
                        child: Icon(
                          Icons.image_not_supported,
                          color: p.textMuted,
                        ),
                      ),
                    ),
                  ),
                  if (anime.duration != null && anime.duration!.isNotEmpty)
                    Positioned(
                      bottom: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: p.bg.withOpacity(0.85),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1,
                          ),
                        ),
                        child: Text(
                          anime.duration!,
                          style: TextStyle(
                            color: p.textPrimary,
                            fontSize: 10,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  Positioned(
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: p.bg.withOpacity(0.6),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1.5,
                          ),
                        ),
                        child: Icon(
                          Icons.play_arrow,
                          color: p.textPrimary,
                          size: 26,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      anime.title,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: p.textPrimary,
                        fontFamily: kFontFamily,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    if (isLatest && anime.upload != null)
                      Text(
                        anime.upload!,
                        style: TextStyle(
                          color: p.textTertiary,
                          fontSize: 9,
                          fontFamily: kFontFamily,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    if (!isLatest &&
                        anime.genres != null &&
                        anime.genres!.isNotEmpty)
                      Expanded(
                        child: Wrap(
                          spacing: 4,
                          runSpacing: 2,
                          children: anime.genres!.take(2).map((genre) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: p.bg,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                genre,
                                style: TextStyle(
                                  color: p.textTertiary,
                                  fontSize: 8,
                                  fontFamily: kFontFamily,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AnimeLoadingShimmer extends StatelessWidget {
  final int itemCount;
  final double childAspectRatio;

  const AnimeLoadingShimmer({
    super.key,
    this.itemCount = 6,
    this.childAspectRatio = 0.7,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: itemCount,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: p.surface,
        highlightColor: p.surfaceAlt,
        child: Container(
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// HOME SCREEN
// ============================================================
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  List<AnimeModel> latestAnimeList = [];
  List<AnimeModel> releaseAnimeList = [];
  List<AnimeModel> searchResults = [];
  bool isLoadingLatest = true;
  bool isLoadingRelease = true;
  bool isSearching = false;
  bool isSearchLoading = false;
  bool isLoadingMore = false;
  bool hasMore = true;
  int currentPage = 1;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    fetchLatestAnime();
    fetchReleaseAnime();
    _setupScrollController();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> fetchLatestAnime() async {
    try {
      final data = await AnimeApiService.getLatestAnime();
      if (!mounted) return;
      setState(() {
        latestAnimeList = data;
        isLoadingLatest = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      if (mounted) setState(() => isLoadingLatest = false);
    }
  }

  Future<void> fetchReleaseAnime({bool isRefresh = false}) async {
    if (isLoadingMore) return;

    if (isRefresh) {
      setState(() {
        currentPage = 1;
        hasMore = true;
        releaseAnimeList.clear();
        isLoadingRelease = true;
      });
    } else {
      setState(() => isLoadingMore = true);
    }

    try {
      final data = await AnimeApiService.getReleaseAnime(currentPage);
      if (!mounted) return;

      if (data.isEmpty) {
        setState(() {
          hasMore = false;
          isLoadingMore = false;
          isLoadingRelease = false;
        });
        return;
      }

      setState(() {
        if (isRefresh) {
          releaseAnimeList = data;
        } else {
          releaseAnimeList.addAll(data);
        }
        currentPage++;
        isLoadingMore = false;
        isLoadingRelease = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      if (mounted) {
        setState(() {
          isLoadingMore = false;
          isLoadingRelease = false;
        });
      }
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }

    setState(() {
      isSearching = true;
      isSearchLoading = true;
    });

    try {
      final data = await AnimeApiService.searchAnime(query);
      if (!mounted) return;
      setState(() {
        searchResults = data;
        isSearchLoading = false;
      });
    } catch (e) {
      debugPrint('Search Error: $e');
      if (!mounted) return;
      setState(() {
        searchResults = [];
        isSearchLoading = false;
      });
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  void _setupScrollController() {
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        if (!isLoadingMore && hasMore && !isSearching) {
          fetchReleaseAnime();
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "ANIME",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 3.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 60),
                _buildSearchBar(p),
                Expanded(
                  child: isSearching
                      ? _buildSearchResults(p)
                      : _buildHomeContent(p),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _AnimeGridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar(AppPalette p) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      padding: const EdgeInsets.symmetric(horizontal: 4),
      height: 46,
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: p.textPrimary,
              decoration: InputDecoration(
                hintText: "Cari anime...",
                hintStyle: TextStyle(
                  color: p.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                prefixIcon:
                    Icon(Icons.search, color: p.textTertiary, size: 18),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear,
                            color: p.textTertiary, size: 16),
                        onPressed: _clearSearch,
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
              onChanged: (value) {
                if (value.isNotEmpty) {
                  searchAnime(value);
                } else {
                  setState(() {
                    isSearching = false;
                    searchResults.clear();
                  });
                }
              },
              onSubmitted: (value) {
                if (value.isNotEmpty) searchAnime(value);
              },
            ),
          ),
          if (isSearchLoading)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: p.textPrimary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHomeContent(AppPalette p) {
    return RefreshIndicator(
      onRefresh: () async {
        await fetchLatestAnime();
        await fetchReleaseAnime(isRefresh: true);
      },
      color: p.textPrimary,
      backgroundColor: p.surfaceAlt,
      child: CustomScrollView(
        controller: _scrollController,
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildSectionHeader(
                    p, "LATEST RELEASES", "${latestAnimeList.length} video terbaru"),
                const SizedBox(height: 12),
                if (isLoadingLatest)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (_, __) => Container(
                        width: 120,
                        margin: const EdgeInsets.only(right: 12),
                        child: Shimmer.fromColors(
                          baseColor: p.surface,
                          highlightColor: p.surfaceAlt,
                          child: Container(
                            decoration: BoxDecoration(
                              color: p.surfaceAlt,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                else if (latestAnimeList.isNotEmpty)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: latestAnimeList.length,
                      itemBuilder: (context, index) {
                        return Container(
                          width: 120,
                          margin: const EdgeInsets.only(right: 12),
                          child: AnimeVideoCard(
                            anime: latestAnimeList[index],
                            isLatest: true,
                          ),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 20),
                _buildSectionHeader(p, "ALL RELEASES", "Halaman $currentPage"),
                const SizedBox(height: 12),
              ],
            ),
          ),
          if (isLoadingRelease)
            const SliverToBoxAdapter(child: AnimeLoadingShimmer())
          else if (releaseAnimeList.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.7,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    return AnimeVideoCard(
                      anime: releaseAnimeList[index],
                      isLatest: false,
                    );
                  },
                  childCount: releaseAnimeList.length,
                ),
              ),
            ),
          if (isLoadingMore)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: CircularProgressIndicator(
                    color: p.textPrimary,
                    strokeWidth: 2.5,
                  ),
                ),
              ),
            ),
          if (!hasMore && releaseAnimeList.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: Text(
                    "Tidak ada lagi data",
                    style: TextStyle(
                      color: p.textMuted,
                      fontFamily: kFontFamily,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(AppPalette p, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 32,
            color: p.textPrimary,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: p.textPrimary,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontFamily: kFontFamily,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResults(AppPalette p) {
    if (isSearchLoading) {
      return const AnimeLoadingShimmer();
    }

    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(
                Icons.search_off,
                color: p.textMuted,
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              "Tidak ada hasil pencarian",
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "Coba dengan kata kunci lain",
              style: TextStyle(
                color: p.textMuted,
                fontFamily: kFontFamily,
                fontSize: 12,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: _buildSectionHeader(
            p,
            "SEARCH RESULTS",
            "${searchResults.length} hasil untuk '${_searchController.text}'",
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
            physics: const BouncingScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.7,
            ),
            itemCount: searchResults.length,
            itemBuilder: (context, index) {
              return AnimeVideoCard(anime: searchResults[index], isLatest: false);
            },
          ),
        ),
      ],
    );
  }
}

// ============================================================
// DETAIL PAGE (class name cocok dengan tools_gateway.dart)
// ============================================================
class AnimeDetailPage extends StatefulWidget {
  final String url;
  const AnimeDetailPage({super.key, required this.url});

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage>
    with WidgetsBindingObserver {
  AnimeDetailModel? animeDetail;
  bool isLoading = true;
  bool isError = false;
  bool isPlaying = false;
  bool isFullScreen = false;
  late WebViewController _webViewController;
  bool _isWebViewLoading = true;
  String? _streamUrl;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fetchAnimeDetail();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final physicalSize = WidgetsBinding.instance.window.physicalSize;
    final pixelRatio = WidgetsBinding.instance.window.devicePixelRatio;
    final logicalSize = physicalSize / pixelRatio;
    final isNowFullScreen = logicalSize.width > logicalSize.height;

    if (isNowFullScreen != isFullScreen) {
      setState(() => isFullScreen = isNowFullScreen);
      if (isFullScreen) {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      } else {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      }
    }
  }

  Future<void> fetchAnimeDetail() async {
    try {
      final data = await AnimeApiService.getAnimeDetail(widget.url);
      if (!mounted) return;
      setState(() {
        animeDetail = data;
        _streamUrl = data.stream;
        isLoading = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  void _initializeWebView() {
    if (_streamUrl == null) return;

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0A0A0A))
      ..addJavaScriptChannel(
        'FullScreen',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'enter') {
            _enterFullScreen();
          } else if (message.message == 'exit') {
            _exitFullScreen();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (progress == 100) {
              if (!mounted) return;
              setState(() => _isWebViewLoading = false);
              _injectJavaScript();
            }
          },
          onPageStarted: (String url) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = true);
          },
          onPageFinished: (String url) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = false);
            _injectJavaScript();
          },
          onWebResourceError: (WebResourceError error) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = false);
          },
          onNavigationRequest: (NavigationRequest request) {
            if (request.url != _streamUrl) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_streamUrl!));
  }

  void _injectJavaScript() {
    _webViewController.runJavaScript('''
      document.addEventListener('click', function(e) {
        const target = e.target.closest('a');
        if (target) { e.preventDefault(); e.stopPropagation(); return false; }
      }, true);
      document.addEventListener('submit', function(e) {
        e.preventDefault(); e.stopPropagation(); return false;
      }, true);
      function handleFullScreenChange() {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
          FullScreen.postMessage('enter');
        } else {
          FullScreen.postMessage('exit');
        }
      }
      document.addEventListener('fullscreenchange', handleFullScreenChange);
      document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.addEventListener('click', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
    ''');
  }

  void _enterFullScreen() {
    if (!isFullScreen) {
      setState(() => isFullScreen = true);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _exitFullScreen() {
    if (isFullScreen) {
      setState(() => isFullScreen = false);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  void _showDownloadOptions() {
    if (animeDetail == null || animeDetail!.downloads.isEmpty) return;
    final p = context.theme;

    showModalBottomSheet(
      context: context,
      backgroundColor: p.surfaceAlt,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: Colors.white, width: 0),
      ),
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border(
              top: BorderSide(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: p.bg,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1.5,
                          ),
                        ),
                        child: Icon(
                          Icons.download,
                          color: p.textPrimary,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        "DOWNLOAD OPTIONS",
                        style: TextStyle(
                          fontFamily: kFontFamily,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ...animeDetail!.downloads.map((option) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: p.bg,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: Theme(
                        data: Theme.of(context).copyWith(
                          dividerColor: Colors.transparent,
                          splashColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                        ),
                        child: ExpansionTile(
                          tilePadding:
                              const EdgeInsets.symmetric(horizontal: 12),
                          leading: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: p.surfaceAlt,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                            child: Text(
                              option.type.toUpperCase(),
                              style: TextStyle(
                                color: p.textPrimary,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: kFontFamily,
                              ),
                            ),
                          ),
                          title: Text(
                            option.title,
                            style: TextStyle(
                              color: p.textPrimary,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              fontFamily: kFontFamily,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          iconColor: p.textPrimary,
                          collapsedIconColor: p.textTertiary,
                          children: option.links.map((link) {
                            return Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () async {
                                  HapticFeedback.selectionClick();
                                  try {
                                    await AnimeUrlLauncher.launch(link.url);
                                  } catch (e) {
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Tidak dapat membuka URL',
                                          style: TextStyle(
                                            color: p.textPrimary,
                                            fontFamily: kFontFamily,
                                          ),
                                        ),
                                        backgroundColor: p.surfaceAlt,
                                        behavior: SnackBarBehavior.floating,
                                        shape: const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.zero,
                                        ),
                                      ),
                                    );
                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 12),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.download,
                                        color: p.textTertiary,
                                        size: 16,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          link.name,
                                          style: TextStyle(
                                            color: p.textPrimary,
                                            fontSize: 12,
                                            fontFamily: kFontFamily,
                                          ),
                                        ),
                                      ),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        color: p.textMuted,
                                        size: 11,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: isFullScreen
          ? null
          : AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              centerTitle: true,
              iconTheme: IconThemeData(color: p.textPrimary),
              title: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: p.primary,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.25),
                      blurRadius: 14,
                    ),
                  ],
                ),
                child: Text(
                  "DETAIL",
                  style: TextStyle(
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: p.onPrimary,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
            ),
      body: isLoading
          ? _buildLoadingShimmer(p)
          : isError || animeDetail == null
              ? _buildError(p)
              : isPlaying
                  ? _buildVideoPlayer(p)
                  : _buildAnimeDetail(p),
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(
                Icons.error_outline,
                color: p.danger,
                size: 40,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "Gagal memuat detail anime",
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 48,
              width: 160,
              child: ElevatedButton(
                onPressed: fetchAnimeDetail,
                style: ElevatedButton.styleFrom(
                  backgroundColor: p.textPrimary,
                  foregroundColor: p.bg,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: Text(
                  "COBA LAGI",
                  style: TextStyle(
                    color: p.bg,
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoPlayer(AppPalette p) {
    return Container(
      width: double.infinity,
      height: isFullScreen ? MediaQuery.of(context).size.height : null,
      color: p.bg,
      child: Stack(
        children: [
          _isWebViewLoading
              ? Container(
                  color: p.bg,
                  child: Center(
                    child: CircularProgressIndicator(
                      color: p.textPrimary,
                      strokeWidth: 2.5,
                    ),
                  ),
                )
              : WebViewWidget(controller: _webViewController),
          if (isFullScreen)
            Positioned(
              top: 40,
              right: 20,
              child: GestureDetector(
                onTap: _exitFullScreen,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: p.bg.withOpacity(0.85),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Icon(
                    Icons.fullscreen_exit,
                    color: p.textPrimary,
                    size: 26,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnimeDetail(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        _buildBackground(p),
        SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 60),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  height: 220,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(5, 5),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      ClipRect(
                        child: Image.network(
                          animeDetail!.image,
                          width: double.infinity,
                          height: 220,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: p.surfaceAlt,
                            alignment: Alignment.center,
                            child: Icon(
                              Icons.image_not_supported,
                              color: p.textMuted,
                            ),
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.5),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Center(
                          child: GestureDetector(
                            onTap: () {
                              HapticFeedback.mediumImpact();
                              setState(() => isPlaying = true);
                              _initializeWebView();
                            },
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: p.bg.withOpacity(0.8),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1.5,
                                ),
                              ),
                              child: Icon(
                                Icons.play_arrow,
                                color: p.textPrimary,
                                size: 36,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    animeDetail!.title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: p.textPrimary,
                      fontFamily: kFontFamily,
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    animeDetail!.info,
                    style: TextStyle(
                      color: p.textTertiary,
                      fontSize: 12,
                      fontFamily: kFontFamily,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: p.surfaceAlt,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.7),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.8),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildInfoItem(p, "Anime", animeDetail!.anime),
                        _buildInfoItem(p, "Producers", animeDetail!.producers),
                        _buildInfoItem(p, "Duration", animeDetail!.duration),
                        _buildInfoItem(p, "Size", animeDetail!.size),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    "GENRE",
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: p.textPrimary,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: animeDetail!.genre.split(',').map((g) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: p.surfaceAlt,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1.5,
                          ),
                        ),
                        child: Text(
                          g.trim(),
                          style: TextStyle(
                            color: p.textPrimary,
                            fontSize: 11,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    "SYNOPSIS",
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: p.textPrimary,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: p.surfaceAlt,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.7),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.8),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Text(
                      animeDetail!.synopsis,
                      style: TextStyle(
                        color: p.textPrimary,
                        fontSize: 12,
                        fontFamily: kFontFamily,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.justify,
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton(
                            onPressed: isPlaying
                                ? null
                                : () {
                                    HapticFeedback.mediumImpact();
                                    setState(() => isPlaying = true);
                                    _initializeWebView();
                                  },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: p.textPrimary,
                              foregroundColor: p.bg,
                              elevation: 0,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.play_arrow, color: p.bg, size: 18),
                                const SizedBox(width: 8),
                                Text(
                                  "PLAY",
                                  style: TextStyle(
                                    color: p.bg,
                                    fontFamily: kFontFamily,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SizedBox(
                          height: 52,
                          child: ElevatedButton(
                            onPressed: _showDownloadOptions,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: p.surfaceAlt,
                              foregroundColor: p.textPrimary,
                              elevation: 0,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.download,
                                    color: p.textPrimary, size: 18),
                                const SizedBox(width: 8),
                                Text(
                                  "DOWNLOAD",
                                  style: TextStyle(
                                    color: p.textPrimary,
                                    fontFamily: kFontFamily,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoItem(AppPalette p, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label.toUpperCase(),
              style: TextStyle(
                color: p.textTertiary,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                fontFamily: kFontFamily,
                letterSpacing: 1.2,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 12,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _AnimeGridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 80),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Shimmer.fromColors(
              baseColor: p.surface,
              highlightColor: p.surfaceAlt,
              child: Container(
                height: 220,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: p.surfaceAlt,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...List.generate(
                  6,
                  (index) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Shimmer.fromColors(
                      baseColor: p.surface,
                      highlightColor: p.surfaceAlt,
                      child: Container(
                        height: index == 0 ? 22 : 16,
                        width: double.infinity,
                        color: p.surfaceAlt,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GRID PAINTER (renamed biar unik)
// ============================================================
class _AnimeGridPainter extends CustomPainter {
  final Color color;
  _AnimeGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _AnimeGridPainter old) => old.color != color;
}