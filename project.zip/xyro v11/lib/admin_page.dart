// lib/admin_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const String kFontFamily = 'Ganang';
const String kBase = 'http://www.rexylegal.rxpedia.web.id:2033';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class AdminHx {
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amethyst = Color(0xFFA78BFA);
  static const rose     = Color(0xFFF472B6);
  static const amber    = Color(0xFFFBBF24);

  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

// ═══════════════════════════════════════════════════════════════
// KONSTANTA QRIS
// ═══════════════════════════════════════════════════════════════
const int kQrisAmount = 2000;
const String kQrisAsset = 'assets/images/qris.jpg';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage>
    with TickerProviderStateMixin {
  int _mode = 0;

  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _dayCtrl = TextEditingController();
  final _editUserCtrl = TextEditingController();
  final _editDayCtrl = TextEditingController();
  final _delUserCtrl = TextEditingController();

  String _newRole = 'member';
  final List<String> _roleOptions = ['member', 'reseller'];

  File? _imageFile;          // bukti foto akun
  File? _paymentProofFile;   // bukti bayar QRIS
  final ImagePicker _picker = ImagePicker();
  bool _isSubmitting = false;

  late AnimationController _pulse;
  late AnimationController _entrance;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _entrance.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    _dayCtrl.dispose();
    _editUserCtrl.dispose();
    _editDayCtrl.dispose();
    _delUserCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    HapticFeedback.mediumImpact();
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (picked == null) return;
      setState(() => _imageFile = File(picked.path));
    } catch (_) {}
  }

  Future<void> _pickPaymentProof() async {
    HapticFeedback.mediumImpact();
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (picked == null) return;
      setState(() => _paymentProofFile = File(picked.path));
    } catch (_) {}
  }

  void _showQrisDialog() {
    HapticFeedback.selectionClick();
    showDialog(
      context: context,
      builder: (_) => const _QrisDialog(),
    );
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    final bg = error ? AdminHx.terra : AdminHx.jade;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: AdminHx.surfaceHi,
      content: Row(
        children: [
          Icon(
            error ? Icons.error_outline : Icons.check_circle_outline,
            color: bg,
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: TextStyle(
                color: bg,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: bg.withOpacity(0.3),
          width: 1,
        ),
      ),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  Future<void> _submitCreate() async {
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    final day = _dayCtrl.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }
    if (username.length < 3) {
      _snack('Username minimal 3 karakter', error: true);
      return;
    }
    if (password.length < 4) {
      _snack('Password minimal 4 karakter', error: true);
      return;
    }
    if (_paymentProofFile == null) {
      _snack('Bukti bayar QRIS wajib di-upload', error: true);
      return;
    }
    if (_imageFile == null) {
      _snack('Bukti foto wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final pendingRes = await http.get(Uri.parse(
        '$kBase/createAccountPending'
        '?key=${widget.sessionKey}'
        '&newUser=${Uri.encodeComponent(username)}'
        '&pass=${Uri.encodeComponent(password)}'
        '&day=${Uri.encodeComponent(day)}'
        '&role=${Uri.encodeComponent(_newRole)}',
      )).timeout(const Duration(seconds: 20));

      final pendingData = jsonDecode(pendingRes.body);
      if (pendingData['valid'] != true || pendingData['created'] != true) {
        _snack(pendingData['message'] ?? 'Gagal buat akun', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      final bytes = await _imageFile!.readAsBytes();
      if (bytes.length > 5 * 1024 * 1024) {
        _snack('Foto terlalu besar (max 5MB)', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }
      final base64Image = base64Encode(bytes);

      final proofBytes = await _paymentProofFile!.readAsBytes();
      if (proofBytes.length > 5 * 1024 * 1024) {
        _snack('Bukti bayar terlalu besar (max 5MB)', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }
      final base64Proof = base64Encode(proofBytes);

      final botRes = await http.post(
        Uri.parse('$kBase/sendPendingToBot'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': username,
          'password': password,
          'day': day,
          'role': _newRole,
          'image': base64Image,
          'paymentProof': base64Proof,
          'paymentAmount': kQrisAmount,
        }),
      ).timeout(const Duration(seconds: 30));

      final botData = jsonDecode(botRes.body);
      if (botData['valid'] != true || botData['sent'] != true) {
        _snack(botData['message'] ?? 'Gagal kirim ke bot', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      HapticFeedback.heavyImpact();
      _snack('✅ Bukti terkirim ke owner. Menunggu ACC.', error: false);

      _userCtrl.clear();
      _passCtrl.clear();
      _dayCtrl.clear();
      setState(() {
        _imageFile = null;
        _paymentProofFile = null;
        _newRole = 'member';
        _isSubmitting = false;
      });
    } catch (e) {
      _snack('Error: $e', error: true);
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitAddDurasi() async {
    final u = _editUserCtrl.text.trim();
    final d = _editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/editUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}'
        '&addDays=${Uri.encodeComponent(d)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        HapticFeedback.heavyImpact();
        _snack('✅ Durasi berhasil ditambah $d hari', error: false);
        _editUserCtrl.clear();
        _editDayCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal tambah durasi', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitHapus() async {
    final u = _delUserCtrl.text.trim();
    if (u.isEmpty) {
      _snack('Username wajib diisi', error: true);
      return;
    }

    HapticFeedback.heavyImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/deleteUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        HapticFeedback.heavyImpact();
        _snack('✅ User berhasil dihapus', error: false);
        _delUserCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal hapus', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Widget _staggered({required int index, required Widget child}) {
    const int total = 8;
    final double start = (index / total) * 0.55;
    final double end = (start + 0.45).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AdminHx.bg,
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),
              Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _staggered(index: 0, child: _buildHeader()),
                const SizedBox(height: 22),
                _staggered(index: 1, child: _buildStatsRow()),
                const SizedBox(height: 20),
                _staggered(index: 2, child: _buildSectionLabel("Actions")),
                const SizedBox(height: 12),
                _staggered(index: 3, child: _buildTabsRow()),
                const SizedBox(height: 20),

                if (_mode == 0)
                  _staggered(index: 4, child: _formCreate())
                else if (_mode == 1)
                  _staggered(index: 4, child: _formAddDurasi())
                else
                  _staggered(index: 4, child: _formHapus()),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 12, color: AdminHx.ivory),
            const SizedBox(width: 10),
            const Text(
              "ADMIN CONTROL",
              style: TextStyle(
                color: AdminHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "Management",
          style: TextStyle(
            color: AdminHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.6,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          "Panel",
          style: TextStyle(
            color: AdminHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: -1.2,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          "Kelola akun member & reseller",
          style: TextStyle(
            color: AdminHx.ash,
            fontFamily: kFontFamily,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: FontAwesomeIcons.userPlus,
            label: "CREATE",
            accent: AdminHx.terra,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: FontAwesomeIcons.clock,
            label: "EXTEND",
            accent: AdminHx.slate,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            icon: FontAwesomeIcons.userSlash,
            label: "DELETE",
            accent: AdminHx.ivory,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required Color accent,
  }) {
    final isWhite = accent == AdminHx.ivory;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: AdminHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: isWhite
                  ? AdminHx.ivory.withOpacity(0.12)
                  : accent.withOpacity(0.12),
              border: Border.all(
                color: isWhite
                    ? Colors.white.withOpacity(0.2)
                    : accent.withOpacity(0.4),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: accent, size: 15),
          ),
          const SizedBox(height: 10),
          Text(
            label,
            style: TextStyle(
              color: isWhite ? AdminHx.ivory : accent,
              fontFamily: kFontFamily,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          Container(width: 3, height: 12, color: AdminHx.ivory),
          const SizedBox(width: 10),
          Text(
            text.toUpperCase(),
            style: const TextStyle(
              color: AdminHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              color: Colors.white.withOpacity(0.08),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabsRow() {
    return Row(
      children: [
        Expanded(
          child: _tab(
            title: 'CREATE',
            subtitle: 'Buat Akun',
            icon: FontAwesomeIcons.userPlus,
            color: AdminHx.terra,
            index: 0,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _tab(
            title: 'EXTEND',
            subtitle: 'Add Durasi',
            icon: FontAwesomeIcons.clock,
            color: AdminHx.slate,
            index: 1,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _tab(
            title: 'DELETE',
            subtitle: 'Hapus Akun',
            icon: FontAwesomeIcons.userSlash,
            color: AdminHx.ivory,
            index: 2,
          ),
        ),
      ],
    );
  }

  Widget _tab({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required int index,
  }) {
    final active = _mode == index;
    final isWhite = color == AdminHx.ivory;

    final activeBg = isWhite ? AdminHx.ivory : color.withOpacity(0.15);
    final activeBorder = isWhite ? AdminHx.ivory : color.withOpacity(0.5);
    final activeText = isWhite ? AdminHx.bg : color;

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _mode = index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
        decoration: BoxDecoration(
          color: active ? activeBg : AdminHx.surfaceHi,
          border: Border.all(
            color: active
                ? activeBorder
                : Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: active
                    ? (isWhite
                        ? AdminHx.ivory.withOpacity(0.2)
                        : color.withOpacity(0.25))
                    : color.withOpacity(0.12),
                border: Border.all(
                  color: active
                      ? (isWhite ? Colors.white : color)
                      : color.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: active
                    ? (isWhite ? AdminHx.bg : color)
                    : color,
                size: 14,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                color: active ? activeText : AdminHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.4,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                color: active
                    ? (isWhite ? AdminHx.bg.withOpacity(0.7) : color.withOpacity(0.8))
                    : AdminHx.ash,
                fontFamily: kFontFamily,
                fontSize: 8.5,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _input({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    required Color accent,
    bool obscure = false,
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: AdminHx.ash,
              fontFamily: kFontFamily,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: AdminHx.surfaceHi2,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: type,
            style: const TextStyle(
              color: AdminHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
            cursorColor: accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: AdminHx.ash2,
                fontSize: 13,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w500,
              ),
              prefixIcon: Icon(icon, color: accent, size: 17),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _card({required Widget child, required Color accent}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AdminHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _cardHeader({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
  }) {
    final isWhite = accent == AdminHx.ivory;
    return Row(
      children: [
        Container(
          width: 46, height: 46,
          decoration: BoxDecoration(
            color: isWhite
                ? AdminHx.ivory.withOpacity(0.12)
                : accent.withOpacity(0.12),
            border: Border.all(
              color: isWhite
                  ? Colors.white.withOpacity(0.2)
                  : accent.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(icon, color: accent, size: 20),
        ),
        const SizedBox(width: 13),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: AdminHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.6,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(
                  color: AdminHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _formCreate() {
    const accent = AdminHx.terra;

    return _card(
      accent: accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _cardHeader(
            icon: FontAwesomeIcons.userPlus,
            title: 'CREATE ACCOUNT',
            subtitle: 'Bayar QRIS Rp 2.000 lalu kirim ke owner',
            accent: accent,
          ),
          const SizedBox(height: 16),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.06),
          ),
          const SizedBox(height: 18),

          // ═══ QRIS SECTION ═══
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Text(
              'PEMBAYARAN QRIS (WAJIB)',
              style: TextStyle(
                color: AdminHx.ash,
                fontFamily: kFontFamily,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.8,
              ),
            ),
          ),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: _showQrisDialog,
            child: Container(
              height: 56,
              decoration: BoxDecoration(
                color: AdminHx.surfaceHi2,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  const Icon(Icons.qr_code_2_rounded,
                      color: AdminHx.ivory, size: 18),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'LIHAT QRIS — Rp 2.000',
                      style: TextStyle(
                        color: AdminHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios_rounded,
                      color: AdminHx.ash.withOpacity(0.5), size: 12),
                  const SizedBox(width: 16),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),

          // Upload bukti bayar
          GestureDetector(
            onTap: _pickPaymentProof,
            child: Container(
              height: 56,
              decoration: BoxDecoration(
                color: AdminHx.surfaceHi2,
                border: Border.all(
                  color: _paymentProofFile != null
                      ? AdminHx.jade.withOpacity(0.5)
                      : Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  Icon(
                    _paymentProofFile != null
                        ? Icons.check_circle_rounded
                        : Icons.upload_file_rounded,
                    color: _paymentProofFile != null
                        ? AdminHx.jade
                        : AdminHx.ivory,
                    size: 18,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _paymentProofFile != null
                          ? 'BUKTI BAYAR TERPILIH ✓'
                          : 'UPLOAD BUKTI BAYAR QRIS',
                      style: TextStyle(
                        color: _paymentProofFile != null
                            ? AdminHx.jade
                            : AdminHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios_rounded,
                      color: AdminHx.ash.withOpacity(0.5), size: 12),
                  const SizedBox(width: 16),
                ],
              ),
            ),
          ),

          if (_paymentProofFile != null) ...[
            const SizedBox(height: 12),
            Container(
              height: 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: Image.file(
                  _paymentProofFile!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                    child: Icon(Icons.broken_image,
                        color: AdminHx.ash2, size: 40),
                  ),
                ),
              ),
            ),
          ],

          const SizedBox(height: 18),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.06),
          ),
          const SizedBox(height: 18),

          // ═══ DATA AKUN ═══
          _input(
            label: 'Username',
            hint: 'contoh: budi123',
            controller: _userCtrl,
            icon: FontAwesomeIcons.user,
            accent: accent,
          ),
          const SizedBox(height: 14),
          _input(
            label: 'Password',
            hint: 'minimal 4 karakter',
            controller: _passCtrl,
            icon: FontAwesomeIcons.lock,
            accent: accent,
            obscure: true,
          ),
          const SizedBox(height: 14),
          _input(
            label: 'Durasi (Hari)',
            hint: 'contoh: 30',
            controller: _dayCtrl,
            icon: FontAwesomeIcons.calendarDay,
            accent: accent,
            type: TextInputType.number,
          ),
          const SizedBox(height: 14),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                child: Text(
                  'ROLE',
                  style: TextStyle(
                    color: AdminHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: AdminHx.surfaceHi2,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _newRole,
                    dropdownColor: AdminHx.surfaceHi,
                    isExpanded: true,
                    style: const TextStyle(
                      color: AdminHx.ivory,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: kFontFamily,
                    ),
                    icon: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: AdminHx.ash,
                    ),
                    items: _roleOptions.map((role) {
                      return DropdownMenuItem(
                        value: role,
                        child: Row(
                          children: [
                            Icon(
                              role == 'member'
                                  ? Icons.person
                                  : Icons.storefront,
                              color: role == 'member'
                                  ? AdminHx.slate
                                  : accent,
                              size: 16,
                            ),
                            const SizedBox(width: 10),
                            Text(role.toUpperCase()),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (val) =>
                        setState(() => _newRole = val ?? 'member'),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // ═══ BUKTI FOTO AKUN ═══
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Text(
              'BUKTI FOTO (WAJIB)',
              style: TextStyle(
                color: AdminHx.ash,
                fontFamily: kFontFamily,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.8,
              ),
            ),
          ),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              height: 56,
              decoration: BoxDecoration(
                color: AdminHx.surfaceHi2,
                border: Border.all(
                  color: _imageFile != null
                      ? AdminHx.jade.withOpacity(0.5)
                      : Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  Icon(
                    _imageFile != null
                        ? Icons.check_circle_rounded
                        : Icons.image_outlined,
                    color: _imageFile != null ? AdminHx.jade : accent,
                    size: 18,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _imageFile != null
                          ? 'FOTO TERPILIH ✓'
                          : 'PILIH FOTO BUKTI',
                      style: TextStyle(
                        color: _imageFile != null
                            ? AdminHx.jade
                            : AdminHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AdminHx.ash.withOpacity(0.5),
                    size: 12,
                  ),
                  const SizedBox(width: 16),
                ],
              ),
            ),
          ),

          if (_imageFile != null) ...[
            const SizedBox(height: 12),
            Container(
              height: 180,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: Image.file(
                  _imageFile!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                    child: Icon(Icons.broken_image,
                        color: AdminHx.ash2, size: 40),
                  ),
                ),
              ),
            ),
          ],

          const SizedBox(height: 18),
          _submitButton(
            label: 'KIRIM KE OWNER',
            icon: Icons.send_rounded,
            accent: accent,
            onTap: _isSubmitting ? null : _submitCreate,
          ),

          const SizedBox(height: 12),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AdminHx.slate.withOpacity(0.08),
              border: Border.all(
                color: AdminHx.slate.withOpacity(0.3),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline_rounded,
                    color: AdminHx.slate, size: 16),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Bayar Rp 2.000 via QRIS, upload bukti bayar + foto akun. '
                    'Semua bukti akan otomatis terkirim ke owner untuk di-ACC.',
                    style: TextStyle(
                      color: AdminHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 11,
                      height: 1.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _formAddDurasi() {
    const accent = AdminHx.slate;

    return _card(
      accent: accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _cardHeader(
            icon: FontAwesomeIcons.clock,
            title: 'ADD DURASI',
            subtitle: 'Tambah masa aktif member',
            accent: accent,
          ),
          const SizedBox(height: 16),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.06),
          ),
          const SizedBox(height: 18),

          _input(
            label: 'Username Target',
            hint: 'contoh: budi123',
            controller: _editUserCtrl,
            icon: FontAwesomeIcons.userEdit,
            accent: accent,
          ),
          const SizedBox(height: 14),
          _input(
            label: 'Tambah Hari',
            hint: 'contoh: 30',
            controller: _editDayCtrl,
            icon: FontAwesomeIcons.calendarPlus,
            accent: accent,
            type: TextInputType.number,
          ),
          const SizedBox(height: 18),

          _submitButton(
            label: 'TAMBAH DURASI',
            icon: Icons.add_circle_outline_rounded,
            accent: accent,
            onTap: _isSubmitting ? null : _submitAddDurasi,
          ),
        ],
      ),
    );
  }

  Widget _formHapus() {
    const accent = AdminHx.terra;

    return _card(
      accent: accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _cardHeader(
            icon: FontAwesomeIcons.userSlash,
            title: 'DELETE ACCOUNT',
            subtitle: 'Hapus akun member permanen',
            accent: accent,
          ),
          const SizedBox(height: 16),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.06),
          ),
          const SizedBox(height: 18),

          _input(
            label: 'Username Target',
            hint: 'contoh: budi123',
            controller: _delUserCtrl,
            icon: FontAwesomeIcons.user,
            accent: accent,
          ),
          const SizedBox(height: 18),

          _submitButton(
            label: 'HAPUS AKUN',
            icon: Icons.delete_outline_rounded,
            accent: accent,
            onTap: _isSubmitting ? null : _submitHapus,
          ),
        ],
      ),
    );
  }

  Widget _submitButton({
    required String label,
    required IconData icon,
    required Color accent,
    required VoidCallback? onTap,
  }) {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: AdminHx.ivory,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Center(
            child: _isSubmitting
                ? const SizedBox(
                    width: 22, height: 22,
                    child: CircularProgressIndicator(
                      color: AdminHx.bg,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon, color: AdminHx.bg, size: 18),
                      const SizedBox(width: 10),
                      Text(
                        label,
                        style: const TextStyle(
                          color: AdminHx.bg,
                          fontFamily: kFontFamily,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.2,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// QRIS DIALOG — pakai assets/images/qris.jpg
// ═══════════════════════════════════════════════════════════════
class _QrisDialog extends StatelessWidget {
  const _QrisDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AdminHx.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'PEMBAYARAN QRIS',
              style: TextStyle(
                color: AdminHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.2,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Rp 2.000',
              style: TextStyle(
                color: AdminHx.jade,
                fontFamily: kFontFamily,
                fontSize: 28,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 16),

            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.all(8),
                child: Image.asset(
                  kQrisAsset,
                  width: 240,
                  height: 240,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 240,
                    height: 240,
                    child: Center(
                      child: Icon(
                        Icons.qr_code_2,
                        color: AdminHx.ash,
                        size: 80,
                      ),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 14),
            const Text(
              'Scan QRIS di atas, bayar Rp 2.000.\nScreenshot bukti bayar & upload di form.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AdminHx.ash,
                fontFamily: kFontFamily,
                fontSize: 11,
                height: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 18),

            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: AdminHx.ivory,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text(
                    'MENGERTI, LANJUT',
                    style: TextStyle(
                      color: AdminHx.bg,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}