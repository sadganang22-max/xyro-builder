import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ============================================================
// APP COLORS — Dark Theme XYRO
// ============================================================
class AppColors {
  static const Color background = Color(0xFF000000);
  static const Color surface = Color(0xFF0A0A0A);
  static const Color surfaceElevated = Color(0xFF111111);
  static const Color border = Color(0xFF1A1A1A);
  static const Color borderStrong = Color(0xFF222222);

  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFCCCCCC);
  static const Color textTertiary = Color(0xFF888888);
  static const Color textMuted = Color(0xFF666666);

  static const Color primary = Color(0xFFFFFFFF);

  static const Color success = Color(0xFF22C55E);
  static const Color successLight = Color(0xFF4ADE80);
  static const Color successBg = Color(0xFF052E16);

  static const Color danger = Color(0xFFDC2626);
  static const Color dangerLight = Color(0xFFF87171);
  static const Color dangerBg = Color(0xFF2A0A0A);

  static const Color warning = Color(0xFFF59E0B);
  static const Color warningLight = Color(0xFFFBBF24);
  static const Color warningBg = Color(0xFF2A1F05);

  static const Color info = Color(0xFF2563EB);
  static const Color infoLight = Color(0xFF60A5FA);
}

const String kFontFamily = 'Ganang';

// ============================================================
// VIEW STATE
// ============================================================
enum SenderView { list, inputForm, pairingCode }

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with TickerProviderStateMixin {
  // ============ STATE ============
  SenderView _currentView = SenderView.list;

  List<dynamic> senderList = [];
  bool isLoading = false;
  String? errorMessage;

  // Form
  final TextEditingController _phoneController = TextEditingController();
  String _inputNumber = "";
  String _pairingCode = "";

  // Animasi
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  late AnimationController _viewController;
  late Animation<double> _viewFade;
  late Animation<Offset> _viewSlide;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _viewController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _viewFade = CurvedAnimation(
      parent: _viewController,
      curve: Curves.easeOut,
    );

    _viewSlide = Tween<Offset>(
      begin: const Offset(0, 0.05),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _viewController,
      curve: Curves.easeOutCubic,
    ));

    _viewController.forward();
    _fetchSenders();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _viewController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  // ============================================================
  // VIEW NAVIGATION
  // ============================================================
  void _changeView(SenderView newView) {
    _viewController.reset();
    setState(() => _currentView = newView);
    _viewController.forward();
  }

  void _handleBack() {
    HapticFeedback.lightImpact();
    if (_currentView == SenderView.list) {
      Navigator.pop(context);
    } else {
      _changeView(SenderView.list);
    }
  }

  // ============================================================
  // API CALLS
  // ============================================================
  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse(
            "http://www.rexylegal.rxpedia.web.id:2033/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          if (mounted) {
            setState(() {
              senderList = data["connections"] ?? [];
            });
          }
        } else {
          if (mounted) {
            setState(() =>
                errorMessage = data["message"] ?? "Failed to fetch senders");
          }
        }
      } else {
        if (mounted) {
          setState(() => errorMessage = "Server error: ${response.statusCode}");
        }
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = "Connection failed: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _generatePairingCode() async {
    final number = _phoneController.text.trim();

    if (number.isEmpty) {
      _showSnackBar("Nomor tidak boleh kosong", isError: true);
      return;
    }

    final cleaned = number.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.length < 8) {
      _showSnackBar("Format nomor tidak valid", isError: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => isLoading = true);

    try {
      final response = await http.get(Uri.parse(
          "http://www.rexylegal.rxpedia.web.id:2033/getPairing?key=${widget.sessionKey}&number=$number"));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _inputNumber = number;
          _pairingCode = data['pairingCode'] ?? '';
          _changeView(SenderView.pairingCode);
        } else {
          _showSnackBar(data['message'] ?? "Pairing failed", isError: true);
        }
      } else {
        _showSnackBar("Server Error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection Fault: $e", isError: true);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await _showConfirmDialog();
    if (confirmed != true) return;

    setState(() => isLoading = true);
    try {
      final response = await http.delete(Uri.parse(
          "http://www.rexylegal.rxpedia.web.id:2033/deleteSender?key=${widget.sessionKey}&id=$senderId"));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          HapticFeedback.mediumImpact();
          _showSnackBar("Node berhasil dihapus", isError: false);
          _fetchSenders();
        } else {
          _showSnackBar(data["message"] ?? "Failed to purge node",
              isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // ============================================================
  // DIALOGS
  // ============================================================
  Future<bool?> _showConfirmDialog() {
    return showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.borderStrong, width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.dangerBg,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.danger.withOpacity(0.4),
                  ),
                ),
                child: const Icon(
                  Icons.warning_amber_rounded,
                  color: AppColors.dangerLight,
                  size: 28,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                "PURGE NODE",
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontFamily: kFontFamily,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                "Apakah Anda yakin ingin menghapus Sender Node ini?\nProses ini tidak dapat dibatalkan.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppColors.textTertiary,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: const BorderSide(color: AppColors.borderStrong),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "CANCEL",
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.danger,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "PURGE",
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: isError ? AppColors.dangerLight : AppColors.successLight,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: AppColors.surfaceElevated,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isError
                ? AppColors.danger.withOpacity(0.4)
                : AppColors.success.withOpacity(0.4),
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            Expanded(
              child: FadeTransition(
                opacity: _viewFade,
                child: SlideTransition(
                  position: _viewSlide,
                  child: _buildCurrentView(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_currentView) {
      case SenderView.list:
        return _buildListView();
      case SenderView.inputForm:
        return _buildInputFormView();
      case SenderView.pairingCode:
        return _buildPairingCodeView();
    }
  }

  // ============================================================
  // APP BAR
  // ============================================================
  Widget _buildAppBar() {
    String title;
    switch (_currentView) {
      case SenderView.list:
        title = "SENDER NODES";
        break;
      case SenderView.inputForm:
        title = "ADD NEW NODE";
        break;
      case SenderView.pairingCode:
        title = "PAIRING CODE";
        break;
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: _handleBack,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.borderStrong),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new,
                  color: AppColors.textPrimary,
                  size: 16,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                letterSpacing: 2.0,
              ),
            ),
          ),
          if (_currentView == SenderView.list)
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: isLoading ? null : _fetchSenders,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderStrong),
                  ),
                  child: Icon(
                    Icons.refresh_rounded,
                    color: isLoading
                        ? AppColors.textMuted
                        : AppColors.textPrimary,
                    size: 18,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // VIEW 1: LIST
  // ============================================================
  Widget _buildListView() {
    if (isLoading && senderList.isEmpty) {
      return _buildLoadingState();
    }
    if (errorMessage != null && senderList.isEmpty) {
      return _buildErrorState();
    }
    if (senderList.isEmpty) {
      return _buildEmptyState();
    }

    return Stack(
      children: [
        RefreshIndicator(
          color: AppColors.primary,
          backgroundColor: AppColors.surface,
          onRefresh: _fetchSenders,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
            children: [
              _buildSectionLabel(
                "${senderList.length} ${senderList.length == 1 ? 'NODE' : 'NODES'} ACTIVE",
              ),
              const SizedBox(height: 16),
              ...senderList.asMap().entries.map((entry) {
                final sender = Map<String, dynamic>.from(entry.value);
                return _buildSenderCard(sender, entry.key);
              }).toList(),
            ],
          ),
        ),
        Positioned(
          bottom: 20,
          right: 20,
          child: FloatingActionButton(
            onPressed: () {
              HapticFeedback.mediumImpact();
              _phoneController.clear();
              _changeView(SenderView.inputForm);
            },
            backgroundColor: AppColors.primary,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.add,
              color: AppColors.background,
              size: 26,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionLabel(String text) {
    return Row(
      children: [
        Text(
          text,
          style: const TextStyle(
            color: AppColors.textMuted,
            fontFamily: kFontFamily,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 2.0,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            height: 1,
            color: AppColors.border,
          ),
        ),
      ],
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final senderId = sender['id']?.toString() ?? '';
    final shortId = senderId.length >= 8 ? senderId.substring(0, 8) : senderId;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.borderStrong),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceElevated,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.borderStrong),
                    ),
                    child: const Icon(
                      Icons.hub_outlined,
                      color: AppColors.textPrimary,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name.toString().toUpperCase(),
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.0,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "#$shortId",
                          style: const TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.successBg,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppColors.success.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedBuilder(
                          animation: _pulseAnimation,
                          builder: (context, child) {
                            return Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: AppColors.success,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.success.withOpacity(
                                      _pulseAnimation.value * 0.6,
                                    ),
                                    blurRadius: 6,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          "ONLINE",
                          style: TextStyle(
                            color: AppColors.successLight,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            fontFamily: kFontFamily,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 1,
              color: AppColors.border,
            ),
            Row(
              children: [
                Expanded(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: _fetchSenders,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.sync,
                              size: 16,
                              color: AppColors.textSecondary,
                            ),
                            SizedBox(width: 8),
                            Text(
                              "SYNC",
                              style: TextStyle(
                                color: AppColors.textSecondary,
                                fontFamily: kFontFamily,
                                fontWeight: FontWeight.w800,
                                fontSize: 11,
                                letterSpacing: 1.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  width: 1,
                  height: 20,
                  color: AppColors.border,
                ),
                Expanded(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => _deleteSender(senderId),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.delete_outline,
                              size: 16,
                              color: AppColors.dangerLight,
                            ),
                            SizedBox(width: 8),
                            Text(
                              "PURGE",
                              style: TextStyle(
                                color: AppColors.dangerLight,
                                fontFamily: kFontFamily,
                                fontWeight: FontWeight.w800,
                                fontSize: 11,
                                letterSpacing: 1.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // VIEW 2: INPUT FORM
  // ============================================================
  Widget _buildInputFormView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 20),
          Center(
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: AppColors.surface,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.borderStrong, width: 1.5),
              ),
              child: const Icon(
                Icons.phone_android_rounded,
                color: AppColors.textPrimary,
                size: 34,
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              "NEW SENDER",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 4.0,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Container(
              width: 40,
              height: 2,
              color: AppColors.borderStrong,
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            "Masukkan nomor WhatsApp yang ingin dijadikan sender node untuk akun kamu.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.textTertiary,
              fontFamily: kFontFamily,
              fontSize: 13,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 36),
          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 10),
            child: Text(
              "PHONE NUMBER",
              style: TextStyle(
                color: AppColors.textMuted,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 2.0,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: AppColors.surfaceElevated,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.borderStrong),
            ),
            child: TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 16,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.0,
              ),
              cursorColor: AppColors.primary,
              decoration: const InputDecoration(
                hintText: "628xxx...",
                hintStyle: TextStyle(
                  color: AppColors.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 15,
                ),
                prefixIcon: Icon(
                  Icons.phone_android,
                  color: AppColors.textTertiary,
                  size: 20,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 18,
                ),
              ),
            ),
          ),
          const SizedBox(height: 40),
          SizedBox(
            height: 58,
            child: ElevatedButton(
              onPressed: isLoading ? null : _generatePairingCode,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: AppColors.background,
                disabledBackgroundColor: AppColors.surfaceElevated,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        color: AppColors.background,
                        strokeWidth: 2.5,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.bolt,
                          color: AppColors.background,
                          size: 20,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "GENERATE PAIRING CODE",
                          style: TextStyle(
                            color: AppColors.background,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // VIEW 3: PAIRING CODE
  // ============================================================
  Widget _buildPairingCodeView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 20),
          Center(
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: AppColors.surface,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.borderStrong, width: 1.5),
              ),
              child: const Icon(
                Icons.link_rounded,
                color: AppColors.textPrimary,
                size: 34,
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              "PAIRING CODE",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 4.0,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Container(
              width: 40,
              height: 2,
              color: AppColors.borderStrong,
            ),
          ),
          const SizedBox(height: 18),
          Center(
            child: Text(
              "Target: $_inputNumber",
              style: const TextStyle(
                color: AppColors.textTertiary,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 30,
            ),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.primary,
                width: 1.5,
              ),
            ),
            child: Center(
              child: Text(
                _pairingCode,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 6,
                  fontFamily: kFontFamily,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: _pairingCode));
                HapticFeedback.lightImpact();
                _showSnackBar("Kode berhasil dicopy", isError: false);
              },
              icon: const Icon(
                Icons.copy_all,
                color: AppColors.textPrimary,
                size: 18,
              ),
              label: const Text(
                "COPY TO CLIPBOARD",
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontFamily: kFontFamily,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                  letterSpacing: 1.5,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.borderStrong),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),
          const SizedBox(height: 28),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.warningBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: AppColors.warning.withOpacity(0.35),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 2),
                  child: Icon(
                    Icons.info_outline,
                    color: AppColors.warningLight,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "Buka WhatsApp di HP target, lalu ketik kode ini saat diminta untuk pairing.",
                    style: TextStyle(
                      color: AppColors.warningLight.withOpacity(0.9),
                      fontFamily: kFontFamily,
                      fontSize: 12,
                      height: 1.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            height: 58,
            child: ElevatedButton(
              onPressed: () {
                HapticFeedback.mediumImpact();
                _phoneController.clear();
                _changeView(SenderView.list);
                _fetchSenders();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: AppColors.background,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: const Text(
                "DONE — REFRESH LIST",
                style: TextStyle(
                  color: AppColors.background,
                  fontFamily: kFontFamily,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.surface,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppColors.borderStrong,
                  width: 1.5,
                ),
              ),
              child: const Icon(
                Icons.router_outlined,
                color: AppColors.textTertiary,
                size: 44,
              ),
            ),
            const SizedBox(height: 28),
            const Text(
              "NO NODES YET",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 16,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.0,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: 40,
              height: 2,
              color: AppColors.borderStrong,
            ),
            const SizedBox(height: 18),
            const Text(
              "Belum ada sender node yang terhubung.\nTambahkan WhatsApp node pertama untuk mulai mengirim payload.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textTertiary,
                fontSize: 12,
                fontFamily: kFontFamily,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  HapticFeedback.mediumImpact();
                  _phoneController.clear();
                  _changeView(SenderView.inputForm);
                },
                icon: const Icon(
                  Icons.add,
                  color: AppColors.background,
                  size: 20,
                ),
                label: const Text(
                  "ADD NEW SENDER",
                  style: TextStyle(
                    color: AppColors.background,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 1.5,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // LOADING STATE
  // ============================================================
  Widget _buildLoadingState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 32,
            height: 32,
            child: CircularProgressIndicator(
              color: AppColors.textPrimary,
              strokeWidth: 2.5,
            ),
          ),
          SizedBox(height: 20),
          Text(
            "LOADING...",
            style: TextStyle(
              color: AppColors.textTertiary,
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 2.5,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ERROR STATE
  // ============================================================
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.surface,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppColors.danger.withOpacity(0.4),
                  width: 1.5,
                ),
              ),
              child: const Icon(
                Icons.wifi_off_rounded,
                color: AppColors.dangerLight,
                size: 44,
              ),
            ),
            const SizedBox(height: 28),
            const Text(
              "CONNECTION FAULT",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 16,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.0,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: 40,
              height: 2,
              color: AppColors.borderStrong,
            ),
            const SizedBox(height: 18),
            Text(
              errorMessage ?? "Unknown connection error occurred",
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.textTertiary,
                fontSize: 12,
                fontFamily: kFontFamily,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: OutlinedButton.icon(
                onPressed: _fetchSenders,
                icon: const Icon(
                  Icons.refresh,
                  color: AppColors.textPrimary,
                  size: 20,
                ),
                label: const Text(
                  "RETRY CONNECTION",
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    letterSpacing: 1.5,
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.borderStrong),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}