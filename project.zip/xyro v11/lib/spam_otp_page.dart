// lib/spam_otp_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class OtpHx {
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);
  static const surfaceHi  = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const jade   = Color(0xFF4ADE80);
  static const slate  = Color(0xFF60A5FA);
  static const terra  = Color(0xFFF87171);
  static const amber  = Color(0xFFFBBF24);
}

// ── Country codes ─────────────────────────────────────────────────────────────
const List<Map<String, String>> _kCountries = [
  {'code': '62',  'flag': '🇮🇩', 'name': 'Indonesia'},
  {'code': '60',  'flag': '🇲🇾', 'name': 'Malaysia'},
  {'code': '65',  'flag': '🇸🇬', 'name': 'Singapore'},
  {'code': '63',  'flag': '🇵🇭', 'name': 'Philippines'},
  {'code': '66',  'flag': '🇹🇭', 'name': 'Thailand'},
  {'code': '84',  'flag': '🇻🇳', 'name': 'Vietnam'},
  {'code': '91',  'flag': '🇮🇳', 'name': 'India'},
  {'code': '1',   'flag': '🇺🇸', 'name': 'USA / Canada'},
  {'code': '44',  'flag': '🇬🇧', 'name': 'United Kingdom'},
  {'code': '61',  'flag': '🇦🇺', 'name': 'Australia'},
  {'code': '55',  'flag': '🇧🇷', 'name': 'Brazil'},
  {'code': '971', 'flag': '🇦🇪', 'name': 'UAE'},
  {'code': '966', 'flag': '🇸🇦', 'name': 'Saudi Arabia'},
];

class SpamOtpPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final String? baseUrl;

  const SpamOtpPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    this.baseUrl,
  });

  @override
  State<SpamOtpPage> createState() => _SpamOtpPageState();
}

class _SpamOtpPageState extends State<SpamOtpPage>
    with TickerProviderStateMixin {

  final _phoneCtrl  = TextEditingController();
  final _scrollCtrl = ScrollController();

  Map<String, String> _country = _kCountries[0];
  int _loop    = 1;
  int _workers = 10;

  bool _running    = false;
  bool _done       = false;
  int  _total      = 0;
  int  _sent       = 0;
  int  _ok         = 0;
  int  _failCount  = 0;
  int  _loopCur    = 1;
  int  _proxyCount = 0;
  bool _proxyOn    = false;
  String _serverStatus = 'checking...';
  bool _serverOk   = false;

  final List<Map<String, dynamic>> _logs = [];

  http.Client? _client;
  StreamSubscription<String>? _streamSub;

  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  // ── VIDEO BANNER ──
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  // ✅ BASE URL
  String get _api => (widget.baseUrl?.isNotEmpty == true)
      ? widget.baseUrl!
      : "http://www.rexylegal.rxpedia.web.id:2060"; // Ganti ke URL utama lu

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.92, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _initVideo();
    _checkServer();
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0); // ✅ Suara nyala
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();
      if (!mounted) return;
      setState(() {
        _videoController = controller;
        _videoReady = true;
      });
    } catch (e) {
      debugPrint('Video error: $e');
    }
  }

  Future<void> _checkServer() async {
    setState(() => _serverStatus = 'checking...');
    int nodeTotal = 0;
    bool nodeOk = false;

    try {
      final res = await http
          .get(Uri.parse('$_api/otp/platforms'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body) as Map<String, dynamic>;
        nodeTotal  = (d['total'] as int?) ?? 0;
        nodeOk     = true;
        if (mounted) setState(() {
          _proxyOn    = d['proxy_enabled'] == true;
          _proxyCount = (d['proxy_count'] as int?) ?? 0;
        });
      }
    } catch (_) {}

    if (mounted) setState(() {
      _total      = nodeTotal; 
      _serverOk   = nodeOk;
      _serverStatus = nodeOk
          ? '$nodeTotal platform aktif'
          : 'Offline — $_api';
    });
  }

  Future<void> _start() async {
    if (!_serverOk) {
      _snack('Server offline — periksa URL');
      await _checkServer();
      return;
    }

    final raw   = _phoneCtrl.text.trim().replaceAll(RegExp(r'[^\d]'), '');
    final phone = raw.startsWith('0') ? raw.substring(1) : raw;
    if (phone.length < 7) { _snack('Nomor minimal 7 digit'); return; }

    setState(() {
      _running = true; _done = false;
      _sent = 0; _ok = 0; _failCount = 0; _loopCur = 1;
      _logs.clear();
    });

    await _startEngine(phone);

    if (mounted) setState(() { _running = false; _done = true; });
  }

  Future<void> _startEngine(String phone) async {
    _client?.close();
    _client = http.Client();
    try {
      final req = http.Request('POST', Uri.parse('$_api/otp/send'))
        ..headers['Content-Type']  = 'application/json'
        ..headers['Accept']        = 'application/x-ndjson'
        ..headers['Authorization'] = 'Bearer ${widget.sessionKey}'
        ..headers['x-auth-token']  = widget.sessionKey
        ..body = jsonEncode({
          'phone':   phone,
          'cc':      _country['code']!,
          'count':   _loop,
          'workers': _workers,
        });

      final streamed = await _client!.send(req).timeout(const Duration(minutes: 30));

      if (streamed.statusCode != 200) {
        _snack('Server: HTTP ${streamed.statusCode}');
        return;
      }

      final completer = Completer<void>();
      String buf = '';
      _streamSub = streamed.stream.transform(utf8.decoder).listen(
        (chunk) {
          buf += chunk;
          while (true) {
            final nl = buf.indexOf('\n');
            if (nl < 0) break;
            final line = buf.substring(0, nl).trim();
            buf = buf.substring(nl + 1);
            if (line.isEmpty) continue;
            try { _handleEvent(jsonDecode(line) as Map<String, dynamic>); }
            catch (_) {}
          }
        },
        onDone: () {
          if (buf.trim().isNotEmpty) {
            try { _handleEvent(jsonDecode(buf.trim()) as Map<String, dynamic>); }
            catch (_) {}
          }
          completer.complete();
        },
        onError: (e) {
          completer.complete();
        },
        cancelOnError: false,
      );
      await completer.future;
    } on TimeoutException {
      _snack('Timeout');
    } catch (e) {
      // Abaikan
    }
  }

  void _handleEvent(Map<String, dynamic> e) {
    if (!mounted) return;
    setState(() {
      switch (e['type'] as String? ?? '') {
        case 'start':
          _total      = (e['total'] as int?) ?? _total;
          _proxyOn    = e['proxy'] == true;
          _proxyCount = (e['proxy_count'] as int?) ?? 0;
        case 'loop':
          _loopCur = (e['loop'] as int?) ?? 1;
        case 'log':
          _sent      = (e['sent'] as int?) ?? _sent;
          _ok        = (e['ok']   as int?) ?? _ok;
          _failCount = (e['fail'] as int?) ?? _failCount;
          _logs.insert(0, e);
          if (_logs.length > 500) _logs.removeLast();
        case 'done':
          _sent      = (e['sent'] as int?) ?? _sent;
          _ok        = (e['ok']   as int?) ?? _ok;
          _failCount = (e['fail'] as int?) ?? _failCount;
          _running = false;
          _done    = true;
      }
    });
  }

  void _stop() {
    _streamSub?.cancel();
    _client?.close();
    _client = null;
    if (mounted) setState(() { _running = false; _done = true; });
  }

  void _reset() => setState(() {
    _done = false; _sent = 0; _ok = 0; _failCount = 0;
    _loopCur = 1; _logs.clear();
  });

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 12)),
      backgroundColor: OtpHx.surfaceHi,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(color: OtpHx.ash2),
      ),
    ));
  }

  @override
  void dispose() {
    _streamSub?.cancel();
    _client?.close();
    _pulseCtrl.dispose();
    _phoneCtrl.dispose();
    _scrollCtrl.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // EFEK HUD & SCANLINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 14, double thickness = 1.5}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 10, left: 10, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 10, right: 10, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 10, left: 10, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 10, right: 10, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: size, height: thickness, color: OtpHx.ivory.withOpacity(0.6)),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: thickness, height: size, color: OtpHx.ivory.withOpacity(0.6)),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.15,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.white.withOpacity(0.4), Colors.transparent],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 160,
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(
                color: OtpHx.surfaceHi2,
                child: const Center(
                  child: SizedBox(
                    width: 22, height: 22,
                    child: CircularProgressIndicator(color: OtpHx.ivory, strokeWidth: 2.0),
                  ),
                ),
              ),
            
            // Overlay
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, OtpHx.bg.withOpacity(0.25), OtpHx.bg.withOpacity(0.65)],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // ✅ EFEK HUD & SCANLINE
            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            // Text overlay
            Positioned(
              left: 18, right: 18, bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'SPAM OTP ENGINE',
                    style: TextStyle(
                      color: OtpHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Bombardir kode OTP via WhatsApp',
                    style: TextStyle(
                      color: OtpHx.ivory.withOpacity(0.65),
                      fontFamily: kFontFamily,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── UI WIDGETS ──────────────────────────────────────────────────────────────
  Widget _stat(IconData icon, String label, String val, {Color? valColor, Color? iconColor}) =>
    Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: iconColor ?? OtpHx.ash, size: 15),
      const SizedBox(height: 3),
      Text(label, style: const TextStyle(color: OtpHx.ash2, fontFamily: kFontFamily, fontSize: 7.5, letterSpacing: 0.8)),
      const SizedBox(height: 1),
      Text(val, style: TextStyle(
        color: valColor ?? OtpHx.ivory, fontFamily: kFontFamily, fontSize: 11.5, fontWeight: FontWeight.w800)),
    ]);

  Widget _vline() => Container(width: 1, height: 32, color: Colors.white.withOpacity(0.08));

  Widget _chip(String icon, String label, Color col) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: col.withOpacity(0.08), borderRadius: BorderRadius.circular(8),
      border: Border.all(color: col.withOpacity(0.3)),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text(icon, style: const TextStyle(fontSize: 12)),
      const SizedBox(width: 5),
      Text(label, style: TextStyle(color: col, fontFamily: kFontFamily, fontSize: 11, fontWeight: FontWeight.w800)),
    ]),
  );

  Widget _buildServerBar() => GestureDetector(
    onTap: _checkServer,
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _serverOk ? OtpHx.jade.withOpacity(0.08) : OtpHx.terra.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: _serverOk ? OtpHx.jade.withOpacity(0.3) : OtpHx.terra.withOpacity(0.3)),
      ),
      child: Row(children: [
        Container(
          width: 7, height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _serverOk ? OtpHx.jade : OtpHx.terra,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            _serverOk ? 'Server OK — $_serverStatus' : '$_serverStatus',
            style: TextStyle(
              color: _serverOk ? OtpHx.jade : OtpHx.terra, fontFamily: kFontFamily, fontSize: 11,
              fontWeight: FontWeight.w700),
          ),
        ),
        Text('tap refresh', style: TextStyle(color: OtpHx.ash2, fontFamily: kFontFamily, fontSize: 9.5)),
      ]),
    ),
  );

  Widget _buildTopStats() {
    final loopStr  = _loop == 1 ? '1x Burst' : '${_loop}x Repeat';
    final proxyStr = _proxyOn ? '$_proxyCount PROXY' : 'OFF';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: OtpHx.surfaceHi, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _stat(Icons.hub_outlined, 'PLATFORM', _total > 0 ? '$_total' : '—'),
          _vline(),
          _stat(Icons.speed_rounded, 'WORKERS', '$_workers thread'),
          _vline(),
          _stat(Icons.flash_on_rounded, 'MODE', loopStr, iconColor: OtpHx.ivory),
          _vline(),
          _stat(Icons.vpn_lock_rounded, 'PROXY', proxyStr,
              iconColor: _proxyOn ? OtpHx.jade : OtpHx.ash2,
              valColor: _proxyOn ? OtpHx.jade : OtpHx.ash),
        ],
      ),
    );
  }

  Widget _buildForm() => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: OtpHx.surfaceHi, borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('NOMOR TARGET', style: TextStyle(
        color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 9.5, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
      const SizedBox(height: 8),
      Row(children: [
        GestureDetector(
          onTap: _showCCPicker,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
            decoration: BoxDecoration(
              color: OtpHx.surfaceHi2, borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Row(children: [
              Text(_country['flag']!, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 5),
              Text('+${_country['code']}',
                style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 13, fontWeight: FontWeight.w700)),
              const Icon(Icons.expand_more_rounded, color: OtpHx.ash, size: 14),
            ]),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: OtpHx.surfaceHi2, borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 14, fontWeight: FontWeight.w600),
              cursorColor: OtpHx.ivory,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d+]'))],
              decoration: InputDecoration(
                hintText: '08xxxxxxxxxx',
                hintStyle: TextStyle(color: OtpHx.ash2, fontFamily: kFontFamily, fontSize: 13),
                prefixIcon: const Icon(Icons.chat_rounded, color: OtpHx.ivory, size: 18),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 13, horizontal: 8),
                suffixIcon: GestureDetector(
                  onTap: () async {
                    final clip = await Clipboard.getData('text/plain');
                    if (clip?.text != null) {
                      _phoneCtrl.text = clip!.text!.replaceAll(RegExp(r'[^\d+]'), '');
                    }
                  },
                  child: Icon(Icons.content_paste_rounded, color: OtpHx.ash, size: 16),
                ),
              ),
            ),
          ),
        ),
      ]),
      const SizedBox(height: 5),
      Row(children: [
        Icon(Icons.info_outline_rounded, color: OtpHx.ash2, size: 12),
        const SizedBox(width: 5),
        Text('OTP masuk ke WhatsApp target — format: 08xx atau 628xx',
          style: TextStyle(color: OtpHx.ash, fontFamily: kFontFamily, fontSize: 10)),
      ]),
      const SizedBox(height: 12),

      Row(children: [
        Expanded(child: _buildStepper('LOOP (ulang)', _loop, 1, 20, (v) => setState(() => _loop = v))),
        const SizedBox(width: 10),
        Expanded(child: _buildStepper('WORKERS (thread)', _workers, 1, 30, (v) => setState(() => _workers = v))),
      ]),
      const SizedBox(height: 14),

      GestureDetector(
        onTap: () {
          if (_running) _stop();
          else { _reset(); _start(); }
        },
        child: AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Transform.scale(
            scale: _running ? _pulseAnim.value : 1.0,
            child: Container(
              width: double.infinity, height: 50, 
              decoration: BoxDecoration(
                color: _running ? OtpHx.surfaceHi2 : OtpHx.ivory,
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(
                  _running ? Icons.stop_circle_rounded : Icons.send_rounded,
                  color: _running ? OtpHx.terra : OtpHx.bg, size: 18,
                ),
                const SizedBox(width: 10),
                Text(
                  _running ? 'STOP SPAM' : 'MULAI SPAM WA OTP',
                  style: TextStyle(
                    color: _running ? OtpHx.terra : OtpHx.bg,
                    fontFamily: kFontFamily, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.5,
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    ]),
  );

  Widget _buildStepper(String label, int val, int min, int max, void Function(int) cb) =>
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: OtpHx.surfaceHi2, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: OtpHx.ash, fontFamily: kFontFamily, fontSize: 8.5, letterSpacing: 1.0)),
        const SizedBox(height: 6),
        Row(children: [
          _stepBtn(Icons.remove, () { if (val > min) cb(val - 1); }),
          Expanded(child: Text('$val',
            textAlign: TextAlign.center,
            style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 18, fontWeight: FontWeight.w900))),
          _stepBtn(Icons.add, () { if (val < max) cb(val + 1); }),
        ]),
      ]),
    );

  Widget _stepBtn(IconData ico, VoidCallback fn) => GestureDetector(
    onTap: fn,
    child: Container(
      width: 26, height: 26,
      decoration: BoxDecoration(
        color: OtpHx.surfaceHi, borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Colors.white.withOpacity(0.08))),
      alignment: Alignment.center,
      child: Icon(ico, color: OtpHx.ivory, size: 14),
    ),
  );

  Widget _buildProgress() {
    if (!_running && !_done) return const SizedBox.shrink();
    final totalShots = _total * _loop;
    final pct  = totalShots > 0 ? (_sent / totalShots).clamp(0.0, 1.0) : 0.0;
    final rate = _sent > 0 ? (_ok / _sent * 100).toStringAsFixed(0) : '0';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: OtpHx.surfaceHi, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _running ? OtpHx.ivory.withOpacity(0.3) : Colors.white.withOpacity(0.08)),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 7, height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _done ? OtpHx.jade : OtpHx.ivory.withOpacity(_pulseAnim.value),
                ),
              ),
            ),
            const SizedBox(width: 7),
            Text(
              _done ? 'SELESAI — Rate $rate%' : 'LIVE  Loop $_loopCur/$_loop',
              style: TextStyle(
                color: _done ? OtpHx.jade : OtpHx.ivory,
                fontFamily: kFontFamily, fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 0.8)),
          ]),
          Text('$_sent / $totalShots', style: TextStyle(color: OtpHx.ash, fontFamily: kFontFamily, fontSize: 10.5)),
        ]),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct, minHeight: 3, backgroundColor: OtpHx.surfaceHi2,
            valueColor: AlwaysStoppedAnimation<Color>(_done ? OtpHx.jade : OtpHx.ivory),
          ),
        ),
        const SizedBox(height: 10),
        Row(children: [
          _chip('✅', '$_ok OK', OtpHx.jade),
          const SizedBox(width: 7),
          _chip('❌', '$_failCount FAIL', OtpHx.terra),
          const Spacer(),
          _chip('📤', '$_sent SENT', OtpHx.ash),
        ]),
      ]),
    );
  }

  Widget _buildLogs() {
    if (_logs.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: OtpHx.surfaceHi, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 11, 14, 7),
          child: Row(children: [
            const Icon(Icons.chat_rounded, color: OtpHx.ivory, size: 13),
            const SizedBox(width: 6),
            Text('WA OTP LOG', style: TextStyle(
              color: OtpHx.ash, fontFamily: kFontFamily, fontSize: 9.5, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
            const Spacer(),
            Text('${_logs.length} requests', style: TextStyle(color: OtpHx.ash2, fontFamily: kFontFamily, fontSize: 9.5)),
          ]),
        ),
        Container(height: 1, color: Colors.white.withOpacity(0.05)),
        SizedBox(
          height: 320,
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.symmetric(vertical: 4),
            itemCount: _logs.length,
            itemBuilder: (_, i) {
              final l  = _logs[i];
              final ok = l['ok'] == true;
              final st = (l['status'] as num?)?.toInt() ?? 0;
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Row(children: [
                  Text(ok ? '✅' : '❌', style: const TextStyle(fontSize: 11)),
                  const SizedBox(width: 5),
                  Text('${l['emoji'] ?? ''}', style: const TextStyle(fontSize: 13)),
                  const SizedBox(width: 5),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${l['name'] ?? ''}',
                        style: TextStyle(
                          color: ok ? OtpHx.ivory : OtpHx.terra,
                          fontFamily: kFontFamily, fontSize: 12, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                      Text('${l['cat'] ?? ''}  •  WA OTP',
                        style: TextStyle(color: OtpHx.ash2, fontFamily: kFontFamily, fontSize: 9.5)),
                    ],
                  )),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: ok ? OtpHx.jade.withOpacity(0.1) : OtpHx.terra.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(
                        color: ok ? OtpHx.jade.withOpacity(0.3) : OtpHx.terra.withOpacity(0.3)),
                    ),
                    child: Text(
                      ok ? 'TERKIRIM' : st == 0 ? 'DEAD' : 'HTTP $st',
                      style: TextStyle(
                        color: ok ? OtpHx.jade : (st == 0 ? OtpHx.ash : OtpHx.terra),
                        fontFamily: kFontFamily, fontSize: 9, fontWeight: FontWeight.w800)),
                  ),
                ]),
              );
            },
          ),
        ),
      ]),
    );
  }

  void _showCCPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: OtpHx.surfaceHi,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 36, height: 4, margin: const EdgeInsets.only(top: 12),
            decoration: BoxDecoration(color: OtpHx.ash2, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 10),
        const Text('Kode Negara', style: TextStyle(
          color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 14, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        ..._kCountries.map((c) => ListTile(
          dense: true,
          leading: Text(c['flag']!, style: const TextStyle(fontSize: 22)),
          title: Text(c['name']!, style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 13)),
          trailing: Text('+${c['code']}',
            style: const TextStyle(color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 12, fontWeight: FontWeight.w700)),
          onTap: () { setState(() => _country = c); Navigator.pop(context); },
        )),
        const SizedBox(height: 10),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final modeStr = _loop == 1 ? '1x Burst' : '${_loop}x Repeat';
    return Scaffold(
      backgroundColor: OtpHx.bg,
      appBar: AppBar(
        backgroundColor: OtpHx.bg, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: OtpHx.ivory, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: OtpHx.ivory.withOpacity(0.1),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: OtpHx.ivory.withOpacity(0.3)),
            ),
            child: const Icon(Icons.chat_rounded, color: OtpHx.ivory, size: 17),
          ),
          const SizedBox(width: 9),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('SPAM OTP', style: TextStyle(
                color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 0.8)),
              const SizedBox(width: 7),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: OtpHx.ivory.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: OtpHx.ivory.withOpacity(0.3)),
                ),
                child: const Text('WA ONLY', style: TextStyle(
                  color: OtpHx.ivory, fontFamily: kFontFamily, fontSize: 9,
                  fontWeight: FontWeight.w800, letterSpacing: 1)),
              ),
            ]),
            Text('OTP via WhatsApp · $modeStr',
              style: TextStyle(color: OtpHx.ash, fontFamily: kFontFamily, fontSize: 9.5)),
          ]),
        ]),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 36),
        child: Column(children: [
          // ✅ BANNER VIDEO OOO.MP4
          _buildVideoBanner(),
          
          _buildServerBar(),
          _buildTopStats(),
          _buildForm(),
          _buildProgress(),
          _buildLogs(),
        ]),
      ),
    );
  }
}