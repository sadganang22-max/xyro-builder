// lib/change_password_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String kFontFamily = 'Ganang';
const String baseUrl = "http://www.rexylegal.rxpedia.web.id:2060";

// ═══════════════════════════════════════════════════════════════
// PALET — OBSIDIAN & CHAMPAGNE
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg = Color(0xFF050608);
  static const surface = Color(0xFF0B0C0F);
  static const surfaceHi = Color(0xFF131418);
  static const surfaceHi2 = Color(0xFF1B1C21);

  static const goldLight = Color(0xFFF2E6C4);
  static const gold = Color(0xFFD9C082);
  static const goldMid = Color(0xFFA88E4C);
  static const goldDeep = Color(0xFF6B5928);

  static const jade = Color(0xFF8FC7A5);
  static const jadeDeep = Color(0xFF3D6B52);
  static const terra = Color(0xFFD8A090);
  static const slate = Color(0xFFA0B8D8);
  static const amethyst = Color(0xFFB8A0D0);

  static const ivory = Color(0xFFEAE6DC);
  static const ash = Color(0xFF8A8479);
  static const ash2 = Color(0xFF565248);

  static const line = Color(0x1AD9C082);
  static const lineSoft = Color(0x10EAE6DC);
}

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage>
    with TickerProviderStateMixin {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;

  // ✅ Real-time validation
  bool get _hasMinLength => newPassCtrl.text.length >= 6;
  bool get _hasUpper => newPassCtrl.text.contains(RegExp(r'[A-Z]'));
  bool get _hasNumber => newPassCtrl.text.contains(RegExp(r'[0-9]'));
  bool get _hasMatch =>
      newPassCtrl.text.isNotEmpty &&
      newPassCtrl.text == confirmPassCtrl.text;

  bool get _canSubmit =>
      oldPassCtrl.text.isNotEmpty &&
      _hasMinLength &&
      _hasUpper &&
      _hasNumber &&
      _hasMatch;

  // Animation controllers
  late AnimationController _ambient;
  late AnimationController _pulse;
  late AnimationController _scan;
  late AnimationController _orbit;
  late AnimationController _shimmer;
  late AnimationController _entrance;

  @override
  void initState() {
    super.initState();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 24),
    )..repeat();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _scan = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    _orbit = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();

    _shimmer = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();

    // Update UI tiap ketik
    oldPassCtrl.addListener(_onTextChanged);
    newPassCtrl.addListener(_onTextChanged);
    confirmPassCtrl.addListener(_onTextChanged);
  }

  void _onTextChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ambient.dispose();
    _pulse.dispose();
    _scan.dispose();
    _orbit.dispose();
    _shimmer.dispose();
    _entrance.dispose();
    oldPassCtrl.removeListener(_onTextChanged);
    newPassCtrl.removeListener(_onTextChanged);
    confirmPassCtrl.removeListener(_onTextChanged);
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _changePassword() async {
    if (!_canSubmit) return;

    HapticFeedback.mediumImpact();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPassCtrl.text.trim(),
          "newPass": newPassCtrl.text.trim(),
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        HapticFeedback.heavyImpact();
        _showSuccessDialog("Password berhasil diubah!");
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showErrorDialog(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showErrorDialog("Koneksi error: $e");
    }

    if (mounted) setState(() => isLoading = false);
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 8;
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══ SUCCESS DIALOG ═══
  void _showSuccessDialog(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => _buildDialog(
        icon: Icons.check_circle_outline_rounded,
        title: "SUCCESS",
        accent: Hx.jade,
        message: msg,
      ),
    );
  }

  void _showErrorDialog(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => _buildDialog(
        icon: Icons.error_outline_rounded,
        title: "NOTICE",
        accent: Hx.terra,
        message: msg,
      ),
    );
  }

  Widget _buildDialog({
    required IconData icon,
    required String title,
    required Color accent,
    required String message,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Hx.surfaceHi2, Hx.surface],
          ),
          border: Border.all(color: Hx.line, width: 0.9),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 40,
              offset: const Offset(0, 16),
            ),
            BoxShadow(
              color: accent.withOpacity(0.15),
              blurRadius: 50,
              spreadRadius: -8,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final v = 0.4 + 0.6 * _pulse.value;
                return Container(
                  width: 64, height: 64,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.15),
                    border: Border.all(
                      color: accent.withOpacity(0.4 + 0.2 * v),
                      width: 0.9,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withOpacity(0.20 * v),
                        blurRadius: 22,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: accent, size: 28),
                );
              },
            ),
            const SizedBox(height: 18),
            Text(
              title,
              style: const TextStyle(
                color: Hx.ivory,
                fontFamily: kFontFamily,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.4,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Hx.ash,
                fontFamily: kFontFamily,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: accent.withOpacity(0.4),
                      width: 0.8,
                    ),
                  ),
                ),
                child: Text(
                  "OK",
                  style: TextStyle(
                    color: accent,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ INPUT FIELD ═══
  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
    required Color accent,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: Hx.ash,
              fontFamily: kFontFamily,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Hx.bg.withOpacity(0.5),
            border: Border.all(color: Hx.line, width: 0.8),
            borderRadius: BorderRadius.circular(14),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            style: const TextStyle(
              color: Hx.ivory,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
            cursorColor: accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: Hx.ash2,
                fontSize: 13,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w500,
              ),
              prefixIcon: Icon(icon, color: accent, size: 17),
              suffixIcon: IconButton(
                icon: Icon(
                  obscure
                      ? Icons.visibility_off_rounded
                      : Icons.visibility_rounded,
                  color: Hx.ash,
                  size: 18,
                ),
                onPressed: () {
                  HapticFeedback.selectionClick();
                  onToggle();
                },
              ),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
      ],
    );
  }

  // ═══ VALIDATION ROW ═══
  Widget _buildValidationRow(String text, bool passed) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: 16, height: 16,
            decoration: BoxDecoration(
              color: passed
                  ? Hx.jade.withOpacity(0.20)
                  : Hx.ash2.withOpacity(0.10),
              border: Border.all(
                color: passed
                    ? Hx.jade.withOpacity(0.5)
                    : Hx.ash2.withOpacity(0.3),
                width: 0.7,
              ),
              borderRadius: BorderRadius.circular(5),
            ),
            child: passed
                ? const Icon(
                    Icons.check_rounded,
                    color: Hx.jade,
                    size: 11,
                  )
                : null,
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(
              color: passed ? Hx.jade : Hx.ash,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  // ═══ ORBITAL EMBLEM ═══
  Widget _buildOrbitalEmblem() {
    return Center(
      child: SizedBox(
        width: 140, height: 140,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Rotating orbit dots
            AnimatedBuilder(
              animation: _orbit,
              builder: (_, __) {
                return Transform.rotate(
                  angle: _orbit.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(140, 140),
                    painter: _OrbitPainter(),
                  ),
                );
              },
            ),

            // Breath halo
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final s = 1 + 0.10 * _pulse.value;
                final op = 0.30 - 0.20 * _pulse.value;
                return Transform.scale(
                  scale: s,
                  child: Container(
                    width: 100, height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Hx.gold.withOpacity(op),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Hx.gold.withOpacity(op),
                          blurRadius: 40 * _pulse.value,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            // Static gold ring
            Container(
              width: 104, height: 104,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Hx.gold.withOpacity(0.45),
                  width: 1.2,
                ),
              ),
            ),

            // Center lock emblem
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final s = 1 + 0.03 * _pulse.value;
                return Transform.scale(
                  scale: s,
                  child: Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(
                        colors: [
                          Color(0xFFF2E6C4),
                          Hx.gold,
                          Hx.goldMid,
                          Hx.goldDeep,
                        ],
                        stops: [0.0, 0.4, 0.75, 1.0],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Hx.gold.withOpacity(0.55),
                          blurRadius: 40,
                          spreadRadius: 2,
                        ),
                        const BoxShadow(
                          color: Color(0xBBFFFFFF),
                          blurRadius: 2,
                          offset: Offset(0, -2),
                        ),
                        BoxShadow(
                          color: Hx.goldDeep.withOpacity(0.75),
                          blurRadius: 14,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.lock_reset_rounded,
                        color: Color(0xFF1A1408),
                        size: 36,
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Hx.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Hx.bg),

          // Ambient blobs
          AnimatedBuilder(
            animation: _ambient,
            builder: (context, _) => CustomPaint(
              painter: _AmbientPainter(progress: _ambient.value),
            ),
          ),

          // Grid
          CustomPaint(
            painter: _GridPainter(color: Hx.gold.withOpacity(0.022)),
          ),

          // Scan line
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _scan,
                builder: (context, _) => CustomPaint(
                  painter: _ScanLinePainter(progress: _scan.value),
                ),
              ),
            ),
          ),

          // Vignette
          IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.05,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.55),
                  ],
                  stops: const [0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              // ✅ padding top 90 biar gak ketiban app bar dashboard
              padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // HEADER BAR
                  _staggered(
                    index: 0,
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            HapticFeedback.selectionClick();
                            Navigator.pop(context);
                          },
                          child: Container(
                            width: 42, height: 42,
                            decoration: BoxDecoration(
                              color: Hx.surfaceHi,
                              border: Border.all(
                                color: Hx.line,
                                width: 0.8,
                              ),
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: const Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: Hx.gold,
                              size: 16,
                            ),
                          ),
                        ),
                        const Spacer(),
                        const Text(
                          "SECURITY",
                          style: TextStyle(
                            color: Hx.gold,
                            fontFamily: kFontFamily,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3.4,
                          ),
                        ),
                        const Spacer(),
                        Container(width: 42, height: 42),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),

                  // ORBITAL EMBLEM
                  _staggered(index: 1, child: _buildOrbitalEmblem()),
                  const SizedBox(height: 22),

                  // TITLE
                  _staggered(
                    index: 2,
                    child: Column(
                      children: [
                        const Text(
                          "Change",
                          style: TextStyle(
                            color: Hx.ivory,
                            fontFamily: kFontFamily,
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.6,
                            height: 1.05,
                          ),
                        ),
                        const SizedBox(height: 3),
                        const Text(
                          "Password",
                          style: TextStyle(
                            color: Hx.gold,
                            fontFamily: kFontFamily,
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.8,
                            height: 1.05,
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          "Update your account security",
                          style: TextStyle(
                            color: Hx.ash,
                            fontFamily: kFontFamily,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 26),

                  // FORM
                  _staggered(
                    index: 3,
                    child: Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Hx.surfaceHi2, Hx.surface],
                        ),
                        border: Border.all(color: Hx.line, width: 0.9),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 30,
                            offset: const Offset(0, 12),
                          ),
                          BoxShadow(
                            color: Hx.gold.withOpacity(0.06),
                            blurRadius: 40,
                            spreadRadius: -10,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildInput(
                            controller: oldPassCtrl,
                            label: 'Old Password',
                            hint: 'Masukkan password lama',
                            icon: Icons.lock_outline_rounded,
                            obscure: _obscureOld,
                            onToggle: () =>
                                setState(() => _obscureOld = !_obscureOld),
                            accent: Hx.terra,
                          ),
                          const SizedBox(height: 16),
                          _buildInput(
                            controller: newPassCtrl,
                            label: 'New Password',
                            hint: 'Min. 6 karakter',
                            icon: Icons.vpn_key_rounded,
                            obscure: _obscureNew,
                            onToggle: () =>
                                setState(() => _obscureNew = !_obscureNew),
                            accent: Hx.gold,
                          ),
                          const SizedBox(height: 16),
                          _buildInput(
                            controller: confirmPassCtrl,
                            label: 'Confirm Password',
                            hint: 'Ulangi password baru',
                            icon: Icons.verified_user_rounded,
                            obscure: _obscureConfirm,
                            onToggle: () => setState(
                                () => _obscureConfirm = !_obscureConfirm),
                            accent: Hx.jade,
                          ),
                          const SizedBox(height: 18),

                          // VALIDATION CHECKLIST
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Hx.bg.withOpacity(0.5),
                              border: Border.all(
                                color: Hx.line,
                                width: 0.7,
                              ),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'PASSWORD REQUIREMENTS',
                                  style: TextStyle(
                                    color: Hx.ash,
                                    fontFamily: kFontFamily,
                                    fontSize: 9.5,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.8,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                _buildValidationRow(
                                    'Minimal 6 karakter', _hasMinLength),
                                _buildValidationRow(
                                    'Mengandung huruf besar', _hasUpper),
                                _buildValidationRow(
                                    'Mengandung angka', _hasNumber),
                                _buildValidationRow(
                                    'Password cocok', _hasMatch),
                              ],
                            ),
                          ),
                          const SizedBox(height: 22),

                          // SUBMIT BUTTON dengan shimmer
                          AnimatedBuilder(
                            animation: _shimmer,
                            builder: (context, _) {
                              return Container(
                                height: 56,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: _canSubmit && !isLoading
                                        ? const [
                                            Hx.goldLight,
                                            Hx.gold,
                                            Hx.goldMid,
                                          ]
                                        : [
                                            Hx.ash2.withOpacity(0.3),
                                            Hx.ash2.withOpacity(0.2),
                                          ],
                                  ),
                                  boxShadow: _canSubmit && !isLoading
                                      ? [
                                          BoxShadow(
                                            color: Hx.gold.withOpacity(0.4),
                                            blurRadius: 26,
                                            spreadRadius: -6,
                                            offset: const Offset(0, 10),
                                          ),
                                          const BoxShadow(
                                            color: Color(0x99FFFFFF),
                                            blurRadius: 1,
                                            offset: Offset(0, -1.2),
                                          ),
                                        ]
                                      : null,
                                ),
                                child: Stack(
                                  children: [
                                    if (_canSubmit && !isLoading)
                                      Positioned.fill(
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                          child: Transform.translate(
                                            offset: Offset(
                                              -260 + (_shimmer.value * 720),
                                              0,
                                            ),
                                            child: Transform.rotate(
                                              angle: -0.35,
                                              child: Container(
                                                width: 72,
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      Colors.transparent,
                                                      Colors.white
                                                          .withOpacity(0.55),
                                                      Colors.transparent,
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius:
                                            BorderRadius.circular(15),
                                        onTap: _canSubmit && !isLoading
                                            ? _changePassword
                                            : null,
                                        child: Center(
                                          child: isLoading
                                              ? const SizedBox(
                                                  width: 22, height: 22,
                                                  child:
                                                      CircularProgressIndicator(
                                                    color: Color(0xFF1A1408),
                                                    strokeWidth: 2.5,
                                                  ),
                                                )
                                              : Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      Icons
                                                          .verified_user_rounded,
                                                      color: _canSubmit
                                                          ? const Color(
                                                              0xFF1A1408)
                                                          : Hx.ash,
                                                      size: 18,
                                                    ),
                                                    const SizedBox(width: 10),
                                                    Text(
                                                      'UPDATE PASSWORD',
                                                      style: TextStyle(
                                                        color: _canSubmit
                                                            ? const Color(
                                                                0xFF1A1408)
                                                            : Hx.ash,
                                                        fontFamily:
                                                            kFontFamily,
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        letterSpacing: 2.2,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// AMBIENT PAINTER
// ═══════════════════════════════════════════════════════════════
class _AmbientPainter extends CustomPainter {
  final double progress;
  _AmbientPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 130);

    paint.color = Hx.gold.withOpacity(0.11);
    canvas.drawCircle(
      Offset(
        size.width * (0.18 + 0.06 * math.sin(t * 0.7)),
        size.height * (0.10 + 0.05 * math.cos(t * 0.5)),
      ),
      size.width * 0.58,
      paint,
    );

    paint.color = Hx.goldDeep.withOpacity(0.14);
    canvas.drawCircle(
      Offset(
        size.width * (0.90 + 0.05 * math.cos(t * 0.6)),
        size.height * (0.85 + 0.05 * math.sin(t * 0.4)),
      ),
      size.width * 0.60,
      paint,
    );

    paint.color = Hx.slate.withOpacity(0.08);
    canvas.drawCircle(
      Offset(
        size.width * (0.55 + 0.08 * math.sin(t * 0.3)),
        size.height * (0.45 + 0.06 * math.cos(t * 0.8)),
      ),
      size.width * 0.50,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AmbientPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// SCAN LINE PAINTER
// ═══════════════════════════════════════════════════════════════
class _ScanLinePainter extends CustomPainter {
  final double progress;
  _ScanLinePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final y = size.height * progress;
    const h = 200.0;

    final rect = Rect.fromLTWH(0, y - h / 2, size.width, h);

    final gradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.transparent,
        Hx.gold.withOpacity(0.00),
        Hx.gold.withOpacity(0.14),
        Hx.gold.withOpacity(0.00),
        Colors.transparent,
      ],
      stops: const [0.0, 0.35, 0.5, 0.65, 1.0],
    );

    final paint = Paint()
      ..shader = gradient.createShader(rect)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);

    canvas.drawRect(rect, paint);

    final linePaint = Paint()
      ..color = Hx.goldLight.withOpacity(0.30)
      ..strokeWidth = 1
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
  }

  @override
  bool shouldRepaint(covariant _ScanLinePainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// ORBIT PAINTER
// ═══════════════════════════════════════════════════════════════
class _OrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    for (int i = 0; i < 12; i++) {
      final angle = (i / 12) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final opacity = 0.15 + 0.75 * ((i / 12 + 0.5) % 1.0);

      final dotPaint = Paint()
        ..color = Hx.gold.withOpacity(opacity)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);

      canvas.drawCircle(Offset(x, y), i == 0 ? 3.5 : 2, dotPaint);

      if (i == 0) {
        final glowPaint = Paint()
          ..color = Hx.goldLight.withOpacity(0.7)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
        canvas.drawCircle(Offset(x, y), 5, glowPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _OrbitPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}