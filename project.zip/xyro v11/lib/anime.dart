// lib/anime.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'theme.dart';

const String kFontFamily = 'Ganang';

// ============================================================
// HOME ANIME PAGE
// ============================================================
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  Map<String, dynamic>? animeData;
  bool isLoading = true;
  bool isSearching = false;
  List<dynamic> searchResults = [];
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  List<Map<String, dynamic>> _watchHistory = [];
  bool _isHistoryLoading = true;

  @override
  void initState() {
    super.initState();
    fetchAnimeData();
    _loadWatchHistory();
  }

  void refreshHistory() {
    _loadWatchHistory();
  }

  Future<void> _loadWatchHistory() async {
    setState(() => _isHistoryLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      if (!mounted) return;
      setState(() {
        _watchHistory = historyJson
            .map((item) => Map<String, dynamic>.from(json.decode(item)))
            .toList();
        _isHistoryLoading = false;
      });
    } catch (e) {
      debugPrint('Error loading watch history: $e');
      if (mounted) setState(() => _isHistoryLoading = false);
    }
  }

  Future<void> fetchAnimeData() async {
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/home'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          animeData = jsonData['data'];
          isLoading = false;
        });
      } else {
        throw Exception('Gagal memuat data anime');
      }
    } catch (e) {
      debugPrint('Error: $e');
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }
    setState(() => isSearching = true);
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/search/$query'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          searchResults = jsonData['data']['animeList'] ?? [];
        });
      } else {
        if (!mounted) return;
        setState(() => searchResults = []);
      }
    } catch (e) {
      debugPrint('Search Error: $e');
      if (!mounted) return;
      setState(() => searchResults = []);
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "ANIME",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 3.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 60),
                _buildSearchBar(p),
                Expanded(
                  child: isLoading
                      ? _buildLoadingShimmer(p)
                      : isSearching
                          ? _buildSearchResults(p)
                          : animeData == null
                              ? _buildErrorWidget(p)
                              : _buildHomeContent(p),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar(AppPalette p) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      height: 46,
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: TextField(
        controller: _searchController,
        focusNode: _searchFocusNode,
        style: TextStyle(
          color: p.textPrimary,
          fontFamily: kFontFamily,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: p.textPrimary,
        decoration: InputDecoration(
          hintText: "Search anime...",
          hintStyle: TextStyle(
            color: p.textMuted,
            fontFamily: kFontFamily,
            fontSize: 13,
          ),
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          prefixIcon: Icon(Icons.search, color: p.textTertiary, size: 18),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: Icon(Icons.clear, color: p.textTertiary, size: 16),
                  onPressed: _clearSearch,
                )
              : null,
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
        ),
        onChanged: (value) {
          if (value.isNotEmpty) {
            searchAnime(value);
          } else {
            setState(() {
              isSearching = false;
              searchResults.clear();
            });
          }
        },
        onSubmitted: (value) {
          if (value.isNotEmpty) searchAnime(value);
        },
      ),
    );
  }

  Widget _buildHomeContent(AppPalette p) {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.wait([fetchAnimeData(), _loadWatchHistory()]);
      },
      color: p.textPrimary,
      backgroundColor: p.surfaceAlt,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(p, Icons.history, "WATCH HISTORY"),
            const SizedBox(height: 12),
            if (_isHistoryLoading)
              SizedBox(
                height: 180,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 5,
                  itemBuilder: (context, index) => Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 12),
                    child: Shimmer.fromColors(
                      baseColor: p.surface,
                      highlightColor: p.surfaceAlt,
                      child: Container(
                        decoration: BoxDecoration(
                          color: p.surfaceAlt,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
            else if (_watchHistory.isEmpty)
              Container(
                height: 100,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: p.surfaceAlt,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  "Belum ada history",
                  style: TextStyle(
                    color: p.textMuted,
                    fontFamily: kFontFamily,
                    fontSize: 12,
                  ),
                ),
              )
            else
              SizedBox(
                height: 210,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _watchHistory.length,
                  itemBuilder: (context, index) =>
                      _buildHistoryCard(p, _watchHistory[index]),
                ),
              ),
            const SizedBox(height: 24),
            _buildSectionHeader(p, Icons.dashboard, "QUICK ACCESS"),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildQuickAccessCard(p, "Genre", Icons.category, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const AnimeGenreListPage()),
                    ).then((_) => refreshHistory());
                  }),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildQuickAccessCard(
                      p, "Schedule", Icons.schedule, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const AnimeSchedulePage()),
                    ).then((_) => refreshHistory());
                  }),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _buildSectionHeader(p, Icons.live_tv, "CURRENTLY AIRING"),
            const SizedBox(height: 12),
            _buildAnimeGrid(p, animeData!['ongoing']['animeList'] ?? []),
            const SizedBox(height: 24),
            _buildSectionHeader(p, Icons.check_circle, "COMPLETED SERIES"),
            const SizedBox(height: 12),
            _buildAnimeGrid(p, animeData!['completed']['animeList'] ?? []),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(AppPalette p, IconData icon, String title) {
    return Row(
      children: [
        Icon(icon, color: p.textPrimary, size: 18),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w900,
            color: p.textPrimary,
            fontFamily: kFontFamily,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Container(height: 1, color: Colors.white.withOpacity(0.15)),
        ),
      ],
    );
  }

  Widget _buildHistoryCard(AppPalette p, Map<String, dynamic> anime) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () {
          if (anime['last_watched_episode_slug'] != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeEpisodePage(
                  episodeSlug: anime['last_watched_episode_slug'],
                  animeSlug: anime['slug'],
                  animeTitle: anime['title'],
                  animePoster: anime['poster'],
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            ).then((_) => refreshHistory());
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  slug: anime['slug'],
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            ).then((_) => refreshHistory());
          }
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Stack(
                children: [
                  ClipRect(
                    child: Image.network(
                      anime['poster'],
                      height: 160,
                      width: 120,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        height: 160,
                        width: 120,
                        color: p.surfaceAlt,
                        alignment: Alignment.center,
                        child: Icon(Icons.image_not_supported,
                            color: p.textMuted),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: p.bg.withOpacity(0.85),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1,
                        ),
                      ),
                      child: Icon(Icons.play_arrow,
                          color: p.textPrimary, size: 14),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            p.bg.withOpacity(0.9),
                          ],
                        ),
                      ),
                      child: Text(
                        anime['last_watched_episode'] ?? '',
                        style: TextStyle(
                          color: p.textPrimary,
                          fontSize: 10,
                          fontFamily: kFontFamily,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              anime['title'],
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 11,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults(AppPalette p) {
    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(Icons.search_off, color: p.textMuted, size: 40),
            ),
            const SizedBox(height: 16),
            Text(
              "No results found",
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      physics: const BouncingScrollPhysics(),
      itemCount: searchResults.length,
      itemBuilder: (context, index) =>
          _buildSearchResultCard(p, searchResults[index]),
    );
  }

  Widget _buildSearchResultCard(AppPalette p, Map<String, dynamic> anime) {
    final String title = anime['title'];
    final String poster = anime['poster'];
    final String? status = anime['status'];
    final String? score = anime['score'];
    final String slug = anime['animeId'];
    final List<dynamic> genres = anime['genreList'] ?? [];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  slug: slug,
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            ).then((_) => refreshHistory());
          },
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Image.network(
                    poster,
                    width: 80,
                    height: 120,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 80,
                      height: 120,
                      color: p.bg,
                      alignment: Alignment.center,
                      child: Icon(Icons.image_not_supported,
                          color: p.textMuted),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: p.textPrimary,
                          fontFamily: kFontFamily,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          if (score != null && score.isNotEmpty) ...[
                            const Icon(Icons.star,
                                color: Color(0xFFFFC107), size: 14),
                            const SizedBox(width: 4),
                            Text(
                              score,
                              style: TextStyle(
                                color: p.textPrimary,
                                fontFamily: kFontFamily,
                                fontSize: 11,
                              ),
                            ),
                            const SizedBox(width: 10),
                          ],
                          if (status != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: p.bg,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                status,
                                style: TextStyle(
                                  color: p.textPrimary,
                                  fontSize: 9,
                                  fontFamily: kFontFamily,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (genres.isNotEmpty)
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: genres.take(3).map<Widget>((genre) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: p.bg,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                genre['title'],
                                style: TextStyle(
                                  color: p.textTertiary,
                                  fontSize: 9,
                                  fontFamily: kFontFamily,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAnimeGrid(AppPalette p, List<dynamic> list) {
    return GridView.builder(
      itemCount: list.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 250,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (context, index) {
        final anime = list[index];
        final String title = anime['title'];
        final String poster = anime['poster'];
        final String? episode = anime['episodes']?.toString();
        final String? date =
            anime['latestReleaseDate'] ?? anime['lastReleaseDate'];
        final String slug = anime['animeId'];

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  slug: slug,
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            ).then((_) => refreshHistory());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Image.network(
                  poster,
                  height: 160,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 160,
                    color: p.surfaceAlt,
                    alignment: Alignment.center,
                    child: Icon(Icons.image_not_supported,
                        color: p.textMuted),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: p.textPrimary,
                    fontFamily: kFontFamily,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  episode != null ? "$episode Episodes" : "-",
                  style: TextStyle(
                    fontSize: 10,
                    color: p.textTertiary,
                    fontFamily: kFontFamily,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                child: Text(
                  date != null ? "Updated: $date" : "",
                  style: TextStyle(
                    fontSize: 9,
                    color: p.textMuted,
                    fontFamily: kFontFamily,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return GridView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: 8,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 250,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: p.surface,
        highlightColor: p.surfaceAlt,
        child: Container(
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildErrorWidget(AppPalette p) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Icon(Icons.error_outline, color: p.danger, size: 40),
          ),
          const SizedBox(height: 20),
          Text(
            "Failed to load data",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 44,
            width: 140,
            child: ElevatedButton(
              onPressed: () async {
                await Future.wait([fetchAnimeData(), _loadWatchHistory()]);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: p.bg,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAccessCard(
      AppPalette p, String title, IconData icon, VoidCallback onTap) {
    return Container(
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: p.bg,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Icon(icon, color: p.textPrimary, size: 20),
                ),
                const SizedBox(height: 10),
                Text(
                  title.toUpperCase(),
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.2,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ANIME DETAIL PAGE
// ============================================================
class AnimeDetailPage extends StatefulWidget {
  final String slug;
  final Function()? onHistoryUpdate;

  const AnimeDetailPage({super.key, required this.slug, this.onHistoryUpdate});

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  Map<String, dynamic>? animeDetail;
  bool isLoading = true;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchAnimeDetail();
  }

  Future<void> fetchAnimeDetail() async {
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/anime/${widget.slug}'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          animeDetail = jsonData['data'];
          isLoading = false;
        });
      } else {
        if (!mounted) return;
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "DETAIL",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer(p)
                : isError || animeDetail == null
                    ? _buildError(p)
                    : _buildAnimeDetail(p),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(Icons.error_outline, color: p.danger, size: 40),
            ),
            const SizedBox(height: 20),
            Text(
              "Failed to load anime details",
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 44,
              width: 140,
              child: ElevatedButton(
                onPressed: fetchAnimeDetail,
                style: ElevatedButton.styleFrom(
                  backgroundColor: p.textPrimary,
                  foregroundColor: p.bg,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: Text(
                  "TRY AGAIN",
                  style: TextStyle(
                    color: p.bg,
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 60),
          Shimmer.fromColors(
            baseColor: p.surface,
            highlightColor: p.surfaceAlt,
            child: Container(
              height: 200,
              width: double.infinity,
              color: p.surfaceAlt,
            ),
          ),
          const SizedBox(height: 16),
          ...List.generate(
            5,
            (i) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Shimmer.fromColors(
                baseColor: p.surface,
                highlightColor: p.surfaceAlt,
                child: Container(
                  height: i == 0 ? 24 : 16,
                  width: double.infinity,
                  color: p.surfaceAlt,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimeDetail(AppPalette p) {
    final anime = animeDetail!;
    final List<dynamic> episodes = anime['episodeList'] ?? [];
    final List<dynamic> recommendations = anime['recommendedAnimeList'] ?? [];
    final List<dynamic> genres = anime['genreList'] ?? [];

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 80, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.8),
                      offset: const Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Image.network(
                  anime['poster'],
                  height: 200,
                  width: 140,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 200,
                    width: 140,
                    color: p.surfaceAlt,
                    alignment: Alignment.center,
                    child:
                        Icon(Icons.image_not_supported, color: p.textMuted),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      anime['title'],
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: p.textPrimary,
                        fontFamily: kFontFamily,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      anime['japanese'] ?? '-',
                      style: TextStyle(
                        fontSize: 11,
                        color: p.textTertiary,
                        fontFamily: kFontFamily,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.star,
                            color: Color(0xFFFFC107), size: 14),
                        const SizedBox(width: 4),
                        Text(
                          anime['score'] ?? '-',
                          style: TextStyle(
                              color: p.textPrimary,
                              fontFamily: kFontFamily,
                              fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _buildInfoItem(p, 'Type', anime['type']),
                    _buildInfoItem(p, 'Status', anime['status']),
                    _buildInfoItem(p, 'Episodes', anime['episodes']?.toString()),
                    _buildInfoItem(p, 'Duration', anime['duration']),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (genres.isNotEmpty) ...[
            Text(
              "GENRE",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
                fontFamily: kFontFamily,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: genres.map<Widget>((genre) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AnimeGenrePage(
                          genreSlug: genre['genreId'],
                          genreName: genre['title'],
                        ),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: p.surfaceAlt,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.7),
                        width: 1.5,
                      ),
                    ),
                    child: Text(
                      genre['title'],
                      style: TextStyle(
                        color: p.textPrimary,
                        fontSize: 11,
                        fontFamily: kFontFamily,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
          ],
          if (anime['synopsis'] != null &&
              anime['synopsis']['paragraphs'].isNotEmpty) ...[
            Text(
              "SYNOPSIS",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
                fontFamily: kFontFamily,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Text(
                anime['synopsis']['paragraphs'].join('\n\n'),
                style: TextStyle(
                  color: p.textPrimary,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  height: 1.5,
                ),
                textAlign: TextAlign.justify,
              ),
            ),
            const SizedBox(height: 20),
          ],
          if (episodes.isNotEmpty) ...[
            Text(
              "EPISODES",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
                fontFamily: kFontFamily,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: episodes.length,
              itemBuilder: (context, index) {
                final episode = episodes[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: p.surfaceAlt,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AnimeEpisodePage(
                              episodeSlug: episode['episodeId'],
                              animeSlug: widget.slug,
                              animeTitle: anime['title'],
                              animePoster: anime['poster'],
                              episodes: episodes,
                              recommendations: recommendations,
                              onHistoryUpdate: widget.onHistoryUpdate,
                            ),
                          ),
                        ).then((_) {
                          if (widget.onHistoryUpdate != null) {
                            widget.onHistoryUpdate!();
                          }
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: p.bg,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1.5,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  episode['eps'].toString(),
                                  style: TextStyle(
                                    color: p.textPrimary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: kFontFamily,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                episode['title'],
                                style: TextStyle(
                                  color: p.textPrimary,
                                  fontFamily: kFontFamily,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Icon(Icons.play_arrow,
                                color: p.textPrimary, size: 18),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
          ],
          if (anime['batch'] != null) ...[
            Container(
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _launchURL(anime['batch']['otakudesuUrl']),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Icon(Icons.download, color: p.textPrimary, size: 18),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "DOWNLOAD BATCH",
                                style: TextStyle(
                                  color: p.textPrimary,
                                  fontFamily: kFontFamily,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                anime['batch']['title'],
                                style: TextStyle(
                                  color: p.textTertiary,
                                  fontFamily: kFontFamily,
                                  fontSize: 10,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.arrow_forward_ios,
                            color: p.textMuted, size: 12),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
          if (recommendations.isNotEmpty) ...[
            Text(
              "RECOMMENDATIONS",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
                fontFamily: kFontFamily,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 200,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: recommendations.length,
                itemBuilder: (context, index) {
                  final rec = recommendations[index];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AnimeDetailPage(
                            slug: rec['animeId'],
                            onHistoryUpdate: widget.onHistoryUpdate,
                          ),
                        ),
                      ).then((_) {
                        if (widget.onHistoryUpdate != null) {
                          widget.onHistoryUpdate!();
                        }
                      });
                    },
                    child: Container(
                      width: 120,
                      margin: const EdgeInsets.only(right: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                            child: Image.network(
                              rec['poster'],
                              height: 160,
                              width: 120,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                height: 160,
                                width: 120,
                                color: p.surfaceAlt,
                                alignment: Alignment.center,
                                child: Icon(Icons.image_not_supported,
                                    color: p.textMuted),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            rec['title'],
                            style: TextStyle(
                              color: p.textPrimary,
                              fontFamily: kFontFamily,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoItem(AppPalette p, String label, String? value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$label: ',
              style: TextStyle(
                color: p.textTertiary,
                fontFamily: kFontFamily,
                fontSize: 10,
              ),
            ),
            TextSpan(
              text: value ?? '-',
              style: TextStyle(
                color: p.textPrimary,
                fontFamily: kFontFamily,
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ANIME GENRE PAGE
// ============================================================
class AnimeGenrePage extends StatefulWidget {
  final String genreSlug;
  final String genreName;

  const AnimeGenrePage({
    super.key,
    required this.genreSlug,
    required this.genreName,
  });

  @override
  State<AnimeGenrePage> createState() => _AnimeGenrePageState();
}

class _AnimeGenrePageState extends State<AnimeGenrePage> {
  List<dynamic> animeList = [];
  Map<String, dynamic>? pagination;
  bool isLoading = true;
  bool isError = false;
  int currentPage = 1;

  Future<void> fetchGenreAnime({int page = 1}) async {
    try {
      final response = await http.get(
        Uri.parse(
            'https://www.sankavollerei.com/anime/genre/${widget.genreSlug}?page=$page'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          animeList = jsonData['data']['animeList'];
          pagination = jsonData['pagination'];
          isLoading = false;
          currentPage = page;
        });
      } else {
        if (!mounted) return;
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchGenreAnime();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            widget.genreName.toUpperCase(),
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer(p)
                : isError
                    ? _buildError(p)
                    : _buildGenreContent(p),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: 8,
      itemBuilder: (context, index) => Shimmer.fromColors(
        baseColor: p.surface,
        highlightColor: p.surfaceAlt,
        child: Container(
          height: 140,
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Icon(Icons.error_outline, color: p.danger, size: 40),
          ),
          const SizedBox(height: 20),
          Text(
            "Failed to load genre data",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 44,
            width: 140,
            child: ElevatedButton(
              onPressed: () => fetchGenreAnime(),
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: p.bg,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGenreContent(AppPalette p) {
    return Column(
      children: [
        if (pagination != null) _buildPaginationInfo(p),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            physics: const BouncingScrollPhysics(),
            itemCount: animeList.length,
            itemBuilder: (context, index) =>
                _buildAnimeCard(p, animeList[index]),
          ),
        ),
        if (pagination != null) _buildPaginationControls(p),
      ],
    );
  }

  Widget _buildPaginationInfo(AppPalette p) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 80, 16, 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Page $currentPage / ${pagination!['totalPages']}",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            "Total: ${animeList.length}",
            style: TextStyle(
              color: p.textTertiary,
              fontFamily: kFontFamily,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaginationControls(AppPalette p) {
    final hasNext = pagination!['hasNextPage'] ?? false;
    final hasPrev = pagination!['hasPrevPage'] ?? false;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.bg,
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.7),
            width: 1.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (hasPrev)
            Expanded(
              child: SizedBox(
                height: 44,
                child: ElevatedButton(
                  onPressed: () => fetchGenreAnime(page: currentPage - 1),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: p.textPrimary,
                    foregroundColor: p.bg,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_back, size: 14, color: p.bg),
                      const SizedBox(width: 6),
                      Text(
                        "PREV",
                        style: TextStyle(
                          color: p.bg,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          if (hasPrev && hasNext) const SizedBox(width: 10),
          if (hasNext)
            Expanded(
              child: SizedBox(
                height: 44,
                child: ElevatedButton(
                  onPressed: () => fetchGenreAnime(page: currentPage + 1),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: p.textPrimary,
                    foregroundColor: p.bg,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "NEXT",
                        style: TextStyle(
                          color: p.bg,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.arrow_forward, size: 14, color: p.bg),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnimeCard(AppPalette p, Map<String, dynamic> anime) {
    final String title = anime['title'];
    final String poster = anime['poster'];
    final String score = anime['score'] ?? '-';
    final String episodeCount = anime['episodes']?.toString() ?? '?';
    final String season = anime['season'] ?? '-';
    final String studio = anime['studios'] ?? '-';
    final String slug = anime['animeId'];
    final List<dynamic> genres = anime['genreList'] ?? [];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(slug: slug),
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Image.network(
                    poster,
                    width: 90,
                    height: 130,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 90,
                      height: 130,
                      color: p.bg,
                      alignment: Alignment.center,
                      child: Icon(Icons.image_not_supported,
                          color: p.textMuted),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: p.textPrimary,
                          fontFamily: kFontFamily,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(Icons.star,
                              color: Color(0xFFFFC107), size: 12),
                          const SizedBox(width: 4),
                          Text(
                            score,
                            style: TextStyle(
                              color: p.textPrimary,
                              fontFamily: kFontFamily,
                              fontSize: 10,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            "$episodeCount Ep",
                            style: TextStyle(
                              color: p.textTertiary,
                              fontFamily: kFontFamily,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "$season • $studio",
                        style: TextStyle(
                          color: p.textMuted,
                          fontFamily: kFontFamily,
                          fontSize: 9,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      if (genres.isNotEmpty)
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: genres.take(3).map<Widget>((genre) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: p.bg,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                genre['title'],
                                style: TextStyle(
                                  color: p.textTertiary,
                                  fontSize: 9,
                                  fontFamily: kFontFamily,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ANIME SCHEDULE PAGE
// ============================================================
class AnimeSchedulePage extends StatefulWidget {
  const AnimeSchedulePage({super.key});

  @override
  State<AnimeSchedulePage> createState() => _AnimeSchedulePageState();
}

class _AnimeSchedulePageState extends State<AnimeSchedulePage> {
  List<dynamic> scheduleData = [];
  bool isLoading = true;
  bool isError = false;

  Future<void> fetchSchedule() async {
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/schedule'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          scheduleData = jsonData['data'];
          isLoading = false;
        });
      } else {
        if (!mounted) return;
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error fetching schedule: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchSchedule();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "SCHEDULE",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer(p)
                : isError
                    ? _buildError(p)
                    : _buildScheduleContent(p),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: 7,
      itemBuilder: (context, index) => Shimmer.fromColors(
        baseColor: p.surface,
        highlightColor: p.surfaceAlt,
        child: Container(
          height: 180,
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Icon(Icons.error_outline, color: p.danger, size: 40),
          ),
          const SizedBox(height: 20),
          Text(
            "Failed to load schedule",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 44,
            width: 140,
            child: ElevatedButton(
              onPressed: fetchSchedule,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: p.bg,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleContent(AppPalette p) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 80, 16, 16),
      physics: const BouncingScrollPhysics(),
      itemCount: scheduleData.length,
      itemBuilder: (context, index) {
        final daySchedule = scheduleData[index];
        final String day = daySchedule['day'];
        final List<dynamic> animeList = daySchedule['anime_list'];

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: p.bg,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: Text(
                        day.toUpperCase(),
                        style: TextStyle(
                          color: p.textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFontFamily,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "${animeList.length} Anime",
                      style: TextStyle(
                        color: p.textTertiary,
                        fontSize: 11,
                        fontFamily: kFontFamily,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (animeList.isNotEmpty)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: animeList.length,
                      itemBuilder: (context, animeIndex) {
                        final anime = animeList[animeIndex];
                        return Container(
                          width: 120,
                          margin: EdgeInsets.only(
                            right: animeIndex == animeList.length - 1 ? 0 : 12,
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      AnimeDetailPage(slug: anime['slug']),
                                ),
                              );
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.7),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Image.network(
                                    anime['poster'],
                                    width: 120,
                                    height: 150,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      width: 120,
                                      height: 150,
                                      color: p.bg,
                                      alignment: Alignment.center,
                                      child: Icon(Icons.image_not_supported,
                                          color: p.textMuted),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Expanded(
                                  child: Text(
                                    anime['title'],
                                    style: TextStyle(
                                      color: p.textPrimary,
                                      fontSize: 10,
                                      fontFamily: kFontFamily,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// ANIME GENRE LIST PAGE
// ============================================================
class AnimeGenreListPage extends StatefulWidget {
  const AnimeGenreListPage({super.key});

  @override
  State<AnimeGenreListPage> createState() => _AnimeGenreListPageState();
}

class _AnimeGenreListPageState extends State<AnimeGenreListPage> {
  List<dynamic> genreList = [];
  bool isLoading = true;
  bool isError = false;

  Future<void> fetchGenreList() async {
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/genre/'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          genreList = jsonData['data']['genreList'];
          isLoading = false;
        });
      } else {
        if (!mounted) return;
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error fetching genre list: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchGenreList();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "GENRES",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer(p)
                : isError
                    ? _buildError(p)
                    : _buildGenreGrid(p),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 80, 16, 16),
      itemCount: 20,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 3.0,
      ),
      itemBuilder: (context, index) => Shimmer.fromColors(
        baseColor: p.surface,
        highlightColor: p.surfaceAlt,
        child: Container(
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Icon(Icons.error_outline, color: p.danger, size: 40),
          ),
          const SizedBox(height: 20),
          Text(
            "Failed to load genre list",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 44,
            width: 140,
            child: ElevatedButton(
              onPressed: fetchGenreList,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: p.bg,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGenreGrid(AppPalette p) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 80, 16, 16),
      physics: const BouncingScrollPhysics(),
      itemCount: genreList.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 3.0,
      ),
      itemBuilder: (context, index) {
        final genre = genreList[index];
        return Container(
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AnimeGenrePage(
                      genreSlug: genre['genreId'],
                      genreName: genre['title'],
                    ),
                  ),
                );
              },
              child: Center(
                child: Text(
                  genre['title'].toString().toUpperCase(),
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.2,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ============================================================
// ANIME EPISODE PAGE
// ============================================================
class AnimeEpisodePage extends StatefulWidget {
  final String episodeSlug;
  final String? animeSlug;
  final String? animeTitle;
  final String? animePoster;
  final List<dynamic>? episodes;
  final List<dynamic>? recommendations;
  final Function()? onHistoryUpdate;

  const AnimeEpisodePage({
    super.key,
    required this.episodeSlug,
    this.animeSlug,
    this.animeTitle,
    this.animePoster,
    this.episodes,
    this.recommendations,
    this.onHistoryUpdate,
  });

  @override
  State<AnimeEpisodePage> createState() => _AnimeEpisodePageState();
}

class _AnimeEpisodePageState extends State<AnimeEpisodePage>
    with WidgetsBindingObserver {
  Map<String, dynamic>? episodeData;
  bool isLoading = true;
  bool isError = false;
  int _currentTabIndex = 0;

  late WebViewController _webViewController;
  bool _isWebViewLoading = true;
  bool _isFullScreen = false;

  List<dynamic> _qualities = [];
  int _selectedQualityIndex = 0;
  int _selectedServerIndex = 0;
  bool _showQualitySelector = false;

  String? _streamUrl;
  int _currentEpisodeIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fetchEpisodeData();
    _findCurrentEpisodeIndex();
  }

  void _findCurrentEpisodeIndex() {
    if (widget.episodes != null) {
      for (int i = 0; i < widget.episodes!.length; i++) {
        if (widget.episodes![i]['episodeId'] == widget.episodeSlug) {
          setState(() => _currentEpisodeIndex = i);
          break;
        }
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final physicalSize = WidgetsBinding.instance.window.physicalSize;
    final pixelRatio = WidgetsBinding.instance.window.devicePixelRatio;
    final logicalSize = physicalSize / pixelRatio;
    final isNowFullScreen = logicalSize.width > logicalSize.height;

    if (isNowFullScreen != _isFullScreen) {
      setState(() => _isFullScreen = isNowFullScreen);
      if (_isFullScreen) {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      } else {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      }
    }
  }

  Future<void> fetchEpisodeData() async {
    try {
      final response = await http.get(
        Uri.parse(
            'https://www.sankavollerei.com/anime/episode/${widget.episodeSlug}'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() {
          episodeData = jsonData['data'];
          _qualities = episodeData?['server']?['qualities'] ?? [];
          if (_qualities.isNotEmpty) {
            for (int i = 0; i < _qualities.length; i++) {
              final quality = _qualities[i];
              final serverList = quality['serverList'] ?? [];
              if (serverList.isNotEmpty) {
                _selectedQualityIndex = i;
                _selectedServerIndex = 0;
                break;
              }
            }
          }
        });
        await _fetchStreamUrl();
        _initializeWebView();
        _addToWatchHistory();
        if (mounted) setState(() => isLoading = false);
      } else {
        if (!mounted) return;
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error: $e');
      if (!mounted) return;
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  Future<void> _fetchStreamUrl() async {
    if (_qualities.isEmpty) return;
    final selectedQuality = _qualities[_selectedQualityIndex];
    final serverList = selectedQuality['serverList'] ?? [];
    if (serverList.isEmpty) return;

    final selectedServer = serverList[_selectedServerIndex];
    final serverId = selectedServer['serverId'];

    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/server/$serverId'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (!mounted) return;
        setState(() => _streamUrl = jsonData['data']['url']);
      }
    } catch (e) {
      debugPrint('Error fetching stream URL: $e');
    }
  }

  Future<void> _addToWatchHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      List<Map<String, dynamic>> watchHistory = historyJson
          .map((item) => Map<String, dynamic>.from(json.decode(item)))
          .toList();

      final historyItem = {
        'slug': widget.animeSlug,
        'title': widget.animeTitle,
        'poster': widget.animePoster,
        'last_watched_episode': episodeData?['title'],
        'last_watched_episode_slug': widget.episodeSlug,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      watchHistory.removeWhere((item) => item['slug'] == widget.animeSlug);
      watchHistory.insert(0, historyItem);
      if (watchHistory.length > 20) {
        watchHistory = watchHistory.sublist(0, 20);
      }

      final newHistoryJson =
          watchHistory.map((item) => json.encode(item)).toList();
      await prefs.setStringList('watch_history', newHistoryJson);
      if (widget.onHistoryUpdate != null) {
        widget.onHistoryUpdate!();
      }
    } catch (e) {
      debugPrint('Error saving to watch history: $e');
    }
  }

  void _initializeWebView() {
    if (_streamUrl == null) return;

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0A0A0A))
      ..addJavaScriptChannel(
        'FullScreen',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'enter') {
            _enterFullScreen();
          } else if (message.message == 'exit') {
            _exitFullScreen();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (progress == 100) {
              if (!mounted) return;
              setState(() => _isWebViewLoading = false);
              _injectFullScreenDetection();
            }
          },
          onPageStarted: (String url) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = true);
          },
          onPageFinished: (String url) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = false);
            _injectFullScreenDetection();
          },
          onWebResourceError: (WebResourceError error) {
            if (!mounted) return;
            setState(() => _isWebViewLoading = false);
          },
          onNavigationRequest: (NavigationRequest request) {
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_streamUrl!), headers: _getChromeHeaders());
  }

  void _injectFullScreenDetection() {
    _webViewController.runJavaScript('''
      function handleFullScreenChange() {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
          FullScreen.postMessage('enter');
        } else {
          FullScreen.postMessage('exit');
        }
      }
      document.addEventListener('fullscreenchange', handleFullScreenChange);
      document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.addEventListener('click', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
    ''');
  }

  void _enterFullScreen() {
    if (!_isFullScreen) {
      setState(() => _isFullScreen = true);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _exitFullScreen() {
    if (_isFullScreen) {
      setState(() => _isFullScreen = false);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  Map<String, String> _getChromeHeaders() {
    return {
      'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    };
  }

  void _refreshWebView() {
    setState(() => _isWebViewLoading = true);
    _webViewController.reload();
  }

  void _openInExternalBrowser() {
    if (_streamUrl != null) _launchURL(_streamUrl!);
  }

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _goToNextEpisode() {
    if (widget.episodes != null &&
        _currentEpisodeIndex < widget.episodes!.length - 1) {
      final nextEpisode = widget.episodes![_currentEpisodeIndex + 1];
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => AnimeEpisodePage(
            episodeSlug: nextEpisode['episodeId'],
            animeSlug: widget.animeSlug,
            animeTitle: widget.animeTitle,
            animePoster: widget.animePoster,
            episodes: widget.episodes,
            recommendations: widget.recommendations,
            onHistoryUpdate: widget.onHistoryUpdate,
          ),
        ),
      );
    }
  }

  void _changeQuality(int qualityIndex, int serverIndex) async {
    setState(() {
      _selectedQualityIndex = qualityIndex;
      _selectedServerIndex = serverIndex;
      _isWebViewLoading = true;
      _streamUrl = null;
    });
    await _fetchStreamUrl();
    _initializeWebView();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: _isFullScreen
          ? null
          : AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              centerTitle: true,
              iconTheme: IconThemeData(color: p.textPrimary),
              title: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: p.primary,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.25),
                      blurRadius: 14,
                    ),
                  ],
                ),
                child: Text(
                  "WATCH",
                  style: TextStyle(
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: p.onPrimary,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
              actions: [
                if (episodeData != null) ...[
                  IconButton(
                    icon: Icon(Icons.refresh, color: p.textPrimary),
                    onPressed: _refreshWebView,
                  ),
                  IconButton(
                    icon: Icon(Icons.open_in_browser, color: p.textPrimary),
                    onPressed: _openInExternalBrowser,
                  ),
                ],
              ],
            ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer(p)
                : isError || episodeData == null
                    ? _buildError(p)
                    : _buildStreamingContent(p),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildError(AppPalette p) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Icon(Icons.error_outline, color: p.danger, size: 40),
          ),
          const SizedBox(height: 20),
          Text(
            "Failed to load episode",
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 44,
            width: 140,
            child: ElevatedButton(
              onPressed: fetchEpisodeData,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: p.bg,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer(AppPalette p) {
    return ListView(
      children: [
        AspectRatio(
          aspectRatio: 16 / 9,
          child: Shimmer.fromColors(
            baseColor: p.surface,
            highlightColor: p.surfaceAlt,
            child: Container(color: p.surfaceAlt),
          ),
        ),
      ],
    );
  }

  Widget _buildStreamingContent(AppPalette p) {
    final List<dynamic> episodes = widget.episodes ?? [];
    final List<dynamic> recommendations = widget.recommendations ?? [];
    final List<dynamic> genres = episodeData?['genreList'] ?? [];

    return Column(
      children: [
        Container(
          height: _isFullScreen
              ? MediaQuery.of(context).size.height
              : MediaQuery.of(context).size.height * 0.35,
          width: double.infinity,
          color: Colors.black,
          child: Stack(
            children: [
              if (_streamUrl != null)
                WebViewWidget(controller: _webViewController)
              else
                const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: Color(0xFFF5F5F5),
                        strokeWidth: 2.5,
                      ),
                      SizedBox(height: 16),
                      Text(
                        "Loading stream URL...",
                        style: TextStyle(color: Color(0xFFF5F5F5)),
                      ),
                    ],
                  ),
                ),
              if (_isWebViewLoading)
                Container(
                  color: Colors.black.withOpacity(0.5),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFF5F5F5),
                      strokeWidth: 2.5,
                    ),
                  ),
                ),
              if (!_isFullScreen && _qualities.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: () {
                      setState(
                          () => _showQualitySelector = !_showQualitySelector);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: p.bg.withOpacity(0.85),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: Icon(Icons.settings,
                          color: p.textPrimary, size: 18),
                    ),
                  ),
                ),
              if (_isFullScreen)
                Positioned(
                  top: 40,
                  right: 20,
                  child: GestureDetector(
                    onTap: _exitFullScreen,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: p.bg.withOpacity(0.85),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: Icon(Icons.fullscreen_exit,
                          color: p.textPrimary, size: 26),
                    ),
                  ),
                ),
            ],
          ),
        ),

        if (_showQualitySelector && !_isFullScreen && _qualities.isNotEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            color: p.surfaceAlt,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "SELECT QUALITY",
                      style: TextStyle(
                        color: p.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFontFamily,
                        letterSpacing: 1.5,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => setState(
                          () => _showQualitySelector = false),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: p.bg,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.7),
                            width: 1.5,
                          ),
                        ),
                        child: Icon(Icons.close,
                            color: p.textPrimary, size: 14),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _qualities.length,
                  itemBuilder: (context, qualityIndex) {
                    final quality = _qualities[qualityIndex];
                    final qualityTitle = quality['title'] ?? '';
                    final serverList = quality['serverList'] ?? [];

                    if (serverList.isEmpty) return const SizedBox.shrink();

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: p.bg,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: ExpansionTile(
                        tilePadding:
                            const EdgeInsets.symmetric(horizontal: 12),
                        title: Text(
                          qualityTitle,
                          style: TextStyle(
                            color: p.textPrimary,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFontFamily,
                            fontSize: 12,
                          ),
                        ),
                        iconColor: p.textPrimary,
                        collapsedIconColor: p.textTertiary,
                        children: serverList.map<Widget>((server) {
                          final serverTitle = server['title'] ?? '';
                          final serverIndex = serverList.indexOf(server);
                          final isSelected =
                              _selectedQualityIndex == qualityIndex &&
                                  _selectedServerIndex == serverIndex;

                          return GestureDetector(
                            onTap: () {
                              _changeQuality(qualityIndex, serverIndex);
                              setState(() => _showQualitySelector = false);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 12),
                              child: Row(
                                children: [
                                  Icon(
                                    isSelected
                                        ? Icons.check_circle
                                        : Icons.radio_button_unchecked,
                                    color: isSelected
                                        ? p.success
                                        : p.textTertiary,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    serverTitle,
                                    style: TextStyle(
                                      color: p.textPrimary,
                                      fontFamily: kFontFamily,
                                      fontSize: 11,
                                      fontWeight: isSelected
                                          ? FontWeight.w800
                                          : FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

        if (!_isFullScreen && !_showQualitySelector) ...[
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border(
                bottom: BorderSide(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
            ),
            child: Row(
              children: [
                _buildTabButton(p, 0, Icons.playlist_play, 'EPISODES'),
                _buildTabButton(p, 1, Icons.recommend, 'RECOMMEND'),
                _buildTabButton(p, 2, Icons.category, 'GENRES'),
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: _currentTabIndex,
              children: [
                _buildEpisodeList(p, episodes),
                _buildRecommendations(p, recommendations),
                _buildGenresList(p, genres),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildTabButton(
      AppPalette p, int index, IconData icon, String label) {
    final isSelected = _currentTabIndex == index;
    return Expanded(
      child: Material(
        color: isSelected ? p.bg : Colors.transparent,
        child: InkWell(
          onTap: () => setState(() => _currentTabIndex = index),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isSelected ? p.textPrimary : p.textTertiary,
                size: 16,
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? p.textPrimary : p.textTertiary,
                  fontSize: 9,
                  fontFamily: kFontFamily,
                  fontWeight:
                      isSelected ? FontWeight.w900 : FontWeight.w500,
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEpisodeList(AppPalette p, List<dynamic> episodes) {
    if (episodes.isEmpty) {
      return Center(
        child: Text(
          "No episodes available",
          style: TextStyle(
            color: p.textMuted,
            fontFamily: kFontFamily,
            fontSize: 12,
          ),
        ),
      );
    }
    return Column(
      children: [
        if (_currentEpisodeIndex < episodes.length - 1)
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              height: 44,
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _goToNextEpisode,
                style: ElevatedButton.styleFrom(
                  backgroundColor: p.textPrimary,
                  foregroundColor: p.bg,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "NEXT EPISODE",
                      style: TextStyle(
                        color: p.bg,
                        fontFamily: kFontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.skip_next, color: p.bg, size: 16),
                  ],
                ),
              ),
            ),
          ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            physics: const BouncingScrollPhysics(),
            itemCount: episodes.length,
            itemBuilder: (context, index) {
              final episode = episodes[index];
              final isCurrentEpisode =
                  episode['episodeId'] == widget.episodeSlug;
              return Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                decoration: BoxDecoration(
                  color: isCurrentEpisode ? p.bg : p.surfaceAlt,
                  border: Border.all(
                    color: isCurrentEpisode
                        ? p.textPrimary
                        : Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () {
                      if (!isCurrentEpisode) {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AnimeEpisodePage(
                              episodeSlug: episode['episodeId'],
                              animeSlug: widget.animeSlug,
                              animeTitle: widget.animeTitle,
                              animePoster: widget.animePoster,
                              episodes: widget.episodes,
                              recommendations: widget.recommendations,
                              onHistoryUpdate: widget.onHistoryUpdate,
                            ),
                          ),
                        );
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: isCurrentEpisode ? p.textPrimary : p.bg,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                episode['eps'].toString(),
                                style: TextStyle(
                                  color: isCurrentEpisode
                                      ? p.bg
                                      : p.textPrimary,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  fontFamily: kFontFamily,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              episode['title'],
                              style: TextStyle(
                                color: p.textPrimary,
                                fontSize: 11,
                                fontFamily: kFontFamily,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Icon(
                            isCurrentEpisode
                                ? Icons.play_arrow
                                : Icons.play_circle_outline,
                            color: p.textPrimary,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildRecommendations(
      AppPalette p, List<dynamic> recommendations) {
    if (recommendations.isEmpty) {
      return Center(
        child: Text(
          "No recommendations",
          style: TextStyle(
            color: p.textMuted,
            fontFamily: kFontFamily,
            fontSize: 12,
          ),
        ),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      physics: const BouncingScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.7,
      ),
      itemCount: recommendations.length,
      itemBuilder: (context, index) {
        final rec = recommendations[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  slug: rec['animeId'],
                  onHistoryUpdate: widget.onHistoryUpdate,
                ),
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Image.network(
                  rec['poster'],
                  height: 140,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 140,
                    color: p.surfaceAlt,
                    alignment: Alignment.center,
                    child:
                        Icon(Icons.image_not_supported, color: p.textMuted),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6),
                child: Text(
                  rec['title'],
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 10,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildGenresList(AppPalette p, List<dynamic> genres) {
    if (genres.isEmpty) {
      return Center(
        child: Text(
          "No genres",
          style: TextStyle(
            color: p.textMuted,
            fontFamily: kFontFamily,
            fontSize: 12,
          ),
        ),
      );
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "GENRES",
            style: TextStyle(
              color: p.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: kFontFamily,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: genres.map<Widget>((genre) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AnimeGenrePage(
                        genreSlug: genre['genreId'],
                        genreName: genre['title'],
                      ),
                    ),
                  );
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: p.surfaceAlt,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: Text(
                    genre['title'],
                    style: TextStyle(
                      color: p.textPrimary,
                      fontSize: 11,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}