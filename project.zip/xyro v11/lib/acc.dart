// lib/acc.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class AccHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amber    = Color(0xFFFBBF24);
  static const purple   = Color(0xFFA78BFA);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

// ═══════════════════════════════════════════════════════════════
// CONFIG — BASE URL SERVER
// ═══════════════════════════════════════════════════════════════
class AccConfig {
  static const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';
}

// ═══════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════
class AccPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const AccPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<AccPage> createState() => _AccPageState();
}

class _AccPageState extends State<AccPage>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _pulseCtrl;
  final TextEditingController _searchCtrl = TextEditingController();

  List<Map<String, dynamic>> _pendingList = [];
  List<Map<String, dynamic>> _historyList = [];
  List<Map<String, dynamic>> _filteredPending = [];
  bool _loading = true;
  String? _error;
  String _searchQuery = '';

  Timer? _autoRefreshTimer;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _searchCtrl.addListener(() {
      setState(() {
        _searchQuery = _searchCtrl.text.toLowerCase();
        _applyFilter();
      });
    });

    _loadPending();
    _loadHistory();

    _autoRefreshTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) {
        if (mounted) {
          _loadPending();
          _loadHistory();
        }
      },
    );
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _tabController.dispose();
    _pulseCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      _filteredPending = List.from(_pendingList);
    } else {
      _filteredPending = _pendingList.where((u) {
        final name = (u['username'] ?? '').toString().toLowerCase();
        return name.contains(_searchQuery);
      }).toList();
    }
  }

  // ══════════════════════════════════════════════════════
  // LOAD PENDING
  // ══════════════════════════════════════════════════════
  Future<void> _loadPending() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/pending?key=${widget.sessionKey}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        if (!mounted) return;
        setState(() {
          _pendingList =
              List<Map<String, dynamic>>.from(data['pending'] ?? []);
          _loading = false;
        });
        _applyFilter();
      } else {
        if (!mounted) return;
        setState(() {
          _error = data['message'] ?? 'Gagal load pending';
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Koneksi error: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadHistory() async {
    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/history?key=${widget.sessionKey}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _historyList =
              List<Map<String, dynamic>>.from(data['history'] ?? []);
        });
      }
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════
  // ACC
  // ══════════════════════════════════════════════════════
  Future<void> _accUser(String username) async {
    HapticFeedback.mediumImpact();

    final ok = await _showConfirm(
      title: 'PERMIT ACCESS',
      subtitle: 'Whitelist user "$username"?',
      confirmLabel: 'PERMIT',
      confirmColor: AccHx.jade,
      icon: Icons.verified_user,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/acc'
        '?key=${widget.sessionKey}&username=$username',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('▸ ACCESS GRANTED :: $username', AccHx.jade);
        _loadPending();
        _loadHistory();
      } else {
        _snack('▸ ${data['message'] ?? 'ACCESS DENIED'}', AccHx.terra);
      }
    } catch (e) {
      _snack('▸ ERR :: $e', AccHx.terra);
    }
  }

  Future<void> _rejectUser(String username) async {
    HapticFeedback.mediumImpact();

    final ok = await _showConfirm(
      title: 'TERMINATE',
      subtitle: 'Purge user "$username" from database?',
      confirmLabel: 'PURGE',
      confirmColor: AccHx.terra,
      icon: Icons.gpp_bad,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/reject'
        '?key=${widget.sessionKey}&username=$username',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('▸ PURGED :: $username', AccHx.terra);
        _loadPending();
        _loadHistory();
      } else {
        _snack('▸ ${data['message'] ?? 'FAILED'}', AccHx.terra);
      }
    } catch (e) {
      _snack('▸ ERR :: $e', AccHx.terra);
    }
  }

  Future<bool?> _showConfirm({
    required String title,
    required String subtitle,
    required String confirmLabel,
    required Color confirmColor,
    required IconData icon,
  }) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AccHx.surfaceHi,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: confirmColor.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: confirmColor.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Icon(icon, color: confirmColor, size: 32),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  color: confirmColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AccHx.ivory,
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: Colors.white.withOpacity(0.2),
                          width: 1,
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        'ABORT',
                        style: TextStyle(
                          color: AccHx.ash,
                          fontSize: 12,
                          letterSpacing: 2,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: confirmColor.withOpacity(0.15),
                        foregroundColor: confirmColor,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(
                            color: confirmColor.withOpacity(0.5),
                            width: 1,
                          ),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        confirmLabel,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          fontFamily: 'monospace',
                          color: confirmColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: 12,
            letterSpacing: 1.2,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        backgroundColor: AccHx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: color.withOpacity(0.3),
            width: 1,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AccHx.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),
              Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildSearchBar(),
              _buildTabs(),
              Expanded(
                child: _loading
                    ? _buildLoader()
                    : _error != null
                        ? _buildError()
                        : TabBarView(
                            controller: _tabController,
                            children: [
                              _buildPendingTab(),
                              _buildHistoryTab(),
                            ],
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // HEADER
  // ══════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        color: AccHx.bg,
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          _IconBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            color: AccHx.ivory,
            onTap: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
          ),
          const SizedBox(width: 10),

          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              return Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AccHx.jade.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AccHx.jade.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.terminal,
                  color: AccHx.jade,
                  size: 20,
                ),
              );
            },
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ACCESS_CTRL',
                  style: TextStyle(
                    color: AccHx.ivory,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: AccHx.jade,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'root@pemula :: ONLINE',
                      style: TextStyle(
                        color: AccHx.ash,
                        fontSize: 10,
                        letterSpacing: 1.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          _IconBtn(
            icon: Icons.refresh,
            color: AccHx.ivory,
            onTap: () {
              HapticFeedback.selectionClick();
              _loadPending();
              _loadHistory();
            },
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // SEARCH BAR
  // ══════════════════════════════════════════════════════
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Container(
        decoration: BoxDecoration(
          color: AccHx.surfaceHi,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
        ),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(
            color: AccHx.ivory,
            fontFamily: 'monospace',
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          cursorColor: AccHx.ivory,
          decoration: InputDecoration(
            hintText: '> grep username...',
            hintStyle: const TextStyle(
              color: AccHx.ash2,
              fontFamily: 'monospace',
              fontSize: 13,
            ),
            prefixIcon: const Icon(Icons.search, color: AccHx.ash, size: 18),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.close, color: AccHx.ash, size: 16),
                    onPressed: () => _searchCtrl.clear(),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              vertical: 14,
              horizontal: 8,
            ),
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TABS
  // ══════════════════════════════════════════════════════
  Widget _buildTabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AccHx.surfaceHi,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: AccHx.ivory,
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: AccHx.bg,
        unselectedLabelColor: AccHx.ash,
        labelStyle: const TextStyle(
          fontSize: 11,
          letterSpacing: 1.5,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w900,
        ),
        unselectedLabelStyle: const TextStyle(
          fontSize: 11,
          letterSpacing: 1.5,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
        ),
        tabs: [
          Tab(
            height: 40,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.pending_actions, size: 14),
                const SizedBox(width: 6),
                Text('PENDING::${_pendingList.length}'),
              ],
            ),
          ),
          Tab(
            height: 40,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.history, size: 14),
                const SizedBox(width: 6),
                Text('LOG::${_historyList.length}'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // LOADER
  // ══════════════════════════════════════════════════════
  Widget _buildLoader() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(AccHx.ivory),
              strokeWidth: 3,
            ),
          ),
          SizedBox(height: 20),
          Text(
            '> FETCHING PAYLOADS_',
            style: TextStyle(
              color: AccHx.ivory,
              fontFamily: 'monospace',
              fontSize: 12,
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AccHx.terra.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(
                  color: AccHx.terra.withOpacity(0.4),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.warning_amber,
                color: AccHx.terra,
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '> CONNECTION_ERROR',
              style: TextStyle(
                color: AccHx.terra,
                fontFamily: 'monospace',
                fontSize: 13,
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _error ?? 'Unknown error',
              style: const TextStyle(
                color: AccHx.ash,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _loadPending,
              icon: const Icon(Icons.refresh, size: 16, color: AccHx.bg),
              label: const Text(
                'RETRY',
                style: TextStyle(
                  fontFamily: 'monospace',
                  letterSpacing: 2,
                  fontWeight: FontWeight.w900,
                  color: AccHx.bg,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AccHx.ivory,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TAB 1 — PENDING
  // ══════════════════════════════════════════════════════
  Widget _buildPendingTab() {
    if (_filteredPending.isEmpty) {
      return _emptyState(
        icon: Icons.shield_outlined,
        title: _searchQuery.isEmpty ? 'NO PENDING TARGETS' : 'NO MATCH FOUND',
        subtitle: _searchQuery.isEmpty
            ? 'Semua akun sudah diproses'
            : 'Coba keyword lain',
      );
    }

    return RefreshIndicator(
      onRefresh: _loadPending,
      color: AccHx.ivory,
      backgroundColor: AccHx.surfaceHi,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        itemCount: _filteredPending.length,
        itemBuilder: (ctx, i) => _buildPendingCard(_filteredPending[i], i),
      ),
    );
  }

  Widget _buildPendingCard(Map<String, dynamic> user, int index) {
    final username = user['username'] ?? '-';
    final role = user['role'] ?? 'member';
    final expired = user['expiredDate'] ?? '-';
    final createdBy = user['createdBy'] ?? 'unknown';
    final createdAt = user['createdAt'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AccHx.surfaceHi,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: const BoxDecoration(
                  color: AccHx.ivory,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: Center(
                  child: Text(
                    username.toString().isNotEmpty
                        ? username[0].toString().toUpperCase()
                        : '?',
                    style: const TextStyle(
                      color: AccHx.bg,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: const TextStyle(
                        color: AccHx.ivory,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        _chip(role.toString().toUpperCase(), AccHx.slate),
                        const SizedBox(width: 6),
                        _chip('PENDING', AccHx.amber),
                      ],
                    ),
                  ],
                ),
              ),

              Text(
                '#${(index + 1).toString().padLeft(2, '0')}',
                style: const TextStyle(
                  color: AccHx.ash2,
                  fontSize: 11,
                  fontFamily: 'monospace',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          _infoLine('EXP', expired, Icons.event, AccHx.amber),
          _infoLine('BY', createdBy, Icons.person_outline, AccHx.jade),
          if (createdAt.isNotEmpty)
            _infoLine(
              'AT',
              _formatDate(createdAt),
              Icons.access_time,
              AccHx.ash,
            ),

          const SizedBox(height: 14),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.06),
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: _actionBtn(
                  label: 'PURGE',
                  icon: Icons.close,
                  color: AccHx.terra,
                  onTap: () => _rejectUser(username),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _actionBtn(
                  label: 'PERMIT',
                  icon: Icons.check,
                  color: AccHx.jade,
                  onTap: () => _accUser(username),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: color.withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  Widget _infoLine(String label, String value, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        children: [
          SizedBox(
            width: 32,
            child: Text(
              label,
              style: const TextStyle(
                color: AccHx.ash2,
                fontSize: 10,
                fontFamily: 'monospace',
                letterSpacing: 1,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: AccHx.ash,
                fontSize: 11,
                fontFamily: 'monospace',
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionBtn({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: color.withOpacity(0.4),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 15),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TAB 2 — HISTORY
  // ══════════════════════════════════════════════════════
  Widget _buildHistoryTab() {
    if (_historyList.isEmpty) {
      return _emptyState(
        icon: Icons.history_toggle_off,
        title: 'NO LOGS',
        subtitle: 'Belum ada riwayat ACC/REJECT',
      );
    }

    return RefreshIndicator(
      onRefresh: _loadHistory,
      color: AccHx.ivory,
      backgroundColor: AccHx.surfaceHi,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        itemCount: _historyList.length,
        itemBuilder: (ctx, i) => _buildHistoryCard(_historyList[i], i),
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> item, int index) {
    final username = item['username'] ?? '-';
    final action = item['action'] ?? '-';
    final timestamp = item['timestamp'] ?? '';
    final isAcc = action == 'acc';
    final color = isAcc ? AccHx.jade : AccHx.terra;
    final icon = isAcc ? Icons.check_circle : Icons.cancel;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
      decoration: BoxDecoration(
        color: AccHx.surfaceHi,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(
                color: color.withOpacity(0.4),
                width: 1,
              ),
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: const TextStyle(
                    color: AccHx.ivory,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(
                      isAcc ? 'PERMITTED' : 'PURGED',
                      style: TextStyle(
                        color: color,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                    if (timestamp.isNotEmpty) ...[
                      const Text(
                        '  ::  ',
                        style: TextStyle(
                          color: AccHx.ash2,
                          fontSize: 10,
                        ),
                      ),
                      Text(
                        _formatDate(timestamp),
                        style: const TextStyle(
                          color: AccHx.ash,
                          fontSize: 10,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Text(
            '#${(index + 1).toString().padLeft(2, '0')}',
            style: const TextStyle(
              color: AccHx.ash2,
              fontSize: 10,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // EMPTY STATE
  // ══════════════════════════════════════════════════════
  Widget _emptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AccHx.surfaceHi,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 1,
              ),
            ),
            child: Icon(icon, color: AccHx.ivory, size: 40),
          ),
          const SizedBox(height: 16),
          Text(
            '> $title',
            style: const TextStyle(
              color: AccHx.ivory,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              color: AccHx.ash2,
              fontSize: 11,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}/'
          '${dt.month.toString().padLeft(2, '0')} '
          '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// COMPONENT — Icon Button
// ═══════════════════════════════════════════════════════════════
class _IconBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _IconBtn({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AccHx.surfaceHi,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      ),
    );
  }
}