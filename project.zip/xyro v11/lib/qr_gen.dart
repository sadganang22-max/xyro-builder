// lib/qr_gen.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

import 'theme.dart';

const String kFontFamily = 'Ganang';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      HapticFeedback.vibrate();
      setState(() {
        _errorMessage = "Text tidak boleh kosong.";
        _qrImage = null;
      });
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    final encodedText = Uri.encodeComponent(text);
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/text2qr?text=$encodedText");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        if (!mounted) return;
        setState(() {
          _qrImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        if (!mounted) return;
        setState(() {
          _errorMessage = "Gagal generate QR Code.";
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _shareQR() async {
    if (_qrImage == null) return;
    final p = context.theme;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
        '${tempDir.path}/qr_code_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(_qrImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'QR Code dari: ${_textController.text}',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Error sharing: $e',
            style: TextStyle(color: p.textPrimary, fontFamily: kFontFamily),
          ),
          backgroundColor: p.surfaceAlt,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "QR GENERATOR",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
              child: Column(
                children: [
                  _buildInputSection(p),
                  const SizedBox(height: 16),
                  if (_errorMessage != null) ...[
                    _buildErrorBox(p, _errorMessage!),
                    const SizedBox(height: 16),
                  ],
                  if (_qrImage != null)
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: _buildQrResult(p),
                      ),
                    )
                  else if (!_isLoading)
                    Expanded(child: _buildPlaceholder(p)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  BoxDecoration _kotakDecoration(AppPalette p, {bool withShadow = true}) {
    return BoxDecoration(
      color: p.surfaceAlt,
      border: Border.all(
        color: Colors.white.withOpacity(0.7),
        width: 1.5,
      ),
      boxShadow: withShadow
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ]
          : null,
    );
  }

  // ── INPUT ──
  Widget _buildInputSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: TextField(
              controller: _textController,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: p.textPrimary,
              onSubmitted: (_) => _generateQR(),
              decoration: InputDecoration(
                hintText: 'Contoh: https://google.com',
                hintStyle: TextStyle(
                  color: p.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                prefixIcon:
                    Icon(Icons.text_fields, color: p.textTertiary, size: 20),
                suffixIcon: _isLoading
                    ? Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: p.textPrimary,
                            strokeWidth: 2,
                          ),
                        ),
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _generateQR,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isLoading ? Icons.hourglass_top : Icons.qr_code,
                    size: 18,
                    color: p.bg,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _isLoading ? 'GENERATING...' : 'GENERATE QR',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── ERROR BOX ──
  Widget _buildErrorBox(AppPalette p, String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(color: p.danger, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: p.danger, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── QR RESULT ──
  Widget _buildQrResult(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: _kotakDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // QR Code dalam kotak putih
          Center(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Image.memory(_qrImage!, width: 220),
            ),
          ),
          const SizedBox(height: 20),

          // Info text
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle, color: p.success, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'QR Code berhasil digenerate!',
                    style: TextStyle(
                      color: p.textPrimary,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      fontFamily: kFontFamily,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // Share button
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _shareQR,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.share, size: 18, color: p.bg),
                  const SizedBox(width: 10),
                  Text(
                    'SHARE QR CODE',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── PLACEHOLDER ──
  Widget _buildPlaceholder(AppPalette p) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(
                Icons.qr_code_scanner,
                size: 48,
                color: p.textMuted,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Generate QR Code',
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 16,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Masukkan text atau URL untuk membuat QR Code',
              style: TextStyle(
                color: p.textMuted,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}