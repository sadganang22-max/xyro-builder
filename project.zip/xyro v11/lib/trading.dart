// lib/trading.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class TradingHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);

  static const jade   = Color(0xFF6EE7B7); // naik
  static const terra  = Color(0xFFFF7A9A); // turun
  static const amber  = Color(0xFFFFD58A);
  static const slate  = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);
}

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════
class Asset {
  final String symbol;
  final String name;
  final String emoji;
  final double basePrice;
  double currentPrice;
  double openPrice; // harga awal (untuk hitung % change)
  final List<double> history; // harga 60 menit terakhir

  Asset({
    required this.symbol,
    required this.name,
    required this.emoji,
    required this.basePrice,
  })  : currentPrice = basePrice,
        openPrice = basePrice,
        history = List.filled(60, basePrice);

  double get changePercent {
    if (openPrice == 0) return 0;
    return ((currentPrice - openPrice) / openPrice) * 100;
  }

  void tick(math.Random rnd) {
    // random walk: perubahan ±1.5% per tick
    final change = (rnd.nextDouble() - 0.48) * 0.015;
    currentPrice = currentPrice * (1 + change);

    // Jaga harga minimal
    if (currentPrice < 0.01) currentPrice = 0.01;

    // Simpan history
    history.add(currentPrice);
    if (history.length > 60) history.removeAt(0);
  }

  Map<String, dynamic> toJson() => {
        'symbol': symbol,
        'name': name,
        'emoji': emoji,
        'basePrice': basePrice,
        'currentPrice': currentPrice,
        'openPrice': openPrice,
        'history': history,
      };

  factory Asset.fromJson(Map<String, dynamic> j) {
    final a = Asset(
      symbol: j['symbol']?.toString() ?? '',
      name: j['name']?.toString() ?? '',
      emoji: j['emoji']?.toString() ?? '',
      basePrice: (j['basePrice'] as num?)?.toDouble() ?? 0,
    );
    a.currentPrice = (j['currentPrice'] as num?)?.toDouble() ?? a.basePrice;
    a.openPrice = (j['openPrice'] as num?)?.toDouble() ?? a.basePrice;
    final hist = (j['history'] as List?) ?? [];
    a.history.clear();
    for (final h in hist) {
      a.history.add((h as num).toDouble());
    }
    if (a.history.isEmpty) a.history.add(a.basePrice);
    return a;
  }
}

class Position {
  final String symbol;
  double quantity;
  double avgPrice;

  Position({
    required this.symbol,
    required this.quantity,
    required this.avgPrice,
  });

  Map<String, dynamic> toJson() => {
        'symbol': symbol,
        'quantity': quantity,
        'avgPrice': avgPrice,
      };

  factory Position.fromJson(Map<String, dynamic> j) => Position(
        symbol: j['symbol']?.toString() ?? '',
        quantity: (j['quantity'] as num?)?.toDouble() ?? 0,
        avgPrice: (j['avgPrice'] as num?)?.toDouble() ?? 0,
      );
}

class TradeOrder {
  final String id;
  final String symbol;
  final String type; // 'buy' | 'sell'
  final double quantity;
  final double price;
  final int timestamp;

  TradeOrder({
    required this.id,
    required this.symbol,
    required this.type,
    required this.quantity,
    required this.price,
    required this.timestamp,
  });

  double get total => quantity * price;

  Map<String, dynamic> toJson() => {
        'id': id,
        'symbol': symbol,
        'type': type,
        'quantity': quantity,
        'price': price,
        'timestamp': timestamp,
      };

  factory TradeOrder.fromJson(Map<String, dynamic> j) => TradeOrder(
        id: j['id']?.toString() ?? '',
        symbol: j['symbol']?.toString() ?? '',
        type: j['type']?.toString() ?? 'buy',
        quantity: (j['quantity'] as num?)?.toDouble() ?? 0,
        price: (j['price'] as num?)?.toDouble() ?? 0,
        timestamp: (j['timestamp'] as num?)?.toInt() ?? 0,
      );
}

// ═══════════════════════════════════════════════════════════════
// PAGE
// ═══════════════════════════════════════════════════════════════
class TradingPage extends StatefulWidget {
  const TradingPage({super.key});

  @override
  State<TradingPage> createState() => _TradingPageState();
}

class _TradingPageState extends State<TradingPage> {
  // Assets
  final List<Asset> _assets = [
    Asset(symbol: 'BTC', name: 'Bitcoin', emoji: '₿', basePrice: 67500),
    Asset(symbol: 'ETH', name: 'Ethereum', emoji: 'Ξ', basePrice: 3520),
    Asset(symbol: 'SOL', name: 'Solana', emoji: '◎', basePrice: 175),
    Asset(symbol: 'BNB', name: 'BNB', emoji: '⬡', basePrice: 595),
    Asset(symbol: 'XRP', name: 'Ripple', emoji: '✕', basePrice: 0.62),
    Asset(symbol: 'AAPL', name: 'Apple Inc.', emoji: '', basePrice: 225),
    Asset(symbol: 'TSLA', name: 'Tesla Inc.', emoji: '⚡', basePrice: 245),
    Asset(symbol: 'NVDA', name: 'NVIDIA', emoji: '', basePrice: 135),
  ];

  // Account
  double _balance = 10000.0;
  List<Position> _positions = [];
  List<TradeOrder> _orders = [];

  Timer? _tickTimer;
  final math.Random _rnd = math.Random();

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadState();
    _startTicker();
  }

  @override
  void dispose() {
    _tickTimer?.cancel();
    super.dispose();
  }

  void _startTicker() {
    _tickTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (!mounted) return;
      setState(() {
        for (final a in _assets) {
          a.tick(_rnd);
        }
      });
      _saveState();
    });
  }

  // ─── Persistence ───
  Future<void> _loadState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final balStr = prefs.getString('trading_balance');
      if (balStr != null) {
        _balance = double.tryParse(balStr) ?? 10000.0;
      }
      final posStr = prefs.getString('trading_positions');
      if (posStr != null) {
        final list = jsonDecode(posStr) as List;
        _positions = list
            .map((e) => Position.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
      final ordStr = prefs.getString('trading_orders');
      if (ordStr != null) {
        final list = jsonDecode(ordStr) as List;
        _orders = list
            .map((e) => TradeOrder.fromJson(Map<String, dynamic>.from(e)))
            .toList();
        _orders.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _saveState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('trading_balance', _balance.toString());
      await prefs.setString(
          'trading_positions', jsonEncode(_positions.map((e) => e.toJson()).toList()));
      await prefs.setString(
          'trading_orders', jsonEncode(_orders.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  // ─── Helpers ───
  Asset _getAsset(String symbol) =>
      _assets.firstWhere((a) => a.symbol == symbol);

  Position? _getPosition(String symbol) {
    try {
      return _positions.firstWhere((p) => p.symbol == symbol);
    } catch (_) {
      return null;
    }
  }

  double get _portfolioValue {
    double total = 0;
    for (final p in _positions) {
      total += p.quantity * _getAsset(p.symbol).currentPrice;
    }
    return total;
  }

  double get _totalEquity => _balance + _portfolioValue;

  double get _unrealizedPnl {
    double total = 0;
    for (final p in _positions) {
      final cur = _getAsset(p.symbol).currentPrice;
      total += (cur - p.avgPrice) * p.quantity;
    }
    return total;
  }

  String _fmt(double v) {
    if (v.abs() >= 1000) {
      return '\$${v.toStringAsFixed(2).replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
    }
    return '\$${v.toStringAsFixed(2)}';
  }

  String _fmtQty(double v) {
    if (v == v.roundToDouble()) return v.toStringAsFixed(0);
    return v.toStringAsFixed(4).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
  }

  // ─── Buy / Sell ───
  void _openTradeSheet(Asset asset) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TradeSheet(
        asset: asset,
        balance: _balance,
        position: _getPosition(asset.symbol),
        onConfirm: (type, qty) {
          if (type == 'buy') {
            _executeBuy(asset, qty);
          } else {
            _executeSell(asset, qty);
          }
        },
      ),
    );
  }

  void _executeBuy(Asset asset, double qty) {
    final cost = qty * asset.currentPrice;
    if (cost > _balance) {
      _snack('Saldo tidak cukup');
      return;
    }

    setState(() {
      _balance -= cost;

      final pos = _getPosition(asset.symbol);
      if (pos == null) {
        _positions.add(Position(
          symbol: asset.symbol,
          quantity: qty,
          avgPrice: asset.currentPrice,
        ));
      } else {
        final newQty = pos.quantity + qty;
        final newAvg =
            (pos.avgPrice * pos.quantity + asset.currentPrice * qty) / newQty;
        pos.quantity = newQty;
        pos.avgPrice = newAvg;
      }

      _orders.insert(
        0,
        TradeOrder(
          id: 'ord_${DateTime.now().microsecondsSinceEpoch}',
          symbol: asset.symbol,
          type: 'buy',
          quantity: qty,
          price: asset.currentPrice,
          timestamp: DateTime.now().millisecondsSinceEpoch,
        ),
      );
      if (_orders.length > 200) _orders.removeLast();
    });

    _saveState();
    _snack('✓ Beli ${_fmtQty(qty)} ${asset.symbol} @ ${_fmt(asset.currentPrice)}');
  }

  void _executeSell(Asset asset, double qty) {
    final pos = _getPosition(asset.symbol);
    if (pos == null || pos.quantity < qty) {
      _snack('Posisi tidak cukup');
      return;
    }

    final revenue = qty * asset.currentPrice;

    setState(() {
      _balance += revenue;
      pos.quantity -= qty;
      if (pos.quantity <= 0.0001) {
        _positions.removeWhere((p) => p.symbol == asset.symbol);
      }

      _orders.insert(
        0,
        TradeOrder(
          id: 'ord_${DateTime.now().microsecondsSinceEpoch}',
          symbol: asset.symbol,
          type: 'sell',
          quantity: qty,
          price: asset.currentPrice,
          timestamp: DateTime.now().millisecondsSinceEpoch,
        ),
      );
      if (_orders.length > 200) _orders.removeLast();
    });

    _saveState();
    _snack('✓ Jual ${_fmtQty(qty)} ${asset.symbol} @ ${_fmt(asset.currentPrice)}');
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: TradingHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
        backgroundColor: TradingHx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: TradingHx.pink.withOpacity(0.4), width: 1),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _resetDemo() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: TradingHx.surfaceHi,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: TradingHx.pink.withOpacity(0.4), width: 1),
        ),
        title: const Text(
          'Reset Demo?',
          style: TextStyle(
            color: TradingHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w900,
          ),
        ),
        content: const Text(
          'Semua saldo, posisi, dan riwayat akan dihapus. Kembali ke \$10,000.',
          style: TextStyle(
            color: TradingHx.ash,
            fontFamily: kFontFamily,
            fontSize: 12.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'BATAL',
              style: TextStyle(
                color: TradingHx.ash,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'RESET',
              style: TextStyle(
                color: TradingHx.terra,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );

    if (ok == true) {
      setState(() {
        _balance = 10000.0;
        _positions.clear();
        _orders.clear();
      });
      await _saveState();
      _snack('Demo direset ke \$10,000');
    }
  }

  // ═════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingHx.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: TradingHx.pinkLight, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Trading ♡',
          style: TextStyle(
            color: TradingHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded,
                color: TradingHx.pinkLight, size: 18),
            onPressed: _resetDemo,
            tooltip: 'Reset Demo',
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(color: TradingHx.pinkLight))
              : DefaultTabController(
                  length: 3,
                  child: Column(
                    children: [
                      _buildEquityCard(),
                      _buildTabBar(),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _buildMarketTab(),
                            _buildPortfolioTab(),
                            _buildHistoryTab(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  // ─── Equity Card ───
  Widget _buildEquityCard() {
    final pnl = _unrealizedPnl;
    final pnlColor = pnl >= 0 ? TradingHx.jade : TradingHx.terra;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [TradingHx.pinkLight, TradingHx.pinkDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: TradingHx.pink.withOpacity(0.5),
            blurRadius: 22,
            spreadRadius: 3,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'DEMO ACCOUNT',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: kFontFamily,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
              const Spacer(),
              Icon(Icons.account_balance_wallet_rounded,
                  color: Colors.white.withOpacity(0.8), size: 16),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _fmt(_totalEquity),
            style: const TextStyle(
              color: Colors.white,
              fontFamily: kFontFamily,
              fontSize: 32,
              fontWeight: FontWeight.w900,
              letterSpacing: -1,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              const Text(
                'Total Equity',
                style: TextStyle(
                  color: Colors.white70,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  '${pnl >= 0 ? '+' : ''}${_fmt(pnl)}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: kFontFamily,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _equityStat('Cash', _fmt(_balance)),
              ),
              Container(
                width: 1,
                height: 32,
                color: Colors.white.withOpacity(0.2),
              ),
              Expanded(
                child: _equityStat('Holdings', _fmt(_portfolioValue)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _equityStat(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontFamily: kFontFamily,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.2,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontFamily: kFontFamily,
            fontSize: 9,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  // ─── Tab Bar ───
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: TradingHx.surfaceHi,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: TradingHx.pink.withOpacity(0.25), width: 1),
      ),
      child: TabBar(
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [TradingHx.pinkLight, TradingHx.pinkDeep],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: TradingHx.pink.withOpacity(0.5),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: const EdgeInsets.all(3),
        labelColor: Colors.white,
        unselectedLabelColor: TradingHx.ash,
        labelStyle: const TextStyle(
          fontFamily: kFontFamily,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.6,
        ),
        unselectedLabelStyle: const TextStyle(
          fontFamily: kFontFamily,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
        ),
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'MARKET'),
          Tab(text: 'PORTFOLIO'),
          Tab(text: 'HISTORY'),
        ],
      ),
    );
  }

  // ─── Market Tab ───
  Widget _buildMarketTab() {
    // Sort by absolute change (paling naik dulu)
    final sorted = [..._assets]..sort(
        (a, b) => b.changePercent.compareTo(a.changePercent));

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      physics: const BouncingScrollPhysics(),
      children: [
        _buildMoversRow(),
        const SizedBox(height: 14),
        const Text(
          'ALL ASSETS',
          style: TextStyle(
            color: TradingHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 10,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.0,
          ),
        ),
        const SizedBox(height: 10),
        ...sorted.map(_buildAssetTile),
      ],
    );
  }

  Widget _buildMoversRow() {
    final sorted = [..._assets]
      ..sort((a, b) => b.changePercent.compareTo(a.changePercent));
    final topGainer = sorted.first;
    final topLoser = sorted.last;

    return Row(
      children: [
        Expanded(
          child: _buildMoverCard('TOP GAINER', topGainer, TradingHx.jade,
              Icons.trending_up_rounded),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildMoverCard('TOP LOSER', topLoser, TradingHx.terra,
              Icons.trending_down_rounded),
        ),
      ],
    );
  }

  Widget _buildMoverCard(
      String label, Asset asset, Color accent, IconData icon) {
    final change = asset.changePercent;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: TradingHx.surfaceHi,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.4), width: 1),
        boxShadow: [
          BoxShadow(
            color: accent.withOpacity(0.2),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: accent, size: 12),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: accent,
                  fontFamily: kFontFamily,
                  fontSize: 8.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                width: 26, height: 26,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: accent.withOpacity(0.4), width: 1),
                ),
                alignment: Alignment.center,
                child: Text(
                  asset.emoji,
                  style: TextStyle(
                    color: accent,
                    fontFamily: kFontFamily,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  asset.symbol,
                  style: const TextStyle(
                    color: TradingHx.ivory,
                    fontFamily: kFontFamily,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${change >= 0 ? '+' : ''}${change.toStringAsFixed(2)}%',
            style: TextStyle(
              color: accent,
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssetTile(Asset a) {
    final isUp = a.changePercent >= 0;
    final accent = isUp ? TradingHx.jade : TradingHx.terra;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openTradeSheet(a),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: TradingHx.surfaceHi,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: TradingHx.pink.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              // Icon emoji
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accent.withOpacity(0.25),
                      accent.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: accent.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  a.emoji.isEmpty ? a.symbol[0] : a.emoji,
                  style: TextStyle(
                    color: accent,
                    fontFamily: kFontFamily,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      a.symbol,
                      style: const TextStyle(
                        color: TradingHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      a.name,
                      style: const TextStyle(
                        color: TradingHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              // Harga + change
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _fmt(a.currentPrice),
                    style: const TextStyle(
                      color: TradingHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(
                        color: accent.withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      '${isUp ? '+' : ''}${a.changePercent.toStringAsFixed(2)}%',
                      style: TextStyle(
                        color: accent,
                        fontFamily: kFontFamily,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded,
                  color: TradingHx.pinkLight, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Portfolio Tab ───
  Widget _buildPortfolioTab() {
    if (_positions.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: TradingHx.pink.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: TradingHx.pink.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.pie_chart_rounded,
                  color: TradingHx.pinkLight,
                  size: 38,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Belum ada posisi',
                style: TextStyle(
                  color: TradingHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Beli aset di tab Market',
                style: TextStyle(
                  color: TradingHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      physics: const BouncingScrollPhysics(),
      children: _positions.map(_buildPositionTile).toList(),
    );
  }

  Widget _buildPositionTile(Position p) {
    final asset = _getAsset(p.symbol);
    final currentValue = p.quantity * asset.currentPrice;
    final costBasis = p.quantity * p.avgPrice;
    final pnl = currentValue - costBasis;
    final pnlPct = costBasis > 0 ? (pnl / costBasis) * 100 : 0;
    final isUp = pnl >= 0;
    final accent = isUp ? TradingHx.jade : TradingHx.terra;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openTradeSheet(asset),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: TradingHx.surfaceHi,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: accent.withOpacity(0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.1),
                blurRadius: 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: accent.withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      asset.emoji.isEmpty ? asset.symbol[0] : asset.emoji,
                      style: TextStyle(
                        color: accent,
                        fontFamily: kFontFamily,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          asset.symbol,
                          style: const TextStyle(
                            color: TradingHx.ivory,
                            fontFamily: kFontFamily,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${_fmtQty(p.quantity)} @ ${_fmt(p.avgPrice)}',
                          style: const TextStyle(
                            color: TradingHx.ash,
                            fontFamily: kFontFamily,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        _fmt(currentValue),
                        style: const TextStyle(
                          color: TradingHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${isUp ? '+' : ''}${_fmt(pnl)} (${pnlPct.toStringAsFixed(1)}%)',
                        style: TextStyle(
                          color: accent,
                          fontFamily: kFontFamily,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── History Tab ───
  Widget _buildHistoryTab() {
    if (_orders.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: TradingHx.pink.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: TradingHx.pink.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.receipt_long_rounded,
                  color: TradingHx.pinkLight,
                  size: 38,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Belum ada transaksi',
                style: TextStyle(
                  color: TradingHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      physics: const BouncingScrollPhysics(),
      itemCount: _orders.length,
      itemBuilder: (_, i) {
        final o = _orders[i];
        final isBuy = o.type == 'buy';
        final accent = isBuy ? TradingHx.jade : TradingHx.terra;
        final t = DateTime.fromMillisecondsSinceEpoch(o.timestamp);
        final ts = '${t.day}/${t.month}/${t.year} '
            '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: TradingHx.surfaceHi,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: TradingHx.pink.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: accent.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Icon(
                  isBuy
                      ? Icons.arrow_downward_rounded
                      : Icons.arrow_upward_rounded,
                  color: accent,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          isBuy ? 'BUY' : 'SELL',
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          o.symbol,
                          style: const TextStyle(
                            color: TradingHx.ivory,
                            fontFamily: kFontFamily,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${_fmtQty(o.quantity)} @ ${_fmt(o.price)}',
                      style: const TextStyle(
                        color: TradingHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${isBuy ? '-' : '+'}${_fmt(o.total)}',
                    style: TextStyle(
                      color: accent,
                      fontFamily: kFontFamily,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    ts,
                    style: const TextStyle(
                      color: TradingHx.ash2,
                      fontFamily: kFontFamily,
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// TRADE SHEET
// ═══════════════════════════════════════════════════════════════
class _TradeSheet extends StatefulWidget {
  final Asset asset;
  final double balance;
  final Position? position;
  final Function(String type, double qty) onConfirm;

  const _TradeSheet({
    required this.asset,
    required this.balance,
    required this.position,
    required this.onConfirm,
  });

  @override
  State<_TradeSheet> createState() => _TradeSheetState();
}

class _TradeSheetState extends State<_TradeSheet> {
  String _type = 'buy';
  final TextEditingController _qtyCtrl = TextEditingController(text: '1');

  @override
  void dispose() {
    _qtyCtrl.dispose();
    super.dispose();
  }

  double get _qty => double.tryParse(_qtyCtrl.text.trim()) ?? 0;
  double get _total => _qty * widget.asset.currentPrice;
  double get _maxBuy =>
      widget.asset.currentPrice > 0 ? widget.balance / widget.asset.currentPrice : 0;
  double get _maxSell => widget.position?.quantity ?? 0;

  void _setQtyPercent(double pct) {
    final max = _type == 'buy' ? _maxBuy : _maxSell;
    final q = max * pct;
    setState(() => _qtyCtrl.text = q.toStringAsFixed(4));
  }

  void _confirm() {
    if (_qty <= 0) {
      _snack('Quantity harus lebih dari 0');
      return;
    }
    if (_type == 'buy' && _total > widget.balance) {
      _snack('Saldo tidak cukup');
      return;
    }
    if (_type == 'sell' && _qty > _maxSell) {
      _snack('Posisi tidak cukup');
      return;
    }
    widget.onConfirm(_type, _qty);
    Navigator.pop(context);
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: TradingHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
        backgroundColor: TradingHx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: TradingHx.pink.withOpacity(0.4), width: 1),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = _type == 'buy' ? TradingHx.jade : TradingHx.terra;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        decoration: const BoxDecoration(
          color: TradingHx.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 44, height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: TradingHx.pink.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // Asset header
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [TradingHx.pinkLight, TradingHx.pinkDeep],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: TradingHx.pink.withOpacity(0.5),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    widget.asset.emoji.isEmpty
                        ? widget.asset.symbol[0]
                        : widget.asset.emoji,
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: kFontFamily,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.asset.symbol,
                        style: const TextStyle(
                          color: TradingHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.asset.name,
                        style: const TextStyle(
                          color: TradingHx.ash,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '\$${widget.asset.currentPrice.toStringAsFixed(2)}',
                      style: const TextStyle(
                        color: TradingHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${widget.asset.changePercent >= 0 ? '+' : ''}${widget.asset.changePercent.toStringAsFixed(2)}%',
                      style: TextStyle(
                        color: widget.asset.changePercent >= 0
                            ? TradingHx.jade
                            : TradingHx.terra,
                        fontFamily: kFontFamily,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Buy/Sell toggle
            Container(
              decoration: BoxDecoration(
                color: TradingHx.surfaceHi2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: TradingHx.pink.withOpacity(0.25),
                  width: 1,
                ),
              ),
              padding: const EdgeInsets.all(4),
              child: Row(
                children: [
                  _typeToggle('buy', 'BUY', TradingHx.jade),
                  _typeToggle('sell', 'SELL', TradingHx.terra),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Quantity input
            Row(
              children: [
                const Text(
                  'QUANTITY',
                  style: TextStyle(
                    color: TradingHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
                const Spacer(),
                Text(
                  _type == 'buy'
                      ? 'Max: ${_maxBuy.toStringAsFixed(4)}'
                      : 'Max: ${_maxSell.toStringAsFixed(4)}',
                  style: const TextStyle(
                    color: TradingHx.ash2,
                    fontFamily: kFontFamily,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: TradingHx.surfaceHi2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: TradingHx.pink.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: TextField(
                controller: _qtyCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: TradingHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
                cursorColor: TradingHx.pink,
                onChanged: (_) => setState(() {}),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                ],
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Percent buttons
            Row(
              children: [
                _pctBtn('25%', 0.25),
                const SizedBox(width: 6),
                _pctBtn('50%', 0.5),
                const SizedBox(width: 6),
                _pctBtn('75%', 0.75),
                const SizedBox(width: 6),
                _pctBtn('MAX', 1.0),
              ],
            ),

            const SizedBox(height: 16),

            // Total
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: TradingHx.surfaceHi2,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: accent.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  const Text(
                    'TOTAL',
                    style: TextStyle(
                      color: TradingHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '\$${_total.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: accent,
                      fontFamily: kFontFamily,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.5,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Confirm button
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _type == 'buy'
                      ? [TradingHx.jade, const Color(0xFF22C55E)]
                      : [TradingHx.terra, const Color(0xFFE84A8A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.5),
                    blurRadius: 16,
                    spreadRadius: 2,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: SizedBox(
                height: 54,
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: _confirm,
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _type == 'buy'
                                ? Icons.shopping_cart_rounded
                                : Icons.sell_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _type == 'buy'
                                ? 'BELI ${widget.asset.symbol}'
                                : 'JUAL ${widget.asset.symbol}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: kFontFamily,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _typeToggle(String type, String label, Color accent) {
    final active = _type == type;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _type = type);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            gradient: active
                ? LinearGradient(
                    colors: [accent.withOpacity(0.85), accent],
                  )
                : null,
            borderRadius: BorderRadius.circular(10),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: accent.withOpacity(0.4),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: active ? Colors.white : TradingHx.ash,
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.4,
            ),
          ),
        ),
      ),
    );
  }

  Widget _pctBtn(String label, double pct) {
    return Expanded(
      child: GestureDetector(
        onTap: () => _setQtyPercent(pct),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: TradingHx.surfaceHi,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: TradingHx.pink.withOpacity(0.25),
              width: 1,
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: const TextStyle(
              color: TradingHx.pinkLight,
              fontFamily: kFontFamily,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ),
    );
  }
}