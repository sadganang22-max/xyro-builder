// lib/spam_ngl.dart
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

const String kFontFamily = 'Ganang';

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  String statusLog = "";
  Timer? timer;

  static const Color _success = Color(0xFF4CAF50);
  static const Color _warning = Color(0xFFFFC107);

  // generate deviceId random
  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16))
        .join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        if (!mounted) return;
        setState(() {
          counter++;
          statusLog = "[$counter] Pesan terkirim";
        });
      } else {
        if (!mounted) return;
        setState(() {
          statusLog = "Ratelimit (${response.statusCode}), tunggu 5 detik...";
        });
        await Future.delayed(const Duration(seconds: 5));
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        statusLog = "Error: $e";
      });
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();

    if (username.isEmpty || message.isEmpty) {
      HapticFeedback.vibrate();
      setState(() {
        statusLog = "Harap isi username & pesan!";
      });
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      isRunning = true;
      counter = 0;
      statusLog = "Mulai mengirim...";
    });

    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (isRunning) {
        sendMessage(username, message);
      }
    });
  }

  void stopLoop() {
    HapticFeedback.mediumImpact();
    setState(() {
      isRunning = false;
      statusLog = "Dihentikan.";
    });
    timer?.cancel();
  }

  @override
  void dispose() {
    timer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "NGL SPAM",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
              child: Column(
                children: [
                  _buildInputSection(p),
                  const SizedBox(height: 16),
                  _buildControlButtons(p),
                  const SizedBox(height: 16),
                  Expanded(child: _buildStatusSection(p)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  BoxDecoration _kotakDecoration(AppPalette p, {bool withShadow = true}) {
    return BoxDecoration(
      color: p.surfaceAlt,
      border: Border.all(
        color: Colors.white.withOpacity(0.7),
        width: 1.5,
      ),
      boxShadow: withShadow
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ]
          : null,
    );
  }

  // ── INPUT ──
  Widget _buildInputSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        children: [
          _buildTextField(
            p: p,
            controller: usernameController,
            hint: 'contoh: username_ngl',
            icon: Icons.person_outline,
            isMultiline: false,
          ),
          const SizedBox(height: 12),
          _buildTextField(
            p: p,
            controller: messageController,
            hint: 'Masukkan pesan yang ingin dikirim...',
            icon: Icons.message_outlined,
            isMultiline: true,
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required AppPalette p,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required bool isMultiline,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: p.bg,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: TextField(
        controller: controller,
        style: TextStyle(
          color: p.textPrimary,
          fontSize: 14,
          fontFamily: kFontFamily,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: p.textPrimary,
        maxLines: isMultiline ? 3 : 1,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: p.textMuted,
            fontFamily: kFontFamily,
            fontSize: 13,
          ),
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          prefixIcon: Padding(
            padding: EdgeInsets.only(
              top: isMultiline ? 12 : 0,
              left: 12,
            ),
            child: Icon(icon, color: p.textTertiary, size: 20),
          ),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 44,
            minHeight: 44,
          ),
          contentPadding: const EdgeInsets.symmetric(
            vertical: 16,
            horizontal: 12,
          ),
        ),
      ),
    );
  }

  // ── CONTROL BUTTONS ──
  Widget _buildControlButtons(AppPalette p) {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: isRunning ? null : startLoop,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.play_arrow, color: p.bg, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    "START",
                    style: TextStyle(
                      color: p.bg,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      fontSize: 13,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: isRunning ? stopLoop : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.danger,
                foregroundColor: p.textPrimary,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.stop, color: p.textPrimary, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    "STOP",
                    style: TextStyle(
                      color: p.textPrimary,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      fontSize: 13,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── STATUS SECTION ──
  Widget _buildStatusSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: p.bg,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.info_outline, color: p.textPrimary, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      "STATUS LOG",
                      style: TextStyle(
                        color: p.textPrimary,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFontFamily,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              if (counter > 0)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: p.bg,
                    border: Border.all(
                      color: _success.withOpacity(0.8),
                      width: 1.5,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.send, color: _success, size: 12),
                      const SizedBox(width: 6),
                      Text(
                        "$counter",
                        style: const TextStyle(
                          color: _success,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFontFamily,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),

          // Log area
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: p.bg,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: SingleChildScrollView(
                child: Text(
                  statusLog.isEmpty ? "Menunggu perintah..." : statusLog,
                  style: TextStyle(
                    color: _getStatusColor(p, statusLog),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: kFontFamily,
                    height: 1.5,
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Info box
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: _warning.withOpacity(0.6),
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.warning_amber, color: _warning, size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    "Auto send setiap 2 detik. Stop manual jika sudah cukup.",
                    style: TextStyle(
                      color: p.textTertiary,
                      fontFamily: kFontFamily,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(AppPalette p, String status) {
    if (status.contains('terkirim')) return _success;
    if (status.contains('Error') ||
        status.contains('Ratelimit') ||
        status.contains('Harap')) {
      return p.danger;
    }
    if (status.contains('Mulai')) return _success;
    if (status.contains('Dihentikan')) return _warning;
    return p.textPrimary;
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}