// lib/theme.dart
import 'package:flutter/material.dart';

// ============================================================
// FIXED PALETTE — HITAM + PUTIH + KOTAK
// ============================================================
class AppPalette {
  final AppThemeMode mode;
  const AppPalette({this.mode = AppThemeMode.normal});

  // ── Background ──
  Color get bg => const Color(0xFF000000);
  Color get bgTop => const Color(0xFF000000);
  Color get bgBottom => const Color(0xFF000000);
  Color get surface => const Color(0xFF0A0A0A);
  Color get surfaceAlt => const Color(0xFF0D0D0D);

  // ── Border ──
  Color get border => const Color(0xFFFFFFFF);
  Color get borderStrong => const Color(0xFFFFFFFF);
  Color get neonColor => const Color(0xFFFFFFFF);
  Color get comicBorder => const Color(0xFFFFFFFF);
  Color get comicShadow => const Color(0xFF000000);

  // ── Text ──
  Color get textPrimary => const Color(0xFFFFFFFF);
  Color get textSecondary => const Color(0xFFEEEEEE);
  Color get textTertiary => const Color(0xFFBBBBBB);
  Color get textMuted => const Color(0xFF888888);

  // ── Accent ──
  Color get primary => const Color(0xFFFFFFFF);
  Color get onPrimary => const Color(0xFF000000);
  Color get success => const Color(0xFF4ADE80);
  Color get danger => const Color(0xFFF87171);
  Color get info => const Color(0xFF60A5FA);

  // ── Flags ──
  bool get kotak => true;
  bool get comic => true;
  bool get neon => true;

  // ── Card decoration ──
  BoxDecoration card({double radius = 0}) {
    return const BoxDecoration(
      color: Color(0xFF0D0D0D),
      border: Border.fromBorderSide(
        BorderSide(color: Color(0xFFFFFFFF), width: 2),
      ),
      boxShadow: [
        BoxShadow(
          color: Color(0xCC000000),
          offset: Offset(5, 5),
          blurRadius: 0,
        ),
      ],
    );
  }
}

// ============================================================
// ENUM (biar file lama yang pakai AppThemeMode.komikPaper gak error)
// ============================================================
enum AppThemeMode { normal, komikPaper, komikNeon }

// ============================================================
// CONTROLLER (stub — cuma 1 tema, tapi lengkap)
// ============================================================
class ThemeController extends ChangeNotifier {
  static final ThemeController instance = ThemeController._();
  ThemeController._();

  // Semua akses balik ke fixed palette
  AppPalette get palette => const AppPalette();
  AppThemeMode get mode => AppThemeMode.normal;

  Future<void> load() async {}
  Future<void> setMode(AppThemeMode m) async {}
}

// ============================================================
// THEMES (biar file lama yang pakai AppThemes.all[m] gak error)
// ============================================================
class AppThemes {
  static const AppPalette normal = AppPalette(mode: AppThemeMode.normal);

  static const Map<AppThemeMode, AppPalette> all = {
    AppThemeMode.normal: normal,
    AppThemeMode.komikPaper: normal,
    AppThemeMode.komikNeon: normal,
  };
}

// ============================================================
// HELPER
// ============================================================
final AppPalette palette = const AppPalette();

extension ThemeCtx on BuildContext {
  AppPalette get theme => palette;
}