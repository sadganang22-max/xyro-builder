// lib/buy.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String kFont = 'Ganang';
const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════
// PALET — OBSIDIAN & CHAMPAGNE
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg = Color(0xFF050608);
  static const surface = Color(0xFF0B0C0F);
  static const surfaceHi = Color(0xFF131418);
  static const surfaceHi2 = Color(0xFF1B1C21);

  static const goldLight = Color(0xFFF2E6C4);
  static const gold = Color(0xFFD9C082);
  static const goldMid = Color(0xFFA88E4C);
  static const goldDeep = Color(0xFF6B5928);

  static const jade = Color(0xFF8FC7A5);
  static const jadeDeep = Color(0xFF3D6B52);
  static const terra = Color(0xFFD8A090);
  static const slate = Color(0xFFA0B8D8);
  static const amethyst = Color(0xFFB8A0D0);
  static const rose = Color(0xFFD8A0B8);

  static const ivory = Color(0xFFEAE6DC);
  static const ash = Color(0xFF8A8479);
  static const ash2 = Color(0xFF565248);

  static const line = Color(0x1AD9C082);
  static const lineSoft = Color(0x10EAE6DC);
}

// ═══════════════════════════════════════════════════════════════════════
//  MODEL PAKET
// ═══════════════════════════════════════════════════════════════════════
class Paket {
  final String id;
  final String role;
  final String durasi;
  final int harga;
  final String label;

  const Paket({
    required this.id,
    required this.role,
    required this.durasi,
    required this.harga,
    required this.label,
  });
}

const List<Paket> kPaketList = [
  Paket(id: 'member_1h', role: 'member', durasi: '1 Hari', harga: 2000, label: 'Member 1h'),
  Paket(id: 'member_7h', role: 'member', durasi: '7 Hari', harga: 12000, label: 'Member 7h'),
  Paket(id: 'member_1m', role: 'member', durasi: '1 Bulan', harga: 17000, label: 'Member 1 Bulan'),
  Paket(id: 'member_perm', role: 'member', durasi: 'Permanen', harga: 30000, label: 'Member Permanen'),
  Paket(id: 'reseller_perm', role: 'reseller', durasi: 'Permanen', harga: 45000, label: 'Reseller Permanen'),
  Paket(id: 'vip_perm', role: 'vip', durasi: 'Permanen', harga: 50000, label: 'VIP Permanen'),
  Paket(id: 'admin_perm', role: 'admin', durasi: 'Permanen', harga: 65000, label: 'Admin Permanen'),
  Paket(id: 'owner_perm', role: 'owner', durasi: 'Permanen', harga: 70000, label: 'Owner Permanen'),
];

// ═══════════════════════════════════════════════════════════════════════
//  BUY PAGE
// ═══════════════════════════════════════════════════════════════════════
class BuyPage extends StatefulWidget {
  final String? sessionKey;
  final String? username;

  const BuyPage({
    super.key,
    this.sessionKey,
    this.username,
  });

  @override
  State<BuyPage> createState() => _BuyPageState();
}

class _BuyPageState extends State<BuyPage> with TickerProviderStateMixin {
  late AnimationController _ambient;
  late AnimationController _pulse;
  late AnimationController _scan;
  late AnimationController _entrance;

  @override
  void initState() {
    super.initState();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 24),
    )..repeat();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _scan = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
  }

  @override
  void dispose() {
    _ambient.dispose();
    _pulse.dispose();
    _scan.dispose();
    _entrance.dispose();
    super.dispose();
  }

  Widget _staggered({required int index, required Widget child}) {
    const int total = 12;
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Hx.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Hx.bg),

          // Ambient blobs
          AnimatedBuilder(
            animation: _ambient,
            builder: (context, _) => CustomPaint(
              painter: _AmbientPainter(progress: _ambient.value),
            ),
          ),

          // Grid
          CustomPaint(
            painter: _GridPainter(color: Hx.gold.withOpacity(0.022)),
          ),

          // Scan line
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _scan,
                builder: (context, _) => CustomPaint(
                  painter: _ScanLinePainter(progress: _scan.value),
                ),
              ),
            ),
          ),

          // Vignette
          IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.05,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.55),
                  ],
                  stops: const [0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _staggered(index: 0, child: _buildHeaderBar()),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    // ✅ padding top 20 (bukan 90) karena header ada di Column
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 40),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _staggered(index: 1, child: _buildHeroTitle()),
                        const SizedBox(height: 18),
                        _staggered(index: 2, child: _buildInfoBanner()),
                        const SizedBox(height: 22),
                        _staggered(index: 3, child: _buildSectionLabel("Paket")),
                        const SizedBox(height: 12),
                        _buildPaketGrid(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ HEADER BAR ═══
  Widget _buildHeaderBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: Hx.surfaceHi,
                border: Border.all(color: Hx.line, width: 0.8),
                borderRadius: BorderRadius.circular(13),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Hx.gold,
                size: 16,
              ),
            ),
          ),
          const Spacer(),
          const Text(
            "PURCHASE",
            style: TextStyle(
              color: Hx.gold,
              fontFamily: kFont,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 3.4,
            ),
          ),
          const Spacer(),
          Container(width: 42, height: 42),
        ],
      ),
    );
  }

  // ═══ HERO TITLE ═══
  Widget _buildHeroTitle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                return Container(
                  width: 3,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Hx.gold.withOpacity(0.6 + 0.4 * _pulse.value),
                    borderRadius: BorderRadius.circular(2),
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "PREMIUM PACKAGES",
              style: TextStyle(
                color: Hx.gold,
                fontFamily: kFont,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "Buy",
          style: TextStyle(
            color: Hx.ivory,
            fontFamily: kFont,
            fontSize: 30,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.8,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Hx.goldLight, Hx.gold, Hx.goldMid, Hx.goldDeep],
            stops: [0.0, 0.35, 0.7, 1.0],
          ).createShader(b),
          child: const Text(
            "Account",
            style: TextStyle(
              color: Colors.white,
              fontFamily: kFont,
              fontSize: 32,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.0,
              height: 1.05,
            ),
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          "Pilih paket, bayar via QRIS, akun otomatis aktif",
          style: TextStyle(
            color: Hx.ash,
            fontFamily: kFont,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  // ═══ INFO BANNER ═══
  Widget _buildInfoBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        border: Border.all(color: Hx.line, width: 0.8),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: Hx.slate.withOpacity(0.14),
              border: Border.all(
                color: Hx.slate.withOpacity(0.32),
                width: 0.7,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.info_outline_rounded,
              color: Hx.slate,
              size: 18,
            ),
          ),
          const SizedBox(width: 13),
          const Expanded(
            child: Text(
              'Pilih paket → isi username & password → scan QRIS → akun dibuat otomatis',
              style: TextStyle(
                color: Hx.ash,
                fontSize: 11,
                height: 1.5,
                fontFamily: kFont,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ SECTION LABEL ═══
  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          Container(
            width: 3, height: 12,
            decoration: BoxDecoration(
              color: Hx.gold,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            text.toUpperCase(),
            style: const TextStyle(
              color: Hx.ivory,
              fontFamily: kFont,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Container(height: 1, color: Hx.line)),
        ],
      ),
    );
  }

  // ═══ PAKET GRID ═══
  Widget _buildPaketGrid() {
    final roles = ['member', 'reseller', 'vip', 'admin', 'owner'];
    final roleLabels = {
      'member': 'MEMBER',
      'reseller': 'RESELLER',
      'vip': 'VIP',
      'admin': 'ADMIN',
      'owner': 'OWNER',
    };

    int idx = 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: roles.expand((role) {
        final pakets = kPaketList.where((p2) => p2.role == role).toList();
        if (pakets.isEmpty) return <Widget>[];

        return <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 14, 4, 10),
            child: Row(
              children: [
                Container(
                  width: 3, height: 14,
                  decoration: BoxDecoration(
                    color: _roleColor(role),
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: _roleColor(role).withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  roleLabels[role] ?? role.toUpperCase(),
                  style: const TextStyle(
                    color: Hx.ivory,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFont,
                    letterSpacing: 2.0,
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7, vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: _roleColor(role).withOpacity(0.12),
                    border: Border.all(
                      color: _roleColor(role).withOpacity(0.3),
                      width: 0.6,
                    ),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    "${pakets.length}",
                    style: TextStyle(
                      color: _roleColor(role),
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFont,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(height: 1, color: Hx.line),
                ),
              ],
            ),
          ),
          ...pakets.map((pk) {
            final widget = Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _buildPaketCard(pk),
            );
            idx++;
            return _staggered(index: 4 + idx, child: widget);
          }),
        ];
      }).toList(),
    );
  }

  Widget _buildPaketCard(Paket pk) {
    final roleColor = _roleColor(pk.role);

    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        return GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            _onPaketTap(pk);
          },
          child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  roleColor.withOpacity(0.06),
                  Hx.surfaceHi,
                ],
              ),
              border: Border.all(
                color: roleColor.withOpacity(0.22 + 0.08 * _pulse.value),
                width: 0.8,
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: roleColor.withOpacity(0.06 + 0.06 * _pulse.value),
                  blurRadius: 20,
                  spreadRadius: -6,
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    color: roleColor.withOpacity(0.15),
                    border: Border.all(
                      color: roleColor.withOpacity(0.4),
                      width: 0.7,
                    ),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    _roleIcon(pk.role),
                    color: roleColor,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        pk.label,
                        style: const TextStyle(
                          color: Hx.ivory,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                          fontFamily: kFont,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        pk.durasi,
                        style: const TextStyle(
                          color: Hx.ash,
                          fontSize: 10.5,
                          fontFamily: kFont,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Rp${_formatHarga(pk.harga)}',
                      style: TextStyle(
                        color: roleColor,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFont,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: roleColor.withOpacity(0.14),
                        border: Border.all(
                          color: roleColor.withOpacity(0.35),
                          width: 0.6,
                        ),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.arrow_forward_rounded,
                            color: roleColor,
                            size: 11,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            'BELI',
                            style: TextStyle(
                              color: roleColor,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              fontFamily: kFont,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Color _roleColor(String role) {
    switch (role) {
      case 'owner':
        return Hx.gold;
      case 'admin':
        return Hx.terra;
      case 'vip':
        return Hx.jade;
      case 'reseller':
        return Hx.slate;
      default:
        return Hx.amethyst;
    }
  }

  IconData _roleIcon(String role) {
    switch (role) {
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'vip':
        return Icons.star_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      default:
        return Icons.person_rounded;
    }
  }

  String _formatHarga(int harga) {
    if (harga >= 1000) {
      final k = harga / 1000;
      return k == k.toInt() ? '${k.toInt()}k' : '${k.toStringAsFixed(1)}k';
    }
    return '$harga';
  }

  void _onPaketTap(Paket pk) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _BuyFlowSheet(
        paket: pk,
        sessionKey: widget.sessionKey,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  BUY FLOW SHEET
// ═══════════════════════════════════════════════════════════════════════
class _BuyFlowSheet extends StatefulWidget {
  final Paket paket;
  final String? sessionKey;

  const _BuyFlowSheet({
    required this.paket,
    this.sessionKey,
  });

  @override
  State<_BuyFlowSheet> createState() => _BuyFlowSheetState();
}

class _BuyFlowSheetState extends State<_BuyFlowSheet>
    with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  int _step = 0;

  String? _depositId;
  String? _qrUrl;
  int _totalPayment = 0;
  int _expiredAt = 0;

  bool _loading = false;
  Timer? _pollTimer;

  late AnimationController _pulse;
  late AnimationController _shimmer;
  late AnimationController _orbit;

  String get _session => widget.sessionKey ?? 'guest';

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _shimmer = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _orbit = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _shimmer.dispose();
    _orbit.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _submitForm() async {
    final user = _userCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    if (user.isEmpty || pass.isEmpty) {
      _toast('Username & password wajib diisi', Hx.gold);
      return;
    }
    if (user.length < 3 || pass.length < 4) {
      _toast('Username min 3, password min 4', Hx.gold);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/buy/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': _session,
          'paketId': widget.paket.id,
          'username': user,
          'password': pass,
        }),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (data['success'] != true) {
        _toast(data['message'] ?? 'Gagal membuat invoice', Hx.terra);
        if (mounted) setState(() => _loading = false);
        return;
      }

      setState(() {
        _depositId = data['depositId'];
        _qrUrl = data['qrUrl'];
        _totalPayment = data['totalPayment'] ?? widget.paket.harga;
        _expiredAt = data['expiredAt'] ?? 0;
        _step = 1;
        _loading = false;
      });

      _startPolling();
    } catch (e) {
      _toast('Error: $e', Hx.terra);
      if (mounted) setState(() => _loading = false);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted) return;
      if (_depositId == null) return;

      try {
        final res = await http.post(
          Uri.parse('$baseUrl/buy/status'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': _session,
            'depositId': _depositId,
          }),
        ).timeout(const Duration(seconds: 15));

        final data = jsonDecode(res.body);
        final status = data['status'];

        if (status == 'success') {
          _pollTimer?.cancel();
          HapticFeedback.heavyImpact();
          if (mounted) setState(() => _step = 2);
        } else if (status == 'expired') {
          _pollTimer?.cancel();
          if (mounted) {
            _toast('Invoice expired', Hx.terra);
            Navigator.pop(context);
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _cancelInvoice() async {
    HapticFeedback.selectionClick();
    _pollTimer?.cancel();
    if (_depositId != null) {
      try {
        await http.post(
          Uri.parse('$baseUrl/buy/cancel'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': _session,
            'depositId': _depositId,
          }),
        ).timeout(const Duration(seconds: 10));
      } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        msg,
        style: const TextStyle(
          color: Color(0xFF0A0A0A),
          fontWeight: FontWeight.w900,
          fontFamily: kFont,
          fontSize: 13,
        ),
      ),
      backgroundColor: color.withOpacity(0.95),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Hx.line, width: 0.8),
      ),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Hx.surfaceHi2, Hx.surface],
        ),
        border: Border.all(color: Hx.line, width: 0.9),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 40,
            offset: const Offset(0, 16),
          ),
          BoxShadow(
            color: Hx.gold.withOpacity(0.10),
            blurRadius: 50,
            spreadRadius: -8,
          ),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44, height: 4,
              decoration: BoxDecoration(
                color: Hx.ash2,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            _buildStepIndicator(),
            const SizedBox(height: 20),
            if (_step == 0) _buildFormStep(),
            if (_step == 1) _buildQrisStep(),
            if (_step == 2) _buildSuccessStep(),
          ],
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    final steps = ['Isi', 'Bayar', 'Selesai'];
    return Row(
      children: List.generate(steps.length, (i) {
        final active = i <= _step;
        final current = i == _step;
        return Expanded(
          child: Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: active ? Hx.gold : Hx.surfaceHi,
                  border: Border.all(
                    color: active ? Hx.gold : Hx.line,
                    width: 0.8,
                  ),
                  borderRadius: BorderRadius.circular(9),
                  boxShadow: active
                      ? [
                          BoxShadow(
                            color: Hx.gold.withOpacity(0.35),
                            blurRadius: 14,
                            spreadRadius: -2,
                          ),
                        ]
                      : null,
                ),
                alignment: Alignment.center,
                child: current && _loading
                    ? const SizedBox(
                        width: 12, height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFF1A1408),
                        ),
                      )
                    : Text(
                        '${i + 1}',
                        style: TextStyle(
                          color: active ? const Color(0xFF1A1408) : Hx.ash,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFont,
                        ),
                      ),
              ),
              const SizedBox(width: 6),
              Text(
                steps[i].toUpperCase(),
                style: TextStyle(
                  color: active ? Hx.gold : Hx.ash2,
                  fontSize: 8.5,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                  letterSpacing: 1.2,
                ),
              ),
              if (i < steps.length - 1)
                Expanded(
                  child: Container(
                    height: 1,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    color: i < _step ? Hx.gold : Hx.line,
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }

  // STEP 0: FORM
  Widget _buildFormStep() {
    final pk = widget.paket;
    final roleColor = _roleColor(pk.role);

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                roleColor.withOpacity(0.10),
                Hx.surfaceHi,
              ],
            ),
            border: Border.all(
              color: roleColor.withOpacity(0.35),
              width: 0.8,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: roleColor.withOpacity(0.15),
                  border: Border.all(
                    color: roleColor.withOpacity(0.4),
                    width: 0.6,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  _roleIcon(pk.role),
                  color: roleColor,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pk.label,
                      style: const TextStyle(
                        color: Hx.ivory,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFont,
                        letterSpacing: 0.2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      pk.durasi,
                      style: const TextStyle(
                        color: Hx.ash,
                        fontSize: 10.5,
                        fontFamily: kFont,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                'Rp${pk.harga}',
                style: TextStyle(
                  color: roleColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                  letterSpacing: -0.3,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        _buildTextField(
          controller: _userCtrl,
          label: 'Username Baru',
          hint: 'contoh: Iwaktempej',
          icon: Icons.person_outline_rounded,
          accent: Hx.gold,
        ),
        const SizedBox(height: 14),
        _buildTextField(
          controller: _passCtrl,
          label: 'Password Baru',
          hint: 'contoh: xxxxbro',
          icon: Icons.lock_outline_rounded,
          accent: Hx.gold,
          obscure: true,
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Hx.gold.withOpacity(0.08),
            border: Border.all(
              color: Hx.gold.withOpacity(0.3),
              width: 0.7,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.warning_amber_rounded,
                color: Hx.gold,
                size: 15,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Catat username & password! Tidak bisa diubah nanti.',
                  style: TextStyle(
                    color: Hx.gold.withOpacity(0.9),
                    fontSize: 10.5,
                    fontFamily: kFont,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        _submitButton(
          label: 'BUAT INVOICE',
          icon: Icons.receipt_long_rounded,
          accent: Hx.gold,
          onTap: _loading ? null : _submitForm,
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    required Color accent,
    bool obscure = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: Hx.ash,
              fontFamily: kFont,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Hx.bg.withOpacity(0.5),
            border: Border.all(color: Hx.line, width: 0.8),
            borderRadius: BorderRadius.circular(14),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            style: const TextStyle(
              color: Hx.ivory,
              fontSize: 14,
              fontFamily: kFont,
              fontWeight: FontWeight.w600,
            ),
            cursorColor: accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: Hx.ash2,
                fontSize: 13,
                fontFamily: kFont,
                fontWeight: FontWeight.w500,
              ),
              prefixIcon: Icon(icon, color: accent, size: 17),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 16,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // STEP 1: QRIS
  Widget _buildQrisStep() {
    final sisaWaktu = _expiredAt > 0
        ? ((_expiredAt - DateTime.now().millisecondsSinceEpoch) / 1000)
            .clamp(0, 3600)
            .toInt()
        : 0;

    return Column(
      children: [
        const Text(
          'SCAN QRIS UNTUK BAYAR',
          style: TextStyle(
            color: Hx.ivory,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            fontFamily: kFont,
            letterSpacing: 2.0,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Bayar sesuai nominal, status terdeteksi otomatis',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Hx.ash,
            fontSize: 11,
            fontFamily: kFont,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 18),
        // QR code dengan gold border glow
        AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) {
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: Hx.gold.withOpacity(0.5 + 0.3 * _pulse.value),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Hx.gold.withOpacity(0.25 + 0.15 * _pulse.value),
                    blurRadius: 30,
                    spreadRadius: -4,
                  ),
                ],
              ),
              child: _qrUrl != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(
                        _qrUrl!,
                        width: 210, height: 210,
                        fit: BoxFit.contain,
                        loadingBuilder: (_, child, pr) => pr == null
                            ? child
                            : const SizedBox(
                                width: 210, height: 210,
                                child: Center(
                                  child: CircularProgressIndicator(
                                    color: Hx.gold,
                                  ),
                                ),
                              ),
                        errorBuilder: (_, __, ___) => const SizedBox(
                          width: 210, height: 210,
                          child: Center(
                            child: Icon(
                              Icons.broken_image,
                              size: 60,
                              color: Hx.ash2,
                            ),
                          ),
                        ),
                      ),
                    )
                  : const SizedBox(
                      width: 210, height: 210,
                      child: Center(
                        child: CircularProgressIndicator(color: Hx.gold),
                      ),
                    ),
            );
          },
        ),
        const SizedBox(height: 18),
        // Total payment
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Hx.gold.withOpacity(0.10),
                Hx.surfaceHi,
              ],
            ),
            border: Border.all(
              color: Hx.gold.withOpacity(0.35),
              width: 0.8,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              const Text(
                'TOTAL BAYAR',
                style: TextStyle(
                  color: Hx.ash,
                  fontSize: 9.5,
                  fontFamily: kFont,
                  letterSpacing: 2.0,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Rp$_totalPayment',
                style: const TextStyle(
                  color: Hx.gold,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                  letterSpacing: -0.8,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Waiting indicator
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 14, height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Hx.jade,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Menunggu pembayaran...',
              style: TextStyle(
                color: Hx.ash,
                fontSize: 12,
                fontFamily: kFont,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        if (sisaWaktu > 0)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Kedaluwarsa dalam ${sisaWaktu}s',
              style: const TextStyle(
                color: Hx.ash2,
                fontSize: 10,
                fontFamily: kFont,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        const SizedBox(height: 18),
        // Cancel button
        GestureDetector(
          onTap: _cancelInvoice,
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: Hx.terra.withOpacity(0.10),
              border: Border.all(
                color: Hx.terra.withOpacity(0.4),
                width: 0.8,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            alignment: Alignment.center,
            child: const Text(
              'BATAL',
              style: TextStyle(
                color: Hx.terra,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: kFont,
                letterSpacing: 2.0,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // STEP 2: SUKSES
  Widget _buildSuccessStep() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _orbit,
          builder: (_, __) {
            return SizedBox(
              width: 120, height: 120,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Rotating orbit dots
                  Transform.rotate(
                    angle: _orbit.value * 2 * math.pi,
                    child: CustomPaint(
                      size: const Size(120, 120),
                      painter: _OrbitPainter(),
                    ),
                  ),
                  // Breath halo
                  AnimatedBuilder(
                    animation: _pulse,
                    builder: (_, __) {
                      final s = 1 + 0.10 * _pulse.value;
                      return Transform.scale(
                        scale: s,
                        child: Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Hx.jade.withOpacity(
                                0.35 - 0.25 * _pulse.value,
                              ),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Hx.jade.withOpacity(
                                  0.28 - 0.20 * _pulse.value,
                                ),
                                blurRadius: 40 * _pulse.value,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  // Center check
                  Container(
                    width: 68, height: 68,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(
                        colors: [
                          Color(0xFFB5E0C4),
                          Hx.jade,
                          Hx.jadeDeep,
                          Color(0xFF1F4A34),
                        ],
                        stops: [0.0, 0.4, 0.75, 1.0],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Hx.jade.withOpacity(0.55),
                          blurRadius: 40,
                          spreadRadius: 2,
                        ),
                        const BoxShadow(
                          color: Color(0xBBFFFFFF),
                          blurRadius: 2,
                          offset: Offset(0, -2),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.check_rounded,
                        color: Color(0xFF0A1F15),
                        size: 36,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        const Text(
          'PEMBAYARAN SUKSES',
          style: TextStyle(
            color: Hx.ivory,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            fontFamily: kFont,
            letterSpacing: 2.4,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Akun sudah otomatis dibuat',
          style: TextStyle(
            color: Hx.ash,
            fontSize: 12,
            fontFamily: kFont,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 22),
        // Info card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Hx.bg.withOpacity(0.5),
            border: Border.all(color: Hx.line, width: 0.8),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              _infoRow(Icons.person_rounded, 'Username',
                  _userCtrl.text.trim()),
              const SizedBox(height: 8),
              _infoRow(Icons.lock_rounded, 'Password',
                  _passCtrl.text.trim()),
              const SizedBox(height: 8),
              _infoRow(
                Icons.workspace_premium_rounded,
                'Paket',
                widget.paket.label,
              ),
              const SizedBox(height: 8),
              _infoRow(Icons.timer_rounded, 'Durasi', widget.paket.durasi),
            ],
          ),
        ),
        const SizedBox(height: 20),
        // Copy button
        GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            Clipboard.setData(ClipboardData(
              text: 'User: ${_userCtrl.text.trim()}\n'
                  'Pass: ${_passCtrl.text.trim()}\n'
                  'Paket: ${widget.paket.label}',
            ));
            _toast('Disalin ke clipboard ✅', Hx.jade);
          },
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: Hx.slate.withOpacity(0.10),
              border: Border.all(
                color: Hx.slate.withOpacity(0.4),
                width: 0.8,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.copy_rounded, color: Hx.slate, size: 16),
                SizedBox(width: 8),
                Text(
                  'SALIN AKUN',
                  style: TextStyle(
                    color: Hx.slate,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFont,
                    letterSpacing: 1.8,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // Done button (dengan shimmer)
        AnimatedBuilder(
          animation: _shimmer,
          builder: (context, _) {
            return Container(
              height: 52,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Hx.jade, Hx.jadeDeep],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Hx.jade.withOpacity(0.35),
                    blurRadius: 22,
                    spreadRadius: -4,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Transform.translate(
                        offset: Offset(
                          -260 + (_shimmer.value * 720),
                          0,
                        ),
                        child: Transform.rotate(
                          angle: -0.35,
                          child: Container(
                            width: 72,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  Colors.white.withOpacity(0.55),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(15),
                      onTap: () {
                        HapticFeedback.selectionClick();
                        Navigator.pop(context);
                      },
                      child: const Center(
                        child: Text(
                          'SELESAI',
                          style: TextStyle(
                            color: Color(0xFF0A1F15),
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: kFont,
                            letterSpacing: 2.4,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: Hx.ash, size: 15),
        const SizedBox(width: 10),
        Text(
          label,
          style: const TextStyle(
            color: Hx.ash,
            fontSize: 11.5,
            fontFamily: kFont,
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
            color: Hx.ivory,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: kFont,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  Color _roleColor(String role) {
    switch (role) {
      case 'owner':
        return Hx.gold;
      case 'admin':
        return Hx.terra;
      case 'vip':
        return Hx.jade;
      case 'reseller':
        return Hx.slate;
      default:
        return Hx.amethyst;
    }
  }

  IconData _roleIcon(String role) {
    switch (role) {
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'vip':
        return Icons.star_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      default:
        return Icons.person_rounded;
    }
  }

  // ═══ SUBMIT BUTTON ═══
  Widget _submitButton({
    required String label,
    required IconData icon,
    required Color accent,
    required VoidCallback? onTap,
  }) {
    return AnimatedBuilder(
      animation: _shimmer,
      builder: (context, _) {
        return Container(
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                accent.withOpacity(0.9),
                accent,
                accent.withOpacity(0.75),
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.35),
                blurRadius: 22,
                spreadRadius: -4,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Stack(
            children: [
              if (onTap != null)
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Transform.translate(
                      offset: Offset(
                        -260 + (_shimmer.value * 720),
                        0,
                      ),
                      child: Transform.rotate(
                        angle: -0.35,
                        child: Container(
                          width: 72,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.white.withOpacity(0.55),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: onTap,
                  child: Center(
                    child: _loading
                        ? const SizedBox(
                            width: 22, height: 22,
                            child: CircularProgressIndicator(
                              color: Color(0xFF1A1408),
                              strokeWidth: 2.5,
                            ),
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(icon,
                                  color: const Color(0xFF1A1408),
                                  size: 18),
                              const SizedBox(width: 10),
                              Text(
                                label,
                                style: const TextStyle(
                                  color: Color(0xFF1A1408),
                                  fontFamily: kFont,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2.2,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// AMBIENT PAINTER
// ═══════════════════════════════════════════════════════════════
class _AmbientPainter extends CustomPainter {
  final double progress;
  _AmbientPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 130);

    paint.color = Hx.gold.withOpacity(0.11);
    canvas.drawCircle(
      Offset(
        size.width * (0.18 + 0.06 * math.sin(t * 0.7)),
        size.height * (0.10 + 0.05 * math.cos(t * 0.5)),
      ),
      size.width * 0.58,
      paint,
    );

    paint.color = Hx.goldDeep.withOpacity(0.14);
    canvas.drawCircle(
      Offset(
        size.width * (0.90 + 0.05 * math.cos(t * 0.6)),
        size.height * (0.85 + 0.05 * math.sin(t * 0.4)),
      ),
      size.width * 0.60,
      paint,
    );

    paint.color = Hx.jadeDeep.withOpacity(0.08);
    canvas.drawCircle(
      Offset(
        size.width * (0.55 + 0.08 * math.sin(t * 0.3)),
        size.height * (0.45 + 0.06 * math.cos(t * 0.8)),
      ),
      size.width * 0.50,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AmbientPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// SCAN LINE PAINTER
// ═══════════════════════════════════════════════════════════════
class _ScanLinePainter extends CustomPainter {
  final double progress;
  _ScanLinePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final y = size.height * progress;
    const h = 200.0;

    final rect = Rect.fromLTWH(0, y - h / 2, size.width, h);

    final gradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.transparent,
        Hx.gold.withOpacity(0.00),
        Hx.gold.withOpacity(0.14),
        Hx.gold.withOpacity(0.00),
        Colors.transparent,
      ],
      stops: const [0.0, 0.35, 0.5, 0.65, 1.0],
    );

    final paint = Paint()
      ..shader = gradient.createShader(rect)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);

    canvas.drawRect(rect, paint);

    final linePaint = Paint()
      ..color = Hx.goldLight.withOpacity(0.28)
      ..strokeWidth = 1
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
  }

  @override
  bool shouldRepaint(covariant _ScanLinePainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// ORBIT PAINTER
// ═══════════════════════════════════════════════════════════════
class _OrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    for (int i = 0; i < 10; i++) {
      final angle = (i / 10) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final opacity = 0.15 + 0.75 * ((i / 10 + 0.5) % 1.0);

      final dotPaint = Paint()
        ..color = Hx.jade.withOpacity(opacity)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);

      canvas.drawCircle(Offset(x, y), i == 0 ? 3 : 1.8, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _OrbitPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}