// lib/pilih_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'home_page.dart' as home;
import 'group_page.dart';
import 'banned.dart';
import 'cek_band_page.dart'; 
import 'spam_otp_page.dart'; // ✅ IMPORT SPAM OTP PAGE

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class PilihHx {
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);
  static const surfaceHi  = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  static const gold      = Color(0xFFFFFFFF);
  static const goldLight = Color(0xFFE0E0E0);
  static const goldDeep  = Color(0xFF808080);

  static const jade   = Color(0xFF4ADE80);
  static const slate  = Color(0xFF60A5FA);
  static const amber  = Color(0xFFFBBF24);
  static const purple = Color(0xFFA78BFA);
  static const terra  = Color(0xFFF87171);

  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
}

class PilihPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const PilihPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<PilihPage> createState() => _PilihPageState();
}

class _PilihPageState extends State<PilihPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _initVideo();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0); // ✅ SUARA NYALA
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();

      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoReady = true;
      });
    } catch (e) {
      debugPrint('Video error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // NAVIGASI
  // ═══════════════════════════════════════════════════════════
  void _goToNumberBug() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => home.HomePage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
    );
  }

  void _goToGroupBug() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroupPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
    );
  }

  void _goToBanned() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BannedPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
    );
  }

  void _goToCekBanned() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CekBandPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
    );
  }

  // ✅ NAVIGASI KE SPAM OTP
  void _goToSpamOtp() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SpamOtpPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EFEK HUD & SCANLINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 14, double thickness = 1.5}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 10, left: 10, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 10, right: 10, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 10, left: 10, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 10, right: 10, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: size, height: thickness, color: PilihHx.ivory.withOpacity(0.6)),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: thickness, height: size, color: PilihHx.ivory.withOpacity(0.6)),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.15,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.white.withOpacity(0.4), Colors.transparent],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BANNER VIDEO
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(
                color: PilihHx.surfaceHi2,
                child: const Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: PilihHx.ivory,
                      strokeWidth: 2.0,
                    ),
                  ),
                ),
              ),

            IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      PilihHx.bg.withOpacity(0.25),
                      PilihHx.bg.withOpacity(0.65),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // ✅ EFEK HUD & SCANLINE
            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: PilihHx.ivory,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'PREMIUM',
                  style: TextStyle(
                    color: PilihHx.bg,
                    fontSize: 9,
                    fontFamily: 'Ganang',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
            ),

            Positioned(
              left: 18,
              right: 18,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BUG ATTACK',
                    style: TextStyle(
                      color: PilihHx.ivory,
                      fontFamily: 'Ganang',
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Pilih mode pengiriman',
                    style: TextStyle(
                      color: PilihHx.ivory.withOpacity(0.65),
                      fontFamily: 'Ganang',
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CARD PILIHAN
  // ═══════════════════════════════════════════════════════════
  Widget _buildChoiceCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required String badge,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PilihHx.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 14,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  border: Border.all(
                    color: accent.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icon, color: accent, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            title,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: PilihHx.ivory,
                              fontFamily: 'Ganang',
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.4,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: accent.withOpacity(0.15),
                            border: Border.all(
                              color: accent.withOpacity(0.4),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            badge,
                            style: TextStyle(
                              color: accent,
                              fontFamily: 'Ganang',
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: PilihHx.ash,
                        fontFamily: 'Ganang',
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: PilihHx.ash.withOpacity(0.6),
                size: 13,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStaggeredEntry({required int index, required Widget child}) {
    const int total = 8; // Disesuaikan karena ada 5 menu
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF000000),
            Color(0xFF0A0A0A),
          ],
        ),
      ),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildStaggeredEntry(
              index: 0,
              child: _buildVideoBanner(),
            ),
            const SizedBox(height: 28),

            _buildStaggeredEntry(
              index: 1,
              child: Row(
                children: [
                  Container(
                    width: 3,
                    height: 12,
                    color: PilihHx.ivory,
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'PILIH MODE',
                    style: TextStyle(
                      color: PilihHx.ivory,
                      fontFamily: 'Ganang',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.4,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 1,
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // CARD 1 — NUMBER BUG
            _buildStaggeredEntry(
              index: 2,
              child: _buildChoiceCard(
                icon: Icons.phone_android_rounded,
                title: 'NUMBER BUG',
                subtitle: 'Kirim bug ke nomor WhatsApp dengan format internasional.',
                badge: 'PRIVATE',
                accent: PilihHx.ivory,
                onTap: _goToNumberBug,
              ),
            ),
            const SizedBox(height: 14),

            // CARD 2 — GROUP BUG
            _buildStaggeredEntry(
              index: 3,
              child: _buildChoiceCard(
                icon: Icons.group_rounded,
                title: 'GROUP BUG',
                subtitle: 'Kirim bug ke grup WhatsApp menggunakan link invite.',
                badge: 'GROUP',
                accent: PilihHx.jade,
                onTap: _goToGroupBug,
              ),
            ),
            const SizedBox(height: 14),

            // CARD 3 — BANNED GB
            _buildStaggeredEntry(
              index: 4,
              child: _buildChoiceCard(
                icon: Icons.gavel_rounded,
                title: 'BANNED GB',
                subtitle: 'Kirim payload banned ke grup WhatsApp via link invite.',
                badge: 'BANNED',
                accent: PilihHx.terra,
                onTap: _goToBanned,
              ),
            ),
            const SizedBox(height: 14),

            // CARD 4 — CEK BANNED
            _buildStaggeredEntry(
              index: 5,
              child: _buildChoiceCard(
                icon: Icons.fact_check_rounded,
                title: 'CEK BANNED',
                subtitle: 'Cek status nomor WhatsApp apakah terkena banned / pembatasan.',
                badge: 'CHECKER',
                accent: PilihHx.slate,
                onTap: _goToCekBanned,
              ),
            ),
            const SizedBox(height: 14),

            // ✅ CARD 5 — SPAM OTP
            _buildStaggeredEntry(
              index: 6,
              child: _buildChoiceCard(
                icon: Icons.message_rounded,
                title: 'SPAM OTP',
                subtitle: 'Bombardir kode OTP WhatsApp ke nomor target.',
                badge: 'WA ONLY',
                accent: PilihHx.amber,
                onTap: _goToSpamOtp,
              ),
            ),

            const SizedBox(height: 24),

            // Info box
            _buildStaggeredEntry(
              index: 7,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: PilihHx.surfaceHi,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: PilihHx.ash,
                      size: 18,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Pilih salah satu mode untuk mulai mengirim bug attack, mengecek banned, atau spam OTP.',
                        style: TextStyle(
                          color: PilihHx.ash.withOpacity(0.9),
                          fontFamily: 'Ganang',
                          fontSize: 11.5,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}