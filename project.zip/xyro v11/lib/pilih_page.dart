// lib/pilih_page.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'home_page.dart' as home;
import 'group_page.dart';
import 'banned.dart';
import 'cek_band_page.dart';
import 'spam_otp_page.dart';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class PilihHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);
  static const surfaceHi  = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  static const jade   = Color(0xFF6EE7B7);
  static const slate  = Color(0xFF93C5FD);
  static const amber  = Color(0xFFFFD58A);
  static const purple = Color(0xFFC4A5FF);
  static const terra  = Color(0xFFFF7A9A);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFFFFFF);
}

// ═══════════════════════════════════════════════════════════════
// LAYOUT MODE ENUM
// ═══════════════════════════════════════════════════════════════
enum PilihLayoutMode { normal, orbit, horizontal }

class PilihPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const PilihPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<PilihPage> createState() => _PilihPageState();
}

class _PilihPageState extends State<PilihPage>
    with TickerProviderStateMixin {
  late AnimationController _entranceController;
  late AnimationController _orbitController;

  VideoPlayerController? _videoController;
  bool _videoReady = false;

  PilihLayoutMode _layoutMode = PilihLayoutMode.normal;

  // ── DATA MENU ──
  final List<_MenuData> _menus = [
    _MenuData(
      icon: Icons.phone_iphone_rounded,
      title: 'NUMBER BUG',
      subtitle: 'Kirim bug ke nomor WhatsApp dengan format internasional.',
      badge: 'PRIVATE',
      accent: PilihHx.pinkLight,
      target: _Target.numberBug,
    ),
    _MenuData(
      icon: Icons.groups_rounded,
      title: 'GROUP BUG',
      subtitle: 'Kirim bug ke grup WhatsApp menggunakan link invite.',
      badge: 'GROUP',
      accent: PilihHx.jade,
      target: _Target.groupBug,
    ),
    _MenuData(
      icon: Icons.gavel_rounded,
      title: 'BANNED GB',
      subtitle: 'Kirim payload banned ke grup WhatsApp via link invite.',
      badge: 'BANNED',
      accent: PilihHx.terra,
      target: _Target.banned,
    ),
    _MenuData(
      icon: Icons.fact_check_rounded,
      title: 'CEK BANNED',
      subtitle: 'Cek status nomor WhatsApp apakah terkena banned / pembatasan.',
      badge: 'CHECKER',
      accent: PilihHx.slate,
      target: _Target.cekBand,
    ),
    _MenuData(
      icon: Icons.sms_rounded,
      title: 'SPAM OTP',
      subtitle: 'Bombardir kode OTP WhatsApp ke nomor target.',
      badge: 'WA ONLY',
      accent: PilihHx.amber,
      target: _Target.spamOtp,
    ),
  ];

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    )..repeat();

    _initVideo();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _orbitController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0);
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();

      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoReady = true;
      });
    } catch (e) {
      debugPrint('Video error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // NAVIGASI
  // ═══════════════════════════════════════════════════════════
  void _handleMenuTap(_Target target) {
    HapticFeedback.mediumImpact();
    switch (target) {
      case _Target.numberBug:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => home.HomePage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case _Target.groupBug:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GroupPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case _Target.banned:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BannedPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case _Target.cekBand:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CekBandPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
              role: widget.role,
            ),
          ),
        );
        break;
      case _Target.spamOtp:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SpamOtpPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
              role: widget.role,
            ),
          ),
        );
        break;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // HUD & SCANLINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 14, double thickness = 1.5}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 10, left: 10, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 10, right: 10, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 10, left: 10, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 10, right: 10, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(
              width: size, height: thickness,
              decoration: BoxDecoration(
                color: PilihHx.pinkLight.withOpacity(0.9),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: PilihHx.pink.withOpacity(0.6), blurRadius: 4),
                ],
              ),
            ),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(
              width: thickness, height: size,
              decoration: BoxDecoration(
                color: PilihHx.pinkLight.withOpacity(0.9),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: PilihHx.pink.withOpacity(0.6), blurRadius: 4),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.18,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  PilihHx.pinkSoft.withOpacity(0.5),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BANNER VIDEO
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: PilihHx.pink.withOpacity(0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: PilihHx.pink.withOpacity(0.2),
            blurRadius: 24,
            spreadRadius: 1,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(
                color: PilihHx.surfaceHi2,
                child: const Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: PilihHx.pinkLight,
                      strokeWidth: 2.0,
                    ),
                  ),
                ),
              ),

            IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      PilihHx.bg.withOpacity(0.25),
                      PilihHx.bg.withOpacity(0.65),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            Positioned(
              top: 12,
              left: 12,
              child: Icon(
                Icons.favorite_rounded,
                color: PilihHx.pink.withOpacity(0.9),
                size: 14,
              ),
            ),

            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: PilihHx.pink,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: PilihHx.pink.withOpacity(0.6),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'PREMIUM ♡',
                  style: TextStyle(
                    color: PilihHx.bg,
                    fontSize: 9,
                    fontFamily: 'Ganang',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ),

            Positioned(
              left: 18,
              right: 18,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BUG ATTACK ♡',
                    style: TextStyle(
                      color: PilihHx.ivory,
                      fontFamily: 'Ganang',
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.2,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Pilih mode pengiriman',
                    style: TextStyle(
                      color: PilihHx.pinkLight.withOpacity(0.9),
                      fontFamily: 'Ganang',
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MODE SWITCHER (tab pill)
  // ═══════════════════════════════════════════════════════════
  Widget _buildModeSwitcher() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: PilihHx.surfaceHi,
        border: Border.all(
          color: PilihHx.pink.withOpacity(0.3),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          _buildModeChip(
            mode: PilihLayoutMode.normal,
            icon: Icons.view_agenda_rounded,
            label: 'Normal',
          ),
          _buildModeChip(
            mode: PilihLayoutMode.orbit,
            icon: Icons.blur_circular_rounded,
            label: 'Orbit',
          ),
          _buildModeChip(
            mode: PilihLayoutMode.horizontal,
            icon: Icons.view_carousel_rounded,
            label: 'Slide',
          ),
        ],
      ),
    );
  }

  Widget _buildModeChip({
    required PilihLayoutMode mode,
    required IconData icon,
    required String label,
  }) {
    final isActive = _layoutMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (_layoutMode == mode) return;
          HapticFeedback.selectionClick();
          setState(() => _layoutMode = mode);
          _entranceController
            ..reset()
            ..forward();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            gradient: isActive
                ? const LinearGradient(
                    colors: [PilihHx.pinkLight, PilihHx.pinkDeep],
                  )
                : null,
            borderRadius: BorderRadius.circular(10),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: PilihHx.pink.withOpacity(0.5),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 15,
                color: isActive ? Colors.white : PilihHx.ash,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? Colors.white : PilihHx.ash,
                  fontFamily: 'Ganang',
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CARD COMPONENT (reusable)
  // ═══════════════════════════════════════════════════════════
  Widget _buildChoiceCard(_MenuData menu) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _handleMenuTap(menu.target),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PilihHx.surfaceHi,
            border: Border.all(
              color: PilihHx.pink.withOpacity(0.3),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: menu.accent.withOpacity(0.15),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: menu.accent.withOpacity(0.18),
                  border: Border.all(
                    color: menu.accent.withOpacity(0.6),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: menu.accent.withOpacity(0.35),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(menu.icon, color: menu.accent, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            menu.title,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: PilihHx.ivory,
                              fontFamily: 'Ganang',
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.4,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: menu.accent.withOpacity(0.18),
                            border: Border.all(
                              color: menu.accent.withOpacity(0.55),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(7),
                          ),
                          child: Text(
                            menu.badge,
                            style: TextStyle(
                              color: menu.accent,
                              fontFamily: 'Ganang',
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      menu.subtitle,
                      style: const TextStyle(
                        color: PilihHx.ash,
                        fontFamily: 'Ganang',
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.chevron_right_rounded,
                color: PilihHx.pinkLight.withOpacity(0.9),
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── COMPACT CARD untuk orbit & horizontal (lebih ringkas) ──
  Widget _buildCompactCard(_MenuData menu, {bool isOrbit = false}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _handleMenuTap(menu.target),
        child: Container(
          padding: EdgeInsets.all(isOrbit ? 12 : 14),
          decoration: BoxDecoration(
            color: PilihHx.surfaceHi,
            border: Border.all(
              color: menu.accent.withOpacity(0.5),
              width: 1.2,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: menu.accent.withOpacity(0.35),
                blurRadius: 18,
                spreadRadius: 2,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: isOrbit ? 42 : 48,
                height: isOrbit ? 42 : 48,
                decoration: BoxDecoration(
                  color: menu.accent.withOpacity(0.2),
                  border: Border.all(
                    color: menu.accent.withOpacity(0.7),
                    width: 1.2,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: menu.accent.withOpacity(0.4),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(
                  menu.icon,
                  color: menu.accent,
                  size: isOrbit ? 20 : 24,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                menu.title,
                style: TextStyle(
                  color: PilihHx.ivory,
                  fontFamily: 'Ganang',
                  fontSize: isOrbit ? 9 : 10.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                  height: 1.1,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: menu.accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  menu.badge,
                  style: TextStyle(
                    color: menu.accent,
                    fontFamily: 'Ganang',
                    fontSize: 7,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MODE 1 — NORMAL (vertical stack, 1 per 1)
  // ═══════════════════════════════════════════════════════════
  Widget _buildNormalLayout() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: List.generate(_menus.length, (index) {
        return Padding(
          padding: EdgeInsets.only(bottom: index < _menus.length - 1 ? 14 : 0),
          child: _buildStaggeredEntry(
            index: index,
            child: _buildChoiceCard(_menus[index]),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MODE 2 — ORBIT (melingkar di sekitar logo tengah)
  // ═══════════════════════════════════════════════════════════
  Widget _buildOrbitLayout() {
    return SizedBox(
      height: 400,
      child: AnimatedBuilder(
        animation: _orbitController,
        builder: (context, _) {
          final rotation = _orbitController.value * 2 * math.pi;
          final center = const Offset(0, 0);
          const orbitRadius = 130.0;
          const cardSize = 100.0;

          return LayoutBuilder(
            builder: (context, constraints) {
              final cx = constraints.maxWidth / 2;
              final cy = 200.0;

              return Stack(
                alignment: Alignment.center,
                children: [
                  // Center logo badge
                  Positioned(
                    left: cx - 45,
                    top: cy - 45,
                    child: _buildOrbitCenter(),
                  ),

                  // Orbit cards
                  ...List.generate(_menus.length, (index) {
                    final angle =
                        (index / _menus.length) * 2 * math.pi + rotation;
                    final dx = cx + orbitRadius * math.cos(angle);
                    final dy = cy + orbitRadius * math.sin(angle);

                    // scale by depth (bigger when front)
                    final depth = (math.sin(angle) + 1) / 2; // 0 back, 1 front
                    final scale = 0.7 + 0.35 * depth;
                    final opacity = 0.55 + 0.45 * depth;

                    return Positioned(
                      left: dx - cardSize / 2,
                      top: dy - cardSize / 2,
                      child: Transform.scale(
                        scale: scale,
                        child: Opacity(
                          opacity: opacity,
                          child: SizedBox(
                            width: cardSize,
                            height: cardSize,
                            child: _buildCompactCard(
                              _menus[index],
                              isOrbit: true,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildOrbitCenter() {
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [PilihHx.pinkLight, PilihHx.pinkDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: PilihHx.pink.withOpacity(0.6),
            blurRadius: 30,
            spreadRadius: 6,
          ),
        ],
      ),
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.favorite_rounded,
              color: Colors.white,
              size: 30,
            ),
            SizedBox(height: 4),
            Text(
              'XYRO',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Ganang',
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MODE 3 — HORIZONTAL (geser kiri carousel)
  // ═══════════════════════════════════════════════════════════
  Widget _buildHorizontalLayout() {
    return SizedBox(
      height: 380,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
        itemCount: _menus.length,
        itemBuilder: (context, index) {
          final menu = _menus[index];
          return Padding(
            padding: EdgeInsets.only(
              right: index < _menus.length - 1 ? 14 : 0,
            ),
            child: _buildStaggeredEntry(
              index: index,
              child: SizedBox(
                width: 280,
                child: _buildHorizontalCard(menu),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHorizontalCard(_MenuData menu) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _handleMenuTap(menu.target),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: PilihHx.surfaceHi,
            border: Border.all(
              color: menu.accent.withOpacity(0.45),
              width: 1.4,
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: menu.accent.withOpacity(0.3),
                blurRadius: 26,
                spreadRadius: 3,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Badge
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: menu.accent.withOpacity(0.18),
                      border: Border.all(
                        color: menu.accent.withOpacity(0.55),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(7),
                    ),
                    child: Text(
                      menu.badge,
                      style: TextStyle(
                        color: menu.accent,
                        fontFamily: 'Ganang',
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Icon(
                    Icons.favorite_rounded,
                    color: menu.accent.withOpacity(0.6),
                    size: 14,
                  ),
                ],
              ),
              const Spacer(),

              // Big icon
              Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(
                  color: menu.accent.withOpacity(0.2),
                  border: Border.all(
                    color: menu.accent.withOpacity(0.65),
                    width: 1.2,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: menu.accent.withOpacity(0.45),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(menu.icon, color: menu.accent, size: 38),
              ),
              const Spacer(),

              // Title
              Text(
                menu.title,
                style: const TextStyle(
                  color: PilihHx.ivory,
                  fontFamily: 'Ganang',
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                  height: 1.1,
                ),
              ),
              const SizedBox(height: 8),

              // Subtitle
              Text(
                menu.subtitle,
                style: const TextStyle(
                  color: PilihHx.ash,
                  fontFamily: 'Ganang',
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  height: 1.45,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),

              // Action button
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      menu.accent.withOpacity(0.8),
                      menu.accent,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: menu.accent.withOpacity(0.5),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text(
                      'OPEN',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Ganang',
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.2,
                      ),
                    ),
                    SizedBox(width: 8),
                    Icon(
                      Icons.arrow_forward_rounded,
                      color: Colors.white,
                      size: 16,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STAGGERED ENTRY
  // ═══════════════════════════════════════════════════════════
  Widget _buildStaggeredEntry({required int index, required Widget child}) {
    const int total = 8;
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF1A0E14),
            Color(0xFF241318),
          ],
        ),
      ),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildStaggeredEntry(
              index: 0,
              child: _buildVideoBanner(),
            ),
            const SizedBox(height: 20),

            // Mode switcher
            _buildStaggeredEntry(
              index: 1,
              child: _buildModeSwitcher(),
            ),
            const SizedBox(height: 20),

            // Section label
            _buildStaggeredEntry(
              index: 2,
              child: Row(
                children: [
                  const Icon(Icons.favorite_rounded,
                      color: PilihHx.pink, size: 12),
                  const SizedBox(width: 8),
                  Text(
                    _layoutMode == PilihLayoutMode.normal
                        ? 'PILIH MODE'
                        : (_layoutMode == PilihLayoutMode.orbit
                            ? 'ORBIT MENU'
                            : 'SLIDE MENU'),
                    style: const TextStyle(
                      color: PilihHx.ivory,
                      fontFamily: 'Ganang',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.4,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            PilihHx.pink.withOpacity(0.5),
                            PilihHx.pink.withOpacity(0.0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // ── CONTENT by mode ──
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              transitionBuilder: (child, anim) {
                return FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0.05, 0),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                );
              },
              child: KeyedSubtree(
                key: ValueKey(_layoutMode),
                child: _layoutMode == PilihLayoutMode.normal
                    ? _buildNormalLayout()
                    : (_layoutMode == PilihLayoutMode.orbit
                        ? _buildOrbitLayout()
                        : _buildHorizontalLayout()),
              ),
            ),

            const SizedBox(height: 24),

            // Info box
            _buildStaggeredEntry(
              index: 6,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: PilihHx.surfaceHi,
                  border: Border.all(
                    color: PilihHx.pink.withOpacity(0.25),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: PilihHx.pink.withOpacity(0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: PilihHx.pink.withOpacity(0.15),
                        border: Border.all(
                          color: PilihHx.pink.withOpacity(0.4),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.favorite_rounded,
                        color: PilihHx.pinkLight,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Pilih salah satu mode untuk mulai mengirim bug attack, mengecek banned, atau spam OTP.',
                        style: TextStyle(
                          color: PilihHx.ash.withOpacity(0.95),
                          fontFamily: 'Ganang',
                          fontSize: 11.5,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════
enum _Target { numberBug, groupBug, banned, cekBand, spamOtp }

class _MenuData {
  final IconData icon;
  final String title;
  final String subtitle;
  final String badge;
  final Color accent;
  final _Target target;

  const _MenuData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.accent,
    required this.target,
  });
}