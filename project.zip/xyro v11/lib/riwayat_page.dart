// lib/riwayat_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';

// ============================================================
// PALET — PURE BLACK MINIMAL
// ============================================================
class RiwayatHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amethyst = Color(0xFFA78BFA);
  static const amber    = Color(0xFFFBBF24);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

const String kFontFamily = 'Ganang';
const String kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

// ============================================================
// ACTIVITY MODEL
// ============================================================
class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}

// ============================================================
// RIWAYAT PAGE
// ============================================================
class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  List<ActivityModel> activities = [];
  List<ActivityModel> filteredActivities = [];
  bool isLoading = true;

  // Filter
  String selectedFilter = 'all';
  final List<Map<String, dynamic>> filterOptions = [
    {'id': 'all', 'label': 'ALL', 'icon': Icons.apps},
    {'id': 'login', 'label': 'LOGIN', 'icon': Icons.login},
    {'id': 'bug', 'label': 'ATTACK', 'icon': Icons.bug_report},
    {'id': 'create', 'label': 'ACCOUNT', 'icon': Icons.person_add},
  ];

  VideoPlayerController? _bgVideoController;

  @override
  void initState() {
    super.initState();
    _initBackgroundVideo();
    _loadActivities();
  }

  @override
  void dispose() {
    _bgVideoController?.dispose();
    super.dispose();
  }

  void _initBackgroundVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/mmk.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        _bgVideoController?.setVolume(0.0);
        _bgVideoController?.setLooping(true);
        _bgVideoController?.play();
        setState(() {});
      }).catchError((_) {});
  }

  Future<void> _loadActivities() async {
    setState(() => isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('$kBase/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          List<dynamic> rawList = data['activities'] ?? [];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                  item['timestamp'] ??
                      DateTime.now().millisecondsSinceEpoch,
                ),
              );
            }).toList();
            _applyFilter();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        setState(() => isLoading = false);
        if (mounted) {
          CustomPopup.show(
            context,
            title: "Server Error",
            message: "Gagal memuat aktivitas.",
            icon: Icons.error_outline,
            iconColor: RiwayatHx.terra,
          );
        }
      }
    } catch (e) {
      setState(() => isLoading = false);
      if (mounted) {
        CustomPopup.show(
          context,
          title: "Connection Error",
          message: "Gagal terhubung ke server.",
          icon: Icons.error_outline,
          iconColor: RiwayatHx.terra,
        );
      }
    }
  }

  void _applyFilter() {
    setState(() {
      if (selectedFilter == 'all') {
        filteredActivities = List.from(activities);
      } else {
        filteredActivities =
            activities.where((a) => a.type == selectedFilter).toList();
      }
    });
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy · HH:mm').format(date);
  }

  String _formatTimeAgo(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);

    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return _formatDate(date);
  }

  Color _getTypeColor(String type) {
    switch (type) {
      case 'login':
        return RiwayatHx.jade;
      case 'bug':
        return RiwayatHx.terra;
      case 'create':
        return RiwayatHx.slate;
      default:
        return RiwayatHx.ash;
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'login':
        return Icons.login_rounded;
      case 'bug':
        return Icons.bug_report_rounded;
      case 'create':
        return Icons.person_add_rounded;
      default:
        return Icons.info_outline_rounded;
    }
  }

  String _getTypeLabel(String type) {
    switch (type) {
      case 'login':
        return 'LOGIN';
      case 'bug':
        return 'ATTACK';
      case 'create':
        return 'ACCOUNT';
      default:
        return 'SYSTEM';
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: RiwayatHx.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Layer 1: Video background
          if (_bgVideoController != null &&
              _bgVideoController!.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController!.value.size.width,
                height: _bgVideoController!.value.size.height,
                child: VideoPlayer(_bgVideoController!),
              ),
            )
          else
            Container(color: RiwayatHx.bg),

          // Layer 2: Dark overlay (lebih pekat biar card kontras)
          Container(
            color: Colors.black.withOpacity(0.82),
          ),

          // Layer 3: Content
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                _buildFilterRow(),
                Expanded(
                  child: isLoading
                      ? _buildLoadingState()
                      : filteredActivities.isEmpty
                          ? _buildEmptyState()
                          : RefreshIndicator(
                              onRefresh: _loadActivities,
                              color: RiwayatHx.ivory,
                              backgroundColor: RiwayatHx.surfaceHi,
                              child: _buildTimeline(),
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============ HEADER ============
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 80, 20, 16),
      child: Row(
        children: [
          // Back button
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => Navigator.pop(context),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: RiwayatHx.surfaceHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new,
                  color: RiwayatHx.ivory,
                  size: 16,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),

          // Title
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "ACTIVITY LOG",
                  style: TextStyle(
                    color: RiwayatHx.ivory,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFontFamily,
                    letterSpacing: 2.0,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "Riwayat aktivitas akun kamu",
                  style: TextStyle(
                    color: RiwayatHx.ash,
                    fontSize: 11,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          // Refresh button
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: isLoading ? null : _loadActivities,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: RiwayatHx.surfaceHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                ),
                child: Icon(
                  Icons.refresh_rounded,
                  color: isLoading
                      ? RiwayatHx.ash2
                      : RiwayatHx.ivory,
                  size: 18,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============ FILTER ROW ============
  Widget _buildFilterRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(
          children: filterOptions.map((opt) {
            final isActive = selectedFilter == opt['id'];
            final count = opt['id'] == 'all'
                ? activities.length
                : activities.where((a) => a.type == opt['id']).length;

            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () {
                  setState(() => selectedFilter = opt['id']);
                  _applyFilter();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: isActive
                        ? RiwayatHx.ivory
                        : RiwayatHx.surfaceHi,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isActive
                          ? RiwayatHx.ivory
                          : Colors.white.withOpacity(0.08),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        opt['icon'],
                        color: isActive
                            ? RiwayatHx.bg
                            : RiwayatHx.ash,
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        opt['label'],
                        style: TextStyle(
                          color: isActive
                              ? RiwayatHx.bg
                              : RiwayatHx.ivory,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                          letterSpacing: 1.0,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 1,
                        ),
                        decoration: BoxDecoration(
                          color: isActive
                              ? RiwayatHx.bg.withOpacity(0.15)
                              : Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '$count',
                          style: TextStyle(
                            color: isActive
                                ? RiwayatHx.bg
                                : RiwayatHx.ash,
                            fontFamily: kFontFamily,
                            fontWeight: FontWeight.w900,
                            fontSize: 9,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  // ============ LOADING ============
  Widget _buildLoadingState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              color: RiwayatHx.ivory,
              strokeWidth: 2.0,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Memuat riwayat...',
            style: TextStyle(
              color: RiwayatHx.ash,
              fontFamily: kFontFamily,
              fontSize: 12,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    );
  }

  // ============ EMPTY ============
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: RiwayatHx.surfaceHi,
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.history_toggle_off,
                color: RiwayatHx.ash,
                size: 40,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Belum Ada Aktivitas",
              style: TextStyle(
                color: RiwayatHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 15,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              "Aktivitas kamu bakal muncul di sini",
              style: TextStyle(
                color: RiwayatHx.ash,
                fontFamily: kFontFamily,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ TIMELINE ============
  Widget _buildTimeline() {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
      itemCount: filteredActivities.length,
      itemBuilder: (context, index) {
        final activity = filteredActivities[index];
        final isLast = index == filteredActivities.length - 1;

        return _buildTimelineItem(activity, isLast);
      },
    );
  }

  Widget _buildTimelineItem(ActivityModel activity, bool isLast) {
    final typeColor = _getTypeColor(activity.type);

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Line + dot
          Column(
            children: [
              // Icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: RiwayatHx.surfaceHi,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: typeColor.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Center(
                  child: Icon(
                    _getTypeIcon(activity.type),
                    color: typeColor,
                    size: 18,
                  ),
                ),
              ),
              // Vertical line
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 1,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          typeColor.withOpacity(0.3),
                          typeColor.withOpacity(0.02),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 14),

          // Card content
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 20),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: RiwayatHx.surfaceHi,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header: type badge + time
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: typeColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: typeColor.withOpacity(0.4),
                                width: 1,
                              ),
                            ),
                            child: Text(
                              _getTypeLabel(activity.type),
                              style: TextStyle(
                                color: typeColor,
                                fontFamily: kFontFamily,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.0,
                              ),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            _formatTimeAgo(activity.timestamp),
                            style: const TextStyle(
                              color: RiwayatHx.ash2,
                              fontFamily: kFontFamily,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      // Title
                      Text(
                        activity.title,
                        style: const TextStyle(
                          color: RiwayatHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          height: 1.3,
                        ),
                      ),
                      const SizedBox(height: 6),

                      // Description
                      Text(
                        activity.description,
                        style: const TextStyle(
                          color: RiwayatHx.ash,
                          fontFamily: kFontFamily,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w500,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Footer: full date
                      Row(
                        children: [
                          const Icon(
                            Icons.access_time_rounded,
                            size: 12,
                            color: RiwayatHx.ash2,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _formatDate(activity.timestamp),
                            style: const TextStyle(
                              color: RiwayatHx.ash2,
                              fontFamily: kFontFamily,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}