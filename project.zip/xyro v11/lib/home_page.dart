// lib/home_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;   // ✅ FIX: untuk math.sin & math.pi
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import 'group_page.dart';

const String kFontFamily = 'Ganang';
const String kBaseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class HomeHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);
  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // PINK FAMILY
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  // Aksen
  static const jade     = Color(0xFF6EE7B7);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFFF7A9A);
  static const slate    = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFFFFFF);
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();

  late AnimationController _entranceController;
  late AnimationController _pulseController;

  String selectedBugId = "";
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMessage;

  int _globalSenderCount = 0;
  int _privateSenderCount = 0;

  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoFailed = false;
  int _videoRetryCount = 0;

  String _currentCountryCode = '';
  String _currentFlagEmoji = '';

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || r == 'admin' || r == 'vip' || r == 'pemula';
  }

  List<Map<String, dynamic>> get _filteredBugs {
    return widget.listBug.where((bug) {
      final type = bug['type']?.toString().toLowerCase() ?? 'number';
      return type == 'number';
    }).toList();
  }

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    final filtered = _filteredBugs;
    if (filtered.isNotEmpty) {
      selectedBugId = filtered[0]['bug_id'];
    }

    _initVideo();
    _fetchSenderStats();
    targetController.addListener(_updateFlagFromInput);
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _pulseController.dispose();
    targetController.removeListener(_updateFlagFromInput);
    targetController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _initVideo() async {
    if (_videoController != null) {
      try {
        await _videoController!.dispose();
      } catch (_) {}
      _videoController = null;
    }
    if (!mounted) return;
    setState(() {
      _videoReady = false;
      _videoFailed = false;
    });

    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0);
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();

      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoReady = true;
        _videoFailed = false;
      });
    } catch (e) {
      debugPrint('Video error: $e');
      if (_videoRetryCount < 3 && mounted) {
        _videoRetryCount++;
        Future.delayed(const Duration(milliseconds: 500), _initVideo);
      } else {
        if (mounted) setState(() => _videoFailed = true);
      }
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final url = "$kBaseUrl/getSenderStats?key=${widget.sessionKey}";
      final res =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['success'] == true) {
          if (!mounted) return;
          setState(() {
            _globalSenderCount = data['global'] ?? 0;
            _privateSenderCount = data['private'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint('Sender stats error: $e');
    }
  }

  String _getCountryCodeFromNumber(String phoneNumber) {
    final cleaned = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+')) return '';
    final countryCodes = {
      '+62': 'ID', '+60': 'MY', '+65': 'SG', '+66': 'TH',
      '+63': 'PH', '+84': 'VN', '+81': 'JP', '+82': 'KR',
      '+86': 'CN', '+91': 'IN', '+92': 'PK', '+1': 'US',
      '+44': 'GB', '+61': 'AU', '+64': 'NZ', '+49': 'DE',
      '+33': 'FR', '+39': 'IT', '+34': 'ES', '+7': 'RU',
      '+55': 'BR', '+54': 'AR', '+52': 'MX', '+27': 'ZA',
      '+20': 'EG', '+234': 'NG', '+971': 'AE', '+966': 'SA',
      '+90': 'TR', '+972': 'IL', '+98': 'IR', '+93': 'AF',
    };
    final sorted = countryCodes.keys.toList()
      ..sort((a, b) => b.length.compareTo(a.length));
    for (final code in sorted) {
      if (cleaned.startsWith(code)) return countryCodes[code] ?? '';
    }
    return '';
  }

  String _getFlagEmoji(String countryCode) {
    if (countryCode.isEmpty) return '';
    final flags = {
      'ID': '🇮🇩', 'MY': '🇲🇾', 'SG': '🇸🇬', 'TH': '🇹🇭',
      'PH': '🇵🇭', 'VN': '🇻🇳', 'JP': '🇯🇵', 'KR': '🇰🇷',
      'CN': '🇨🇳', 'IN': '🇮🇳', 'PK': '🇵🇰', 'US': '🇺🇸',
      'GB': '🇬🇧', 'AU': '🇦🇺', 'NZ': '🇳🇿', 'DE': '🇩🇪',
      'FR': '🇫🇷', 'IT': '🇮🇹', 'ES': '🇪🇸', 'RU': '🇷🇺',
      'BR': '🇧🇷', 'AR': '🇦🇷', 'MX': '🇲🇽', 'ZA': '🇿🇦',
      'EG': '🇪🇬', 'NG': '🇳🇬', 'AE': '🇦🇪', 'SA': '🇸🇦',
      'TR': '🇹🇷', 'IL': '🇮🇱', 'IR': '🇮🇷', 'AF': '🇦🇫',
    };
    return flags[countryCode] ?? '';
  }

  void _updateFlagFromInput() {
    final input = targetController.text;
    if (input.isNotEmpty) {
      final code = _getCountryCodeFromNumber(input);
      if (code != _currentCountryCode) {
        setState(() {
          _currentCountryCode = code;
          _currentFlagEmoji = _getFlagEmoji(code);
        });
      }
    } else if (_currentFlagEmoji.isNotEmpty) {
      setState(() {
        _currentCountryCode = '';
        _currentFlagEmoji = '';
      });
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    final target = formatPhoneNumber(rawInput);
    if (target == null || key.isEmpty) {
      _showAlert("INVALID NUMBER",
          "Gunakan format internasional (contoh: +62, +1, +44).");
      return;
    }

    if (_senderType == 'global' && !canAccessGlobalSender) {
      _showAlert('ACCESS DENIED',
          'Global Sender hanya untuk Owner, Admin, VIP & Pemula!');
      return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert("NO BUG", "Pilih bug terlebih dahulu.");
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final url = Uri.parse(
          "$kBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId"
          "${_senderType == 'global' ? '&senderMode=global' : ''}");
      final res = await http.get(url).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown. Tunggu sebentar.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Session expired.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Server maintenance.");
      } else {
        HapticFeedback.heavyImpact();
        setState(() => _responseMessage = "✅ Bug berhasil dikirim!");
        targetController.clear();
        setState(() {
          _currentFlagEmoji = '';
          _currentCountryCode = '';
        });
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Terjadi kesalahan.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: HomeHx.surfaceHi2,
            border: Border.all(
              color: HomeHx.pink.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: HomeHx.pink.withOpacity(0.25),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: HomeHx.pink.withOpacity(0.15),
                  border: Border.all(
                    color: HomeHx.pink.withOpacity(0.5),
                    width: 1,
                  ),
                ),
                child: const Icon(Icons.favorite_rounded,
                    color: HomeHx.pink, size: 28),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: HomeHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: HomeHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: HomeHx.pink,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      color: HomeHx.bg,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSenderSelectorBottomSheet() {
    if (!canAccessGlobalSender) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: EdgeInsets.fromLTRB(
            22,
            18,
            22,
            22 + MediaQuery.of(context).padding.bottom,
          ),
          decoration: const BoxDecoration(
            color: HomeHx.bgAlt,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: HomeHx.pink.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  const Icon(Icons.favorite_rounded,
                      color: HomeHx.pink, size: 14),
                  const SizedBox(width: 10),
                  const Text(
                    "SELECT SENDER ♡",
                    style: TextStyle(
                      color: HomeHx.ivory,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      letterSpacing: 2.0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildBottomSheetOption(
                icon: Icons.person_rounded,
                label: "PRIVATE",
                count: _privateSenderCount,
                isSelected: _senderType == "private",
                onTap: () {
                  setState(() => _senderType = "private");
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 10),
              _buildBottomSheetOption(
                icon: Icons.public_rounded,
                label: "GLOBAL",
                count: _globalSenderCount,
                isSelected: _senderType == "global",
                onTap: () {
                  setState(() => _senderType = "global");
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomSheetOption({
    required IconData icon,
    required String label,
    required int count,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final accent = label == "GLOBAL" ? HomeHx.pinkLight : HomeHx.jade;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? accent.withOpacity(0.12)
              : HomeHx.surfaceHi,
          border: Border.all(
            color: isSelected
                ? accent.withOpacity(0.6)
                : HomeHx.pink.withOpacity(0.2),
            width: 1.2,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: accent.withOpacity(0.3),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.18),
                border: Border.all(
                  color: accent.withOpacity(0.6),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(icon, color: accent, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: HomeHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    isSelected ? "Currently active ♡" : "Tap to activate",
                    style: TextStyle(
                      color: isSelected ? accent : HomeHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: HomeHx.surfaceHi2,
                border: Border.all(
                  color: accent.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                "$count",
                style: TextStyle(
                  color: accent,
                  fontFamily: kFontFamily,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 10),
            if (isSelected)
              Icon(Icons.check_circle_rounded,
                  color: accent.withOpacity(0.9), size: 22),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EFEK HUD & SCANLINE — PINK CUTE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 16, double thickness = 2}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 12, left: 12, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 12, right: 12, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 12, left: 12, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 12, right: 12, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(
              width: size, height: thickness,
              decoration: BoxDecoration(
                color: HomeHx.pinkLight.withOpacity(0.9),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: HomeHx.pink.withOpacity(0.6), blurRadius: 4),
                ],
              ),
            ),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(
              width: thickness, height: size,
              decoration: BoxDecoration(
                color: HomeHx.pinkLight.withOpacity(0.9),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: HomeHx.pink.withOpacity(0.6), blurRadius: 4),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.18,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  HomeHx.pinkSoft.withOpacity(0.5),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PROFILE CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: HomeHx.surfaceHi,
        border: Border.all(
          color: HomeHx.pink.withOpacity(0.3),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: HomeHx.pink.withOpacity(0.15),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [HomeHx.pinkLight, HomeHx.pinkDeep],
              ),
              boxShadow: [
                BoxShadow(
                  color: HomeHx.pink.withOpacity(0.6),
                  blurRadius: 16,
                  spreadRadius: 2,
                ),
              ],
            ),
            padding: const EdgeInsets.all(2.5),
            child: ClipOval(
              child: Container(
                color: HomeHx.surfaceHi,
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                    child: Icon(Icons.person_rounded,
                        color: HomeHx.pink, size: 28),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.username.toUpperCase(),
                  style: const TextStyle(
                    color: HomeHx.ivory,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 7),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _pill(
                      text: widget.role.toUpperCase(),
                      color: HomeHx.pinkLight,
                    ),
                    _pill(
                      text: 'EXP ${widget.expiredDate}',
                      color: HomeHx.ash,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _pill({required String text, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        border: Border.all(color: color.withOpacity(0.5), width: 1),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.25),
            blurRadius: 6,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontFamily: kFontFamily,
          fontSize: 9.5,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.0,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 180,
      margin: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: HomeHx.pink.withOpacity(0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: HomeHx.pink.withOpacity(0.2),
            blurRadius: 24,
            spreadRadius: 1,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else if (_videoFailed)
              Container(
                color: HomeHx.surfaceHi2,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.videocam_off_rounded,
                          color: HomeHx.pinkLight.withOpacity(0.5), size: 32),
                      const SizedBox(height: 8),
                      const Text('BANNER',
                          style: TextStyle(
                            color: HomeHx.pinkLight,
                            fontFamily: kFontFamily,
                            fontSize: 11,
                            letterSpacing: 3,
                            fontWeight: FontWeight.w800,
                          )),
                    ],
                  ),
                ),
              )
            else
              Container(
                color: HomeHx.surfaceHi2,
                child: const Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: HomeHx.pinkLight,
                      strokeWidth: 2.0,
                    ),
                  ),
                ),
              ),

            // Overlay gradient
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      HomeHx.bg.withOpacity(0.25),
                      HomeHx.bg.withOpacity(0.6),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            // Heart kecil atas kiri
            Positioned(
              top: 12,
              left: 12,
              child: Icon(
                Icons.favorite_rounded,
                color: HomeHx.pink.withOpacity(0.9),
                size: 14,
              ),
            ),

            // Badge
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: HomeHx.pink,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: HomeHx.pink.withOpacity(0.6),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'PREMIUM ♡',
                  style: TextStyle(
                    color: HomeHx.bg,
                    fontSize: 9,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // GROUP BUG BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildGroupBugButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GroupPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          color: HomeHx.surfaceHi,
          border: Border.all(
            color: HomeHx.pink.withOpacity(0.3),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: HomeHx.pink.withOpacity(0.15),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: HomeHx.amethyst.withOpacity(0.18),
                border: Border.all(
                  color: HomeHx.amethyst.withOpacity(0.6),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: HomeHx.amethyst.withOpacity(0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.groups_rounded,
                  color: HomeHx.amethyst, size: 22),
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "GROUP BUG ♡",
                    style: TextStyle(
                      color: HomeHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    "Kirim bug ke WhatsApp Group",
                    style: TextStyle(
                      color: HomeHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: HomeHx.pinkLight, size: 22),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUG CAROUSEL — hanya number
  // ═══════════════════════════════════════════════════════════
  Widget _buildBugCarousel() {
    final filtered = _filteredBugs;

    if (filtered.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: HomeHx.surfaceHi,
          border: Border.all(
            color: HomeHx.pink.withOpacity(0.3),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Center(
          child: Text(
            "No number bugs available",
            style: TextStyle(
              color: HomeHx.ash,
              fontFamily: kFontFamily,
              fontSize: 12,
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: 118,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filtered.length,
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
        itemBuilder: (context, index) {
          final bug = filtered[index];
          final isSelected = bug['bug_id'] == selectedBugId;

          return TweenAnimationBuilder(
            tween: Tween<double>(begin: 0.85, end: 1.0),
            duration: Duration(milliseconds: 320 + index * 70),
            curve: Curves.easeOutBack,
            builder: (context, double scale, child) =>
                Transform.scale(scale: scale, child: child),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() => selectedBugId = bug['bug_id']);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutCubic,
                width: 154,
                margin: const EdgeInsets.only(right: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isSelected
                      ? HomeHx.pink.withOpacity(0.15)
                      : HomeHx.surfaceHi,
                  border: Border.all(
                    color: isSelected
                        ? HomeHx.pink.withOpacity(0.6)
                        : HomeHx.pink.withOpacity(0.2),
                    width: isSelected ? 1.5 : 1,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: HomeHx.pink.withOpacity(0.35),
                            blurRadius: 14,
                            spreadRadius: 1,
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (_, __) {
                        final scale = isSelected
                            ? 1.0 +
                                0.12 *
                                    math.sin(
                                        _pulseController.value * math.pi * 2)
                            : 1.0;
                        return Transform.scale(
                          scale: scale,
                          child: Icon(
                            isSelected
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            color: isSelected
                                ? HomeHx.pink
                                : HomeHx.ash,
                            size: 22,
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 7),
                    Text(
                      bug['bug_name'] ?? 'Bug ${index + 1}',
                      style: TextStyle(
                        color: isSelected ? HomeHx.ivory : HomeHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'ID ${bug['bug_id']}',
                      style: TextStyle(
                        color: isSelected
                            ? HomeHx.pinkLight
                            : HomeHx.ash2,
                        fontFamily: kFontFamily,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SENDER SELECTOR
  // ═══════════════════════════════════════════════════════════
  Widget _buildSenderSelector() {
    final currentCount =
        _senderType == "private" ? _privateSenderCount : _globalSenderCount;
    final isGlobal = _senderType == "global";
    final accent = isGlobal ? HomeHx.pinkLight : HomeHx.jade;

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        _showSenderSelectorBottomSheet();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        decoration: BoxDecoration(
          color: HomeHx.surfaceHi,
          border: Border.all(
            color: HomeHx.pink.withOpacity(0.3),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.15),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.18),
                border: Border.all(
                  color: accent.withOpacity(0.6),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(
                isGlobal ? Icons.public_rounded : Icons.person_rounded,
                color: accent,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "SENDER MODE ♡",
                    style: TextStyle(
                      color: HomeHx.pinkLight,
                      fontFamily: kFontFamily,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Text(
                        isGlobal ? "GLOBAL" : "PRIVATE",
                        style: const TextStyle(
                          color: HomeHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: HomeHx.surfaceHi2,
                          border: Border.all(
                            color: accent.withOpacity(0.4),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          "$currentCount",
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: HomeHx.pinkLight, size: 22),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INPUT PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (canAccessGlobalSender) ...[
          _buildStaggeredEntry(
            index: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _sectionLabel("SENDER MODE"),
                const SizedBox(height: 10),
                _buildSenderSelector(),
              ],
            ),
          ),
          const SizedBox(height: 18),
        ],

        _buildStaggeredEntry(
          index: 3,
          child: _buildGroupBugButton(),
        ),
        const SizedBox(height: 18),

        _buildStaggeredEntry(
          index: 4,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _sectionLabelWithFlag(),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  color: HomeHx.surfaceHi,
                  border: Border.all(
                    color: HomeHx.pink.withOpacity(0.3),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: HomeHx.pink.withOpacity(0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: TextField(
                  controller: targetController,
                  style: const TextStyle(
                    color: HomeHx.ivory,
                    fontSize: 14.5,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                  cursorColor: HomeHx.pink,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: "+62xxxxxxxxxx",
                    hintStyle: const TextStyle(
                      color: HomeHx.ash2,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w600,
                    ),
                    filled: true,
                    fillColor: Colors.transparent,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    prefixIcon: Padding(
                      padding: const EdgeInsets.only(left: 14, right: 6),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (_currentFlagEmoji.isNotEmpty)
                            Text(_currentFlagEmoji,
                                style: const TextStyle(fontSize: 20)),
                          const SizedBox(width: 5),
                          const Icon(Icons.phone_iphone_rounded,
                              color: HomeHx.pinkLight, size: 18),
                        ],
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 18,
                      horizontal: 12,
                    ),
                  ),
                  onChanged: (_) => _updateFlagFromInput(),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        _buildStaggeredEntry(
          index: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _sectionLabel("SELECT BUG"),
              const SizedBox(height: 10),
              _buildBugCarousel(),
            ],
          ),
        ),
        const SizedBox(height: 22),

        _buildStaggeredEntry(
          index: 6,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _sectionLabelWithFlag() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(
        children: [
          Expanded(child: _sectionLabel("NOMOR TARGET")),
          if (_currentFlagEmoji.isNotEmpty)
            AnimatedContainer(
              duration: const Duration(milliseconds: 240),
              padding: const EdgeInsets.symmetric(
                horizontal: 9,
                vertical: 5,
              ),
              decoration: BoxDecoration(
                color: HomeHx.pink.withOpacity(0.15),
                border: Border.all(
                  color: HomeHx.pink.withOpacity(0.5),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_currentFlagEmoji,
                      style: const TextStyle(fontSize: 15)),
                  const SizedBox(width: 5),
                  Text(
                    _currentCountryCode,
                    style: const TextStyle(
                      color: HomeHx.pinkLight,
                      fontFamily: kFontFamily,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.favorite_rounded,
              color: HomeHx.pink, size: 12),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              color: HomeHx.ivory,
              fontWeight: FontWeight.w900,
              fontSize: 11,
              fontFamily: kFontFamily,
              letterSpacing: 2.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStaggeredEntry({required int index, required Widget child}) {
    const int total = 7;
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildSendButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          colors: [HomeHx.pinkLight, HomeHx.pinkDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: HomeHx.pink.withOpacity(0.5),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: SizedBox(
        height: 58,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: _isSending
                ? null
                : () {
                    HapticFeedback.mediumImpact();
                    _sendBug();
                  },
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      height: 24,
                      width: 24,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_rounded,
                            color: Colors.white, size: 20),
                        SizedBox(width: 12),
                        Text(
                          "EXECUTE ♡",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 2.8,
                            fontFamily: kFontFamily,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color accent;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      accent = HomeHx.jade;
      icon = Icons.check_circle_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      accent = HomeHx.terra;
      icon = Icons.cancel_rounded;
    } else {
      accent = HomeHx.pinkLight;
      icon = Icons.info_rounded;
    }

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
      builder: (context, double opacity, Widget? child) {
        return Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - opacity)),
            child: child,
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 16),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: HomeHx.surfaceHi,
            border: Border.all(
              color: accent.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.2),
                blurRadius: 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: accent, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _responseMessage!,
                  style: TextStyle(
                    color: accent,
                    fontWeight: FontWeight.w800,
                    fontSize: 12.5,
                    fontFamily: kFontFamily,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomeHx.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1A0E14),
              Color(0xFF241318),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 90, 16, 140),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildStaggeredEntry(
                  index: 0,
                  child: _buildProfileCard(),
                ),
                _buildStaggeredEntry(
                  index: 1,
                  child: _buildVideoBanner(),
                ),
                const SizedBox(height: 4),
                _buildInputPanel(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}