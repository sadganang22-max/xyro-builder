// lib/pemula_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'widgets/custom_popup.dart';

const String kFontFamily = 'Ganang';
const String kBase = 'http://www.rexylegal.rxpedia.web.id:2033';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class PemulaHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amethyst = Color(0xFFA78BFA);
  static const rose     = Color(0xFFF472B6);
  static const amber    = Color(0xFFFBBF24);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class PemulaPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const PemulaPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<PemulaPage> createState() => _PemulaPageState();
}

class _PemulaPageState extends State<PemulaPage>
    with TickerProviderStateMixin {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
    'member',
    'vip',
    'reseller',
    'admin',
    'owner',
  ];

  final List<String> filterRoles = [
    'member',
    'vip',
    'reseller',
    'admin',
    'owner',
  ];

  String selectedFilterRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _pulse;
  late AnimationController _entrance;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();

    _fetchUsers();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _entrance.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$kBase/listUsers?key=${widget.sessionKey}'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedFilterRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$kBase/deleteUser?key=${widget.sessionKey}&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$kBase/userAdd?key=${widget.sessionKey}&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses",
            "Akun ${newUserRole.toUpperCase()} berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$kBase/editUser?key=${widget.sessionKey}&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.show(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses")
          ? Icons.check_circle_outline
          : Icons.info_outline,
    );
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 8;
    final double start = (index / total) * 0.55;
    final double end = (start + 0.45).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══ ROLE HELPERS ═══
  Color _getRoleColor(String? role) {
    switch ((role ?? 'member').toLowerCase()) {
      case 'owner':
        return PemulaHx.ivory;
      case 'admin':
        return PemulaHx.terra;
      case 'reseller':
        return PemulaHx.slate;
      case 'vip':
        return PemulaHx.jade;
      default:
        return PemulaHx.ash;
    }
  }

  IconData _getRoleIcon(String? role) {
    switch ((role ?? 'member').toLowerCase()) {
      case 'owner':
        return Icons.workspace_premium_rounded;
      case 'admin':
        return Icons.admin_panel_settings_rounded;
      case 'reseller':
        return Icons.storefront_rounded;
      case 'vip':
        return Icons.star_rounded;
      default:
        return Icons.person_rounded;
    }
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PemulaHx.bg,
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),
              Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: isLoading && fullUserList.isEmpty
              ? const Center(
                  child: SizedBox(
                    width: 28, height: 28,
                    child: CircularProgressIndicator(
                      color: PemulaHx.ivory,
                      strokeWidth: 2.0,
                    ),
                  ),
                )
              : SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _staggered(index: 0, child: _buildHeader()),
                      const SizedBox(height: 22),
                      _staggered(index: 1, child: _buildActionGrid()),
                      const SizedBox(height: 22),
                      _staggered(index: 2,
                          child: _buildSectionLabel("User Directory")),
                      const SizedBox(height: 12),
                      _staggered(index: 3, child: _buildFilterCard()),
                      const SizedBox(height: 16),

                      if (isLoading && fullUserList.isNotEmpty)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(20),
                            child: SizedBox(
                              width: 24, height: 24,
                              child: CircularProgressIndicator(
                                color: PemulaHx.ivory,
                                strokeWidth: 2.0,
                              ),
                            ),
                          ),
                        ),

                      if (filteredList.isEmpty && !isLoading)
                        _buildEmptyState(),

                      ..._getCurrentPageData()
                          .asMap()
                          .entries
                          .map((e) => _staggered(
                                index: 4 + e.key,
                                child: _buildUserItem(e.value),
                              ))
                          .toList(),

                      const SizedBox(height: 20),
                      Center(child: _buildPagination()),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  // ═══ HEADER ═══
  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 3,
              height: 12,
              color: PemulaHx.ivory,
            ),
            const SizedBox(width: 10),
            const Text(
              "PEMULA ACCESS",
              style: TextStyle(
                color: PemulaHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "Universal",
          style: TextStyle(
            color: PemulaHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.6,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          "Console",
          style: TextStyle(
            color: PemulaHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: -1.2,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          "Welcome, ${widget.username} · Full access enabled",
          style: const TextStyle(
            color: PemulaHx.ash,
            fontFamily: kFontFamily,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  // ═══ ACTION GRID ═══
  Widget _buildActionGrid() {
    return Row(
      children: [
        _buildActionCard(
          title: "CREATE",
          subtitle: "Buat Akun",
          icon: FontAwesomeIcons.userPlus,
          color: PemulaHx.ivory,
          onTap: _showCreateAccountPopup,
        ),
        const SizedBox(width: 10),
        _buildActionCard(
          title: "EXTEND",
          subtitle: "Add Durasi",
          icon: FontAwesomeIcons.clock,
          color: PemulaHx.slate,
          onTap: _showExtendDurationPopup,
        ),
        const SizedBox(width: 10),
        _buildActionCard(
          title: "DELETE",
          subtitle: "Hapus Akun",
          icon: FontAwesomeIcons.userSlash,
          color: PemulaHx.terra,
          onTap: _showDeleteAccountPopup,
        ),
      ],
    );
  }

  Widget _buildActionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    final isWhite = color == PemulaHx.ivory;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.mediumImpact();
          onTap();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
          decoration: BoxDecoration(
            color: PemulaHx.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: isWhite
                      ? PemulaHx.ivory.withOpacity(0.12)
                      : color.withOpacity(0.12),
                  border: Border.all(
                    color: isWhite
                        ? Colors.white.withOpacity(0.2)
                        : color.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(height: 10),
              Text(
                title,
                style: TextStyle(
                  color: isWhite ? PemulaHx.ivory : color,
                  fontFamily: kFontFamily,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: const TextStyle(
                  color: PemulaHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 8.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ SECTION LABEL ═══
  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 12,
            color: PemulaHx.ivory,
          ),
          const SizedBox(width: 10),
          Text(
            text.toUpperCase(),
            style: const TextStyle(
              color: PemulaHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              color: Colors.white.withOpacity(0.08),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ FILTER CARD ═══
  Widget _buildFilterCard() {
    final currentCount = fullUserList
        .where((u) => u['role'] == selectedFilterRole)
        .length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: PemulaHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedFilterRole,
          dropdownColor: PemulaHx.surfaceHi,
          isExpanded: true,
          style: const TextStyle(
            color: PemulaHx.ivory,
            fontSize: 13,
            fontWeight: FontWeight.w800,
            fontFamily: kFontFamily,
            letterSpacing: 0.6,
          ),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: PemulaHx.ash,
          ),
          items: filterRoles.map((role) {
            final rc = _getRoleColor(role);
            final isWhite = rc == PemulaHx.ivory;
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(_getRoleIcon(role), color: rc, size: 15),
                  const SizedBox(width: 10),
                  Text(
                    role.toUpperCase(),
                    style: const TextStyle(
                      fontFamily: kFontFamily,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7, vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: isWhite
                          ? PemulaHx.ivory
                          : rc.withOpacity(0.15),
                      border: Border.all(
                        color: isWhite
                            ? PemulaHx.ivory
                            : rc.withOpacity(0.4),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      "$currentCount",
                      style: TextStyle(
                        color: isWhite ? PemulaHx.bg : rc,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFontFamily,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) {
              setState(() {
                selectedFilterRole = val;
                _filterAndPaginate();
              });
            }
          },
        ),
      ),
    );
  }

  // ═══ USER ITEM ═══
  Widget _buildUserItem(Map user) {
    final roleColor = _getRoleColor(user['role']);
    final isWhiteRole = roleColor == PemulaHx.ivory;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: PemulaHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: isWhiteRole
                  ? PemulaHx.ivory.withOpacity(0.12)
                  : roleColor.withOpacity(0.12),
              border: Border.all(
                color: isWhiteRole
                    ? Colors.white.withOpacity(0.2)
                    : roleColor.withOpacity(0.4),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              _getRoleIcon(user['role']),
              color: roleColor,
              size: 17,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'] ?? '-',
                  style: const TextStyle(
                    color: PemulaHx.ivory,
                    fontWeight: FontWeight.w900,
                    fontSize: 13.5,
                    fontFamily: kFontFamily,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: isWhiteRole
                            ? PemulaHx.ivory
                            : roleColor.withOpacity(0.15),
                        border: Border.all(
                          color: isWhiteRole
                              ? PemulaHx.ivory
                              : roleColor.withOpacity(0.4),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        (user['role'] ?? 'member').toUpperCase(),
                        style: TextStyle(
                          color: isWhiteRole ? PemulaHx.bg : roleColor,
                          fontSize: 8.5,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFontFamily,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        "EXP ${user['expiredDate'] ?? '-'}",
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: PemulaHx.ash,
                          fontSize: 10,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                deleteController.text = user['username'] ?? '';
                _showDeleteAccountPopup();
              },
              child: Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  color: PemulaHx.terra.withOpacity(0.12),
                  border: Border.all(
                    color: PemulaHx.terra.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.delete_outline_rounded,
                  color: PemulaHx.terra,
                  size: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ EMPTY STATE ═══
  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: PemulaHx.surfaceHi,
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.person_off_outlined,
              color: PemulaHx.ash,
              size: 30,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            "Belum ada user '${selectedFilterRole.toUpperCase()}'",
            style: const TextStyle(
              color: PemulaHx.ash,
              fontFamily: kFontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ═══ PAGINATION ═══
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected
                  ? PemulaHx.ivory
                  : PemulaHx.surfaceHi,
              border: Border.all(
                color: isSelected
                    ? PemulaHx.ivory
                    : Colors.white.withOpacity(0.08),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? PemulaHx.bg : PemulaHx.ivory,
                fontWeight: FontWeight.w900,
                fontFamily: kFontFamily,
                fontSize: 12,
              ),
            ),
          ),
        );
      }),
    );
  }

  // ═══ INPUT ═══
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    Color accent = PemulaHx.ivory,
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: PemulaHx.ash,
              fontFamily: kFontFamily,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: PemulaHx.surfaceHi2,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: controller,
            keyboardType: type,
            style: const TextStyle(
              color: PemulaHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
            cursorColor: accent,
            decoration: InputDecoration(
              hintText: 'Masukkan $label...',
              hintStyle: const TextStyle(
                color: PemulaHx.ash2,
                fontSize: 13,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w500,
              ),
              prefixIcon: Icon(icon, color: accent, size: 17),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
      ],
    );
  }

  // ═══ POPUP WRAPPER ═══
  Widget _popupShell({
    required IconData icon,
    required String title,
    required Color accent,
    required List<Widget> children,
  }) {
    final isWhite = accent == PemulaHx.ivory;
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: PemulaHx.surfaceHi,
          border: Border.all(
            color: Colors.white.withOpacity(0.1),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  color: isWhite
                      ? PemulaHx.ivory.withOpacity(0.12)
                      : accent.withOpacity(0.12),
                  border: Border.all(
                    color: isWhite
                        ? Colors.white.withOpacity(0.2)
                        : accent.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: accent, size: 24),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: const TextStyle(
                  color: PemulaHx.ivory,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFontFamily,
                  letterSpacing: 2.4,
                ),
              ),
              const SizedBox(height: 22),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  // ═══ ACTION BUTTON ═══
  Widget _buildActionButton({
    required String label,
    required Color accent,
    required VoidCallback onTap,
  }) {
    final isWhite = accent == PemulaHx.ivory;
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: isWhite ? PemulaHx.ivory : accent.withOpacity(0.15),
          foregroundColor: isWhite ? PemulaHx.bg : accent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: isWhite
                  ? PemulaHx.ivory
                  : accent.withOpacity(0.5),
              width: 1,
            ),
          ),
          elevation: 0,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isWhite ? PemulaHx.bg : accent,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.4,
            fontFamily: kFontFamily,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  // ═══ CREATE POPUP ═══
  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return _popupShell(
            icon: FontAwesomeIcons.userPlus,
            title: "CREATE ACCOUNT",
            accent: PemulaHx.ivory,
            children: [
              _buildInput(
                label: "Username",
                controller: createUsernameController,
                icon: FontAwesomeIcons.user,
                accent: PemulaHx.ivory,
              ),
              const SizedBox(height: 14),
              _buildInput(
                label: "Password",
                controller: createPasswordController,
                icon: FontAwesomeIcons.lock,
                accent: PemulaHx.ivory,
              ),
              const SizedBox(height: 14),
              _buildInput(
                label: "Durasi (Hari)",
                controller: createDayController,
                icon: FontAwesomeIcons.calendarDay,
                accent: PemulaHx.ivory,
                type: TextInputType.number,
              ),
              const SizedBox(height: 14),

              // Role dropdown
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    child: Text(
                      'ROLE',
                      style: TextStyle(
                        color: PemulaHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 2),
                    decoration: BoxDecoration(
                      color: PemulaHx.surfaceHi2,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: newUserRole,
                        dropdownColor: PemulaHx.surfaceHi,
                        isExpanded: true,
                        style: const TextStyle(
                          color: PemulaHx.ivory,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFontFamily,
                        ),
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: PemulaHx.ash,
                        ),
                        items: roleOptions.map((role) {
                          final rc = _getRoleColor(role);
                          return DropdownMenuItem(
                            value: role,
                            child: Row(
                              children: [
                                Icon(_getRoleIcon(role), color: rc, size: 16),
                                const SizedBox(width: 10),
                                Text(role.toUpperCase()),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: (val) => setModalState(
                            () => newUserRole = val ?? 'member'),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildActionButton(
                label: "CREATE",
                accent: PemulaHx.ivory,
                onTap: () {
                  Navigator.pop(context);
                  _createAccount();
                },
              ),
            ],
          );
        },
      ),
    );
  }

  // ═══ EXTEND POPUP ═══
  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => _popupShell(
        icon: FontAwesomeIcons.clock,
        title: "ADD DURATION",
        accent: PemulaHx.slate,
        children: [
          _buildInput(
            label: "Username Target",
            controller: editUsernameController,
            icon: FontAwesomeIcons.userEdit,
            accent: PemulaHx.slate,
          ),
          const SizedBox(height: 14),
          _buildInput(
            label: "Tambah Hari",
            controller: editDayController,
            icon: FontAwesomeIcons.calendarPlus,
            accent: PemulaHx.slate,
            type: TextInputType.number,
          ),
          const SizedBox(height: 20),
          _buildActionButton(
            label: "ADD DAYS",
            accent: PemulaHx.slate,
            onTap: () {
              Navigator.pop(context);
              _editUser();
            },
          ),
        ],
      ),
    );
  }

  // ═══ DELETE POPUP ═══
  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => _popupShell(
        icon: FontAwesomeIcons.userSlash,
        title: "DELETE ACCOUNT",
        accent: PemulaHx.terra,
        children: [
          _buildInput(
            label: "Username Target",
            controller: deleteController,
            icon: FontAwesomeIcons.user,
            accent: PemulaHx.terra,
          ),
          const SizedBox(height: 20),
          _buildActionButton(
            label: "DELETE",
            accent: PemulaHx.terra,
            onTap: () {
              Navigator.pop(context);
              _deleteUser();
            },
          ),
        ],
      ),
    );
  }
}