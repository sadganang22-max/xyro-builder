// lib/profile_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';
import 'login_page.dart';

const String kFontFamily = 'Ganang';

// ═══════════════════════════════════════════════════════════════
// PALET — KOMIK 3D (PUTIH + MERAH)
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg = Color(0xFFF5F5F7);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceHi = Color(0xFFFFFFFF);
  static const surfaceHi2 = Color(0xFFF0F0F2);

  static const goldLight = Color(0xFFFF6B6B);
  static const gold = Color(0xFFE63946);
  static const goldMid = Color(0xFFB71C2C);
  static const goldDeep = Color(0xFF7A0F1A);

  static const jade = Color(0xFF2ECC71);
  static const jadeDeep = Color(0xFF1E8449);
  static const terra = Color(0xFFE63946);
  static const slate = Color(0xFF3B82F6);
  static const amethyst = Color(0xFF8B5CF6);

  static const ivory = Color(0xFF1A1A1A);
  static const ash = Color(0xFF6B6B6B);
  static const ash2 = Color(0xFFB0B0B0);

  static const line = Color(0x33E63946);
  static const lineSoft = Color(0x1AE63946);
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  void _copyToClipboard(String text, String label) async {
    HapticFeedback.selectionClick();
    if (text.isEmpty) {
      _showSnack("❌ $label tidak tersedia", isError: true);
      return;
    }
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    _showSnack("✅ $label berhasil disalin", isError: false);
  }

  void _showSnack(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: isError ? Hx.terra : Hx.jade,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontFamily: kFontFamily,
                  color: Hx.ivory,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Hx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isError ? Hx.terra : Hx.jade,
            width: 2,
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _confirmLogout() async {
    HapticFeedback.mediumImpact();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Hx.surfaceHi,
            border: Border.all(color: Hx.gold, width: 2.5),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Hx.gold.withOpacity(0.3),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Hx.terra.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: Hx.terra, width: 2.5),
                ),
                child: const Icon(
                  Icons.logout,
                  color: Hx.terra,
                  size: 26,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                "LOG OUT",
                style: TextStyle(
                  color: Hx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                "Yakin ingin keluar dari akun ini?",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Hx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        HapticFeedback.selectionClick();
                        Navigator.pop(context, false);
                      },
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: const BorderSide(
                          color: Hx.gold,
                          width: 2,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "CANCEL",
                        style: TextStyle(
                          color: Hx.ash,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        HapticFeedback.mediumImpact();
                        Navigator.pop(context, true);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Hx.gold,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: const BorderSide(
                            color: Hx.goldDeep,
                            width: 2,
                          ),
                        ),
                      ),
                      child: const Text(
                        "LOG OUT",
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: kFontFamily,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Hx.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTopBar(),
              const SizedBox(height: 30),
              _buildHeroAvatar(),
              const SizedBox(height: 32),
              _buildUidCard(),
              const SizedBox(height: 28),
              _buildSectionDivider("ACCOUNT INFO"),
              const SizedBox(height: 16),
              _buildInfoItem(
                icon: Icons.person_outline,
                label: "Username",
                value: _censorText(widget.username),
              ),
              const SizedBox(height: 12),
              _buildInfoItem(
                icon: Icons.lock_outline,
                label: "Password",
                value: _censorText(widget.password, isPassword: true),
              ),
              const SizedBox(height: 12),
              _buildInfoItem(
                icon: Icons.shield_outlined,
                label: "Role",
                value: widget.role.toUpperCase(),
              ),
              const SizedBox(height: 12),
              _buildInfoItem(
                icon: Icons.timer_outlined,
                label: "Expires",
                value: widget.expiredDate,
              ),
              const SizedBox(height: 28),
              _buildSectionDivider("SESSION"),
              const SizedBox(height: 16),
              _buildInfoItem(
                icon: Icons.vpn_key_outlined,
                label: "Session Key",
                value: widget.sessionKey.length > 12
                    ? "${widget.sessionKey.substring(0, 12)}..."
                    : widget.sessionKey,
                copyValue: widget.sessionKey,
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 56,
                child: ElevatedButton.icon(
                  icon: const Icon(
                    Icons.lock_reset,
                    color: Colors.white,
                    size: 20,
                  ),
                  label: const Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 2.0,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Hx.gold,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: const BorderSide(
                        color: Hx.goldDeep,
                        width: 2.5,
                      ),
                    ),
                  ),
                  onPressed: () {
                    HapticFeedback.mediumImpact();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: widget.username,
                          sessionKey: widget.sessionKey,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 56,
                child: OutlinedButton.icon(
                  icon: const Icon(
                    Icons.logout,
                    color: Hx.terra,
                    size: 20,
                  ),
                  label: const Text(
                    "LOG OUT",
                    style: TextStyle(
                      color: Hx.terra,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 2.0,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(
                      color: Hx.terra,
                      width: 2.5,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: _confirmLogout,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============ TOP BAR ============
  Widget _buildTopBar() {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            Navigator.pop(context);
          },
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Hx.surfaceHi,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Hx.gold, width: 2.5),
              boxShadow: [
                BoxShadow(
                  color: Hx.gold.withOpacity(0.25),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.arrow_back_ios_new,
              color: Hx.gold,
              size: 16,
            ),
          ),
        ),
        const SizedBox(width: 14),
        const Expanded(
          child: Text(
            "MY PROFILE",
            style: TextStyle(
              color: Hx.ivory,
              fontFamily: kFontFamily,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ],
    );
  }

  // ============ HERO AVATAR ============
  Widget _buildHeroAvatar() {
    return Column(
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: Hx.gold, width: 3),
            boxShadow: [
              BoxShadow(
                color: Hx.gold.withOpacity(0.35),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.person,
                    color: Hx.ash2,
                    size: 50,
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Text(
                widget.username.toUpperCase(),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Hx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: Hx.slate,
                shape: BoxShape.circle,
                border: Border.all(color: Hx.gold, width: 2),
              ),
              child: const Icon(
                Icons.check,
                color: Colors.white,
                size: 14,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          width: 50,
          height: 3,
          decoration: BoxDecoration(
            color: Hx.gold,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: Hx.gold,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Hx.goldDeep, width: 2),
          ),
          child: Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              fontFamily: kFontFamily,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ],
    );
  }

  // ============ UID CARD ============
  Widget _buildUidCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Hx.gold, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: Hx.gold.withOpacity(0.25),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Hx.gold,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Hx.goldDeep, width: 2),
            ),
            child: const Icon(
              FontAwesomeIcons.idCard,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "UID / ID",
                  style: TextStyle(
                    color: Hx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.uid ?? "Tidak tersedia",
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: const TextStyle(
                    color: Hx.ivory,
                    fontFamily: kFontFamily,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          if (widget.uid != null && widget.uid!.isNotEmpty)
            GestureDetector(
              onTap: () => _copyToClipboard(widget.uid!, "UID"),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Hx.gold, width: 2),
                ),
                child: const Icon(
                  Icons.copy,
                  color: Hx.gold,
                  size: 16,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============ SECTION DIVIDER ============
  Widget _buildSectionDivider(String label) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: Hx.gold,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          label,
          style: const TextStyle(
            color: Hx.ivory,
            fontFamily: kFontFamily,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            height: 2,
            color: Hx.gold.withOpacity(0.3),
          ),
        ),
      ],
    );
  }

  // ============ INFO ITEM ============
  Widget _buildInfoItem({
    required IconData icon,
    required String label,
    required String value,
    String? copyValue,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Hx.gold, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: Hx.gold.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Hx.gold.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Hx.gold, width: 2),
            ),
            child: Icon(
              icon,
              color: Hx.gold,
              size: 18,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: const TextStyle(
                    color: Hx.ash,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: const TextStyle(
                    color: Hx.ivory,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFontFamily,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          if (copyValue != null && copyValue.isNotEmpty)
            GestureDetector(
              onTap: () => _copyToClipboard(copyValue, label),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Hx.gold, width: 2),
                ),
                child: const Icon(
                  Icons.copy,
                  color: Hx.gold,
                  size: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }
}