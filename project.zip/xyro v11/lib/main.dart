// lib/main.dart
import 'package:flutter/material.dart';
import 'pertama.dart';
import 'landing.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'control_panel.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ThemeController.instance.load();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ThemeController.instance,
      builder: (context, _) {
        final p = ThemeController.instance.palette;

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'XYRO',
          theme: ThemeData(
            brightness: p.comic ? Brightness.light : Brightness.dark,
            fontFamily: 'ShareTechMono',
            scaffoldBackgroundColor: p.bg,
            colorScheme: ColorScheme.fromSeed(
              seedColor: p.primary,
              brightness: p.comic ? Brightness.light : Brightness.dark,
              background: p.bg,
              surface: p.surface,
            ),
            primaryColor: p.primary,
            appBarTheme: AppBarTheme(
              backgroundColor: p.surface,
              foregroundColor: p.textPrimary,
              iconTheme: IconThemeData(color: p.textPrimary),
            ),
            iconTheme: IconThemeData(color: p.textPrimary),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: p.primary,
                foregroundColor: p.onPrimary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: p.textSecondary),
            ),
            outlinedButtonTheme: OutlinedButtonThemeData(
              style: OutlinedButton.styleFrom(
                foregroundColor: p.textPrimary,
                side: BorderSide(color: p.borderStrong),
              ),
            ),
            floatingActionButtonTheme: FloatingActionButtonThemeData(
              backgroundColor: p.surfaceAlt,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: p.surfaceAlt,
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: p.comic ? p.comicBorder : p.borderStrong,
                  width: p.comic ? 2 : 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: p.comic ? p.comicBorder : p.border,
                  width: p.comic ? 2 : 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            snackBarTheme: SnackBarThemeData(
              backgroundColor: p.surface,
              contentTextStyle: TextStyle(color: p.textPrimary),
            ),
          ),

          initialRoute: '/fingerprint',

          onGenerateRoute: (settings) {
            switch (settings.name) {
              case '/fingerprint':
                return MaterialPageRoute(
                  builder: (_) => const PertamaPage(),
                );

              case '/':
              case '/landing':
                return MaterialPageRoute(
                  builder: (_) => const LandingPage(),
                );

              case '/login':
                return MaterialPageRoute(
                  builder: (_) => const LoginPage(),
                );

              case '/dashboard':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => DashboardPage(
                    username: args['username'],
                    password: args['password'],
                    role: args['role'],
                    sessionKey: args['key'],
                    expiredDate: args['expiredDate'],
                    listBug:
                        List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                    listDoos:
                        List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                    uid: args['uid'],
                    // news: HAPUS
                  ),
                );

              case '/home':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => HomePage(
                    username: args['username'],
                    password: args['password'],
                    listBug:
                        List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                    role: args['role'],
                    expiredDate: args['expiredDate'],
                    sessionKey: args['sessionKey'],
                  ),
                );

              case '/seller':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => SellerPage(keyToken: args['keyToken']),
                );

              case '/admin':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => AdminPage(sessionKey: args['sessionKey']),
                );

              case '/owner':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => OwnerPage(
                    sessionKey: args['sessionKey'],
                    username: args['username'],
                  ),
                );

              case '/control_panel':
                final args = settings.arguments as Map<String, dynamic>?;
                return MaterialPageRoute(
                  builder: (_) => ControlPanelPage(
                    targetDevice: args != null
                        ? args['targetDevice'] as Map<String, dynamic>?
                        : null,
                    role: args != null
                        ? (args['role']?.toString() ?? 'owner')
                        : 'owner',
                  ),
                );

              default:
                return MaterialPageRoute(
                  builder: (_) => Scaffold(
                    body: const Center(child: Text("404 - Not Found")),
                  ),
                );
            }
          },
        );
      },
    );
  }
}