// lib/banned.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const String kFontFamily = 'Ganang';
const String kBaseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class BannedHx {
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);
  static const surfaceHi  = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  static const gold      = Color(0xFFFFFFFF);
  static const goldLight = Color(0xFFE0E0E0);
  static const goldDeep  = Color(0xFF808080);

  static const jade   = Color(0xFF4ADE80);
  static const slate  = Color(0xFF60A5FA);
  static const amber  = Color(0xFFFBBF24);
  static const purple = Color(0xFFA78BFA);
  static const terra  = Color(0xFFF87171);

  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
}

class BannedPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const BannedPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<BannedPage> createState() => _BannedPageState();
}

class _BannedPageState extends State<BannedPage>
    with TickerProviderStateMixin {
  final groupController = TextEditingController();

  late AnimationController _entranceController;

  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoFailed = false;
  int _videoRetryCount = 0;

  String selectedBugId = "";
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMessage;

  int _globalSenderCount = 0;
  int _privateSenderCount = 0;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase().trim();
    return r == 'owner' || r == 'admin' || r == 'vip' || r == 'pemula';
  }

  List<Map<String, dynamic>> get _filteredBugs {
    return widget.listBug.where((bug) {
      final type = bug['type']?.toString().toLowerCase() ?? '';
      return type == 'banned';
    }).toList();
  }

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    final filtered = _filteredBugs;
    if (filtered.isNotEmpty) {
      selectedBugId = filtered[0]['bug_id'];
    }

    _initVideo();
    _fetchSenderStats();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    groupController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BANNER
  // ═══════════════════════════════════════════════════════════
  Future<void> _initVideo() async {
    if (_videoController != null) {
      try {
        await _videoController!.dispose();
      } catch (_) {}
      _videoController = null;
    }
    if (!mounted) return;
    setState(() {
      _videoReady = false;
      _videoFailed = false;
    });

    try {
      final controller = VideoPlayerController.asset('assets/ooo.mp4');
      await controller.setVolume(1.0); // ✅ SUARA NYALA
      await controller.setLooping(true);
      await controller.initialize();
      await controller.play();

      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoReady = true;
        _videoFailed = false;
      });
    } catch (e) {
      debugPrint('Video error: $e');
      if (_videoRetryCount < 3 && mounted) {
        _videoRetryCount++;
        Future.delayed(const Duration(milliseconds: 500), _initVideo);
      } else {
        if (mounted) setState(() => _videoFailed = true);
      }
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final url = "$kBaseUrl/getSenderStats?key=${widget.sessionKey}";
      final res = await http
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['success'] == true) {
          if (!mounted) return;
          setState(() {
            _globalSenderCount = data['global'] ?? 0;
            _privateSenderCount = data['private'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint('Sender stats error: $e');
    }
  }

  bool isValidGroupLink(String input) {
    final trimmed = input.trim();
    return trimmed.startsWith('https://') &&
        trimmed.contains('chat.whatsapp.com');
  }

  Future<void> _sendBanned() async {
    if (_isSending) return;
    final rawInput = groupController.text.trim();
    final key = widget.sessionKey;

    if (!isValidGroupLink(rawInput)) {
      _showAlert("INVALID LINK",
          "Masukkan link WhatsApp Group yang valid.\nContoh: https://chat.whatsapp.com/xxxxx");
      return;
    }

    if (_senderType == 'global' && !canAccessGlobalSender) {
      _showAlert('ACCESS DENIED',
          'Global Sender hanya untuk Owner, Admin, VIP & Pemula!');
      return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert("NO PAYLOAD", "Pilih payload BANNED terlebih dahulu.");
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final url = Uri.parse(
          "$kBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId"
          "${_senderType == 'global' ? '&senderMode=global' : ''}");
      final res = await http.get(url).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown. Tunggu sebentar.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Session expired.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Server maintenance.");
      } else {
        HapticFeedback.heavyImpact();
        setState(() => _responseMessage = "✅ BANNED berhasil dikirim!");
        groupController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Terjadi kesalahan.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: BannedHx.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: BannedHx.ivory.withOpacity(0.08),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1,
                  ),
                ),
                child: const Icon(Icons.info_outline_rounded,
                    color: BannedHx.ivory, size: 26),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: BannedHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: BannedHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                        color: Colors.white.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      color: BannedHx.ivory,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSenderSelectorBottomSheet() {
    if (!canAccessGlobalSender) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: EdgeInsets.fromLTRB(
            22,
            18,
            22,
            22 + MediaQuery.of(context).padding.bottom,
          ),
          decoration: const BoxDecoration(
            color: BannedHx.bgAlt,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: BannedHx.ash2,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Container(
                    width: 3,
                    height: 14,
                    color: BannedHx.ivory,
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "SELECT SENDER",
                    style: TextStyle(
                      color: BannedHx.ivory,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      letterSpacing: 2.2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildBottomSheetOption(
                icon: Icons.person,
                label: "PRIVATE",
                count: _privateSenderCount,
                isSelected: _senderType == "private",
                onTap: () {
                  setState(() => _senderType = "private");
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 10),
              _buildBottomSheetOption(
                icon: Icons.public,
                label: "GLOBAL",
                count: _globalSenderCount,
                isSelected: _senderType == "global",
                onTap: () {
                  setState(() => _senderType = "global");
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomSheetOption({
    required IconData icon,
    required String label,
    required int count,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final accent = label == "GLOBAL" ? BannedHx.ivory : BannedHx.jade;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? accent.withOpacity(0.08)
              : BannedHx.surfaceHi,
          border: Border.all(
            color: isSelected
                ? accent.withOpacity(0.4)
                : Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.12),
                border: Border.all(
                  color: accent.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: accent, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: BannedHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    isSelected ? "Currently active" : "Tap to activate",
                    style: TextStyle(
                      color: isSelected ? accent : BannedHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: BannedHx.surfaceHi2,
                border: Border.all(
                  color: accent.withOpacity(0.3),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Text(
                "$count",
                style: TextStyle(
                  color: accent,
                  fontFamily: kFontFamily,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 10),
            if (isSelected)
              Icon(Icons.check_circle,
                  color: accent.withOpacity(0.8), size: 20),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EFEK HUD & SCANLINE
  // ═══════════════════════════════════════════════════════════
  Widget _buildHudCorners({double size = 14, double thickness = 1.5}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 10, left: 10, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 10, right: 10, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 10, left: 10, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 10, right: 10, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: size, height: thickness, color: BannedHx.ivory.withOpacity(0.6)),
          ),
          Positioned(
            top: top ? 0 : null, bottom: top ? null : 0, left: left ? 0 : null, right: left ? null : 0,
            child: Container(width: thickness, height: size, color: BannedHx.ivory.withOpacity(0.6)),
          ),
        ],
      ),
    );
  }

  Widget _buildScanlines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: 0.15,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.white.withOpacity(0.4), Colors.transparent],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BANNER WIDGET
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 180,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else if (_videoFailed)
              Container(
                color: BannedHx.surfaceHi2,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.videocam_off_outlined,
                          color: BannedHx.ash.withOpacity(0.5), size: 32),
                      const SizedBox(height: 8),
                      const Text('BANNED GB',
                          style: TextStyle(
                            color: BannedHx.ash,
                            fontFamily: kFontFamily,
                            fontSize: 11,
                            letterSpacing: 3,
                            fontWeight: FontWeight.w800,
                          )),
                    ],
                  ),
                ),
              )
            else
              Container(
                color: BannedHx.surfaceHi2,
                child: const Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: BannedHx.ivory,
                      strokeWidth: 2.0,
                    ),
                  ),
                ),
              ),

            // Overlay gradient
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      BannedHx.bg.withOpacity(0.25),
                      BannedHx.bg.withOpacity(0.65),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // ✅ EFEK HUD & SCANLINE
            _buildHudCorners(size: 14, thickness: 1.5),
            _buildScanlines(),

            // Badge
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: BannedHx.ivory,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'BANNED',
                  style: TextStyle(
                    color: BannedHx.bg,
                    fontSize: 9,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
            ),

            // Text overlay
            Positioned(
              left: 18,
              right: 18,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BANNED GB ATTACK',
                    style: TextStyle(
                      color: BannedHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Masukkan link GB → pilih sender → pilih payload',
                    style: TextStyle(
                      color: BannedHx.ivory.withOpacity(0.65),
                      fontFamily: kFontFamily,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.6,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INPUT LINK
  // ═══════════════════════════════════════════════════════════
  Widget _buildLinkInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _sectionLabel("WHATSAPP GROUP LINK"),
        const SizedBox(height: 10),
        Container(
          decoration: BoxDecoration(
            color: BannedHx.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
          ),
          child: TextField(
            controller: groupController,
            style: const TextStyle(
              color: BannedHx.ivory,
              fontSize: 14,
              fontFamily: kFontFamily,
              fontWeight: FontWeight.w600,
            ),
            cursorColor: BannedHx.ivory,
            keyboardType: TextInputType.url,
            minLines: 1,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: "https://chat.whatsapp.com/xxxxxxxxx",
              hintStyle: TextStyle(
                color: BannedHx.ash2,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              prefixIcon: Padding(
                padding: EdgeInsets.only(left: 14, right: 6),
                child: Icon(Icons.link, color: BannedHx.ash),
              ),
              contentPadding: EdgeInsets.symmetric(
                vertical: 18,
                horizontal: 12,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SENDER SELECTOR CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildSenderSelector() {
    final currentCount =
        _senderType == "private" ? _privateSenderCount : _globalSenderCount;
    final isGlobal = _senderType == "global";
    final accent = isGlobal ? BannedHx.ivory : BannedHx.jade;

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        _showSenderSelectorBottomSheet();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        decoration: BoxDecoration(
          color: BannedHx.surfaceHi,
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.12),
                border: Border.all(
                  color: accent.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                isGlobal ? Icons.public : Icons.person,
                color: accent,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "SENDER MODE",
                    style: TextStyle(
                      color: BannedHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.8,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Text(
                        isGlobal ? "GLOBAL" : "PRIVATE",
                        style: const TextStyle(
                          color: BannedHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: BannedHx.surfaceHi2,
                          border: Border.all(
                            color: accent.withOpacity(0.3),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          "$currentCount",
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: BannedHx.ash, size: 22),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PAYLOAD CAROUSEL (bug type == banned)
  // ═══════════════════════════════════════════════════════════
  Widget _buildPayloadCarousel() {
    final filtered = _filteredBugs;

    if (filtered.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: BannedHx.surfaceHi,
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Center(
          child: Text(
            "No BANNED payload available",
            style: TextStyle(
              color: BannedHx.ash,
              fontFamily: kFontFamily,
              fontSize: 12,
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: 116,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filtered.length,
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
        itemBuilder: (context, index) {
          final bug = filtered[index];
          final isSelected = bug['bug_id'] == selectedBugId;

          return TweenAnimationBuilder(
            tween: Tween<double>(begin: 0.85, end: 1.0),
            duration: Duration(milliseconds: 320 + index * 70),
            curve: Curves.easeOutBack,
            builder: (context, double scale, child) =>
                Transform.scale(scale: scale, child: child),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() => selectedBugId = bug['bug_id']);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutCubic,
                width: 152,
                margin: const EdgeInsets.only(right: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.white.withOpacity(0.08)
                      : BannedHx.surfaceHi,
                  border: Border.all(
                    color: isSelected
                        ? Colors.white.withOpacity(0.3)
                        : Colors.white.withOpacity(0.08),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.gavel_rounded,
                      color: isSelected ? BannedHx.ivory : BannedHx.ash,
                      size: 22,
                    ),
                    const SizedBox(height: 7),
                    Text(
                      bug['bug_name'] ?? 'Payload ${index + 1}',
                      style: TextStyle(
                        color: isSelected ? BannedHx.ivory : BannedHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'ID ${bug['bug_id']}',
                      style: TextStyle(
                        color: isSelected
                            ? BannedHx.ash
                            : BannedHx.ash2,
                        fontFamily: kFontFamily,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SEND BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildSendButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: BannedHx.ivory,
      ),
      child: SizedBox(
        height: 58,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _isSending
                ? null
                : () {
                    HapticFeedback.mediumImpact();
                    _sendBanned();
                  },
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      height: 24,
                      width: 24,
                      child: CircularProgressIndicator(
                        color: BannedHx.bg,
                        strokeWidth: 2.5,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.gavel_rounded,
                            color: BannedHx.bg, size: 20),
                        SizedBox(width: 12),
                        Text(
                          "EXECUTE BANNED",
                          style: TextStyle(
                            color: BannedHx.bg,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 2.5,
                            fontFamily: kFontFamily,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color accent;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      accent = BannedHx.jade;
      icon = Icons.check_circle_outline;
    } else if (_responseMessage!.startsWith('❌')) {
      accent = BannedHx.terra;
      icon = Icons.error_outline;
    } else {
      accent = BannedHx.ivory;
      icon = Icons.info_outline;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: BannedHx.surfaceHi,
          border: Border.all(
            color: accent.withOpacity(0.3),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(icon, color: accent, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(
                  color: accent,
                  fontWeight: FontWeight.w800,
                  fontSize: 12.5,
                  fontFamily: kFontFamily,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 3,
            height: 12,
            color: BannedHx.ivory,
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: const TextStyle(
              color: BannedHx.ivory,
              fontWeight: FontWeight.w900,
              fontSize: 11,
              fontFamily: kFontFamily,
              letterSpacing: 2.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStaggeredEntry({required int index, required Widget child}) {
    const int total = 6;
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BannedHx.bg,
      appBar: AppBar(
        backgroundColor: BannedHx.bg,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new,
              color: BannedHx.ivory, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "BANNED GB",
          style: TextStyle(
            color: BannedHx.ivory,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w900,
            fontSize: 15,
            letterSpacing: 2.5,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),  // atas: hitam murni
              Color(0xFF0A0A0A),  // bawah: hitam sedikit terang
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildStaggeredEntry(
                  index: 0,
                  child: _buildVideoBanner(),
                ),
                const SizedBox(height: 20),

                _buildStaggeredEntry(
                  index: 1,
                  child: _buildLinkInput(),
                ),
                const SizedBox(height: 18),

                if (canAccessGlobalSender) ...[
                  _buildStaggeredEntry(
                    index: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _sectionLabel("SENDER MODE"),
                        const SizedBox(height: 10),
                        _buildSenderSelector(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                ],

                _buildStaggeredEntry(
                  index: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _sectionLabel("SELECT PAYLOAD BANNED"),
                      const SizedBox(height: 10),
                      _buildPayloadCarousel(),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                _buildStaggeredEntry(
                  index: 4,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildSendButton(),
                      _buildResponseMessage(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}