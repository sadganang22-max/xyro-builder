// lib/domain_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

const String kFontFamily = 'Ganang';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<dynamic>? _subdomainsData;
  String? _errorMessage;

  @override
  void dispose() {
    _domainController.dispose();
    super.dispose();
  }

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      HapticFeedback.vibrate();
      setState(() {
        _errorMessage = "Domain tidak boleh kosong.";
        _dnsData = null;
        _subdomainsData = null;
      });
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _subdomainsData = null;
    });

    try {
      final dnsResult = await _fetchDnsInfo(domain);
      final subdoResult = await _fetchSubdomains(domain);

      if (!mounted) return;
      if (dnsResult != null && subdoResult != null) {
        setState(() {
          _dnsData = dnsResult;
          _subdomainsData = subdoResult;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data domain.";
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<Map<String, dynamic>?> _fetchDnsInfo(String domain) async {
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/dns?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  Future<List<dynamic>?> _fetchSubdomains(String domain) async {
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/subdomains?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  void _copyToClipboard(String text, String label) {
    HapticFeedback.selectionClick();
    Clipboard.setData(ClipboardData(text: text));
    final p = context.theme;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$label disalin ke clipboard',
          style: TextStyle(
            color: p.textPrimary,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w700,
          ),
        ),
        backgroundColor: p.surfaceAlt,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "DOMAIN OSINT",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
              child: Column(
                children: [
                  _buildInputSection(p),
                  const SizedBox(height: 16),
                  if (_errorMessage != null) ...[
                    _buildErrorBox(p, _errorMessage!),
                    const SizedBox(height: 16),
                  ],
                  if (_dnsData != null || _subdomainsData != null)
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          children: [
                            if (_dnsData != null)
                              _buildCategoryCard(
                                p: p,
                                title: "INFORMASI DOMAIN",
                                icon: Icons.domain,
                                children: [
                                  _buildInfoRow(
                                    p: p,
                                    label: "Domain",
                                    value: _dnsData!['unicodeDomain']
                                        ?.toString(),
                                    showCopyButton: true,
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Punycode",
                                    value: _dnsData!['punycodeDomain']
                                        ?.toString(),
                                    showCopyButton: true,
                                  ),
                                  ..._buildDnsRecords(p),
                                ],
                              ),
                            const SizedBox(height: 14),
                            if (_subdomainsData != null)
                              _buildCategoryCard(
                                p: p,
                                title: "SUBDOMAINS",
                                icon: Icons.list_alt,
                                children: _buildSubdomainsList(p),
                              ),
                            const SizedBox(height: 14),
                            if (_dnsData != null &&
                                _dnsData!['records'] != null)
                              _buildCategoryCard(
                                p: p,
                                title: "INFORMASI SERVER",
                                icon: Icons.dns_outlined,
                                children: [
                                  if (_dnsData!['records']['a']?['query']
                                          ?['server'] !=
                                      null)
                                    _buildInfoRow(
                                      p: p,
                                      label: "DNS Server",
                                      value: _dnsData!['records']['a']!['query']!
                                              ['server']!['ip']
                                          ?.toString(),
                                      showCopyButton: true,
                                    ),
                                  if (_dnsData!['records']['a']?['query']
                                          ?['server']?['location'] !=
                                      null)
                                    _buildInfoRow(
                                      p: p,
                                      label: "Lokasi Server",
                                      value:
                                          "Lat: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lat']}, Lon: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lon']}",
                                    ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  BoxDecoration _kotakDecoration(AppPalette p, {bool withShadow = true}) {
    return BoxDecoration(
      color: p.surfaceAlt,
      border: Border.all(
        color: Colors.white.withOpacity(0.7),
        width: 1.5,
      ),
      boxShadow: withShadow
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ]
          : null,
    );
  }

  // ── INPUT ──
  Widget _buildInputSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: TextField(
              controller: _domainController,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: p.textPrimary,
              onSubmitted: (_) => _checkDomain(),
              decoration: InputDecoration(
                hintText: 'Contoh: google.com',
                hintStyle: TextStyle(
                  color: p.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                prefixIcon: Icon(Icons.domain, color: p.textTertiary, size: 20),
                suffixIcon: _isLoading
                    ? Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: p.textPrimary,
                            strokeWidth: 2,
                          ),
                        ),
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _checkDomain,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isLoading ? Icons.hourglass_top : Icons.search,
                    size: 18,
                    color: p.bg,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _isLoading ? 'MEMPROSES...' : 'CEK DOMAIN',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── ERROR BOX ──
  Widget _buildErrorBox(AppPalette p, String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(color: p.danger, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: p.danger, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── CATEGORY CARD ──
  Widget _buildCategoryCard({
    required AppPalette p,
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: _kotakDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border(
                bottom: BorderSide(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: p.textPrimary, size: 18),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFontFamily,
                    letterSpacing: 2.0,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  // ── INFO ROW ──
  Widget _buildInfoRow({
    required AppPalette p,
    required String label,
    required String? value,
    bool showCopyButton = false,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.bg,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: kFontFamily,
                  ),
                ),
              ],
            ),
          ),
          if (showCopyButton)
            GestureDetector(
              onTap: () => _copyToClipboard(value, label),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: p.surfaceAlt,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  Icons.copy,
                  color: p.textPrimary,
                  size: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── DNS RECORDS ──
  List<Widget> _buildDnsRecords(AppPalette p) {
    if (_dnsData == null || _dnsData!['records'] == null) return [];

    final records = _dnsData!['records'] as Map<String, dynamic>;
    final widgets = <Widget>[];

    // NS Records
    if (records['ns']?['response']?['answer'] != null) {
      final nsRecords = records['ns']!['response']!['answer'] as List;
      if (nsRecords.isNotEmpty) {
        widgets.addAll([
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 10),
            child: Row(
              children: [
                Text(
                  'NAME SERVERS',
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.15),
                  ),
                ),
              ],
            ),
          ),
          ...nsRecords.map((record) => _buildInfoRow(
                p: p,
                label: 'NS Record',
                value: record['record']?['target']?.toString(),
                showCopyButton: true,
              )),
        ]);
      }
    }

    // SOA Record
    if (records['soa']?['response']?['answer'] != null) {
      final soaRecords = records['soa']!['response']!['answer'] as List;
      if (soaRecords.isNotEmpty) {
        final soa = soaRecords.first['record'];
        widgets.addAll([
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 10),
            child: Row(
              children: [
                Text(
                  'SOA RECORD',
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.15),
                  ),
                ),
              ],
            ),
          ),
          _buildInfoRow(
            p: p,
            label: 'Primary NS',
            value: soa?['host']?.toString(),
            showCopyButton: true,
          ),
          _buildInfoRow(
            p: p,
            label: 'Admin Email',
            value: soa?['admin']?.toString(),
            showCopyButton: true,
          ),
          _buildInfoRow(p: p, label: 'Serial', value: soa?['serial']?.toString()),
          _buildInfoRow(p: p, label: 'Refresh', value: soa?['refresh']?.toString()),
          _buildInfoRow(p: p, label: 'Retry', value: soa?['retry']?.toString()),
          _buildInfoRow(p: p, label: 'Expire', value: soa?['expire']?.toString()),
          _buildInfoRow(p: p, label: 'Minimum TTL', value: soa?['minimum']?.toString()),
        ]);
      }
    }

    // A Records
    if (records['a']?['response']?['answer'] != null) {
      final aRecords = records['a']!['response']!['answer'] as List;
      if (aRecords.isNotEmpty) {
        widgets.addAll([
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 10),
            child: Row(
              children: [
                Text(
                  'A RECORDS',
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.15),
                  ),
                ),
              ],
            ),
          ),
          ...aRecords.map((record) => _buildInfoRow(
                p: p,
                label: 'A Record',
                value: record['record']?['data']?.toString(),
                showCopyButton: true,
              )),
        ]);
      }
    }

    return widgets;
  }

  // ── SUBDOMAINS ──
  List<Widget> _buildSubdomainsList(AppPalette p) {
    if (_subdomainsData == null) return [];

    final cleanSubdomains = _subdomainsData!
        .map((item) => item.toString().split('\n').last.trim())
        .where((subdomain) => subdomain.isNotEmpty && !subdomain.startsWith('*'))
        .toSet()
        .toList()
      ..sort();

    return [
      Text(
        'Ditemukan ${cleanSubdomains.length} subdomain',
        style: TextStyle(
          color: p.textTertiary,
          fontSize: 11,
          fontFamily: kFontFamily,
          fontWeight: FontWeight.w600,
        ),
      ),
      const SizedBox(height: 10),
      ...cleanSubdomains.map((subdomain) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.link, color: p.textTertiary, size: 14),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    subdomain,
                    style: TextStyle(
                      color: p.textPrimary,
                      fontSize: 12,
                      fontFamily: kFontFamily,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => _copyToClipboard(subdomain, 'Subdomain'),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: p.surfaceAlt,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.7),
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      Icons.copy,
                      color: p.textPrimary,
                      size: 12,
                    ),
                  ),
                ),
              ],
            ),
          )),
    ];
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}