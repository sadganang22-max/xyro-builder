// lib/login_page.dart
import 'dart:math' as math;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dashboard_page.dart';
import 'splash_video_page.dart';
import 'widgets/custom_popup.dart';
import 'theme.dart';

const String baseUrl = "http://www.rexylegal.rxpedia.web.id:2060";
const String kFontFamily = 'Ganang';
const String kBrandName = 'XYRO';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class LoginHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  // ── CARD ──
  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // ── PINK FAMILY ──
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  // ── AKSEN CUTE ──
  static const jade     = Color(0xFF6EE7B7);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFFF7A9A);
  static const slate    = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);

  // ── TEXT ──
  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
  static const lineSoft = Color(0x0DFF6FA5);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _entranceController;
  late AnimationController _pulseController;
  late AnimationController _sparkleController;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _sparkleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();

    initLogin();
  }

  // ═══ OPEN TELEGRAM ═══
  Future<void> _openTelegram() async {
    HapticFeedback.mediumImpact();

    final Uri tgApp = Uri.parse('tg://resolve?domain=hann_xd');
    final Uri tgWeb = Uri.parse('https://t.me/hann_xd');

    try {
      final launched = await launchUrl(
        tgApp,
        mode: LaunchMode.externalApplication,
      );
      if (launched) return;
    } catch (_) {}

    try {
      final launched = await launchUrl(
        tgWeb,
        mode: LaunchMode.externalNonBrowserApplication,
      );
      if (launched) return;
    } catch (_) {}

    try {
      final launched = await launchUrl(tgWeb, mode: LaunchMode.platformDefault);
      if (launched) return;
    } catch (_) {}

    if (!mounted) return;
    final p = context.theme;
    CustomPopup.show(
      context,
      title: "Tidak Bisa Membuka Link",
      message: "Silakan buka manual di browser:\nhttps://t.me/hann_xd",
      icon: Icons.error_outline,
      iconColor: p.danger,
      confirmText: "OK",
    );
  }

  // ═══ LOGIN INIT ═══
  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SplashVideoPage(
                  username: savedUser,
                  password: savedPass,
                  role: data['role'],
                  sessionKey: data['key'],
                  expiredDate: data['expiredDate'],
                  listBug: (data['listBug'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  listDoos: (data['listDDoS'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  uid: data['uid'],
                ),
              ),
            );
          }
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (e) {
      return "unknown_device";
    }
  }

  // ═══ LOGIN ═══
  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    HapticFeedback.mediumImpact();

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();
        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "Sesi Aktif",
            message:
                "Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama.",
          );
        } else {
          _showPopup(
            title: "Login Gagal",
            message: "Username atau password salah.",
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashVideoPage(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (validData['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                uid: validData['uid'],
              ),
            ),
          );
        }
      }
    } catch (e) {
      _showPopup(
        title: "Connection Error",
        message: "Gagal terhubung ke server.",
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    bool showContact = false,
  }) {
    final p = context.theme;
    final bool isError = title.toLowerCase().contains("gagal") ||
        title.toLowerCase().contains("expired") ||
        title.toLowerCase().contains("error");

    CustomPopup.show(
      context,
      title: title,
      message: message,
      icon: isError ? Icons.error_outline : Icons.info_outline,
      iconColor: isError ? p.danger : p.info,
      cancelText: showContact ? "Contact Admin" : null,
      onCancel: showContact ? _openTelegram : null,
      confirmText: "Close",
    );
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _pulseController.dispose();
    _sparkleController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 8;
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 34 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ThemeController.instance,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: LoginHx.bg,
          resizeToAvoidBottomInset: true,
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1A0E14),
                  Color(0xFF241318),
                ],
              ),
            ),
            child: SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 22, vertical: 24),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 430),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _staggered(index: 0, child: _buildTopBadge()),
                        const SizedBox(height: 26),
                        _staggered(index: 1, child: _buildCrestLogo()),
                        const SizedBox(height: 22),
                        _staggered(index: 2, child: _buildTitleBlock()),
                        const SizedBox(height: 34),
                        _staggered(index: 3, child: _buildBannerImage()),
                        const SizedBox(height: 24),
                        _staggered(index: 4, child: _buildFormCard()),
                        const SizedBox(height: 22),
                        _staggered(index: 5, child: _buildFooter()),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══ TOP BADGE — pink cute ═══
  Widget _buildTopBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: LoginHx.surfaceHi,
        border: Border.all(
          color: LoginHx.pink.withOpacity(0.3),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(100),
        boxShadow: [
          BoxShadow(
            color: LoginHx.pink.withOpacity(0.15),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) {
              final v = 0.5 + 0.5 * _pulseController.value;
              return Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: LoginHx.pink.withOpacity(v),
                  boxShadow: [
                    BoxShadow(
                      color: LoginHx.pink.withOpacity(v),
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(width: 8),
          const Text(
            "NAXRAT SECURE ACCESS",
            style: TextStyle(
              color: LoginHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 3.0,
            ),
          ),
        ],
      ),
    );
  }

  // ═══ CREST LOGO — pink gradient ═══
  Widget _buildCrestLogo() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _sparkleController]),
      builder: (context, _) {
        final pulse = _pulseController.value;
        return SizedBox(
          width: 130, height: 130,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Sparkle ring rotating — pink
              Transform.rotate(
                angle: _sparkleController.value * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(130, 130),
                  painter: _SparkleRingPainter(),
                ),
              ),

              // Pulse halo ring (pink)
              Container(
                width: 108 + (12 * pulse),
                height: 108 + (12 * pulse),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: LoginHx.pink.withOpacity(0.5 - 0.3 * pulse),
                    width: 1.2,
                  ),
                ),
              ),

              // Static ring dalam (card)
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: LoginHx.surfaceHi,
                  border: Border.all(
                    color: LoginHx.pink.withOpacity(0.3),
                    width: 1,
                  ),
                ),
              ),

              // Center crest — gradient pink + glow
              Container(
                width: 84, height: 84,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [LoginHx.pinkLight, LoginHx.pinkDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: LoginHx.pink.withOpacity(0.6),
                      blurRadius: 22,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Center(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/logo.png',
                      fit: BoxFit.cover,
                      width: 78, height: 78,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.favorite_rounded,
                        color: Colors.white,
                        size: 36,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══ TITLE BLOCK — pink gradient ═══
  Widget _buildTitleBlock() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [LoginHx.pinkLight, LoginHx.pinkDeep],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
          child: const Text(
            "XYRO ACCESS ♡",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontFamily: kFontFamily,
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: 4.0,
              height: 1.05,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 22, height: 1,
              color: LoginHx.pink.withOpacity(0.4),
            ),
            const SizedBox(width: 12),
            const Text(
              "P R E M I U M   S Y S T E M",
              style: TextStyle(
                color: LoginHx.ash,
                fontFamily: kFontFamily,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 3.2,
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 22, height: 1,
              color: LoginHx.pink.withOpacity(0.4),
            ),
          ],
        ),
      ],
    );
  }

  // ═══ BANNER IMAGE — pink glow ═══
  Widget _buildBannerImage() {
    return Container(
      width: double.infinity,
      height: 130,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: LoginHx.pink.withOpacity(0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: LoginHx.pink.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 1,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/banner.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: LoginHx.surfaceHi2,
                child: const Center(
                  child: Icon(
                    Icons.image_rounded,
                    color: LoginHx.pinkLight,
                    size: 34,
                  ),
                ),
              ),
            ),

            // Gradient overlay
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      LoginHx.bg.withOpacity(0.25),
                      LoginHx.bg.withOpacity(0.55),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // Badge PREMIUM — pink gradient
            Positioned(
              top: 10, right: 10,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 9, vertical: 4,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [LoginHx.pinkLight, LoginHx.pinkDeep],
                  ),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: LoginHx.pink.withOpacity(0.6),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'PREMIUM ♡',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 8.5,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ FORM CARD — pink border ═══
  Widget _buildFormCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: LoginHx.surfaceHi,
        border: Border.all(
          color: LoginHx.pink.withOpacity(0.3),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: LoginHx.pink.withOpacity(0.15),
            blurRadius: 20,
            spreadRadius: 1,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildTextField(
              controller: userController,
              label: "USERNAME",
              hint: "Enter your username",
              icon: Icons.person_rounded,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: passController,
              label: "PASSWORD",
              hint: "Enter your password",
              icon: Icons.lock_rounded,
              isPassword: true,
            ),
            const SizedBox(height: 24),
            _buildSignInButton(),
          ],
        ),
      ),
    );
  }

  // ═══ TEXT FIELD — pink accent ═══
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded, color: LoginHx.pink, size: 12),
              const SizedBox(width: 7),
              Text(
                label,
                style: const TextStyle(
                  color: LoginHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.4,
                ),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: LoginHx.surfaceHi2,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: LoginHx.pink.withOpacity(0.25),
              width: 1,
            ),
          ),
          child: TextFormField(
            controller: controller,
            obscureText: isPassword ? _obscurePassword : false,
            style: const TextStyle(
              color: LoginHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 14.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.2,
            ),
            cursorColor: LoginHx.pink,
            validator: (val) {
              if (val == null || val.trim().isEmpty) return "Required";
              return null;
            },
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: LoginHx.ash2,
                fontFamily: kFontFamily,
                fontSize: 13.5,
                fontWeight: FontWeight.w500,
              ),
              prefixIcon: Icon(icon, color: LoginHx.pinkLight, size: 19),
              suffixIcon: isPassword
                  ? IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_off_rounded
                            : Icons.visibility_rounded,
                        color: LoginHx.pinkLight,
                        size: 19,
                      ),
                      onPressed: () => setState(
                          () => _obscurePassword = !_obscurePassword),
                    )
                  : null,
              border: InputBorder.none,
              errorStyle: const TextStyle(
                color: LoginHx.terra,
                fontFamily: kFontFamily,
                fontSize: 10.5,
                height: 0.9,
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 16,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ═══ SIGN IN BUTTON — gradient pink ═══
  Widget _buildSignInButton() {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(
          colors: [LoginHx.pinkLight, LoginHx.pinkDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: LoginHx.pink.withOpacity(0.55),
            blurRadius: 18,
            spreadRadius: 2,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: isLoading ? null : login,
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 24, height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "SIGN IN ♡",
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: kFontFamily,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.8,
                        ),
                      ),
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_forward_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  // ═══ FOOTER — pink accent ═══
  Widget _buildFooter() {
    return GestureDetector(
      onTap: _openTelegram,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: LoginHx.surfaceHi,
          border: Border.all(
            color: LoginHx.pink.withOpacity(0.25),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: LoginHx.pink.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.telegram_rounded,
              color: LoginHx.pinkLight,
              size: 14,
            ),
            const SizedBox(width: 8),
            const Text(
              "Need access? Contact admin",
              style: TextStyle(
                color: LoginHx.ash,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SPARKLE RING PAINTER — PINK stars di sekeliling crest
// ═══════════════════════════════════════════════════════════════
class _SparkleRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6;

    // 4 sparkle points — pink
    for (int i = 0; i < 4; i++) {
      final angle = (i / 4) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final sparklePaint = Paint()
        ..color = LoginHx.pinkLight.withOpacity(0.7)
        ..style = PaintingStyle.fill;

      _drawStar(canvas, Offset(x, y), 6, sparklePaint);
    }
  }

  void _drawStar(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx + size * 0.3, center.dy - size * 0.3);
    path.lineTo(center.dx + size, center.dy);
    path.lineTo(center.dx + size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx, center.dy + size);
    path.lineTo(center.dx - size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx - size, center.dy);
    path.lineTo(center.dx - size * 0.3, center.dy - size * 0.3);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparkleRingPainter old) => false;
}