// lib/dashboard_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'pilih_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'devices_page.dart';
import 'pemula_page.dart';
import 'acc.dart';
import 'chat.dart';
import 'quran.dart';
import 'trading.dart';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg     = Color(0xFF1A0E14);
  static const bgAlt  = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  static const jade     = Color(0xFF6EE7B7);
  static const terra    = Color(0xFFFF7A9A);
  static const slate    = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);
  static const rose     = Color(0xFFFF9EC4);
  static const amber    = Color(0xFFFFD58A);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFFFFFF);
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  WebSocketChannel? channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox.shrink();

  int onlineUsers = 0;
  int activeConnections = 0;

  bool _entranceVisible = false;

  // MUSIC
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isMusicPlaying = false;
  Duration _musicDuration = Duration.zero;
  Duration _musicPosition = Duration.zero;
  StreamSubscription? _durationSub;
  StreamSubscription? _positionSub;
  StreamSubscription? _stateSub;

  // PRAYER
  bool _prayerLoading = true;
  String _prayerCity = '';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerName = '';
  String _nextPrayerTime = '';
  Timer? _prayerTimer;

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    uid = widget.uid;

    _selectedPage = _buildNewsPage();

    Future.microtask(() {
      if (mounted) setState(() => _entranceVisible = true);
    });

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _setupMusicPlayer();
    _loadPrayerTimes();

    _prayerTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) _updateNextPrayer();
    });
  }

  @override
  void dispose() {
    try {
      channel?.sink.close(status.goingAway);
    } catch (_) {}

    _durationSub?.cancel();
    _positionSub?.cancel();
    _stateSub?.cancel();
    _audioPlayer.dispose();
    _prayerTimer?.cancel();

    super.dispose();
  }

  void _setupMusicPlayer() {
    try {
      _audioPlayer.setReleaseMode(ReleaseMode.loop);
      _audioPlayer.setVolume(0.8);

      _durationSub = _audioPlayer.onDurationChanged.listen((d) {
        if (mounted) setState(() => _musicDuration = d);
      });
      _positionSub = _audioPlayer.onPositionChanged.listen((p) {
        if (mounted) setState(() => _musicPosition = p);
      });
      _stateSub = _audioPlayer.onPlayerStateChanged.listen((s) {
        if (mounted) {
          setState(() {
            _isMusicPlaying = s == PlayerState.playing;
          });
        }
      });
    } catch (e) {
      debugPrint('Music init error: $e');
    }
  }

  Future<void> _toggleMusic() async {
    HapticFeedback.selectionClick();
    try {
      if (_isMusicPlaying) {
        await _audioPlayer.pause();
      } else {
        if (_musicPosition == Duration.zero) {
          await _audioPlayer.play(AssetSource('sound/amba.mp3'));
        } else {
          await _audioPlayer.resume();
        }
      }
    } catch (e) {
      debugPrint('Music toggle error: $e');
    }
  }

  Future<void> _stopMusic() async {
    try {
      await _audioPlayer.stop();
      if (mounted) {
        setState(() {
          _isMusicPlaying = false;
          _musicPosition = Duration.zero;
        });
      }
    } catch (_) {}
  }

  String _formatMusicTime(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════════════════
  // JADWAL SHOLAT
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadPrayerTimes() async {
    if (mounted) setState(() => _prayerLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedDate = prefs.getString('prayer_date');
      final today = DateTime.now();
      final todayStr =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';

      if (cachedDate == todayStr) {
        final cached = prefs.getString('prayer_times');
        final cachedCity = prefs.getString('prayer_city');
        if (cached != null && cachedCity != null) {
          final map = Map<String, String>.from(jsonDecode(cached));
          if (mounted) {
            setState(() {
              _prayerTimes = map;
              _prayerCity = cachedCity;
              _prayerLoading = false;
            });
            _updateNextPrayer();
          }
          return;
        }
      }

      String city = 'Jakarta';
      try {
        final ipRes = await http
            .get(Uri.parse('http://ip-api.com/json/'))
            .timeout(const Duration(seconds: 6));
        if (ipRes.statusCode == 200) {
          final ipData = jsonDecode(ipRes.body);
          city = ipData['city']?.toString() ?? 'Jakarta';
        }
      } catch (_) {}

      final res = await http
          .get(Uri.parse(
              'https://api.aladhan.com/v1/timingsByCity?city=$city&country=ID&method=11'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) {
        if (mounted) setState(() => _prayerLoading = false);
        return;
      }

      final data = jsonDecode(res.body);
      if (data['code'] != 200) {
        if (mounted) setState(() => _prayerLoading = false);
        return;
      }

      final timings = data['data']['timings'] as Map;
      final times = {
        'Subuh': (timings['Fajr']?.toString() ?? '—').substring(0, 5),
        'Dzuhur': (timings['Dhuhr']?.toString() ?? '—').substring(0, 5),
        'Ashar': (timings['Asr']?.toString() ?? '—').substring(0, 5),
        'Maghrib': (timings['Maghrib']?.toString() ?? '—').substring(0, 5),
        'Isya': (timings['Isha']?.toString() ?? '—').substring(0, 5),
      };

      await prefs.setString('prayer_date', todayStr);
      await prefs.setString('prayer_times', jsonEncode(times));
      await prefs.setString('prayer_city', city);

      if (mounted) {
        setState(() {
          _prayerTimes = times;
          _prayerCity = city;
          _prayerLoading = false;
        });
        _updateNextPrayer();
      }
    } catch (e) {
      debugPrint('Prayer error: $e');
      if (mounted) setState(() => _prayerLoading = false);
    }
  }

  void _updateNextPrayer() {
    if (_prayerTimes.isEmpty) return;

    final now = DateTime.now();
    final nowMinutes = now.hour * 60 + now.minute;

    String? nextName;
    String? nextTime;
    int nextDiff = 999999;

    final order = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
    for (final name in order) {
      final time = _prayerTimes[name];
      if (time == null || time == '—') continue;
      final parts = time.split(':');
      if (parts.length != 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      final minutes = h * 60 + m;

      final diff = minutes - nowMinutes;
      if (diff > 0 && diff < nextDiff) {
        nextDiff = diff;
        nextName = name;
        nextTime = time;
      }
    }

    if (nextName == null) {
      nextName = 'Subuh';
      nextTime = _prayerTimes['Subuh'] ?? '—';
    }

    if (mounted) {
      setState(() {
        _nextPrayerName = nextName ?? '';
        _nextPrayerTime = nextTime ?? '';
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PROFILE IMAGE
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_$username');
      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (await file.exists()) {
          if (!mounted) return;
          setState(() => _profileImage = file);
        } else {
          await prefs.remove('profile_image_$username');
        }
      }
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════
  // WEBSOCKET
  // ═══════════════════════════════════════════════════════════
  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id;
    } catch (_) {
      androidId = "unknown_device";
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse('wss://ws-dark.NAXSUS.my.id'),
      );
      channel!.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      channel!.sink.add(jsonEncode({"type": "stats"}));

      channel!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data['type'] == 'myInfo') {
              if (data['valid'] == false) {
                if (data['reason'] == 'androidIdMismatch') {
                  _handleInvalidSession(
                      "Your account has logged on another device.");
                } else if (data['reason'] == 'keyInvalid') {
                  _handleInvalidSession(
                      "Key is not valid. Please login again.");
                }
              }
            }
            if (data['type'] == 'stats') {
              if (!mounted) return;
              setState(() {
                onlineUsers = data['onlineUsers'] ?? 0;
                activeConnections = data['activeConnections'] ?? 0;
              });
            }
          } catch (_) {}
        },
        onError: (_) {},
        cancelOnError: false,
      );
    } catch (_) {}
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Hx.surfaceHi2,
            border: Border.all(color: Hx.pink.withOpacity(0.4), width: 1),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Hx.pink.withOpacity(0.25),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Hx.terra.withOpacity(0.15),
                  border: Border.all(color: Hx.terra.withOpacity(0.5), width: 1),
                ),
                child: const Icon(Icons.sentiment_dissatisfied_rounded, color: Hx.terra, size: 30),
              ),
              const SizedBox(height: 16),
              const Text(
                "SESSION EXPIRED",
                style: TextStyle(
                  color: Hx.ivory,
                  fontFamily: 'Ganang',
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Hx.ash,
                  fontFamily: 'Ganang',
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                      (route) => false,
                    );
                  },
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: Hx.pink,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      color: Hx.bg,
                      fontFamily: 'Ganang',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NAV — 7 tab
  // Index: 0=Home, 1=WA, 2=Quran, 3=Device, 4=Tools, 5=Trading, 6=Chat
  // ═══════════════════════════════════════════════════════════
  void _onBottomNavTapped(int index) {
    HapticFeedback.mediumImpact();
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = PilihPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        );
      } else if (index == 2) {
        _selectedPage = const QuranPage();
      } else if (index == 3) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DevicesPage(
              username: username,
              sessionKey: sessionKey,
            ),
          ),
        );
      } else if (index == 4) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      } else if (index == 5) {
        _selectedPage = const TradingPage();
      } else if (index == 6) {
        _selectedPage = ChatPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    HapticFeedback.mediumImpact();
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PemulaPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
    Navigator.pop(context);
  }

  // ═══════════════════════════════════════════════════════════
  // HOME
  // ═══════════════════════════════════════════════════════════
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildBannerVideoNormal(),
          const SizedBox(height: 14),
          _buildImageAndStatsRow(),
          const SizedBox(height: 22),
          _buildSectionLabel("Actions"),
          const SizedBox(height: 12),
          _buildMusicPlayer(),
          const SizedBox(height: 12),
          _buildBugSenderButton(),
          const SizedBox(height: 20),
          _buildSectionLabel("Jadwal Sholat"),
          const SizedBox(height: 12),
          _buildPrayerCard(),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildHudCorners({double size = 16, double thickness = 2}) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(top: 8, left: 8, child: _hudCorner(top: true, left: true, size: size, thickness: thickness)),
            Positioned(top: 8, right: 8, child: _hudCorner(top: true, left: false, size: size, thickness: thickness)),
            Positioned(bottom: 8, left: 8, child: _hudCorner(top: false, left: true, size: size, thickness: thickness)),
            Positioned(bottom: 8, right: 8, child: _hudCorner(top: false, left: false, size: size, thickness: thickness)),
          ],
        ),
      ),
    );
  }

  Widget _hudCorner({required bool top, required bool left, required double size, required double thickness}) {
    return SizedBox(
      width: size, height: size,
      child: Stack(
        children: [
          Positioned(
            top: top ? 0 : null,
            bottom: top ? null : 0,
            left: left ? 0 : null,
            right: left ? null : 0,
            child: Container(
              width: size,
              height: thickness,
              color: Hx.pinkLight.withOpacity(0.9),
            ),
          ),
          Positioned(
            top: top ? 0 : null,
            bottom: top ? null : 0,
            left: left ? 0 : null,
            right: left ? null : 0,
            child: Container(
              width: thickness,
              height: size,
              color: Hx.pinkLight.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerVideoNormal() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          color: Hx.surfaceHi,
          border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1.2),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Hx.pink.withOpacity(0.2),
              blurRadius: 20,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const BannerVideo(),
            _buildHudCorners(size: 16, thickness: 2),
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Hx.pink,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: Hx.pink.withOpacity(0.6),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'PREMIUM',
                  style: TextStyle(
                    color: Hx.bg,
                    fontSize: 9,
                    fontFamily: 'Ganang',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Hx.pinkLight.withOpacity(0.5), width: 1),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _LivePulseDot(),
                    SizedBox(width: 7),
                    Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontFamily: 'Ganang',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageAndStatsRow() {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 5,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Container(
                constraints: const BoxConstraints(minHeight: 140),
                decoration: BoxDecoration(
                  color: Hx.surfaceHi,
                  border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/images/pppp.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: Hx.surfaceHi2,
                        child: const Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.broken_image_rounded, color: Hx.ash2, size: 28),
                              SizedBox(height: 8),
                              Text("pppp.jpg tidak ada", style: TextStyle(color: Hx.ash2, fontSize: 10, fontFamily: 'Ganang')),
                            ],
                          ),
                        ),
                      ),
                    ),
                    _buildHudCorners(size: 12, thickness: 1.5),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 5,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.wifi_rounded,
                    label: "CONNECTED",
                    value: "$activeConnections",
                    accent: Hx.pinkLight,
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.favorite_rounded,
                    label: "ONLINE",
                    value: "$onlineUsers",
                    accent: Hx.pink,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.12),
              border: Border.all(color: accent.withOpacity(0.4), width: 1),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, color: accent, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    color: Hx.ivory,
                    fontFamily: 'Ganang',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    height: 1.0,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: accent,
                    fontFamily: 'Ganang',
                    fontSize: 8,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          Container(width: 3, height: 12, color: Hx.pinkLight),
          const SizedBox(width: 10),
          Text(
            text.toUpperCase(),
            style: const TextStyle(
              color: Hx.ivory,
              fontFamily: 'Ganang',
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(height: 1, color: Hx.pink.withOpacity(0.2)),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MUSIC PLAYER
  // ═══════════════════════════════════════════════════════════
  Widget _buildMusicPlayer() {
    final progress = _musicDuration.inMilliseconds > 0
        ? (_musicPosition.inMilliseconds / _musicDuration.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: Hx.amethyst.withOpacity(0.12),
                  border: Border.all(color: Hx.amethyst.withOpacity(0.4), width: 1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.music_note_rounded, color: Hx.amethyst, size: 22),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'NOW PLAYING',
                      style: TextStyle(color: Hx.ash, fontFamily: 'Ganang', fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.6),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'amba.mp3',
                      style: TextStyle(color: Hx.ivory, fontFamily: 'Ganang', fontSize: 13.5, fontWeight: FontWeight.w900, letterSpacing: 0.4),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: _toggleMusic,
                child: Container(
                  width: 48, height: 48,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Hx.pink),
                  child: Icon(
                    _isMusicPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: Hx.bg,
                    size: 26,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _stopMusic,
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Hx.surfaceHi2,
                    border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1),
                  ),
                  child: const Icon(Icons.stop_rounded, color: Hx.pinkLight, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 3,
              backgroundColor: Hx.surfaceHi2,
              valueColor: const AlwaysStoppedAnimation(Hx.pink),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _formatMusicTime(_musicPosition),
                style: const TextStyle(color: Hx.ash, fontFamily: 'Ganang', fontSize: 10, fontWeight: FontWeight.w700),
              ),
              Text(
                _formatMusicTime(_musicDuration),
                style: const TextStyle(color: Hx.ash, fontFamily: 'Ganang', fontSize: 10, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUG SENDER BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildBugSenderButton() {
    return _buildActionButton(
      icon: Icons.pest_control_rodent_rounded,
      label: "MANAGE BUG SENDER",
      subtitle: "Kelola sender untuk bug attack",
      accent: Hx.terra,
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Hx.surfaceHi,
            border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  border: Border.all(color: accent.withOpacity(0.4), width: 1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: accent, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(color: Hx.ivory, fontFamily: 'Ganang', fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.4),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Hx.ash, fontFamily: 'Ganang', fontSize: 11, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Hx.pinkLight, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PRAYER CARD (JADWAL SHOLAT)
  // ═══════════════════════════════════════════════════════════
  Widget _buildPrayerCard() {
    if (_prayerLoading) {
      return Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Hx.surfaceHi,
          border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(
                  color: Hx.pinkLight,
                  strokeWidth: 2,
                ),
              ),
              SizedBox(width: 12),
              Text(
                'Memuat jadwal sholat...',
                style: TextStyle(
                  color: Hx.ash,
                  fontFamily: 'Ganang',
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_prayerTimes.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Hx.surfaceHi,
          border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            const Icon(Icons.mosque_rounded, color: Hx.pinkLight, size: 30),
            const SizedBox(height: 10),
            const Text(
              'Jadwal sholat tidak tersedia',
              style: TextStyle(
                color: Hx.ivory,
                fontFamily: 'Ganang',
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: _loadPrayerTimes,
              child: const Text(
                'REFRESH',
                style: TextStyle(
                  color: Hx.pinkLight,
                  fontFamily: 'Ganang',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ),
          ],
        ),
      );
    }

    final order = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1.2),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Hx.pink.withOpacity(0.15),
            blurRadius: 14,
            spreadRadius: 1,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header: city + next prayer
          Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Hx.pinkLight, Hx.pinkDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Hx.pink.withOpacity(0.5),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.mosque_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _prayerCity.toUpperCase(),
                      style: const TextStyle(
                        color: Hx.ivory,
                        fontFamily: 'Ganang',
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.location_on_rounded,
                            color: Hx.pinkLight, size: 10),
                        const SizedBox(width: 3),
                        Text(
                          'Jadwal Sholat Hari Ini',
                          style: TextStyle(
                            color: Hx.ash.withOpacity(0.9),
                            fontFamily: 'Ganang',
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Refresh button
              GestureDetector(
                onTap: _loadPrayerTimes,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Hx.pink.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: Hx.pink.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.refresh_rounded,
                    color: Hx.pinkLight,
                    size: 16,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Next prayer banner
          if (_nextPrayerName.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Hx.pink.withOpacity(0.2),
                    Hx.pinkDeep.withOpacity(0.15),
                  ],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Hx.pink.withOpacity(0.4),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      color: Hx.pinkLight,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Hx.pink.withOpacity(0.8),
                          blurRadius: 6,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'SELANJUTNYA',
                    style: TextStyle(
                      color: Hx.pinkLight,
                      fontFamily: 'Ganang',
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '$_nextPrayerName · $_nextPrayerTime',
                    style: const TextStyle(
                      color: Hx.ivory,
                      fontFamily: 'Ganang',
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],

          // List 5 waktu
          ...order.map((name) {
            final time = _prayerTimes[name] ?? '—';
            final isNext = name == _nextPrayerName;
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: isNext
                      ? Hx.pink.withOpacity(0.15)
                      : Hx.surfaceHi2,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: isNext
                        ? Hx.pink.withOpacity(0.5)
                        : Hx.pink.withOpacity(0.15),
                    width: isNext ? 1.2 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _prayerIcon(name),
                      color: isNext ? Hx.pinkLight : Hx.ash,
                      size: 14,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        name,
                        style: TextStyle(
                          color: isNext ? Hx.ivory : Hx.ash,
                          fontFamily: 'Ganang',
                          fontSize: 12.5,
                          fontWeight:
                              isNext ? FontWeight.w900 : FontWeight.w700,
                        ),
                      ),
                    ),
                    if (isNext)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          color: Hx.pink,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'NEXT',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Ganang',
                            fontSize: 7.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                    Text(
                      time,
                      style: TextStyle(
                        color: isNext ? Hx.pinkLight : Hx.ivory,
                        fontFamily: 'Ganang',
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  IconData _prayerIcon(String name) {
    switch (name) {
      case 'Subuh':
        return Icons.nightlight_round;
      case 'Dzuhur':
        return Icons.wb_sunny_rounded;
      case 'Ashar':
        return Icons.wb_twilight_rounded;
      case 'Maghrib':
        return Icons.wb_twilight_rounded;
      case 'Isya':
        return Icons.nights_stay_rounded;
      default:
        return Icons.access_time_rounded;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DRAWER
  // ═══════════════════════════════════════════════════════════
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: Hx.bg,
      width: MediaQuery.of(context).size.width * 0.78,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
            decoration: BoxDecoration(
              color: Hx.bg,
              border: Border(bottom: BorderSide(color: Hx.pink.withOpacity(0.25), width: 1)),
            ),
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          color: Hx.pink,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Center(child: Text('M', style: TextStyle(color: Hx.bg, fontFamily: 'Ganang', fontSize: 17, fontWeight: FontWeight.w900))),
                      ),
                      const SizedBox(width: 10),
                      const Text('XYRO', style: TextStyle(color: Hx.ivory, fontFamily: 'Ganang', fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 2.8)),
                    ],
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Container(
                        width: 64, height: 64,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: Hx.pink),
                        child: ClipOval(
                          child: _profileImage != null
                              ? Image.file(_profileImage!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: Hx.bg, size: 26))
                              : const Icon(Icons.person_rounded, color: Hx.bg, size: 26),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username.toUpperCase(),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Hx.ivory, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: 'Ganang', letterSpacing: 1.0),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: Hx.pink, borderRadius: BorderRadius.circular(6)),
                              child: Text(
                                role.toUpperCase(),
                                style: const TextStyle(color: Hx.bg, fontSize: 9, fontFamily: 'Ganang', fontWeight: FontWeight.w900, letterSpacing: 1.4),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Hx.surfaceHi,
                      border: Border.all(color: Hx.pink.withOpacity(0.25), width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.schedule_rounded, color: Hx.pinkLight, size: 14),
                        const SizedBox(width: 8),
                        Text('Expires: $expiredDate', style: const TextStyle(color: Hx.ash, fontSize: 11, fontFamily: 'Ganang', fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12),
              children: [
                if (role == "reseller")
                  _buildDrawerMenuItem(icon: Icons.storefront_rounded, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                if (role == "admin")
                  _buildDrawerMenuItem(icon: Icons.shield_rounded, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                if (role == "owner")
                  _buildDrawerMenuItem(icon: Icons.workspace_premium_rounded, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                if (role == "pemula")
                  _buildDrawerMenuItem(icon: Icons.auto_awesome_rounded, label: "Pemula Page", onTap: () => _onSidebarTabSelected(4)),
                if (role == "pemula")
                  _buildDrawerMenuItem(
                    icon: Icons.verified_rounded,
                    label: "Permit Access",
                    onTap: () {
                      Navigator.pop(context);
                      HapticFeedback.mediumImpact();
                      Navigator.push(context, MaterialPageRoute(builder: (_) => AccPage(sessionKey: sessionKey, username: username, role: role)));
                    },
                  ),
                _buildDrawerMenuItem(
                  icon: Icons.history_rounded,
                  label: "Riwayat Aktivitas",
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
                  },
                ),
                _buildDrawerMenuItem(
                  icon: Icons.support_agent_rounded,
                  label: "Customer Service",
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage()));
                  },
                ),
                const SizedBox(height: 16),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(height: 1, color: Hx.pink.withOpacity(0.2))),
                const SizedBox(height: 16),
                _buildDrawerMenuItem(
                  icon: Icons.logout_rounded,
                  label: "Log Out",
                  isLogout: true,
                  onTap: () async {
                    if (!mounted) return;
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final accent = isLogout ? Hx.terra : Hx.pinkLight;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            HapticFeedback.selectionClick();
            onTap();
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    border: Border.all(color: accent.withOpacity(0.4), width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: accent, size: 18),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(color: isLogout ? Hx.terra : Hx.ivory, fontFamily: 'Ganang', fontWeight: FontWeight.w700, fontSize: 13.5, letterSpacing: 0.2),
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: accent.withOpacity(0.7), size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FLOATING APP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildFloatingAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Builder(
            builder: (context) => Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {
                  HapticFeedback.selectionClick();
                  Scaffold.of(context).openDrawer();
                },
                child: Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: Hx.surfaceHi,
                    border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.spa_rounded, color: Hx.pinkLight, size: 20),
                ),
              ),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
            decoration: BoxDecoration(color: Hx.pink, borderRadius: BorderRadius.circular(12)),
            child: const Text('XYRO', style: TextStyle(color: Hx.bg, fontWeight: FontWeight.w900, fontSize: 11, fontFamily: 'Ganang', letterSpacing: 2.8)),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  ),
                ),
              );
            },
            child: Container(
              width: 42, height: 42,
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Hx.pink),
              child: ClipOval(
                child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: Hx.bg, size: 20))
                    : const Icon(Icons.person_rounded, color: Hx.bg, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NAV ITEM
  // ═══════════════════════════════════════════════════════════
  Widget _buildFlatNavItem({
    required IconData icon,
    required String label,
    required bool isActive,
    required VoidCallback onTap,
    Color? iconColor,
  }) {
    final activeColor = iconColor ?? Hx.pinkLight;
    final color = isActive ? activeColor : Hx.ash2;

    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          height: 64,
          alignment: Alignment.center,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 240),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            decoration: BoxDecoration(
              color: isActive ? activeColor.withOpacity(0.12) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 18, color: color),
                const SizedBox(height: 3),
                Text(
                  label,
                  style: TextStyle(color: color, fontFamily: 'Ganang', fontSize: 8, fontWeight: isActive ? FontWeight.w900 : FontWeight.w700, letterSpacing: 0.3),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingDeviceNavItem({
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: SizedBox(
          height: 74,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              Positioned(
                top: -18,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 280),
                  curve: Curves.easeOutCubic,
                  width: isActive ? 62 : 56,
                  height: isActive ? 62 : 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isActive ? Hx.pink : Hx.surfaceHi,
                    border: Border.all(color: isActive ? Hx.pinkLight : Hx.pink.withOpacity(0.3), width: isActive ? 3 : 2),
                    boxShadow: [
                      BoxShadow(
                        color: isActive ? Hx.pink.withOpacity(0.5) : Colors.black.withOpacity(0.4),
                        blurRadius: isActive ? 18 : 12,
                        spreadRadius: isActive ? 2 : 0,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Icon(Icons.phone_iphone_rounded, size: isActive ? 28 : 24, color: isActive ? Hx.bg : Hx.pinkLight),
                ),
              ),
              Positioned(
                bottom: 8,
                child: Column(
                  children: [
                    const SizedBox(height: 42),
                    Text(
                      'Device',
                      style: TextStyle(color: isActive ? Hx.pinkLight : Hx.ash2, fontFamily: 'Ganang', fontSize: 8, fontWeight: isActive ? FontWeight.w900 : FontWeight.w700, letterSpacing: 0.3),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Hx.bg,
      extendBodyBehindAppBar: true,
      extendBody: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A0E14), Color(0xFF241318)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(
                child: AnimatedOpacity(
                  opacity: _entranceVisible ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 250),
                  child: _selectedPage,
                ),
              ),
              Positioned(top: 0, left: 0, right: 0, child: _buildFloatingAppBar()),
            ],
          ),
        ),
      ),
      drawer: _buildCustomDrawer(),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10.0),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Hx.surfaceHi,
                  border: Border.all(color: Hx.pink.withOpacity(0.3), width: 1.2),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(color: Hx.pink.withOpacity(0.2), blurRadius: 24, spreadRadius: 1, offset: const Offset(0, 10)),
                  ],
                ),
                child: SizedBox(
                  height: 74,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      // 0. Home
                      _buildFlatNavItem(
                        icon: Icons.cottage_rounded,
                        label: 'Home',
                        isActive: _bottomNavIndex == 0,
                        onTap: () => _onBottomNavTapped(0),
                      ),
                      // 1. WA (Pilih)
                      _buildFlatNavItem(
                        icon: FontAwesomeIcons.whatsapp,
                        label: 'WA',
                        isActive: _bottomNavIndex == 1,
                        iconColor: const Color(0xFF25D366),
                        onTap: () => _onBottomNavTapped(1),
                      ),
                      // 2. Quran
                      _buildFlatNavItem(
                        icon: Icons.menu_book_rounded,
                        label: 'Quran',
                        isActive: _bottomNavIndex == 2,
                        iconColor: Hx.amber,
                        onTap: () => _onBottomNavTapped(2),
                      ),
                      // 3. Device (floating)
                      _buildFloatingDeviceNavItem(
                        isActive: _bottomNavIndex == 3,
                        onTap: () => _onBottomNavTapped(3),
                      ),
                      // 4. Tools
                      _buildFlatNavItem(
                        icon: Icons.handyman_rounded,
                        label: 'Tools',
                        isActive: _bottomNavIndex == 4,
                        iconColor: Hx.terra,
                        onTap: () => _onBottomNavTapped(4),
                      ),
                      // 5. Trading
                      _buildFlatNavItem(
                        icon: Icons.show_chart_rounded,
                        label: 'Trade',
                        isActive: _bottomNavIndex == 5,
                        iconColor: Hx.jade,
                        onTap: () => _onBottomNavTapped(5),
                      ),
                      // 6. Chat
                      _buildFlatNavItem(
                        icon: Icons.forum_rounded,
                        label: 'Chat',
                        isActive: _bottomNavIndex == 6,
                        iconColor: Hx.pinkLight,
                        onTap: () => _onBottomNavTapped(6),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BANNER VIDEO
// ═══════════════════════════════════════════════════════════════
class BannerVideo extends StatefulWidget {
  const BannerVideo({super.key});

  @override
  State<BannerVideo> createState() => _BannerVideoState();
}

class _BannerVideoState extends State<BannerVideo> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/ooo.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _controller?.setLooping(true);
        _controller?.setVolume(0.0);
        _controller?.play();
      }).catchError((e) {
        debugPrint('Banner video error: $e');
      });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        if (_controller != null && _controller!.value.isInitialized)
          FittedBox(
            fit: BoxFit.cover,
            clipBehavior: Clip.hardEdge,
            child: SizedBox(
              width: _controller!.value.size.width,
              height: _controller!.value.size.height,
              child: VideoPlayer(_controller!),
            ),
          )
        else
          Container(
            color: Hx.surfaceHi2,
            child: const Center(
              child: SizedBox(
                width: 22, height: 22,
                child: CircularProgressIndicator(color: Hx.pinkLight, strokeWidth: 2.0),
              ),
            ),
          ),
        IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Hx.bg.withOpacity(0.15), Hx.bg.withOpacity(0.4)],
                stops: const [0.0, 0.6, 1.0],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// LIVE PULSE DOT
// ═══════════════════════════════════════════════════════════════
class _LivePulseDot extends StatefulWidget {
  const _LivePulseDot();

  @override
  State<_LivePulseDot> createState() => _LivePulseDotState();
}

class _LivePulseDotState extends State<_LivePulseDot> with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final v = 0.4 + 0.6 * _c.value;
        return Container(
          width: 7, height: 7,
          decoration: BoxDecoration(
            color: Hx.pink.withOpacity(v),
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Hx.pink.withOpacity(v * 0.8), blurRadius: 6, spreadRadius: 1)],
          ),
        );
      },
    );
  }
}