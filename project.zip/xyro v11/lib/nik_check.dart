// lib/nik_check.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

const String kFontFamily = 'Ganang';

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnimation =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _nikController.dispose();
    _animController.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      HapticFeedback.vibrate();
      setState(() {
        _errorMessage = "NIK tidak boleh kosong.";
        _data = null;
      });
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/nik-checker?nik=$nik");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          if (!mounted) return;
          setState(() {
            _data = json['data'];
            _errorMessage = null;
          });
          _animController.forward(from: 0);
        } else {
          if (!mounted) return;
          setState(() {
            _errorMessage = "Data tidak ditemukan atau NIK tidak valid.";
          });
        }
      } else {
        if (!mounted) return;
        setState(() {
          _errorMessage = "Gagal mengambil data dari server.";
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    HapticFeedback.selectionClick();
    Clipboard.setData(ClipboardData(text: text));
    final p = context.theme;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$label disalin ke clipboard',
          style: TextStyle(
            color: p.textPrimary,
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w700,
          ),
        ),
        backgroundColor: p.surfaceAlt,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "NIK CHECK",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
              child: Column(
                children: [
                  _buildInputSection(p),
                  const SizedBox(height: 16),
                  if (_errorMessage != null) ...[
                    _buildErrorBox(p, _errorMessage!),
                    const SizedBox(height: 16),
                  ],
                  if (_data != null)
                    Expanded(
                      child: FadeTransition(
                        opacity: _fadeAnimation,
                        child: SingleChildScrollView(
                          physics: const BouncingScrollPhysics(),
                          child: Column(
                            children: [
                              _buildCategoryCard(
                                p: p,
                                title: "IDENTITAS DIRI",
                                icon: Icons.person_outline,
                                children: [
                                  _buildInfoRow(
                                    p: p,
                                    label: "NIK",
                                    value: _data!["nik"]?.toString(),
                                    onCopy: () => _copyToClipboard(
                                      _data!["nik"]?.toString() ?? "",
                                      "NIK",
                                    ),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Nama Lengkap",
                                    value: _data!["data"]["nama"]?.toString(),
                                    onCopy: () => _copyToClipboard(
                                      _data!["data"]["nama"]?.toString() ?? "",
                                      "Nama",
                                    ),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Jenis Kelamin",
                                    value: _data!["data"]["kelamin"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Tempat Lahir",
                                    value: _data!["data"]["tempat_lahir"]
                                        ?.toString(),
                                    onCopy: () => _copyToClipboard(
                                      _data!["data"]["tempat_lahir"]
                                              ?.toString() ??
                                          "",
                                      "Tempat Lahir",
                                    ),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Usia",
                                    value: _data!["data"]["usia"]?.toString(),
                                  ),
                                ],
                              ),
                              _buildCategoryCard(
                                p: p,
                                title: "DATA DOMISILI",
                                icon: Icons.location_on_outlined,
                                children: [
                                  _buildInfoRow(
                                    p: p,
                                    label: "Provinsi",
                                    value: _data!["data"]["provinsi"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Kabupaten/Kota",
                                    value: _data!["data"]["kabupaten"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Kecamatan",
                                    value: _data!["data"]["kecamatan"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Kelurahan/Desa",
                                    value: _data!["data"]["kelurahan"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Alamat Lengkap",
                                    value:
                                        _data!["data"]["alamat"]?.toString(),
                                    onCopy: () => _copyToClipboard(
                                      _data!["data"]["alamat"]?.toString() ??
                                          "",
                                      "Alamat",
                                    ),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "TPS",
                                    value: _data!["data"]["tps"]?.toString(),
                                  ),
                                ],
                              ),
                              _buildCategoryCard(
                                p: p,
                                title: "INFORMASI TAMBAHAN",
                                icon: Icons.info_outline,
                                children: [
                                  _buildInfoRow(
                                    p: p,
                                    label: "Zodiak",
                                    value: _data!["data"]["zodiak"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Ultah Mendatang",
                                    value: _data!["data"]["ultah_mendatang"]
                                        ?.toString(),
                                  ),
                                  _buildInfoRow(
                                    p: p,
                                    label: "Pasaran",
                                    value: _data!["data"]["pasaran"]
                                        ?.toString(),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  BoxDecoration _kotakDecoration(AppPalette p, {bool withShadow = true}) {
    return BoxDecoration(
      color: p.surfaceAlt,
      border: Border.all(
        color: Colors.white.withOpacity(0.7),
        width: 1.5,
      ),
      boxShadow: withShadow
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ]
          : null,
    );
  }

  // ── INPUT ──
  Widget _buildInputSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: TextField(
              controller: _nikController,
              keyboardType: TextInputType.number,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: p.textPrimary,
              onSubmitted: (_) => _checkNik(),
              decoration: InputDecoration(
                hintText: 'Contoh: 5206085405880001',
                hintStyle: TextStyle(
                  color: p.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                prefixIcon: Icon(
                  Icons.badge_outlined,
                  color: p.textTertiary,
                  size: 20,
                ),
                suffixIcon: _isLoading
                    ? Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: p.textPrimary,
                            strokeWidth: 2,
                          ),
                        ),
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _checkNik,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isLoading ? Icons.hourglass_top : Icons.search,
                    size: 18,
                    color: p.bg,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _isLoading ? 'MEMPROSES...' : 'CEK DATA NIK',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── ERROR BOX ──
  Widget _buildErrorBox(AppPalette p, String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(color: p.danger, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: p.danger, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── CATEGORY CARD ──
  Widget _buildCategoryCard({
    required AppPalette p,
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: _kotakDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border(
                bottom: BorderSide(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: p.textPrimary, size: 18),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFontFamily,
                    letterSpacing: 2.0,
                  ),
                ),
              ],
            ),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  // ── INFO ROW ──
  Widget _buildInfoRow({
    required AppPalette p,
    required String label,
    required String? value,
    VoidCallback? onCopy,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.bg,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: TextStyle(
                    color: p.textTertiary,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: kFontFamily,
                  ),
                ),
              ],
            ),
          ),
          if (onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: p.surfaceAlt,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  Icons.copy,
                  color: p.textPrimary,
                  size: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}