// lib/info_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String kFontFamily = 'Ganang';
const String kBrandName = 'XYRO';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class InfoHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);  // hitam murni
  static const bgAlt = Color(0xFF0A0A0A);  // hitam hampir pekat

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);  // hitam card
  static const surfaceHi2 = Color(0xFF1C1C1C); // hitam inner card

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);  // putih keabuan
  static const gold      = Color(0xFFFFFFFF);  // putih
  static const goldMid   = Color(0xFFD0D0D0);  // grey terang
  static const goldDeep  = Color(0xFF808080);  // grey

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);  // hijau
  static const jadeDeep = Color(0xFF22C55E);  // hijau gelap
  static const terra    = Color(0xFFF87171);  // merah
  static const slate    = Color(0xFF60A5FA);  // biru
  static const amethyst = Color(0xFFA78BFA);  // ungu
  static const rose     = Color(0xFFF472B6);  // pink
  static const amber    = Color(0xFFFBBF24);  // kuning

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);  // putih
  static const ash   = Color(0xFF9CA3AF);  // grey
  static const ash2  = Color(0xFF4B5563);  // grey gelap

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage>
    with TickerProviderStateMixin {
  bool isLoading = true;
  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = InfoHx.ash2;
  String apiStatusText = "CHECKING";
  String apiStatusSub = "Please wait";
  Timer? _pingTimer;

  // ═══ ANIMATION CONTROLLERS ═══
  late AnimationController _pulse;
  late AnimationController _entrance;
  late AnimationController _sparkle;

  final List<Map<String, dynamic>> rulesList = [
    {
      "no": "01",
      "title": "No Account Bartering",
      "icon": Icons.swap_horizontal_circle_outlined,
      "accent": InfoHx.terra,
      "desc":
          "Akun XYRO tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apapun."
    },
    {
      "no": "02",
      "title": "Personal Use Only",
      "icon": Icons.person_off_outlined,
      "accent": InfoHx.slate,
      "desc":
          "Setiap akun terenkripsi untuk satu pengguna, terikat Device ID."
    },
    {
      "no": "03",
      "title": "No Reselling",
      "icon": Icons.money_off_csred_outlined,
      "accent": InfoHx.ivory,
      "desc": "Member reguler dilarang memperjualbelikan akun."
    },
    {
      "no": "04",
      "title": "No Illegal Duration",
      "icon": Icons.timer_off_outlined,
      "accent": InfoHx.amethyst,
      "desc": "Dilarang menjual akses eceran harian atau trial ilegal."
    },
    {
      "no": "05",
      "title": "No Price Dumping",
      "icon": Icons.trending_down_rounded,
      "accent": InfoHx.jade,
      "desc": "Dilarang merusak standar harga pasar di bawah kesepakatan."
    },
  ];

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _sparkle = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();

    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _pulse.dispose();
    _sparkle.dispose();
    _entrance.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http.get(Uri.parse(
          'http://console.jhonaleystore.id:2870/getServerInfo?key=${widget.sessionKey}'));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse(
              'http://console.jhonaleystore.id:2870/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = InfoHx.jade;
            apiStatusSub = "$duration ms · Optimal";
          } else if (duration < 500) {
            apiStatusColor = InfoHx.amber;
            apiStatusSub = "$duration ms · Slow";
          } else {
            apiStatusColor = InfoHx.terra;
            apiStatusSub = "$duration ms · Very Slow";
          }
          apiStatusText = "SYSTEM ONLINE";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = InfoHx.terra;
          apiStatusText = "SYSTEM OFFLINE";
          apiStatusSub = "Connection lost";
        });
      }
    }
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({required int index, required Widget child}) {
    const int total = 14;
    final double start = (index / total) * 0.55;
    final double end = (start + 0.45).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: InfoHx.bg,
        body: Center(
          child: SizedBox(
            width: 28, height: 28,
            child: CircularProgressIndicator(
              color: InfoHx.ivory,
              strokeWidth: 2.0,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: InfoHx.bg,
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),  // atas: hitam murni
              Color(0xFF0A0A0A),  // bawah: hitam sedikit terang
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 90, 18, 140),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _staggered(index: 0, child: _buildHeader()),
                const SizedBox(height: 22),
                _staggered(index: 1, child: _buildShieldEmblem()),
                const SizedBox(height: 22),
                _staggered(index: 2, child: _buildStatusCard()),
                const SizedBox(height: 26),
                _staggered(index: 3, child: _buildSectionLabel()),
                const SizedBox(height: 12),
                ...rulesList.asMap().entries.map((e) => _staggered(
                      index: 4 + e.key,
                      child: _buildRuleCard(e.value),
                    )),
                const SizedBox(height: 10),
                _staggered(index: 10, child: _buildWarningCard()),
                const SizedBox(height: 30),
                _staggered(index: 11, child: _buildThanksSection()),
                const SizedBox(height: 24),
                _staggered(index: 12, child: _buildFooter()),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ HEADER ═══
  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                return Container(
                  width: 3,
                  height: 12,
                  color: InfoHx.ivory.withOpacity(
                    0.6 + 0.4 * _pulse.value,
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "TERMS OF SERVICE",
              style: TextStyle(
                color: InfoHx.ivory,
                fontFamily: kFontFamily,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "EULA &",
          style: TextStyle(
            color: InfoHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.6,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          "INFO",
          style: TextStyle(
            color: InfoHx.ivory,
            fontFamily: kFontFamily,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: -1.2,
            height: 1.05,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          "Baca sebelum pakai. Melanggar = banned.",
          style: TextStyle(
            color: InfoHx.ash,
            fontFamily: kFontFamily,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  // ═══ SHIELD EMBLEM ═══
  Widget _buildShieldEmblem() {
    return Center(
      child: SizedBox(
        width: 220, height: 220,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedBuilder(
              animation: _sparkle,
              builder: (_, __) {
                return Transform.rotate(
                  angle: _sparkle.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(220, 220),
                    painter: _SparklePainter(),
                  ),
                );
              },
            ),

            Container(
              width: 180, height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.15),
                  width: 1,
                ),
              ),
            ),

            Container(
              width: 160, height: 160,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: InfoHx.surfaceHi,
              ),
            ),

            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final s = 1 + 0.08 * _pulse.value;
                return Transform.scale(
                  scale: s,
                  child: Container(
                    width: 140, height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(
                          0.3 - 0.15 * _pulse.value,
                        ),
                        width: 1,
                      ),
                    ),
                  ),
                );
              },
            ),

            Container(
              width: 108, height: 108,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: InfoHx.ivory,
              ),
              child: const Center(
                child: Icon(
                  Icons.shield_moon_rounded,
                  color: InfoHx.bg,
                  size: 46,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ STATUS CARD ═══
  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: InfoHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) {
              return Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: apiStatusColor.withOpacity(
                    0.10 + 0.06 * _pulse.value,
                  ),
                  border: Border.all(
                    color: apiStatusColor.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isApiOnline
                      ? Icons.check_circle_outline_rounded
                      : Icons.cloud_off_rounded,
                  color: apiStatusColor,
                  size: 22,
                ),
              );
            },
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  apiStatusText,
                  style: TextStyle(
                    color: apiStatusColor,
                    fontFamily: kFontFamily,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  apiStatusSub,
                  style: const TextStyle(
                    color: InfoHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) {
              final v = 0.5 + 0.5 * _pulse.value;
              return Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                  color: apiStatusColor.withOpacity(v),
                  shape: BoxShape.circle,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ═══ SECTION LABEL ═══
  Widget _buildSectionLabel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 12,
            color: InfoHx.ivory,
          ),
          const SizedBox(width: 10),
          const Text(
            "RULES & PROTOCOLS",
            style: TextStyle(
              color: InfoHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              color: Colors.white.withOpacity(0.08),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 8, vertical: 3,
            ),
            decoration: BoxDecoration(
              color: InfoHx.ivory,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              "${rulesList.length}",
              style: const TextStyle(
                color: InfoHx.bg,
                fontFamily: kFontFamily,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ RULE CARD ═══
  Widget _buildRuleCard(Map<String, dynamic> rule) {
    final Color accent = rule['accent'] as Color;
    final int idx = int.parse(rule['no']);

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 400 + idx * 100),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Transform.translate(
          offset: Offset(30 * (1 - value), 0),
          child: Opacity(
            opacity: value.clamp(0.0, 1.0),
            child: child,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: InfoHx.surfaceHi,
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.12),
                border: Border.all(
                  color: accent.withOpacity(0.4),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                rule['icon'],
                color: accent,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: accent.withOpacity(0.15),
                          border: Border.all(
                            color: accent.withOpacity(0.4),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          rule['no'],
                          style: TextStyle(
                            color: accent,
                            fontFamily: kFontFamily,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          rule['title'],
                          style: const TextStyle(
                            color: InfoHx.ivory,
                            fontFamily: kFontFamily,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                            height: 1.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    rule['desc'],
                    style: const TextStyle(
                      color: InfoHx.ash,
                      fontFamily: kFontFamily,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      height: 1.55,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ WARNING CARD ═══
  Widget _buildWarningCard() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: InfoHx.surfaceHi,
            border: Border.all(
              color: InfoHx.terra.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: InfoHx.terra.withOpacity(
                  0.08 + 0.06 * _pulse.value,
                ),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: InfoHx.terra.withOpacity(0.12),
                  border: Border.all(
                    color: InfoHx.terra.withOpacity(0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.warning_amber_rounded,
                  color: InfoHx.terra,
                  size: 22,
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 2),
                    Text(
                      "PELANGGARAN = BAN PERMANEN",
                      style: TextStyle(
                        color: InfoHx.terra,
                        fontFamily: kFontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.0,
                        height: 1.3,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Akun akan dihapus tanpa pengembalian saldo atau kompensasi apapun.",
                      style: TextStyle(
                        color: InfoHx.ash,
                        fontFamily: kFontFamily,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        height: 1.55,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══ TQ TO SECTION ═══
  Widget _buildThanksSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSectionLabelCustom(
          "TQ TO",
          InfoHx.amethyst,
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: InfoHx.surfaceHi,
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _pulse,
                    builder: (_, __) {
                      final s = 1 + 0.15 * _pulse.value;
                      return Transform.scale(
                        scale: s,
                        child: Container(
                          width: 90, height: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: InfoHx.ivory.withOpacity(0.06),
                          ),
                        ),
                      );
                    },
                  ),
                  Container(
                    width: 78, height: 78,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: InfoHx.ivory,
                    ),
                    child: const Center(
                      child: Text(
                        'G',
                        style: TextStyle(
                          color: InfoHx.bg,
                          fontFamily: kFontFamily,
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 4, right: 4,
                    child: Icon(Icons.star_rounded,
                        color: InfoHx.ivory.withOpacity(0.8), size: 18),
                  ),
                  Positioned(
                    bottom: 8, left: 0,
                    child: Icon(Icons.star_rounded,
                        color: InfoHx.ivory.withOpacity(0.6), size: 12),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              const Text(
                'GANANG',
                style: TextStyle(
                  color: InfoHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 4.0,
                  height: 1.0,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: InfoHx.ivory,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'DEVELOPER',
                  style: TextStyle(
                    color: InfoHx.bg,
                    fontFamily: kFontFamily,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.4,
                  ),
                ),
              ),
              const SizedBox(height: 18),

              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: InfoHx.surfaceHi2,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.06),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'Pembuat dan pencipta aplikasi XYRO ini. '
                  'Terima kasih atas kerja keras, dedikasi, dan '
                  'karya luar biasa yang telah dibuat.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: InfoHx.ash,
                    fontFamily: kFontFamily,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    height: 1.65,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 1,
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Icon(Icons.favorite_rounded,
                        color: InfoHx.ivory.withOpacity(0.6), size: 16),
                  ),
                  Expanded(
                    child: Container(
                      height: 1,
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              const Text(
                'MADE WITH LOVE IN INDONESIA',
                style: TextStyle(
                  color: InfoHx.ivory,
                  fontFamily: kFontFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.8,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Helper label custom accent
  Widget _buildSectionLabelCustom(String text, Color accent) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 12,
            color: accent,
          ),
          const SizedBox(width: 10),
          Text(
            text.toUpperCase(),
            style: const TextStyle(
              color: InfoHx.ivory,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.4,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              color: accent.withOpacity(0.3),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ FOOTER ═══
  Widget _buildFooter() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) {
            return Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: InfoHx.surfaceHi,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.shield_outlined,
                color: InfoHx.ivory.withOpacity(
                  0.6 + 0.4 * _pulse.value,
                ),
                size: 20,
              ),
            );
          },
        ),
        const SizedBox(height: 16),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem XYRO. Dengan mengakses aplikasi, Anda menyetujui seluruh protokol di atas.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: InfoHx.ash,
              fontFamily: kFontFamily,
              fontSize: 11,
              fontStyle: FontStyle.italic,
              height: 1.65,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const SizedBox(height: 22),
        Text(
          "© 2026 $kBrandName · v2.0",
          style: TextStyle(
            color: InfoHx.ash2,
            fontFamily: kFontFamily,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 2.0,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SPARKLE PAINTER — bintang halus di sekeliling shield
// ═══════════════════════════════════════════════════════════════
class _SparklePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 8;

    for (int i = 0; i < 6; i++) {
      final angle = (i / 6) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final sparklePaint = Paint()
        ..color = Colors.white.withOpacity(0.4)
        ..style = PaintingStyle.fill;

      _drawStar(canvas, Offset(x, y), i == 0 ? 9 : 6, sparklePaint);
    }

    for (int i = 0; i < 4; i++) {
      final angle = (i / 4) * 2 * math.pi + math.pi / 4;
      final x = center.dx + radius * 0.75 * math.cos(angle);
      final y = center.dy + radius * 0.75 * math.sin(angle);

      final dotPaint = Paint()
        ..color = Colors.white.withOpacity(0.25);
      canvas.drawCircle(Offset(x, y), 2.5, dotPaint);
    }
  }

  void _drawStar(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx + size * 0.3, center.dy - size * 0.3);
    path.lineTo(center.dx + size, center.dy);
    path.lineTo(center.dx + size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx, center.dy + size);
    path.lineTo(center.dx - size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx - size, center.dy);
    path.lineTo(center.dx - size * 0.3, center.dy - size * 0.3);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparklePainter old) => false;
}