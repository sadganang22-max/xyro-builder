// lib/instagram_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'theme.dart';

const String kFontFamily = 'Ganang';

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() => _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  List<dynamic>? _mediaData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = "URL Instagram tidak boleh kosong.";
        _mediaData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
    });

    final encodedUrl = Uri.encodeComponent(url);
    final apiUrl = Uri.parse(
        "https://api.siputzx.my.id/api/d/igdl?url=$encodedUrl");

    try {
      final response = await http.get(apiUrl);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _mediaData = json['data']);
          _initializeVideoPlayer();
        } else {
          setState(() => _errorMessage = "Gagal mengambil data Instagram.");
        }
      } else {
        setState(() => _errorMessage = "Gagal terhubung ke server.");
      }
    } catch (e) {
      setState(() => _errorMessage = "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer() {
    if (_mediaData != null && _mediaData!.isNotEmpty) {
      final mediaUrl = _mediaData![0]['url'];
      _videoController = VideoPlayerController.networkUrl(Uri.parse(mediaUrl))
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() {
            _chewieController = ChewieController(
              videoPlayerController: _videoController!,
              autoPlay: true,
              looping: false,
              showControls: true,
            );
          });
        });
    }
  }

  Future<void> _shareVideo() async {
    if (_mediaData == null || _mediaData!.isEmpty) return;
    final p = context.theme;

    try {
      final mediaUrl = _mediaData![0]['url'];
      final response = await http.get(Uri.parse(mediaUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/instagram_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles([XFile(file.path)], text: 'Video Instagram');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Error sharing: $e',
            style: TextStyle(
              color: p.textPrimary,
              fontFamily: kFontFamily,
            ),
          ),
          backgroundColor: p.surfaceAlt,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(0),
            side: BorderSide(
              color: Colors.white.withOpacity(0.7),
              width: 1.5,
            ),
          ),
        ),
      );
    }
  }

  void _playVideo(String videoUrl) {
    _videoController?.dispose();
    _chewieController?.dispose();

    _videoController = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            looping: false,
            showControls: true,
          );
        });
      });
  }

  // ============ BOX WRAPPER (gaya sama seperti tools_gateway) ============
  Widget _boxWrapper(
    AppPalette p,
    Widget child, {
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(AppPalette p, IconData icon, String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(
          color: Colors.white.withOpacity(0.7),
          width: 1.5,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: p.textPrimary, size: 16),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              color: p.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              fontFamily: kFontFamily,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMediaGrid(AppPalette p) {
    if (_mediaData == null) return const SizedBox.shrink();

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.8,
      ),
      itemCount: _mediaData!.length,
      itemBuilder: (context, index) {
        final media = _mediaData![index];
        final isVideo = media['type'] == 'video';

        return GestureDetector(
          onTap: () {
            if (isVideo) _playVideo(media['url']);
          },
          child: Container(
            decoration: BoxDecoration(
              color: p.surfaceAlt,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  offset: const Offset(3, 3),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Column(
              children: [
                Expanded(
                  child: ClipRect(
                    child: isVideo
                        ? Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.network(
                                media['thumbnail'] ?? media['url'],
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  color: p.bg,
                                  child: Icon(
                                    Icons.videocam,
                                    color: p.textMuted,
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: p.bg,
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.7),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Icon(
                                    Icons.play_arrow,
                                    color: p.textPrimary,
                                    size: 16,
                                  ),
                                ),
                              ),
                            ],
                          )
                        : Image.network(
                            media['url'],
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: p.bg,
                              child: Icon(
                                Icons.photo,
                                color: p.textMuted,
                              ),
                            ),
                          ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isVideo ? Icons.videocam : Icons.photo,
                        color: p.textPrimary,
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isVideo ? 'Video' : 'Photo',
                        style: TextStyle(
                          color: p.textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: kFontFamily,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          'INSTAGRAM DOWNLOADER',
          style: TextStyle(
            fontFamily: kFontFamily,
            fontWeight: FontWeight.w800,
            color: p.textPrimary,
            letterSpacing: 1.5,
            fontSize: 16,
          ),
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        iconTheme: IconThemeData(color: p.textPrimary),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // ===== INPUT SECTION =====
                  _boxWrapper(
                    p,
                    Column(
                      children: [
                        TextField(
                          controller: _urlController,
                          style: TextStyle(
                            color: p.textPrimary,
                            fontSize: 14,
                            fontFamily: kFontFamily,
                          ),
                          cursorColor: p.textPrimary,
                          decoration: InputDecoration(
                            labelText: 'Masukkan URL Instagram',
                            labelStyle: TextStyle(
                              color: p.textMuted,
                              fontFamily: kFontFamily,
                            ),
                            hintText:
                                'Contoh: https://www.instagram.com/reel/xxx/',
                            hintStyle: TextStyle(
                              color: p.textMuted,
                              fontFamily: kFontFamily,
                              fontSize: 13,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                              borderRadius: BorderRadius.circular(0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.white,
                                width: 1.5,
                              ),
                              borderRadius: BorderRadius.circular(0),
                            ),
                            filled: true,
                            fillColor: p.bg,
                            prefixIcon: Icon(
                              Icons.camera_alt,
                              color: p.textPrimary,
                            ),
                            suffixIcon: _isLoading
                                ? Padding(
                                    padding: const EdgeInsets.all(12.0),
                                    child: SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        color: p.textPrimary,
                                        strokeWidth: 2,
                                      ),
                                    ),
                                  )
                                : null,
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed:
                                _isLoading ? null : _downloadInstagram,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: p.surfaceAlt,
                              foregroundColor: p.textPrimary,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(0),
                                side: BorderSide(
                                  color: Colors.white.withOpacity(0.7),
                                  width: 1.5,
                                ),
                              ),
                              elevation: 0,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _isLoading
                                      ? Icons.hourglass_top
                                      : Icons.download,
                                  size: 18,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _isLoading ? 'PROSES...' : 'DOWNLOAD',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: kFontFamily,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ===== ERROR MESSAGE =====
                  if (_errorMessage != null)
                    _boxWrapper(
                      p,
                      Row(
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: p.textPrimary,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: TextStyle(
                                color: p.textPrimary,
                                fontSize: 13,
                                fontFamily: kFontFamily,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  if (_errorMessage != null) const SizedBox(height: 16),

                  // ===== VIDEO PLAYER =====
                  if (_chewieController != null) ...[
                    _boxWrapper(
                      p,
                      Column(
                        children: [
                          _buildSectionHeader(
                            p,
                            Icons.play_arrow,
                            "VIDEO PLAYER",
                          ),
                          const SizedBox(height: 16),
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                            child: ClipRect(
                              child: AspectRatio(
                                aspectRatio:
                                    _videoController!.value.aspectRatio,
                                child: Chewie(controller: _chewieController!),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _shareVideo,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: p.surfaceAlt,
                                foregroundColor: p.textPrimary,
                                padding: const EdgeInsets.symmetric(
                                    vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(0),
                                  side: BorderSide(
                                    color: Colors.white.withOpacity(0.7),
                                    width: 1.5,
                                  ),
                                ),
                                elevation: 0,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.share, size: 18),
                                  const SizedBox(width: 8),
                                  Text(
                                    'SHARE VIDEO',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: kFontFamily,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // ===== MEDIA GRID =====
                  if (_mediaData != null && _chewieController == null) ...[
                    _boxWrapper(
                      p,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildSectionHeader(
                            p,
                            Icons.photo_library,
                            "MEDIA GALLERY (${_mediaData!.length})",
                          ),
                          const SizedBox(height: 16),
                          _buildMediaGrid(p),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // ===== PLACEHOLDER =====
                  if (_mediaData == null &&
                      !_isLoading &&
                      _errorMessage == null)
                    Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: p.surfaceAlt,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.7),
                                width: 1.5,
                              ),
                            ),
                            child: Icon(
                              Icons.camera_alt,
                              size: 48,
                              color: p.textMuted,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'INSTAGRAM DOWNLOADER',
                            style: TextStyle(
                              color: p.textPrimary,
                              fontSize: 14,
                              fontFamily: kFontFamily,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              'Masukkan URL Instagram Reel, Post, atau Story untuk mendownload media',
                              style: TextStyle(
                                color: p.textMuted,
                                fontSize: 13,
                                fontFamily: kFontFamily,
                                height: 1.5,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}