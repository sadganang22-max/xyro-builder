// lib/pertama.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'landing.dart';

const String kFontFamily = 'Orbitron';

// ═══════════════════════════════════════════════════════════════
// PALET — PINK CUTE MINIMAL 🌸
// ═══════════════════════════════════════════════════════════════
class PertamaHx {
  static const bg    = Color(0xFF1A0E14);
  static const bgAlt = Color(0xFF241318);

  static const surface   = Color(0xFF2A1720);
  static const surfaceHi = Color(0xFF2A1720);
  static const surfaceHi2 = Color(0xFF361D28);

  static const pinkSoft  = Color(0xFFFFC1DA);
  static const pinkLight = Color(0xFFFF9EC4);
  static const pink      = Color(0xFFFF6FA5);
  static const pinkDeep  = Color(0xFFE84A8A);
  static const pinkGlow  = Color(0xFFFFB6D3);

  static const jade     = Color(0xFF6EE7B7);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFFF7A9A);
  static const slate    = Color(0xFF93C5FD);
  static const amethyst = Color(0xFFC4A5FF);

  static const ivory = Color(0xFFFFF5F8);
  static const ash   = Color(0xFFC9A8B6);
  static const ash2  = Color(0xFF7A5A66);

  static const line = Color(0x1AFF6FA5);
  static const lineSoft = Color(0x0DFF6FA5);
}

class PertamaPage extends StatefulWidget {
  const PertamaPage({super.key});

  @override
  State<PertamaPage> createState() => _PertamaPageState();
}

class _PertamaPageState extends State<PertamaPage>
    with TickerProviderStateMixin {
  double _progress = 0;
  bool _isPressing = false;
  bool _completed = false;

  Timer? _ticker;
  DateTime? _lastTick;

  late AnimationController _ambient;
  late AnimationController _spin;
  late AnimationController _pulse;
  late AnimationController _entrance;

  static const double _fillSpeed = 0.55;
  static const double _drainSpeed = 1.5;

  @override
  void initState() {
    super.initState();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 22),
    )..repeat();

    _spin = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 26),
    )..repeat();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _ambient.dispose();
    _spin.dispose();
    _pulse.dispose();
    _entrance.dispose();
    super.dispose();
  }

  void _startTicker() {
    if (_ticker != null) return;
    _lastTick = DateTime.now();
    _ticker = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  void _stopTicker() {
    _ticker?.cancel();
    _ticker = null;
  }

  void _tick() {
    if (!mounted) return;
    final now = DateTime.now();
    final dt = now.difference(_lastTick!).inMilliseconds / 1000.0;
    _lastTick = now;

    if (_completed) {
      _stopTicker();
      return;
    }

    if (_isPressing) {
      setState(() {
        _progress += _fillSpeed * dt;
        if (_progress >= 1.0) {
          _progress = 1.0;
          _onComplete();
        }
      });
    } else if (_progress > 0) {
      setState(() {
        _progress -= _drainSpeed * dt;
        if (_progress <= 0) {
          _progress = 0;
          _stopTicker();
        }
      });
    } else {
      _stopTicker();
    }
  }

  void _onPressStart(TapDownDetails _) {
    if (_completed) return;
    HapticFeedback.mediumImpact();
    setState(() => _isPressing = true);
    _startTicker();
  }

  void _onPressEnd(TapUpDetails _) {
    if (_completed) return;
    HapticFeedback.selectionClick();
    setState(() => _isPressing = false);
    _startTicker();
  }

  void _onPressCancel() {
    if (_completed) return;
    setState(() => _isPressing = false);
    _startTicker();
  }

  Future<void> _onComplete() async {
    _completed = true;
    _stopTicker();
    HapticFeedback.heavyImpact();

    await Future.delayed(const Duration(milliseconds: 550));
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 700),
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  Widget _staggered({required int index, required Widget child}) {
    const int total = 5;
    final double start = (index / total) * 0.4;
    final double end = (start + 0.6).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 34 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PertamaHx.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: PertamaHx.bg),

          AnimatedBuilder(
            animation: _ambient,
            builder: (context, _) => CustomPaint(
              painter: _AmbientPainter(progress: _ambient.value),
            ),
          ),

          CustomPaint(
            painter: _GridPainter(color: PertamaHx.pink.withOpacity(0.04)),
          ),

          IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.05,
                  colors: [
                    Colors.transparent,
                    PertamaHx.bg.withOpacity(0.5),
                  ],
                  stops: const [0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 10),
                    _staggered(index: 0, child: _buildBanner()),
                    const SizedBox(height: 34),
                    _staggered(index: 1, child: _buildBrand()),
                    const SizedBox(height: 40),
                    _staggered(index: 2, child: _buildUnlockButton()),
                    const SizedBox(height: 40),
                    _staggered(index: 3, child: _buildProgressInfo()),
                    const SizedBox(height: 22),
                    _staggered(index: 4, child: _buildHint()),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ BANNER — video dengan SUARA ═══
  Widget _buildBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Container(
        height: 160,
        decoration: BoxDecoration(
          color: PertamaHx.surfaceHi,
          border: Border.all(
            color: PertamaHx.pink.withOpacity(0.3),
            width: 1.2,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: PertamaHx.pink.withOpacity(0.2),
              blurRadius: 22,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const _BannerVideo(),

            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      PertamaHx.bg.withOpacity(0.25),
                      PertamaHx.bg.withOpacity(0.55),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 5,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [PertamaHx.pinkLight, PertamaHx.pinkDeep],
                  ),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: PertamaHx.pink.withOpacity(0.6),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'PREMIUM ♡',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontFamily: 'Ganang',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ),

            Positioned(
              bottom: 12,
              left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: PertamaHx.pinkLight.withOpacity(0.5),
                    width: 1,
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _PulseDot(),
                    SizedBox(width: 8),
                    Text(
                      'XYRO SHOWCASE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9.5,
                        fontFamily: 'Ganang',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ BRAND ═══
  Widget _buildBrand() {
    return Column(
      children: [
        Container(
          width: 68, height: 68,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [PertamaHx.pinkLight, PertamaHx.pinkDeep],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: PertamaHx.pink.withOpacity(0.6),
                blurRadius: 18,
                spreadRadius: 3,
              ),
            ],
          ),
          child: const Center(
            child: Text(
              'X',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Ganang',
                fontSize: 34,
                fontWeight: FontWeight.w900,
                letterSpacing: -1,
              ),
            ),
          ),
        ),
        const SizedBox(height: 22),

        const Text(
          'XYRO',
          style: TextStyle(
            fontFamily: kFontFamily,
            fontSize: 44,
            fontWeight: FontWeight.w900,
            letterSpacing: 10,
            color: PertamaHx.ivory,
            height: 1.0,
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 26, height: 1,
              color: PertamaHx.pink.withOpacity(0.4),
            ),
            const SizedBox(width: 12),
            const Text(
              'DEVICE VERIFICATION',
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 10,
                letterSpacing: 5.5,
                color: PertamaHx.ash,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 26, height: 1,
              color: PertamaHx.pink.withOpacity(0.4),
            ),
          ],
        ),
      ],
    );
  }

  // ═══ UNLOCK BUTTON — TAP & HOLD (trend style) ═══
  Widget _buildUnlockButton() {
    const double size = 280;

    return GestureDetector(
      onTapDown: _onPressStart,
      onTapUp: _onPressEnd,
      onTapCancel: _onPressCancel,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Rotating dots ring
            AnimatedBuilder(
              animation: _spin,
              builder: (_, __) {
                return Transform.rotate(
                  angle: _spin.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(size, size),
                    painter: _DotsRingPainter(
                      color: PertamaHx.pinkLight.withOpacity(0.6),
                      radius: size / 2 - 4,
                      dotCount: 32,
                      dotSize: 2.2,
                    ),
                  ),
                );
              },
            ),

            // Pulse glow
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final active = _isPressing || _completed;
                if (!active) return const SizedBox.shrink();
                final accent = _completed ? PertamaHx.jade : PertamaHx.pink;
                final scale = 1 + 0.06 * _pulse.value;
                return Transform.scale(
                  scale: scale,
                  child: Container(
                    width: size - 20,
                    height: size - 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.3),
                          blurRadius: 50,
                          spreadRadius: 6,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            // Track ring
            Container(
              width: size - 36,
              height: size - 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: PertamaHx.pink.withOpacity(0.2),
                  width: 2.5,
                ),
              ),
            ),

            // Progress ring
            SizedBox(
              width: size - 36,
              height: size - 36,
              child: CustomPaint(
                painter: _RingProgressPainter(
                  progress: _progress,
                  color: _completed ? PertamaHx.jade : PertamaHx.pink,
                ),
              ),
            ),

            // Inner circle
            AnimatedContainer(
              duration: const Duration(milliseconds: 320),
              curve: Curves.easeOutCubic,
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: PertamaHx.surfaceHi,
                border: Border.all(
                  color: _completed
                      ? PertamaHx.jade
                      : (_isPressing
                          ? PertamaHx.pink
                          : PertamaHx.pink.withOpacity(0.3)),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _completed
                        ? PertamaHx.jade.withOpacity(0.3)
                        : (_isPressing
                            ? PertamaHx.pink.withOpacity(0.4)
                            : PertamaHx.pink.withOpacity(0.15)),
                    blurRadius: _completed || _isPressing ? 40 : 18,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: ClipOval(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // ── TAP TO UNLOCK (lock + finger tap icon) ──
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (_, __) {
                        final active = _isPressing || _completed;
                        final scale = active
                            ? 1.0 + 0.05 * _pulse.value
                            : 1.0;
                        return Transform.scale(
                          scale: scale,
                          child: _UnlockBadgeIcon(
                            progress: _progress,
                            completed: _completed,
                            isPressing: _isPressing,
                          ),
                        );
                      },
                    ),

                    // Scanning beam
                    if (_isPressing && _progress > 0 && !_completed)
                      Positioned(
                        left: 0, right: 0,
                        bottom: _progress * 190,
                        child: Container(
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                PertamaHx.pinkLight,
                                Colors.transparent,
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: PertamaHx.pink.withOpacity(0.8),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                        ),
                      ),

                    // Completed overlay
                    if (_completed)
                      Container(
                        color: PertamaHx.bg.withOpacity(0.7),
                        child: const Center(
                          child: Icon(
                            Icons.check_circle_rounded,
                            color: PertamaHx.jade,
                            size: 70,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ PROGRESS INFO ═══
  Widget _buildProgressInfo() {
    final pct = (_progress * 100).floor();
    final label = _completed
        ? 'UNLOCKED ♡'
        : (_isPressing ? 'UNLOCKING...' : 'TAP & HOLD TO UNLOCK');

    final accent = _completed
        ? PertamaHx.jade
        : (_isPressing ? PertamaHx.pinkLight : PertamaHx.ash);

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              pct.toString().padLeft(2, '0'),
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 56,
                fontWeight: FontWeight.w900,
                color: _completed ? PertamaHx.jade : PertamaHx.ivory,
                letterSpacing: -1.5,
                height: 1.0,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              '%',
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: accent,
                height: 1.0,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        AnimatedDefaultTextStyle(
          duration: const Duration(milliseconds: 220),
          style: TextStyle(
            fontFamily: kFontFamily,
            fontSize: 11.5,
            letterSpacing: 3.4,
            fontWeight: FontWeight.w900,
            color: accent,
          ),
          child: Text(label),
        ),
      ],
    );
  }

  // ═══ HINT ═══
  Widget _buildHint() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: PertamaHx.surfaceHi,
        border: Border.all(
          color: PertamaHx.pink.withOpacity(0.3),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(100),
        boxShadow: [
          BoxShadow(
            color: PertamaHx.pink.withOpacity(0.15),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.touch_app_rounded, color: PertamaHx.pinkLight, size: 16),
          SizedBox(width: 8),
          Text(
            'KEEP HOLDING · DO NOT RELEASE',
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.0,
              color: PertamaHx.ivory,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// UNLOCK BADGE ICON — lock + tap (trend style) 🩷
// ═══════════════════════════════════════════════════════════════
class _UnlockBadgeIcon extends StatelessWidget {
  final double progress;
  final bool completed;
  final bool isPressing;

  const _UnlockBadgeIcon({
    required this.progress,
    required this.completed,
    required this.isPressing,
  });

  @override
  Widget build(BuildContext context) {
    final accent = completed
        ? PertamaHx.jade
        : (isPressing ? PertamaHx.pink : PertamaHx.pinkLight);

    return SizedBox(
      width: 100,
      height: 100,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Glow behind
          Container(
            width: 90, height: 90,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.35),
                  blurRadius: 30,
                  spreadRadius: 6,
                ),
              ],
            ),
          ),
          // Lock open/closed icon
          Icon(
            completed
                ? Icons.lock_open_rounded
                : Icons.lock_rounded,
            size: 64,
            color: accent.withOpacity(0.95),
            shadows: [
              Shadow(
                color: accent.withOpacity(0.6),
                blurRadius: 20,
              ),
            ],
          ),
          // Small tap dot inside (hint "tap")
          if (!completed)
            Positioned(
              bottom: 22,
              child: Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: PertamaHx.bg.withOpacity(0.5),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BANNER VIDEO — dengan SUARA
// ═══════════════════════════════════════════════════════════════
class _BannerVideo extends StatefulWidget {
  const _BannerVideo();

  @override
  State<_BannerVideo> createState() => _BannerVideoState();
}

class _BannerVideoState extends State<_BannerVideo> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/ooo.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _controller?.setLooping(true);
        _controller?.setVolume(1.0); // ✅ SUARA NYALA
        _controller?.play();
      }).catchError((e) {
        debugPrint('Banner video error: $e');
      });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_controller != null && _controller!.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        clipBehavior: Clip.hardEdge,
        child: SizedBox(
          width: _controller!.value.size.width,
          height: _controller!.value.size.height,
          child: VideoPlayer(_controller!),
        ),
      );
    }
    return Container(
      color: PertamaHx.surfaceHi2,
      child: const Center(
        child: SizedBox(
          width: 22, height: 22,
          child: CircularProgressIndicator(
            color: PertamaHx.pinkLight,
            strokeWidth: 2.0,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// PULSE DOT
// ═══════════════════════════════════════════════════════════════
class _PulseDot extends StatefulWidget {
  const _PulseDot();

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final v = 0.4 + 0.6 * _c.value;
        return Container(
          width: 6, height: 6,
          decoration: BoxDecoration(
            color: PertamaHx.pink.withOpacity(v),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: PertamaHx.pink.withOpacity(v),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// AMBIENT PAINTER — pink glow
// ═══════════════════════════════════════════════════════════════
class _AmbientPainter extends CustomPainter {
  final double progress;
  _AmbientPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 140);

    paint.color = PertamaHx.pink.withOpacity(0.06);
    canvas.drawCircle(
      Offset(
        size.width * (0.16 + 0.06 * math.sin(t * 0.7)),
        size.height * (0.10 + 0.05 * math.cos(t * 0.5)),
      ),
      size.width * 0.55,
      paint,
    );

    paint.color = PertamaHx.pinkDeep.withOpacity(0.05);
    canvas.drawCircle(
      Offset(
        size.width * (0.90 + 0.05 * math.cos(t * 0.6)),
        size.height * (0.85 + 0.05 * math.sin(t * 0.4)),
      ),
      size.width * 0.58,
      paint,
    );

    paint.color = PertamaHx.pinkLight.withOpacity(0.03);
    canvas.drawCircle(
      Offset(
        size.width * (0.55 + 0.08 * math.sin(t * 0.3)),
        size.height * (0.50 + 0.06 * math.cos(t * 0.8)),
      ),
      size.width * 0.48,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AmbientPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════════
// DOTS RING PAINTER — pink
// ═══════════════════════════════════════════════════════════════
class _DotsRingPainter extends CustomPainter {
  final Color color;
  final double radius;
  final int dotCount;
  final double dotSize;

  _DotsRingPainter({
    required this.color,
    required this.radius,
    required this.dotCount,
    required this.dotSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint();

    for (int i = 0; i < dotCount; i++) {
      final angle = (i / dotCount) * 2 * math.pi;
      final dx = center.dx + radius * math.cos(angle);
      final dy = center.dy + radius * math.sin(angle);
      final op = (i / dotCount);
      paint.color = color.withOpacity(0.15 + op * 0.6);
      canvas.drawCircle(Offset(dx, dy), dotSize, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DotsRingPainter old) =>
      old.color != color || old.radius != radius;
}

// ═══════════════════════════════════════════════════════════════
// RING PROGRESS PAINTER — pink → jade
// ═══════════════════════════════════════════════════════════════
class _RingProgressPainter extends CustomPainter {
  final double progress;
  final Color color;

  _RingProgressPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;

    if (progress > 0) {
      final glowPaint = Paint()
        ..color = color.withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

      const startAngle = -math.pi / 2;
      final sweepAngle = 2 * math.pi * progress;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        glowPaint,
      );
    }

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round;

    const startAngle = -math.pi / 2;
    final sweepAngle = 2 * math.pi * progress;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      paint,
    );

    if (progress > 0.02 && progress < 1.0) {
      final angle = startAngle + sweepAngle;
      final dotX = center.dx + radius * math.cos(angle);
      final dotY = center.dy + radius * math.sin(angle);
      canvas.drawCircle(
        Offset(dotX, dotY),
        5,
        Paint()..color = color,
      );
      canvas.drawCircle(
        Offset(dotX, dotY),
        9,
        Paint()
          ..color = color.withOpacity(0.5)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RingProgressPainter old) =>
      old.progress != progress || old.color != color;
}