// lib/pertama.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'landing.dart';

const String kFontFamily = 'Orbitron';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class PertamaHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class PertamaPage extends StatefulWidget {
  const PertamaPage({super.key});

  @override
  State<PertamaPage> createState() => _PertamaPageState();
}

class _PertamaPageState extends State<PertamaPage>
    with TickerProviderStateMixin {
  double _progress = 0;
  bool _isPressing = false;
  bool _completed = false;

  Timer? _ticker;
  DateTime? _lastTick;

  late AnimationController _ambient;
  late AnimationController _spin;
  late AnimationController _pulse;
  late AnimationController _entrance;

  static const double _fillSpeed = 0.55;
  static const double _drainSpeed = 1.5;

  @override
  void initState() {
    super.initState();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 22),
    )..repeat();

    _spin = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 26),
    )..repeat();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _ambient.dispose();
    _spin.dispose();
    _pulse.dispose();
    _entrance.dispose();
    super.dispose();
  }

  void _startTicker() {
    if (_ticker != null) return;
    _lastTick = DateTime.now();
    _ticker = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  void _stopTicker() {
    _ticker?.cancel();
    _ticker = null;
  }

  void _tick() {
    if (!mounted) return;
    final now = DateTime.now();
    final dt = now.difference(_lastTick!).inMilliseconds / 1000.0;
    _lastTick = now;

    if (_completed) {
      _stopTicker();
      return;
    }

    if (_isPressing) {
      setState(() {
        _progress += _fillSpeed * dt;
        if (_progress >= 1.0) {
          _progress = 1.0;
          _onComplete();
        }
      });
    } else if (_progress > 0) {
      setState(() {
        _progress -= _drainSpeed * dt;
        if (_progress <= 0) {
          _progress = 0;
          _stopTicker();
        }
      });
    } else {
      _stopTicker();
    }
  }

  void _onPressStart(TapDownDetails _) {
    if (_completed) return;
    HapticFeedback.mediumImpact();
    setState(() => _isPressing = true);
    _startTicker();
  }

  void _onPressEnd(TapUpDetails _) {
    if (_completed) return;
    HapticFeedback.selectionClick();
    setState(() => _isPressing = false);
    _startTicker();
  }

  void _onPressCancel() {
    if (_completed) return;
    setState(() => _isPressing = false);
    _startTicker();
  }

  Future<void> _onComplete() async {
    _completed = true;
    _stopTicker();
    HapticFeedback.heavyImpact();

    await Future.delayed(const Duration(milliseconds: 550));
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 700),
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  Widget _staggered({required int index, required Widget child}) {
    const int total = 5;
    final double start = (index / total) * 0.4;
    final double end = (start + 0.6).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entrance,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 34 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PertamaHx.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: PertamaHx.bg),

          AnimatedBuilder(
            animation: _ambient,
            builder: (context, _) => CustomPaint(
              painter: _AmbientPainter(progress: _ambient.value),
            ),
          ),

          CustomPaint(
            painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
          ),

          IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.05,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.4),
                  ],
                  stops: const [0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 10),
                    _staggered(index: 0, child: _buildBanner()),
                    const SizedBox(height: 34),
                    _staggered(index: 1, child: _buildBrand()),
                    const SizedBox(height: 40),
                    _staggered(index: 2, child: _buildFingerprint()),
                    const SizedBox(height: 40),
                    _staggered(index: 3, child: _buildProgressInfo()),
                    const SizedBox(height: 22),
                    _staggered(index: 4, child: _buildHint()),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ BANNER ═══
  Widget _buildBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 160,
        decoration: BoxDecoration(
          color: PertamaHx.surfaceHi,
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const _BannerVideo(),

            // Overlay gradient
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      PertamaHx.bg.withOpacity(0.25),
                      PertamaHx.bg.withOpacity(0.55),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),

            // Badge PREMIUM — putih + text hitam
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: PertamaHx.ivory,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'PREMIUM',
                  style: TextStyle(
                    color: PertamaHx.bg,
                    fontSize: 9,
                    fontFamily: 'Ganang',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
            ),

            // Bottom label
            Positioned(
              bottom: 12,
              left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.white24, width: 1),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _PulseDot(),
                    SizedBox(width: 8),
                    Text(
                      'XYRO SHOWCASE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9.5,
                        fontFamily: 'Ganang',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ BRAND ═══
  Widget _buildBrand() {
    return Column(
      children: [
        // Brand mark
        Container(
          width: 68, height: 68,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: PertamaHx.ivory,
          ),
          child: const Center(
            child: Text(
              'X',
              style: TextStyle(
                color: PertamaHx.bg,
                fontFamily: 'Ganang',
                fontSize: 34,
                fontWeight: FontWeight.w900,
                letterSpacing: -1,
              ),
            ),
          ),
        ),
        const SizedBox(height: 22),

        // Brand name — putih
        const Text(
          'XYRO',
          style: TextStyle(
            fontFamily: kFontFamily,
            fontSize: 44,
            fontWeight: FontWeight.w900,
            letterSpacing: 10,
            color: PertamaHx.ivory,
            height: 1.0,
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 26, height: 1,
              color: Colors.white.withOpacity(0.2),
            ),
            const SizedBox(width: 12),
            const Text(
              'DEVICE VERIFICATION',
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 10,
                letterSpacing: 5.5,
                color: PertamaHx.ash,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 26, height: 1,
              color: Colors.white.withOpacity(0.2),
            ),
          ],
        ),
      ],
    );
  }

  // ═══ FINGERPRINT ═══
  Widget _buildFingerprint() {
    const double size = 280;

    return GestureDetector(
      onTapDown: _onPressStart,
      onTapUp: _onPressEnd,
      onTapCancel: _onPressCancel,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Rotating dots ring
            AnimatedBuilder(
              animation: _spin,
              builder: (_, __) {
                return Transform.rotate(
                  angle: _spin.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(size, size),
                    painter: _DotsRingPainter(
                      color: Colors.white.withOpacity(0.5),
                      radius: size / 2 - 4,
                      dotCount: 32,
                      dotSize: 2.2,
                    ),
                  ),
                );
              },
            ),

            // Pulse glow
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                final active = _isPressing || _completed;
                if (!active) return const SizedBox.shrink();
                final accent = _completed ? PertamaHx.jade : PertamaHx.ivory;
                final scale = 1 + 0.06 * _pulse.value;
                return Transform.scale(
                  scale: scale,
                  child: Container(
                    width: size - 20,
                    height: size - 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.15),
                          blurRadius: 40,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            // Track ring
            Container(
              width: size - 36,
              height: size - 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 2.5,
                ),
              ),
            ),

            // Progress ring
            SizedBox(
              width: size - 36,
              height: size - 36,
              child: CustomPaint(
                painter: _RingProgressPainter(
                  progress: _progress,
                  color: _completed ? PertamaHx.jade : PertamaHx.ivory,
                ),
              ),
            ),

            // Inner circle
            AnimatedContainer(
              duration: const Duration(milliseconds: 320),
              curve: Curves.easeOutCubic,
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: PertamaHx.surfaceHi,
                border: Border.all(
                  color: _completed
                      ? PertamaHx.jade
                      : (_isPressing
                          ? PertamaHx.ivory
                          : Colors.white.withOpacity(0.15)),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _completed
                        ? PertamaHx.jade.withOpacity(0.15)
                        : (_isPressing
                            ? PertamaHx.ivory.withOpacity(0.10)
                            : Colors.black.withOpacity(0.4)),
                    blurRadius: _completed || _isPressing ? 36 : 12,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipOval(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 130,
                      height: 130,
                      child: CustomPaint(
                        painter: _FingerprintPainter(
                          progress: _progress,
                          isPressing: _isPressing,
                          completed: _completed,
                        ),
                      ),
                    ),

                    if (_isPressing && _progress > 0)
                      Positioned(
                        left: 0, right: 0,
                        bottom: _progress * 190,
                        child: Container(
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                PertamaHx.ivory,
                                Colors.transparent,
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: PertamaHx.ivory.withOpacity(0.6),
                                blurRadius: 18,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                        ),
                      ),

                    if (_completed)
                      Container(
                        color: PertamaHx.bg.withOpacity(0.6),
                        child: const Center(
                          child: Icon(
                            Icons.check_rounded,
                            color: PertamaHx.jade,
                            size: 70,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ PROGRESS INFO ═══
  Widget _buildProgressInfo() {
    final pct = (_progress * 100).floor();
    final label = _completed
        ? 'VERIFICATION SUCCESS'
        : (_isPressing ? 'VERIFYING...' : 'HOLD FINGER TO SCAN');

    final accent = _completed
        ? PertamaHx.jade
        : (_isPressing ? PertamaHx.ivory : PertamaHx.ash);

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              pct.toString().padLeft(2, '0'),
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 56,
                fontWeight: FontWeight.w900,
                color: _completed ? PertamaHx.jade : PertamaHx.ivory,
                letterSpacing: -1.5,
                height: 1.0,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              '%',
              style: TextStyle(
                fontFamily: kFontFamily,
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: accent,
                height: 1.0,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        AnimatedDefaultTextStyle(
          duration: const Duration(milliseconds: 220),
          style: TextStyle(
            fontFamily: kFontFamily,
            fontSize: 11.5,
            letterSpacing: 3.4,
            fontWeight: FontWeight.w900,
            color: accent,
          ),
          child: Text(label),
        ),
      ],
    );
  }

  // ═══ HINT ═══
  Widget _buildHint() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: PertamaHx.surfaceHi,
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(100),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.fingerprint_rounded, color: PertamaHx.ivory, size: 16),
          SizedBox(width: 8),
          Text(
            'KEEP HOLDING · DO NOT RELEASE',
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.0,
              color: PertamaHx.ivory,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BANNER VIDEO WIDGET
// ═══════════════════════════════════════════════════════════════
class _BannerVideo extends StatefulWidget {
  const _BannerVideo();

  @override
  State<_BannerVideo> createState() => _BannerVideoState();
}

class _BannerVideoState extends State<_BannerVideo> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/ooo.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _controller?.setLooping(true);
        _controller?.setVolume(0.0);
        _controller?.play();
      }).catchError((e) {
        debugPrint('Banner video error: $e');
      });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_controller != null && _controller!.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        clipBehavior: Clip.hardEdge,
        child: SizedBox(
          width: _controller!.value.size.width,
          height: _controller!.value.size.height,
          child: VideoPlayer(_controller!),
        ),
      );
    }
    return Container(
      color: PertamaHx.surfaceHi2,
      child: const Center(
        child: SizedBox(
          width: 22, height: 22,
          child: CircularProgressIndicator(
            color: PertamaHx.ivory,
            strokeWidth: 2.0,
          ),
        ),
      ),
    );
  }
}

class _PulseDot extends StatefulWidget {
  const _PulseDot();

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final v = 0.4 + 0.6 * _c.value;
        return Container(
          width: 6, height: 6,
          decoration: BoxDecoration(
            color: PertamaHx.ivory.withOpacity(v),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: PertamaHx.ivory.withOpacity(v),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// AMBIENT PAINTER
// ═══════════════════════════════════════════════════════════════
class _AmbientPainter extends CustomPainter {
  final double progress;
  _AmbientPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 140);

    paint.color = Colors.white.withOpacity(0.04);
    canvas.drawCircle(
      Offset(
        size.width * (0.16 + 0.06 * math.sin(t * 0.7)),
        size.height * (0.10 + 0.05 * math.cos(t * 0.5)),
      ),
      size.width * 0.55,
      paint,
    );

    paint.color = Colors.white.withOpacity(0.03);
    canvas.drawCircle(
      Offset(
        size.width * (0.90 + 0.05 * math.cos(t * 0.6)),
        size.height * (0.85 + 0.05 * math.sin(t * 0.4)),
      ),
      size.width * 0.58,
      paint,
    );

    paint.color = Colors.white.withOpacity(0.02);
    canvas.drawCircle(
      Offset(
        size.width * (0.55 + 0.08 * math.sin(t * 0.3)),
        size.height * (0.50 + 0.06 * math.cos(t * 0.8)),
      ),
      size.width * 0.48,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AmbientPainter old) =>
      old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════════
// DOTS RING PAINTER
// ═══════════════════════════════════════════════════════════════
class _DotsRingPainter extends CustomPainter {
  final Color color;
  final double radius;
  final int dotCount;
  final double dotSize;

  _DotsRingPainter({
    required this.color,
    required this.radius,
    required this.dotCount,
    required this.dotSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint();

    for (int i = 0; i < dotCount; i++) {
      final angle = (i / dotCount) * 2 * math.pi;
      final dx = center.dx + radius * math.cos(angle);
      final dy = center.dy + radius * math.sin(angle);
      final op = (i / dotCount);
      paint.color = color.withOpacity(0.15 + op * 0.6);
      canvas.drawCircle(Offset(dx, dy), dotSize, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DotsRingPainter old) =>
      old.color != color || old.radius != radius;
}

// ═══════════════════════════════════════════════════════════════
// RING PROGRESS PAINTER
// ═══════════════════════════════════════════════════════════════
class _RingProgressPainter extends CustomPainter {
  final double progress;
  final Color color;

  _RingProgressPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;

    if (progress > 0) {
      final glowPaint = Paint()
        ..color = color.withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

      const startAngle = -math.pi / 2;
      final sweepAngle = 2 * math.pi * progress;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        glowPaint,
      );
    }

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round;

    const startAngle = -math.pi / 2;
    final sweepAngle = 2 * math.pi * progress;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      paint,
    );

    if (progress > 0.02 && progress < 1.0) {
      final angle = startAngle + sweepAngle;
      final dotX = center.dx + radius * math.cos(angle);
      final dotY = center.dy + radius * math.sin(angle);
      canvas.drawCircle(
        Offset(dotX, dotY),
        5,
        Paint()..color = color,
      );
      canvas.drawCircle(
        Offset(dotX, dotY),
        9,
        Paint()
          ..color = color.withOpacity(0.5)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RingProgressPainter old) =>
      old.progress != progress || old.color != color;
}

// ═══════════════════════════════════════════════════════════════
// FINGERPRINT PAINTER
// ═══════════════════════════════════════════════════════════════
class _FingerprintPainter extends CustomPainter {
  final double progress;
  final bool isPressing;
  final bool completed;

  _FingerprintPainter({
    required this.progress,
    required this.isPressing,
    required this.completed,
  });

  static const List<String> _ridges = [
    'M 30 130 Q 30 60 100 60 Q 170 60 170 130',
    'M 45 130 Q 45 75 100 75 Q 155 75 155 130',
    'M 60 130 Q 60 90 100 90 Q 140 90 140 130',
    'M 75 130 Q 75 105 100 105 Q 125 105 125 130',
    'M 100 60 Q 60 60 60 130 Q 60 180 100 200 Q 140 180 140 130 Q 140 60 100 60',
    'M 100 75 Q 75 75 75 130 Q 75 170 100 185 Q 125 170 125 130 Q 125 75 100 75',
    'M 100 90 Q 90 90 90 130 Q 90 160 100 170 Q 110 160 110 130 Q 110 90 100 90',
    'M 40 160 Q 40 210 100 230 Q 160 210 160 160',
    'M 55 165 Q 55 200 100 215 Q 145 200 145 165',
    'M 70 170 Q 70 190 100 200 Q 130 190 130 170',
    'M 30 130 Q 30 170 45 195',
    'M 170 130 Q 170 170 155 195',
  ];

  @override
  void paint(Canvas canvas, Size size) {
    const vbW = 200.0;
    const vbH = 260.0;
    final scaleX = size.width / vbW;
    final scaleY = size.height / vbH;
    final scale = scaleX < scaleY ? scaleX : scaleY;

    final offsetX = (size.width - vbW * scale) / 2;
    final offsetY = (size.height - vbH * scale) / 2;

    final fillY = vbH * (1 - progress);

    final basePaint = Paint()
      ..color = Colors.white.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = completed ? PertamaHx.jade : PertamaHx.ivory
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    canvas.save();
    canvas.translate(offsetX, offsetY);
    canvas.scale(scale);

    for (final d in _ridges) {
      _drawSvgPath(canvas, d, basePaint);
    }

    if (progress > 0) {
      canvas.save();
      canvas.clipRect(Rect.fromLTWH(0, fillY, vbW, vbH - fillY));
      for (final d in _ridges) {
        _drawSvgPath(canvas, d, fillPaint);
      }
      canvas.restore();
    }

    canvas.restore();
  }

  void _drawSvgPath(Canvas canvas, String pathData, Paint paint) {
    final path = _parseSvgPath(pathData);
    canvas.drawPath(path, paint);
  }

  Path _parseSvgPath(String d) {
    final path = Path();
    final tokens = _tokenize(d);
    int i = 0;
    double cx = 0, cy = 0;
    double startX = 0, startY = 0;

    while (i < tokens.length) {
      final cmd = tokens[i];
      i++;

      switch (cmd) {
        case 'M':
          cx = tokens[i] as double;
          cy = tokens[i + 1] as double;
          i += 2;
          path.moveTo(cx, cy);
          startX = cx;
          startY = cy;
          break;
        case 'L':
          cx = tokens[i] as double;
          cy = tokens[i + 1] as double;
          i += 2;
          path.lineTo(cx, cy);
          break;
        case 'H':
          cx = tokens[i] as double;
          i += 1;
          path.lineTo(cx, cy);
          break;
        case 'V':
          cy = tokens[i] as double;
          i += 1;
          path.lineTo(cx, cy);
          break;
        case 'Q':
          final qx = tokens[i] as double;
          final qy = tokens[i + 1] as double;
          final ex = tokens[i + 2] as double;
          final ey = tokens[i + 3] as double;
          i += 4;
          path.quadraticBezierTo(qx, qy, ex, ey);
          cx = ex;
          cy = ey;
          break;
        case 'C':
          final c1x = tokens[i] as double;
          final c1y = tokens[i + 1] as double;
          final c2x = tokens[i + 2] as double;
          final c2y = tokens[i + 3] as double;
          final ex = tokens[i + 4] as double;
          final ey = tokens[i + 5] as double;
          i += 6;
          path.cubicTo(c1x, c1y, c2x, c2y, ex, ey);
          cx = ex;
          cy = ey;
          break;
        case 'Z':
          path.close();
          cx = startX;
          cy = startY;
          break;
      }
    }
    return path;
  }

  List<dynamic> _tokenize(String d) {
    final regex = RegExp(r'([MLHVCQZmlhvcqz])|(-?\d*\.?\d+)');
    final tokens = <dynamic>[];
    for (final m in regex.allMatches(d)) {
      final g1 = m.group(1);
      final g2 = m.group(2);
      if (g1 != null) {
        tokens.add(g1.toUpperCase());
      } else if (g2 != null) {
        tokens.add(double.parse(g2));
      }
    }
    return tokens;
  }

  @override
  bool shouldRepaint(covariant _FingerprintPainter old) =>
      old.progress != progress ||
      old.isPressing != isPressing ||
      old.completed != completed;
}