// lib/landing.dart
import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'buy.dart';
import 'login_page.dart';

const String kFont = 'Ganang';
const String kBrand = 'xizy crash';
const String kTg = 'https://t.me/hann_xd';
const String kSound = 'sound/cintaku.mp3';

// ═══════════════════════════════════════════════════════════════
// PALET — PURE BLACK MINIMAL
// ═══════════════════════════════════════════════════════════════
class LandingHx {
  // ── BACKGROUND ──
  static const bg    = Color(0xFF000000);
  static const bgAlt = Color(0xFF0A0A0A);

  // ── CARD ──
  static const surface   = Color(0xFF141414);
  static const surfaceHi = Color(0xFF141414);
  static const surfaceHi2 = Color(0xFF1C1C1C);

  // ── AKSEN — PUTIH SAJA ──
  static const goldLight = Color(0xFFE0E0E0);
  static const gold      = Color(0xFFFFFFFF);
  static const goldMid   = Color(0xFFD0D0D0);
  static const goldDeep  = Color(0xFF808080);

  // ── AKSEN WARNA (minimal, hanya status) ──
  static const jade     = Color(0xFF4ADE80);
  static const jadeDeep = Color(0xFF22C55E);
  static const terra    = Color(0xFFF87171);
  static const slate    = Color(0xFF60A5FA);
  static const amethyst = Color(0xFFA78BFA);

  // ── TEXT ──
  static const ivory = Color(0xFFFFFFFF);
  static const ash   = Color(0xFF9CA3AF);
  static const ash2  = Color(0xFF4B5563);

  static const line = Color(0x1AFFFFFF);
  static const lineSoft = Color(0x0DFFFFFF);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late final AnimationController _pulse;
  late final AnimationController _sparkle;
  late final AnimationController _breathe;
  late final AnimationController _stagger;

  final _audio = AudioPlayer();

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);

    _sparkle = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    _breathe = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _stagger = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();

    _playSound();
  }

  Future<void> _playSound() async {
    try {
      await _audio.setReleaseMode(ReleaseMode.loop);
      await _audio.setVolume(0.85);
      await _audio.play(AssetSource(kSound));
    } catch (_) {}
  }

  Future<void> _stopSound() async {
    try {
      await _audio.stop();
    } catch (_) {}
  }

  @override
  void dispose() {
    _pulse.dispose();
    _sparkle.dispose();
    _breathe.dispose();
    _stagger.dispose();
    _audio.dispose();
    super.dispose();
  }

  Future<void> _toLogin() async {
    HapticFeedback.mediumImpact();
    await _stopSound();
    if (!mounted) return;
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const LoginPage()));
  }

  Future<void> _toBuy() async {
    HapticFeedback.mediumImpact();
    await _stopSound();
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const BuyPage(sessionKey: '', username: ''),
      ),
    );
  }

  Future<void> _toTg() async {
    HapticFeedback.selectionClick();
    final Uri tgApp = Uri.parse('tg://resolve?domain=hann_xd');
    final Uri tgWeb = Uri.parse(kTg);

    try {
      final launched = await launchUrl(
        tgApp,
        mode: LaunchMode.externalApplication,
      );
      if (launched) return;
    } catch (_) {}

    try {
      final launched = await launchUrl(
        tgWeb,
        mode: LaunchMode.externalNonBrowserApplication,
      );
      if (launched) return;
    } catch (_) {}

    try {
      await launchUrl(tgWeb, mode: LaunchMode.platformDefault);
    } catch (_) {}
  }

  // ═══ STAGGERED ENTRY ═══
  Widget _staggered({
    required int index,
    required Widget child,
    int total = 6,
  }) {
    final double start = (index / total) * 0.5;
    final double end = (start + 0.5).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _stagger,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LandingHx.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF000000),
              Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 14),
                _staggered(index: 0, child: _topBar()),
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _staggered(index: 1, child: _emblemLogo()),
                          const SizedBox(height: 30),
                          _staggered(index: 2, child: _hero()),
                        ],
                      ),
                    ),
                  ),
                ),
                _staggered(index: 3, child: _bottom()),
                const SizedBox(height: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _topBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: LandingHx.ivory,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Center(
                child: Text(
                  'M',
                  style: TextStyle(
                    color: LandingHx.bg,
                    fontFamily: kFont,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              kBrand,
              style: TextStyle(
                color: LandingHx.ivory,
                fontFamily: kFont,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.2,
              ),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
          decoration: BoxDecoration(
            color: LandingHx.surfaceHi,
            border: Border.all(
              color: LandingHx.jade.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(100),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) {
                  final v = 0.4 + 0.6 * _pulse.value;
                  return Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: LandingHx.jade.withOpacity(v),
                      shape: BoxShape.circle,
                    ),
                  );
                },
              ),
              const SizedBox(width: 7),
              const Text(
                'ONLINE',
                style: TextStyle(
                  color: LandingHx.jade,
                  fontFamily: kFont,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.8,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══ EMBLEM LOGO ═══
  Widget _emblemLogo() {
    return SizedBox(
      width: 220, height: 220,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Sparkle stars rotating
          AnimatedBuilder(
            animation: _sparkle,
            builder: (_, __) {
              return Transform.rotate(
                angle: _sparkle.value * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(220, 220),
                  painter: _SparklePainter(),
                ),
              );
            },
          ),

          // Outer ring — putih subtle
          Container(
            width: 180, height: 180,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1,
              ),
            ),
          ),

          // Card gap
          Container(
            width: 160, height: 160,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: LandingHx.surfaceHi,
            ),
          ),

          // Pulse halo
          AnimatedBuilder(
            animation: _breathe,
            builder: (_, __) {
              final s = 1 + 0.06 * _breathe.value;
              return Transform.scale(
                scale: s,
                child: Container(
                  width: 140, height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withOpacity(
                        0.3 - 0.2 * _breathe.value,
                      ),
                      width: 1,
                    ),
                  ),
                ),
              );
            },
          ),

          // Center emblem — putih solid + text hitam
          AnimatedBuilder(
            animation: _breathe,
            builder: (_, __) {
              final s = 1 + 0.03 * _breathe.value;
              return Transform.scale(
                scale: s,
                child: Container(
                  width: 108, height: 108,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: LandingHx.ivory,
                  ),
                  child: const Center(
                    child: Text(
                      'M',
                      style: TextStyle(
                        color: LandingHx.bg,
                        fontFamily: kFont,
                        fontSize: 54,
                        fontWeight: FontWeight.w900,
                        height: 1.0,
                        letterSpacing: -2,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ═══ HERO TEXT ═══
  Widget _hero() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Eyebrow with animated white bar
        Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) {
                return Container(
                  width: 3,
                  height: 12,
                  color: LandingHx.ivory.withOpacity(
                    0.6 + 0.4 * _pulse.value,
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              'PREMIUM GUARDIAN',
              style: TextStyle(
                color: LandingHx.ivory,
                fontFamily: kFont,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text(
          'Secure',
          style: TextStyle(
            color: LandingHx.ivory,
            fontFamily: kFont,
            fontSize: 56,
            fontWeight: FontWeight.w900,
            height: 0.95,
            letterSpacing: -2.2,
          ),
        ),
        // Putih juga — bukan merah lagi
        const Text(
          'Everything.',
          style: TextStyle(
            color: LandingHx.ivory,
            fontFamily: kFont,
            fontSize: 56,
            fontWeight: FontWeight.w900,
            height: 0.95,
            letterSpacing: -2.2,
          ),
        ),
        const SizedBox(height: 24),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 3, height: 42,
              margin: const EdgeInsets.only(top: 4, right: 14),
              color: LandingHx.ivory.withOpacity(0.3),
            ),
            const Expanded(
              child: Text(
                'Satu akun untuk semua akses premium.\nCepat, aman, dan selalu online.',
                style: TextStyle(
                  color: LandingHx.ash,
                  fontFamily: kFont,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w500,
                  height: 1.55,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 30),
        // Chips
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _chip(Icons.bolt_rounded, 'Fast', LandingHx.ivory),
            _chip(Icons.shield_outlined, 'Secure', LandingHx.jade),
            _chip(Icons.public_rounded, 'Global', LandingHx.slate),
          ],
        ),
      ],
    );
  }

  Widget _chip(IconData i, String t, Color accent) {
    final isWhite = accent == LandingHx.ivory;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
      decoration: BoxDecoration(
        color: LandingHx.surfaceHi,
        border: Border.all(
          color: isWhite
              ? Colors.white.withOpacity(0.15)
              : accent.withOpacity(0.4),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(i, size: 14, color: accent),
          const SizedBox(width: 7),
          Text(
            t,
            style: const TextStyle(
              color: LandingHx.ivory,
              fontFamily: kFont,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  // ═══ BOTTOM BUTTONS ═══
  Widget _bottom() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // PRIMARY — putih solid + text hitam
        Container(
          height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: LandingHx.ivory,
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _toLogin,
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'GET STARTED',
                      style: TextStyle(
                        color: LandingHx.bg,
                        fontFamily: kFont,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3.0,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_rounded,
                      color: LandingHx.bg,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _outlineButton(
                icon: Icons.shopping_bag_outlined,
                label: 'BUY',
                accent: LandingHx.jade,
                onTap: _toBuy,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _outlineButton(
                icon: Icons.headset_mic_outlined,
                label: 'SUPPORT',
                accent: LandingHx.slate,
                onTap: _toTg,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _outlineButton({
    required IconData icon,
    required String label,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          HapticFeedback.mediumImpact();
          onTap();
        },
        child: Container(
          height: 54,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: LandingHx.surfaceHi,
            border: Border.all(
              color: accent.withOpacity(0.4),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16, color: accent),
              const SizedBox(width: 9),
              Text(
                label,
                style: const TextStyle(
                  color: LandingHx.ivory,
                  fontFamily: kFont,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SPARKLE PAINTER — bintang halus di sekeliling emblem
// ═══════════════════════════════════════════════════════════════
class _SparklePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 8;

    // 6 sparkle points
    for (int i = 0; i < 6; i++) {
      final angle = (i / 6) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      final sparklePaint = Paint()
        ..color = Colors.white.withOpacity(0.5)
        ..style = PaintingStyle.fill;

      _drawStar(canvas, Offset(x, y), i == 0 ? 9 : 6, sparklePaint);
    }

    // 4 small dots
    for (int i = 0; i < 4; i++) {
      final angle = (i / 4) * 2 * math.pi + math.pi / 4;
      final x = center.dx + radius * 0.75 * math.cos(angle);
      final y = center.dy + radius * 0.75 * math.sin(angle);

      final dotPaint = Paint()..color = Colors.white.withOpacity(0.3);
      canvas.drawCircle(Offset(x, y), 2.5, dotPaint);
    }
  }

  void _drawStar(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    // 4-point star
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx + size * 0.3, center.dy - size * 0.3);
    path.lineTo(center.dx + size, center.dy);
    path.lineTo(center.dx + size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx, center.dy + size);
    path.lineTo(center.dx - size * 0.3, center.dy + size * 0.3);
    path.lineTo(center.dx - size, center.dy);
    path.lineTo(center.dx - size * 0.3, center.dy - size * 0.3);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparklePainter old) => false;
}