// lib/tiktok_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

import 'theme.dart';

const String kFontFamily = 'Ganang';

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _videoInit = false;

  static const Color _warning = Color(0xFFFFC107);

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // PARSE URL TIKTOK → ambil video HD (100% work)
  // ═══════════════════════════════════════════════════════════
  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = "URL TikTok tidak boleh kosong.";
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoInit = false;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    // Coba multiple endpoint biar 100% work
    final endpoints = [
      "https://api.siputzx.my.id/api/d/tiktok?url=$url",
      "https://api.tiklydown.eu.org/api/download?url=$url",
      "https://www.tikwm.com/api/?url=$url&hd=1",
      "https://api.douyin.wtf/api/hybrid/video_data?url=$url&minimal=false",
    ];

    Map<String, dynamic>? result;
    String? lastError;

    for (final endpoint in endpoints) {
      try {
        final res = await http.get(Uri.parse(endpoint)).timeout(
              const Duration(seconds: 15),
            );
        if (res.statusCode != 200) {
          lastError = "Server error ${res.statusCode}";
          continue;
        }

        final json = jsonDecode(res.body);

        // Parse struktur response yang berbeda-beda
        result = _parseResponse(json);
        if (result != null) break;
      } catch (e) {
        lastError = "Error: $e";
        continue;
      }
    }

    if (!mounted) return;

    if (result != null) {
      setState(() {
        _videoData = result;
        _isLoading = false;
      });
      _initializeVideoPlayer();
    } else {
      setState(() {
        _errorMessage = lastError ?? "Gagal mengambil video. Coba URL lain.";
        _isLoading = false;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PARSE RESPONSE DARI BERBAGAI API
  // ═══════════════════════════════════════════════════════════
  Map<String, dynamic>? _parseResponse(dynamic json) {
    try {
      // Format 1: siputzx
      if (json['status'] == true && json['data'] != null) {
        final d = json['data'];
        final urls = (d['urls'] as List?)?.cast<String>() ?? [];
        if (urls.isNotEmpty) {
          return {
            'videoUrl': urls[0],
            'title': d['metadata']?['title'] ?? 'TikTok Video',
            'creator': d['metadata']?['creator'] ?? 'Unknown',
          };
        }
      }

      // Format 2: tiklydown
      if (json['video'] != null || json['music'] != null) {
        final video = json['video'];
        String videoUrl = '';
        if (video is Map) {
          videoUrl = video['noWatermark'] ??
              video['playAddr'] ??
              video['downloadAddr'] ??
              '';
        } else if (video is String) {
          videoUrl = video;
        }
        if (videoUrl.isNotEmpty) {
          return {
            'videoUrl': videoUrl,
            'title': json['title'] ?? 'TikTok Video',
            'creator': json['author']?['nickname'] ??
                json['author']?['unique_id'] ??
                'Unknown',
          };
        }
      }

      // Format 3: tikwm
      if (json['code'] == 0 && json['data'] != null) {
        final d = json['data'];
        final hd = d['hdplay'] ?? d['play'] ?? '';
        if (hd.isNotEmpty) {
          return {
            'videoUrl': hd,
            'title': d['title'] ?? 'TikTok Video',
            'creator': d['author']?['nickname'] ?? 'Unknown',
          };
        }
      }

      // Format 4: douyin.wtf
      if (json['data'] != null) {
        final d = json['data'];
        final url = d['video_data']?['nwm_video_url_HQ'] ??
            d['video_data']?['nwm_video_url'] ??
            d['video_data']?['wm_video_url_HQ'] ??
            d['video_data']?['wm_video_url'] ??
            '';
        if (url.isNotEmpty) {
          return {
            'videoUrl': url,
            'title': d['desc'] ?? 'TikTok Video',
            'creator': d['author']?['nickname'] ?? 'Unknown',
          };
        }
      }

      return null;
    } catch (e) {
      debugPrint("Parse error: $e");
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // INIT VIDEO PLAYER
  // ═══════════════════════════════════════════════════════════
  void _initializeVideoPlayer() {
    final videoUrl = _videoData?['videoUrl'];
    if (videoUrl == null || videoUrl.toString().isEmpty) return;

    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(videoUrl),
      httpHeaders: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://www.tiktok.com/',
      },
    );

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        showControls: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFFF5F5F5),
          handleColor: const Color(0xFFF5F5F5),
          backgroundColor: Colors.white.withOpacity(0.3),
          bufferedColor: Colors.white.withOpacity(0.2),
        ),
      );
      setState(() => _videoInit = true);
    }).catchError((e) {
      debugPrint("Video init error: $e");
      if (!mounted) return;
      setState(() {
        _errorMessage = "Gagal memuat video: ${e.toString()}";
      });
    });
  }

  // ═══════════════════════════════════════════════════════════
  // SHARE VIDEO
  // ═══════════════════════════════════════════════════════════
  Future<void> _shareVideo() async {
    final videoUrl = _videoData?['videoUrl'];
    if (videoUrl == null) return;

    final p = context.theme;

    try {
      final response = await http.get(
        Uri.parse(videoUrl),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
          'Referer': 'https://www.tiktok.com/',
        },
      );

      final tempDir = await getTemporaryDirectory();
      final file = File(
        '${tempDir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4',
      );
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Video TikTok dari: ${_videoData?['creator'] ?? 'Unknown'}',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Error sharing: $e',
            style: TextStyle(color: p.textPrimary, fontFamily: kFontFamily),
          ),
          backgroundColor: p.surfaceAlt,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
        ),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final p = context.theme;

    return Scaffold(
      backgroundColor: p.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: p.textPrimary),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: p.primary,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text(
            "TIKTOK DL",
            style: TextStyle(
              fontFamily: kFontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: p.onPrimary,
              letterSpacing: 2.0,
            ),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(p),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
              child: Column(
                children: [
                  // ── INPUT SECTION ──
                  _buildInputSection(p),
                  const SizedBox(height: 16),

                  // ── ERROR ──
                  if (_errorMessage != null) ...[
                    _buildErrorBox(p, _errorMessage!),
                    const SizedBox(height: 16),
                  ],

                  // ── RESULT ──
                  if (_videoData != null)
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: _buildVideoResult(p),
                      ),
                    )
                  else if (!_isLoading)
                    Expanded(child: _buildPlaceholder(p)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground(AppPalette p) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: p.bg),
        CustomPaint(
          painter: _GridPainter(color: Colors.white.withOpacity(0.03)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.6),
              radius: 0.9,
              colors: [
                Colors.white.withOpacity(0.04),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  BoxDecoration _kotakDecoration(AppPalette p, {
    bool withShadow = true,
    Color? fillColor,
  }) {
    return BoxDecoration(
      color: fillColor ?? p.surfaceAlt,
      border: Border.all(
        color: Colors.white.withOpacity(0.7),
        width: 1.5,
      ),
      boxShadow: withShadow
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                offset: const Offset(5, 5),
                blurRadius: 0,
              ),
            ]
          : null,
    );
  }

  // ── INPUT ──
  Widget _buildInputSection(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: TextField(
              controller: _urlController,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 14,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: p.textPrimary,
              decoration: InputDecoration(
                hintText: 'https://vt.tiktok.com/xxx/',
                hintStyle: TextStyle(
                  color: p.textMuted,
                  fontFamily: kFontFamily,
                  fontSize: 13,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                prefixIcon: Icon(Icons.link, color: p.textTertiary, size: 20),
                suffixIcon: _isLoading
                    ? Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: p.textPrimary,
                            strokeWidth: 2,
                          ),
                        ),
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _downloadTiktok,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                disabledBackgroundColor: p.surfaceAlt,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isLoading ? Icons.hourglass_top : Icons.download,
                    size: 20,
                    color: p.bg,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _isLoading ? 'PROSES...' : 'DOWNLOAD',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── ERROR BOX ──
  Widget _buildErrorBox(AppPalette p, String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surfaceAlt,
        border: Border.all(color: p.danger, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: p.danger, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── VIDEO RESULT ──
  Widget _buildVideoResult(AppPalette p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _kotakDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header pill
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: p.bg,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.7),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.videocam, color: p.textPrimary, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      "VIDEO PREVIEW",
                      style: TextStyle(
                        color: p.textPrimary,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: kFontFamily,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Video player
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: _chewieController != null && _videoInit
                ? AspectRatio(
                    aspectRatio: _videoController!.value.aspectRatio,
                    child: Chewie(controller: _chewieController!),
                  )
                : Container(
                    height: 220,
                    color: p.bg,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: p.textPrimary,
                            strokeWidth: 2.5,
                          ),
                          const SizedBox(height: 14),
                          Text(
                            'Loading video...',
                            style: TextStyle(
                              color: p.textMuted,
                              fontSize: 12,
                              fontFamily: kFontFamily,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),

          const SizedBox(height: 14),

          // Metadata
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.bg,
              border: Border.all(
                color: Colors.white.withOpacity(0.7),
                width: 1.5,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _videoData?['title'] ?? 'No Title',
                  style: TextStyle(
                    color: p.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFontFamily,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.person, color: p.textTertiary, size: 14),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Creator: ${_videoData?['creator'] ?? 'Unknown'}',
                        style: TextStyle(
                          color: p.textTertiary,
                          fontSize: 11,
                          fontFamily: kFontFamily,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // Share button
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _shareVideo,
              style: ElevatedButton.styleFrom(
                backgroundColor: p.textPrimary,
                foregroundColor: p.bg,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.share, size: 18, color: p.bg),
                  const SizedBox(width: 10),
                  Text(
                    'SHARE VIDEO',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: kFontFamily,
                      letterSpacing: 1.5,
                      color: p.bg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── PLACEHOLDER ──
  Widget _buildPlaceholder(AppPalette p) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: p.surfaceAlt,
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(
                Icons.video_library,
                size: 48,
                color: p.textMuted,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'TikTok Downloader',
              style: TextStyle(
                color: p.textPrimary,
                fontSize: 16,
                fontFamily: kFontFamily,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Masukkan URL TikTok untuk mendownload video',
              style: TextStyle(
                color: p.textMuted,
                fontSize: 12,
                fontFamily: kFontFamily,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;
    const s = 40.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color;
}