import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  bool _navigated = false;

  final GlobalKey _videoKey = GlobalKey();

  late AnimationController _orbitCtrl1;
  late AnimationController _orbitCtrl2;
  late AnimationController _orbitCtrl3;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _orbitCtrl1 = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();
    _orbitCtrl2 = AnimationController(
        vsync: this, duration: const Duration(seconds: 10))
      ..repeat();
    _orbitCtrl3 = AnimationController(
        vsync: this, duration: const Duration(seconds: 14))
      ..repeat();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);

    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      _videoCtrl =
          VideoPlayerController.asset('assets/videos/splash.mp4');
      await _videoCtrl.initialize();
      await _videoCtrl.setLooping(false);
      await _videoCtrl.setVolume(0);

      _videoCtrl.addListener(_onVideoTick);

      await _videoCtrl.play();

      if (!mounted) {
        await _videoCtrl.dispose();
        return;
      }
      setState(() => _videoReady = true);
    } catch (_) {
      if (mounted) {
        setState(() => _videoReady = false);
        Future.delayed(const Duration(seconds: 3), _navigateToDashboard);
      }
    } finally {
      _videoInitializing = false;
    }
  }

  void _onVideoTick() {
    if (!mounted || _navigated) return;
    final pos = _videoCtrl.value.position;
    final dur = _videoCtrl.value.duration;
    if (dur != Duration.zero && pos >= dur) {
      _navigateToDashboard();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _videoReady ? _videoCtrl : null;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying && !_navigated) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  void _navigateToDashboard() {
    if (_navigated || !mounted) return;
    _navigated = true;
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (_videoReady) {
      try {
        _videoCtrl.removeListener(_onVideoTick);
      } catch (_) {}
      try {
        _videoCtrl.dispose();
      } catch (_) {}
    }
    _orbitCtrl1.dispose();
    _orbitCtrl2.dispose();
    _orbitCtrl3.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Colors.black),

          if (!_videoReady)
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF0A0A0A),
                    Color(0xFF141414),
                    Color(0xFF000000),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),

          if (_videoReady)
            Positioned.fill(
              child: RepaintBoundary(
                child: ClipRect(
                  child: _CoverVideo(
                    key: _videoKey,
                    controller: _videoCtrl,
                  ),
                ),
              ),
            ),

          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.30),
                  Colors.black.withOpacity(0.60),
                  Colors.black.withOpacity(0.85),
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),

          Center(
            child: SizedBox(
              width: 280,
              height: 280,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Container(
                      width: 240,
                      height: 240,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFFFF2E2E).withOpacity(
                              0.10 + _pulseCtrl.value * 0.10),
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 180,
                    height: 180,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color:
                            const Color(0xFFFF2E2E).withOpacity(0.20),
                        width: 1,
                      ),
                    ),
                  ),
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color:
                            const Color(0xFFFF2E2E).withOpacity(0.35),
                        width: 1.5,
                      ),
                    ),
                  ),
                  _buildOrbitDot(
                    controller: _orbitCtrl1,
                    radius: 120,
                    size: 12,
                    color: const Color(0xFFFF2E2E),
                  ),
                  _buildOrbitDot(
                    controller: _orbitCtrl2,
                    radius: 90,
                    size: 10,
                    color: const Color(0xFFFFFFFF),
                    reverse: true,
                  ),
                  _buildOrbitDot(
                    controller: _orbitCtrl3,
                    radius: 60,
                    size: 8,
                    color: const Color(0xFFFF2E2E),
                  ),
                  AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.black.withOpacity(0.85),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF2E2E).withOpacity(
                                0.5 + _pulseCtrl.value * 0.3),
                            blurRadius: 30,
                            spreadRadius: 4,
                          ),
                        ],
                        border: Border.all(
                          color: const Color(0xFFFF2E2E),
                          width: 2,
                        ),
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/logo.png',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(
                            Icons.shield_rounded,
                            color: Color(0xFFFF2E2E),
                            size: 38,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            top: 50,
            right: 20,
            child: GestureDetector(
              onTap: _navigateToDashboard,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFFFF2E2E).withOpacity(0.6),
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.skip_next_rounded,
                        color: Color(0xFFFF2E2E), size: 18),
                    SizedBox(width: 4),
                    Text(
                      'SKIP',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          Positioned(
            bottom: 60,
            left: 0,
            right: 0,
            child: Column(
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [
                      Colors.white,
                      Color(0xFFFF2E2E),
                      Colors.white,
                    ],
                    stops: [0.0, 0.5, 1.0],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ).createShader(bounds),
                  child: const Text(
                    'XYRO ENGINE',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 4,
                      shadows: [
                        Shadow(
                          color: Color(0xFFFF2E2E),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  width: 120,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Colors.transparent,
                        Color(0xFFFF2E2E),
                        Colors.transparent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 12),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    'Support Xyro Apps\nBug X · RAT · Tools Terlengkap',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      height: 1.5,
                      letterSpacing: 0.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFFF2E2E),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Powered by @ganang',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.white.withOpacity(0.75),
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFFF2E2E),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          Positioned(
            top: 100,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: const Color(0xFFFF2E2E).withOpacity(0.6),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrbitDot({
    required AnimationController controller,
    required double radius,
    required double size,
    required Color color,
    bool reverse = false,
  }) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        final angle = (reverse ? -1 : 1) * controller.value * 2 * math.pi;
        final x = radius * math.cos(angle);
        final y = radius * math.sin(angle);
        return Transform.translate(
          offset: Offset(x, y),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.8),
                  blurRadius: size * 1.5,
                  spreadRadius: size * 0.3,
                ),
                BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: size * 3,
                  spreadRadius: size * 0.5,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}