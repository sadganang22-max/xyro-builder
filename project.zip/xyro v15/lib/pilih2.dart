// ═══════════════════════════════════════════════════════════════════════════
//  PILIH2 PAGE — MENU 3 MODE · HORIZONTAL SCROLL (FIXED)
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'home_page.dart';
import 'group_page.dart';
import 'custom_bug.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const greenSoft = Color(0xFFECFDF5);
  static const purple    = Color(0xFF8B5CF6);
  static const purpleSoft= Color(0xFFF5F3FF);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

// ═══════════════════════════════════════════════════════════════════════════
//  MENU DATA
// ═══════════════════════════════════════════════════════════════════════════
class _MenuData {
  final IconData icon;
  final String title;
  final String subtitle;
  final String description;
  final String tag;
  final Color accent;
  final List<String> features;
  final Widget Function() builder;

  const _MenuData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.tag,
    required this.accent,
    required this.features,
    required this.builder,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE
// ═══════════════════════════════════════════════════════════════════════════
class Pilih2Page extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const Pilih2Page({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.listBug,
  });

  @override
  State<Pilih2Page> createState() => _Pilih2PageState();
}

class _Pilih2PageState extends State<Pilih2Page> with TickerProviderStateMixin {
  late final List<_MenuData> _menus;
  late PageController _pageCtrl;
  int _currentPage = 0;

  late AnimationController _entranceCtrl;

  @override
  void initState() {
    super.initState();

    _menus = [
      // ✅ FIX: Hapus password, role, expiredDate dari HomePage (kecuali yang emang ada)
      _MenuData(
        icon: Icons.phone_android_rounded,
        title: 'NUMBER',
        subtitle: 'Kirim ke nomor HP',
        description: 'Kirim bug ke nomor WhatsApp target. Cepat, gacor, dan stabil untuk pengiriman massal ke nomor pribadi.',
        tag: 'NUM',
        accent: _C.ice2,
        features: ['Single number', 'Fast send', 'Auto detect'],
        builder: () => HomePage(
          username: widget.username,
          password: '',
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: '',
        ),
      ),
      // ✅ FIX: GroupPage cuma butuh username, sessionKey, listBug
      _MenuData(
        icon: Icons.groups_rounded,
        title: 'GROUP',
        subtitle: 'Kirim ke grup WhatsApp',
        description: 'Deteksi info group otomatis dari link. Kirim bug ke grup dengan sender aktif tanpa ribet.',
        tag: 'GRP',
        accent: _C.purple,
        features: ['Auto detect group', 'Foto & member', 'Link support'],
        builder: () => GroupPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
        ),
      ),
      _MenuData(
        icon: Icons.tune_rounded,
        title: 'CUSTOM',
        subtitle: 'Multi-select bug',
        description: 'Pilih lebih dari 1 bug sekaligus. Bisa select all atau pick manual. Kirim ke nomor target sekali jalan.',
        tag: 'CST',
        accent: _C.green,
        features: ['Multi select', 'Select all', 'Bulk send'],
        builder: () => CustomBugPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
          listBug: widget.listBug,
        ),
      ),
    ];

    _pageCtrl = PageController(viewportFraction: 0.78);
    _pageCtrl.addListener(() {
      final p = _pageCtrl.page?.round() ?? 0;
      if (p != _currentPage && p >= 0 && p < _menus.length) {
        setState(() => _currentPage = p);
      }
    });

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _entranceCtrl.dispose();
    super.dispose();
  }

  Future<void> _openMenu(_MenuData menu) async {
    final page = menu.builder();
    await Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionDuration: const Duration(milliseconds: 350),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildAppBar(),
                const SizedBox(height: 20),
                _buildHeader(),
                const SizedBox(height: 16),
                _buildHintBar(),
                const SizedBox(height: 24),
                Expanded(
                  child: PageView.builder(
                    controller: _pageCtrl,
                    physics: const BouncingScrollPhysics(),
                    itemCount: _menus.length,
                    itemBuilder: (context, i) {
                      return AnimatedBuilder(
                        animation: _pageCtrl,
                        builder: (context, child) {
                          double scale = 1.0;
                          double opacity = 1.0;
                          if (_pageCtrl.position.haveDimensions) {
                            final page = _pageCtrl.page ?? 0;
                            final diff = (page - i).abs().clamp(0.0, 1.0);
                            scale = 1 - diff * 0.10;
                            opacity = 1 - diff * 0.4;
                          }
                          return Transform.scale(
                            scale: scale,
                            child: Opacity(opacity: opacity.clamp(0.5, 1.0), child: child),
                          );
                        },
                        child: _buildMenuCard(_menus[i]),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 14),
                _buildDots(),
                const SizedBox(height: 16),
                _buildFooter(),
                const SizedBox(height: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded, color: _C.text, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('PILIH MODE',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        letterSpacing: 2)),
                Text('Pilih tipe pengiriman bug',
                    style: TextStyle(color: _C.textDim, fontSize: 12, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_C.ice, _C.ice2, _C.ice3],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: _shPrimary,
            ),
            child: ClipOval(
              child: Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.shield_rounded, color: Colors.white, size: 20)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border),
              boxShadow: _sh1,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _AnimatedDotCyan(),
                const SizedBox(width: 6),
                const Text('SWIPE UNTUK PILIH',
                    style: TextStyle(color: _C.textSub, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
              ],
            ),
          ),
          const SizedBox(height: 10),
          const Text('Pilih Mode',
              style: TextStyle(
                  color: _C.text,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 26,
                  letterSpacing: -0.5)),
        ],
      ),
    );
  }

  Widget _buildHintBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _C.iceSoft,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.ice.withOpacity(0.35)),
        ),
        child: Row(
          children: [
            Container(
              width: 26, height: 26,
              decoration: BoxDecoration(shape: BoxShape.circle, color: _C.ice2.withOpacity(0.15)),
              child: const Icon(Icons.info_outline_rounded, color: _C.ice2, size: 14),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text('Swipe kiri-kanan, lalu tap card untuk mulai',
                  style: TextStyle(color: _C.ice3, fontSize: 11, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard(_MenuData menu) {
    return GestureDetector(
      onTap: () => _openMenu(menu),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: menu.accent.withOpacity(0.3), width: 1.5),
          boxShadow: _sh2,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned(
                left: 0, top: 0, bottom: 0,
                child: Container(
                  width: 5,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [menu.accent, menu.accent.withOpacity(0.5)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 20, 18, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 54, height: 54,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [menu.accent, menu.accent.withOpacity(0.7)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(color: menu.accent.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6)),
                            ],
                          ),
                          child: Icon(menu.icon, color: Colors.white, size: 26),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(menu.title,
                                  style: const TextStyle(
                                      color: _C.text,
                                      fontFamily: 'Orbitron',
                                      fontWeight: FontWeight.w900,
                                      fontSize: 20,
                                      letterSpacing: 1.5)),
                              const SizedBox(height: 3),
                              Text(menu.subtitle,
                                  style: const TextStyle(color: _C.textSub, fontSize: 12, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: menu.accent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: menu.accent.withOpacity(0.4)),
                          ),
                          child: Text(menu.tag,
                              style: TextStyle(
                                  color: menu.accent,
                                  fontFamily: 'Orbitron',
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _C.cardAlt,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border),
                      ),
                      child: Text(menu.description,
                          style: const TextStyle(color: _C.textSub, fontSize: 12, height: 1.6)),
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: menu.features.map((f) {
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: menu.accent.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: menu.accent.withOpacity(0.3)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.check_circle_rounded, color: menu.accent, size: 11),
                              const SizedBox(width: 4),
                              Text(f, style: TextStyle(color: menu.accent, fontSize: 10, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [menu.accent, menu.accent.withOpacity(0.75)],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(color: menu.accent.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4)),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('Buka',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                    letterSpacing: 0.5)),
                            SizedBox(width: 6),
                            Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_menus.length, (i) {
        final isActive = i == _currentPage;
        return GestureDetector(
          onTap: () => _pageCtrl.animateToPage(
            i,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic,
          ),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: isActive ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: isActive ? _C.ice2 : _C.borderMid,
            ),
          ),
        );
      }),
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Column(
        children: [
          Container(
            height: 2, width: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_C.ice, _C.ice2, _C.ice3]),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 8),
          const Text('XYRO ENGINE · v1.0',
              style: TextStyle(
                  color: _C.textDim,
                  fontFamily: 'Orbitron',
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5)),
        ],
      ),
    );
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────
class _AnimatedDotCyan extends StatefulWidget {
  @override
  State<_AnimatedDotCyan> createState() => _AnimatedDotCyanState();
}

class _AnimatedDotCyanState extends State<_AnimatedDotCyan> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _a = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: 6, height: 6,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _C.green,
        boxShadow: [BoxShadow(color: _C.green.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}