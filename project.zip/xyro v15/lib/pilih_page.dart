// ═══════════════════════════════════════════════════════════════════════════
//  PILIH PAGE — HORIZONTAL SHOWCASE
//  Scroll horizontal · snap card · parallax · indicator · open button
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';

import 'pilih2.dart';
import 'bug_sender.dart';
import 'spam_ngl.dart';
import 'al_quran.dart';
import 'devices_page.dart';
import 'game.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const green  = Color(0xFF10B981);
  static const ice2   = Color(0xFF0EA5E9);
  static const red    = Color(0xFFEF4444);
  static const blue   = Color(0xFF3B82F6);
  static const pink   = Color(0xFFEC4899);
  static const purple = Color(0xFF8B5CF6);
}

// ═══════════════════════════════════════════════════════════════════════════
//  MENU DATA
// ═══════════════════════════════════════════════════════════════════════════
class _MenuItem {
  final IconData icon;
  final String title;
  final String tag;
  final Color accent;
  final Widget Function(BuildContext) builder;

  const _MenuItem({
    required this.icon,
    required this.title,
    required this.tag,
    required this.accent,
    required this.builder,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE
// ═══════════════════════════════════════════════════════════════════════════
class PilihPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;

  const PilihPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    this.listBug = const [],
    this.listDoos = const [],
  });

  @override
  State<PilihPage> createState() => _PilihPageState();
}

class _PilihPageState extends State<PilihPage> with TickerProviderStateMixin {
  late final List<_MenuItem> _items;
  late PageController _pageCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _spinCtrl;

  int _current = 0;

  @override
  void initState() {
    super.initState();

    _items = [
      _MenuItem(
        icon: Icons.chat_bubble_rounded,
        title: 'Bug & Pairing',
        tag: 'WA',
        accent: _C.green,
        builder: (context) => Pilih2Page(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
          listBug: widget.listBug,
        ),
      ),
      _MenuItem(
        icon: Icons.send_rounded,
        title: 'Sender',
        tag: 'SND',
        accent: _C.ice2,
        builder: (context) => BugSenderPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
      _MenuItem(
        icon: Icons.bug_report_rounded,
        title: 'Rat / Trojan',
        tag: 'RAT',
        accent: _C.red,
        builder: (context) => DevicesPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
      _MenuItem(
        icon: Icons.sports_esports_rounded,
        title: 'Xyro Arcade',
        tag: 'GAME',
        accent: _C.blue,
        builder: (context) => const GameHubPage(),
      ),
      _MenuItem(
        icon: Icons.campaign_rounded,
        title: 'Spam NGL',
        tag: 'NGL',
        accent: _C.pink,
        builder: (context) => NglPage(),
      ),
      _MenuItem(
        icon: Icons.menu_book_rounded,
        title: 'Al Quran',
        tag: 'QUR',
        accent: _C.purple,
        builder: (context) => AlQuranPage(),
      ),
    ];

    _pageCtrl = PageController(viewportFraction: 0.70, initialPage: 0);
    _pageCtrl.addListener(() {
      final p = _pageCtrl.page?.round() ?? 0;
      if (p != _current && p >= 0 && p < _items.length) {
        setState(() => _current = p);
      }
    });

    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _spinCtrl.dispose();
    super.dispose();
  }

  Future<void> _openItem(_MenuItem item) async {
    final page = item.builder(context);
    await Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (ctx, anim, secAnim) => page,
        transitionDuration: const Duration(milliseconds: 400),
        transitionsBuilder: (ctx, anim, secAnim, child) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // ── BG IMAGE ──
          Positioned.fill(
            child: Image.asset(
              'assets/images/pilih_bg.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF0C4A6E),
                      Color(0xFF0369A1),
                      Color(0xFF0284C7),
                      Color(0xFF0EA5E9),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // ── VIGNETTE ──
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.55),
                    Colors.black.withOpacity(0.15),
                    Colors.black.withOpacity(0.10),
                    Colors.black.withOpacity(0.72),
                  ],
                  stops: const [0.0, 0.35, 0.55, 1.0],
                ),
              ),
            ),
          ),
          // ── CLOUD BOTTOM ──
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: IgnorePointer(child: _buildCloudOverlay()),
          ),

          // ── CONTENT ──
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 6),
                _buildTopBar(),
                const SizedBox(height: 16),
                _buildHeader(),
                const SizedBox(height: 8),
                Expanded(child: _buildShowcase()),
                _buildIndicator(),
                const SizedBox(height: 16),
                _buildOpenButton(),
                const SizedBox(height: 22),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── TOP BAR ──
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.15),
                border: Border.all(color: Colors.white.withOpacity(0.30), width: 1.2),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.2),
            ),
            child: Row(
              children: [
                _pulseDot(),
                const SizedBox(width: 6),
                const Text(
                  'XYRO MENU',
                  style: TextStyle(
                    color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _pulseDot() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Container(
        width: 6, height: 6,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _C.green,
          boxShadow: [
            BoxShadow(
              color: _C.green.withOpacity(0.5 + _pulseCtrl.value * 0.5),
              blurRadius: 6, spreadRadius: 1,
            ),
          ],
        ),
      ),
    );
  }

  // ── HEADER ──
  Widget _buildHeader() {
    return FadeTransition(
      opacity: CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'MENU UTAMA',
                    style: TextStyle(
                      color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900,
                      fontStyle: FontStyle.italic, letterSpacing: 1.5, height: 1.0,
                      shadows: [
                        Shadow(color: Colors.black54, offset: Offset(0, 3), blurRadius: 10),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(width: 24, height: 2, color: Colors.white.withOpacity(0.7)),
                      const SizedBox(width: 8),
                      Text(
                        '${_items.length} MENU · SWIPE →',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.88), fontSize: 10,
                          fontWeight: FontWeight.w700, letterSpacing: 2.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            // counter
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: ScaleTransition(scale: anim, child: child),
              ),
              child: Container(
                key: ValueKey(_current),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _items[_current].accent.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _items[_current].accent, width: 1.2),
                ),
                child: Text(
                  '${(_current + 1).toString().padLeft(2, '0')} / ${_items.length.toString().padLeft(2, '0')}',
                  style: const TextStyle(
                    color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── SHOWCASE (Horizontal Scroll) ──
  Widget _buildShowcase() {
    return AnimatedBuilder(
      animation: _pageCtrl,
      builder: (context, _) {
        double page = 0;
        if (_pageCtrl.hasClients && _pageCtrl.position.haveDimensions) {
          page = _pageCtrl.page ?? 0;
        }
        return PageView.builder(
          controller: _pageCtrl,
          physics: const BouncingScrollPhysics(),
          padEnds: true,
          itemCount: _items.length,
          itemBuilder: (context, i) {
            final diff = (page - i).abs().clamp(0.0, 1.0);
            final scale = 1 - diff * 0.16;
            final opacity = 1 - diff * 0.55;
            final isActive = i == _current;
            return Transform.scale(
              scale: scale,
              child: Opacity(
                opacity: opacity.clamp(0.30, 1.0),
                child: _buildMenuCard(_items[i], i, isActive),
              ),
            );
          },
        );
      },
    );
  }

  // ── MENU CARD ──
  Widget _buildMenuCard(_MenuItem item, int index, bool isActive) {
    return GestureDetector(
      onTap: () {
        if (isActive) {
          _openItem(item);
        } else {
          _pageCtrl.animateToPage(
            index,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOutCubic,
          );
        }
      },
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isActive
                  ? [
                      item.accent.withOpacity(0.30),
                      item.accent.withOpacity(0.10),
                      Colors.black.withOpacity(0.30),
                    ]
                  : [
                      Colors.white.withOpacity(0.10),
                      Colors.white.withOpacity(0.04),
                      Colors.black.withOpacity(0.20),
                    ],
              stops: const [0.0, 0.5, 1.0],
            ),
            border: Border.all(
              color: isActive
                  ? item.accent.withOpacity(0.85)
                  : Colors.white.withOpacity(0.15),
              width: isActive ? 2.0 : 1.2,
            ),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: item.accent.withOpacity(0.55),
                      blurRadius: 32,
                      spreadRadius: 4,
                      offset: const Offset(0, 16),
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.40),
                      blurRadius: 20,
                      offset: const Offset(0, 12),
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: Stack(
              children: [
                // Corner accent glow
                Positioned(
                  top: -40, right: -40,
                  child: Container(
                    width: 160, height: 160,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          item.accent.withOpacity(isActive ? 0.35 : 0.15),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // TOP — tag badge
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: item.accent.withOpacity(0.20),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: item.accent.withOpacity(0.6), width: 1),
                            ),
                            child: Text(
                              item.tag,
                              style: const TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 2,
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              (index + 1).toString().padLeft(2, '0'),
                              style: const TextStyle(
                                color: Colors.white, fontSize: 10,
                                fontWeight: FontWeight.w900, letterSpacing: 1,
                              ),
                            ),
                          ),
                        ],
                      ),

                      // MIDDLE — icon + orbit
                      SizedBox(
                        width: 170, height: 170,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // glow
                            Container(
                              width: isActive ? 160 : 140,
                              height: isActive ? 160 : 140,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    item.accent.withOpacity(isActive ? 0.45 : 0.20),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                            // orbit ring
                            if (isActive)
                              AnimatedBuilder(
                                animation: _spinCtrl,
                                builder: (_, __) => Transform.rotate(
                                  angle: _spinCtrl.value * 2 * math.pi,
                                  child: CustomPaint(
                                    size: const Size(150, 150),
                                    painter: _OrbitPainter(color: item.accent),
                                  ),
                                ),
                              ),
                            // icon
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              width: isActive ? 88 : 76,
                              height: isActive ? 88 : 76,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [item.accent, item.accent.withOpacity(0.7)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                border: Border.all(
                                  color: Colors.white.withOpacity(isActive ? 0.85 : 0.45),
                                  width: isActive ? 3 : 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: item.accent.withOpacity(isActive ? 0.85 : 0.40),
                                    blurRadius: isActive ? 30 : 16,
                                    spreadRadius: isActive ? 4 : 0,
                                    offset: const Offset(0, 8),
                                  ),
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.30),
                                    blurRadius: 12,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                              ),
                              child: Icon(item.icon, color: Colors.white, size: isActive ? 40 : 34),
                            ),
                          ],
                        ),
                      ),

                      // BOTTOM — title + active bar
                      Column(
                        children: [
                          Text(
                            item.title,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: isActive ? Colors.white : Colors.white.withOpacity(0.75),
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.4,
                              shadows: const [
                                Shadow(color: Colors.black87, offset: Offset(0, 1), blurRadius: 6),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            height: 3,
                            width: isActive ? 50 : 24,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: isActive ? item.accent : Colors.white.withOpacity(0.25),
                              boxShadow: isActive
                                  ? [
                                      BoxShadow(
                                        color: item.accent.withOpacity(0.8),
                                        blurRadius: 8,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── CLOUD OVERLAY BOTTOM ──
  Widget _buildCloudOverlay() {
    return SizedBox(
      height: 160,
      child: Stack(
        children: [
          Positioned(
            bottom: -60, left: -40,
            child: Container(
              width: 220, height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: Colors.white.withOpacity(0.08),
              ),
            ),
          ),
          Positioned(
            bottom: -100, left: 60,
            child: Container(
              width: 260, height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: Colors.white.withOpacity(0.06),
              ),
            ),
          ),
          Positioned(
            bottom: -80, right: -30,
            child: Container(
              width: 240, height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: Colors.white.withOpacity(0.08),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── INDICATOR BAR ──
  Widget _buildIndicator() {
    return Container(
      height: 8,
      margin: const EdgeInsets.symmetric(horizontal: 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_items.length, (i) {
          final isActive = i == _current;
          final accent = _items[i].accent;
          return GestureDetector(
            onTap: () => _pageCtrl.animateToPage(
              i,
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOutCubic,
            ),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 28 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? accent : Colors.white.withOpacity(0.35),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: accent.withOpacity(0.8),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ]
                    : null,
              ),
            ),
          );
        }),
      ),
    );
  }

  // ── OPEN BUTTON ──
  Widget _buildOpenButton() {
    final item = _items[_current];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => _openItem(item),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: [item.accent.withOpacity(0.98), item.accent.withOpacity(0.78)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: Colors.white.withOpacity(0.45), width: 1.3),
            boxShadow: [
              BoxShadow(
                color: item.accent.withOpacity(0.65),
                blurRadius: 24,
                spreadRadius: 2,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.30),
                blurRadius: 12,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 30, height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.25),
                  ),
                  child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16),
                ),
                const SizedBox(width: 12),
                Flexible(
                  child: Text(
                    'BUKA ${item.title.toUpperCase()}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(color: Colors.black38, offset: Offset(0, 1), blurRadius: 4),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ORBIT PAINTER
// ═══════════════════════════════════════════════════════════════════════════
class _OrbitPainter extends CustomPainter {
  final Color color;
  _OrbitPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    // Dashed ring
    final dashPaint = Paint()
      ..color = color.withOpacity(0.55)
      ..strokeWidth = 1.6
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 24;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.10, false, dashPaint);
    }

    // Satellite dots
    for (int i = 0; i < 3; i++) {
      final angle = i * 2 * math.pi / 3 + 0.3;
      final dx = center.dx + radius * math.cos(angle);
      final dy = center.dy + radius * math.sin(angle);
      canvas.drawCircle(Offset(dx, dy), 3.5, Paint()..color = color.withOpacity(0.85));
      canvas.drawCircle(Offset(dx, dy), 8, Paint()..color = color.withOpacity(0.20));
    }
  }

  @override
  bool shouldRepaint(covariant _OrbitPainter old) => old.color != color;
}