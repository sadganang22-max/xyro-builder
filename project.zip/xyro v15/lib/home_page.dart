// ═══════════════════════════════════════════════════════════════════════════
//  HOME PAGE — BUG NUMBER · ROMBAK TOTAL
//  Command console layout · bug list full-width · sender dock bottom
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9), Color(0xFF0284C7), Color(0xFF0369A1)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _resultCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _orbitCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;
  late Animation<double> _entrance;

  final targetController = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  List<Map<String, dynamic>> get _numberBugs => widget.listBug
      .where((b) => (b['type']?.toString().toLowerCase() ?? '') == 'number')
      .toList();

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;

  String _selectedSender = 'private';

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase().trim();
    return r == 'owner' || r == 'vip' || r == 'pemula';
  }

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);

    _resultCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 10))..repeat();

    _fetchSenderStats();
    if (canAccessGlobalSender) _loadGlobalSenders();

    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
    });

    if (_numberBugs.isNotEmpty) {
      _selectedBugId = _numberBugs[0]['bug_id'] as String? ?? '0';
    }
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _resultCtrl.dispose();
    _entranceCtrl.dispose();
    _orbitCtrl.dispose();
    targetController.dispose();
    _scrollCtrl.dispose();
    _senderTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/getSenderStats?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _loadingSender = false;
          });
        } else {
          setState(() => _loadingSender = false);
        }
      } else {
        setState(() => _loadingSender = false);
      }
    } catch (_) {
      setState(() => _loadingSender = false);
    }
  }

  Future<void> _loadGlobalSenders() async {
    if (!canAccessGlobalSender) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) {
          setState(() {
            _globalSenders = List<String>.from(data['senders']);
            _globalSenderCount = _globalSenders.length;
          });
        }
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
    // Auto scroll ke result
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (formatPhoneNumber(rawInput) == null) {
      _showAlert("❌ Nomor Tidak Valid",
          "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
      return;
    }

    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert("❌ Akses Ditolak",
          "Sender Global hanya untuk Owner / VIP / Pemula!");
      return;
    }

    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert("❌ No Bug Selected", "Pilih 1 bug untuk dikirim.");
      return;
    }

    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert("❌ No Private Sender", "Tidak ada private sender tersedia.");
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert("❌ No Global Sender", "Tidak ada global sender tersedia.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });
    _resultCtrl.reset();

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final res = await http.get(Uri.parse(
        '$baseUrl/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', data['message'] ?? 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final role = data['role'] ?? widget.role;
        _setResponse('success', 'Bug berhasil dikirim ke $rawInput! [$role]');
        targetController.clear();
      } else {
        _setResponse('error', data['message'] ?? 'Gagal mengirim. Server sedang maintenance.');
      }
    } catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _C.ice.withOpacity(0.4), width: 1.5),
        ),
        title: Text(title,
            style: const TextStyle(
                color: _C.ice3, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK",
                style: TextStyle(color: _C.ice2, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // BG IMAGE
          Positioned.fill(
            child: Image.asset('assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          // Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(0.75),
                    Colors.white.withOpacity(0.85),
                    Colors.white.withOpacity(0.70),
                  ],
                ),
              ),
            ),
          ),
          // Grid pattern
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),

          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                _buildDivider(),
                Expanded(
                  child: FadeTransition(
                    opacity: _entrance,
                    child: SingleChildScrollView(
                      controller: _scrollCtrl,
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildHeroCommandCard(),
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '01',
                            title: 'TARGET NUMBER',
                            icon: Icons.phone_android_rounded,
                            color: _C.ice2,
                            child: _buildPhoneInput(),
                          ),
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '02',
                            title: 'SELECT BUG',
                            icon: Icons.bug_report_rounded,
                            color: _C.red,
                            child: _buildBugList(),
                          ),
                          if (canAccessGlobalSender) ...[
                            const SizedBox(height: 14),
                            _buildStepPanel(
                              step: '03',
                              title: 'SENDER CHANNEL',
                              icon: Icons.swap_horiz_rounded,
                              color: _C.ice3,
                              child: _buildSenderSelection(),
                            ),
                          ],
                          const SizedBox(height: 20),
                          _buildSendButton(),
                          _buildResponseMessage(),
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() => Container(
    height: 1,
    margin: const EdgeInsets.symmetric(horizontal: 14),
    color: _C.border.withOpacity(0.6),
  );

  // ─── TOP BAR ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _C.primaryGrad,
              boxShadow: _shPrimary,
            ),
            child: const Icon(Icons.shield_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('XYRO ENGINE',
                    style: TextStyle(
                        color: _C.text, fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2)),
                Text('BUG NUMBER CONSOLE',
                    style: TextStyle(
                        color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w700,
                        letterSpacing: 2, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.ice.withOpacity(0.5), width: 1.2),
              color: _C.iceSoft,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 6, height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, color: _C.green,
                    boxShadow: [BoxShadow(color: _C.green.withOpacity(0.6), blurRadius: 4)],
                  ),
                ),
                const SizedBox(width: 6),
                const Text('LIVE',
                    style: TextStyle(
                        color: _C.ice3, fontSize: 9,
                        fontWeight: FontWeight.w900, letterSpacing: 1.5,
                        fontFamily: 'Orbitron')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO COMMAND CARD ──────────────────────────────────────────────────────
  Widget _buildHeroCommandCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF0A2540), Color(0xFF0F3A5F), Color(0xFF0A2540)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: _C.ice2.withOpacity(0.35), blurRadius: 28, offset: const Offset(0, 12)),
          BoxShadow(color: _C.text.withOpacity(0.20), blurRadius: 48, offset: const Offset(0, 20)),
        ],
        border: Border.all(color: _C.ice2.withOpacity(0.4), width: 1.2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            // Orbital decoration
            Positioned(
              top: -40, right: -40,
              child: AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: _orbitCtrl.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(180, 180),
                    painter: _HeroOrbitPainter(),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.ice2.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.ice2.withOpacity(0.6)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.bolt_rounded, color: _C.ice, size: 11),
                            const SizedBox(width: 4),
                            const Text('ACTIVE SESSION',
                              style: TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 1.5,
                              )),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text('v1.0',
                        style: TextStyle(
                          color: _C.ice.withOpacity(0.6),
                          fontSize: 10, fontWeight: FontWeight.w900,
                          letterSpacing: 2, fontFamily: 'Orbitron',
                        )),
                    ],
                  ),
                  const SizedBox(height: 18),
                  // Avatar + info
                  Row(
                    children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _C.ice.withOpacity(0.6), width: 2),
                          boxShadow: [BoxShadow(color: _C.ice2.withOpacity(0.5), blurRadius: 16)],
                        ),
                        child: ClipOval(
                          child: Image.asset('assets/images/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                              const Icon(Icons.person, color: _C.ice, size: 30)),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.username.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1,
                              ),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.ice2.withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(widget.role.toUpperCase(),
                                    style: const TextStyle(
                                      color: _C.ice, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: 1,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Icon(Icons.access_time_rounded, color: _C.ice.withOpacity(0.6), size: 11),
                                const SizedBox(width: 4),
                                Flexible(
                                  child: Text(widget.expiredDate.isEmpty ? 'N/A' : widget.expiredDate,
                                    style: TextStyle(
                                      color: _C.ice.withOpacity(0.85), fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w700, fontSize: 10,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Container(height: 1, color: Colors.white.withOpacity(0.10)),
                  const SizedBox(height: 14),
                  // Stats row
                  Row(
                    children: [
                      _miniStat('${_numberBugs.length}', 'BUGS', _C.ice),
                      const SizedBox(width: 16),
                      _miniStat('${_privateSenderCount + _globalSenderCount}', 'SENDERS', _C.green),
                      const SizedBox(width: 16),
                      _miniStat('GACOR', 'STATUS', _C.green),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniStat(String value, String label, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value,
          style: TextStyle(
            color: color, fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 0.5,
          ),
        ),
        Text(label,
          style: TextStyle(
            color: _C.ice.withOpacity(0.6), fontSize: 9,
            fontWeight: FontWeight.w700, letterSpacing: 1.5,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  // ─── STEP PANEL WRAPPER ─────────────────────────────────────────────────────
  Widget _buildStepPanel({
    required String step,
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: _sh2,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            // Top accent bar
            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.4)],
                  ),
                ),
              ),
            ),
            // Big step number background
            Positioned(
              top: -10, right: 8,
              child: Text(step,
                style: TextStyle(
                  color: color.withOpacity(0.06),
                  fontSize: 80, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron', height: 1.0,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: color.withOpacity(0.3)),
                        ),
                        child: Icon(icon, color: color, size: 16),
                      ),
                      const SizedBox(width: 10),
                      Text(title,
                        style: const TextStyle(
                          color: _C.text, fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(step,
                          style: TextStyle(
                            color: color, fontSize: 9,
                            fontWeight: FontWeight.w900, letterSpacing: 1,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  child,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PHONE INPUT ────────────────────────────────────────────────────────────
  Widget _buildPhoneInput() {
    return Container(
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.borderMid),
      ),
      child: TextField(
        controller: targetController,
        style: const TextStyle(
          color: _C.text, fontFamily: 'ShareTechMono',
          fontSize: 15, fontWeight: FontWeight.w600,
        ),
        cursorColor: _C.ice2,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          hintText: '+62812xxxxxxxx',
          hintStyle: TextStyle(
            color: _C.textDim.withOpacity(0.7),
            fontFamily: 'ShareTechMono',
            fontSize: 14,
          ),
          prefixIcon: const Icon(Icons.language_rounded, color: _C.textSub, size: 20),
          suffixIcon: GestureDetector(
            onTap: () => targetController.clear(),
            child: const Icon(Icons.close_rounded, color: _C.textDim, size: 18),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  // ─── BUG LIST (FULL WIDTH, NO PAGER) ────────────────────────────────────────
  Widget _buildBugList() {
    final bugs = _numberBugs;
    if (bugs.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 30),
        decoration: BoxDecoration(
          color: _C.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
        ),
        child: const Center(
          child: Text('Tidak ada bug type "number"',
            style: TextStyle(color: _C.textDim, fontSize: 12)),
        ),
      );
    }

    return Column(
      children: bugs.map((bug) {
        final bugId = bug['bug_id'] as String? ?? '0';
        final isSelected = _selectedBugId == bugId;
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: GestureDetector(
            onTap: () => setState(() => _selectedBugId = bugId),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                gradient: isSelected
                    ? LinearGradient(
                        colors: [_C.iceSoft, _C.surface],
                        begin: Alignment.centerLeft, end: Alignment.centerRight,
                      )
                    : null,
                color: isSelected ? null : _C.cardAlt,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isSelected ? _C.ice2 : _C.border,
                  width: isSelected ? 1.5 : 1.0,
                ),
                boxShadow: isSelected
                    ? [BoxShadow(color: _C.ice2.withOpacity(0.20), blurRadius: 12, offset: const Offset(0, 4))]
                    : null,
              ),
              child: Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isSelected
                          ? _C.primaryGrad
                          : LinearGradient(
                              colors: [_C.textDim.withOpacity(0.15), _C.textDim.withOpacity(0.05)],
                            ),
                      boxShadow: isSelected ? _shPrimary : null,
                    ),
                    child: Icon(Icons.phone_android_rounded,
                      color: isSelected ? Colors.white : _C.textDim,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (bug['bug_name'] as String? ?? 'BUG').toUpperCase(),
                          style: TextStyle(
                            color: isSelected ? _C.ice3 : _C.text,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          bug['bug_id']?.toString().toLowerCase() ?? 'bug',
                          style: const TextStyle(
                            color: _C.textDim,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Right status
                  Container(
                    width: 26, height: 26,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isSelected ? _C.ice2 : Colors.transparent,
                      border: Border.all(
                        color: isSelected ? _C.ice2 : _C.borderMid,
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                        : null,
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  // ─── SENDER SELECTION ───────────────────────────────────────────────────────
  Widget _buildSenderSelection() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _selectedSender = 'private'),
                child: _buildSenderCard(
                  title: 'PRIBADI',
                  subtitle: 'Private sender',
                  icon: Icons.person_rounded,
                  isSelected: _selectedSender == 'private',
                  count: _privateSenderCount,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() => _selectedSender = 'global');
                  _loadGlobalSenders();
                },
                child: _buildSenderCard(
                  title: 'GLOBAL',
                  subtitle: 'Public sender',
                  icon: Icons.public_rounded,
                  isSelected: _selectedSender == 'global',
                  count: _globalSenderCount,
                ),
              ),
            ),
          ],
        ),
        if (_selectedSender == 'global' && _globalSenders.isNotEmpty) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.list_rounded, color: _C.textSub, size: 13),
                  const SizedBox(width: 6),
                  Text('${_globalSenders.length} sender aktif',
                    style: const TextStyle(
                      color: _C.textSub, fontSize: 11,
                      fontFamily: 'ShareTechMono', fontWeight: FontWeight.w700,
                    )),
                ]),
                const SizedBox(height: 8),
                ...(_globalSenders.take(3).map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Row(children: [
                    Container(width: 5, height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: _C.green,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(s,
                      style: const TextStyle(
                        color: _C.ice3, fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                      overflow: TextOverflow.ellipsis,
                    )),
                  ]),
                ))),
                if (_globalSenders.length > 3)
                  Text('+ ${_globalSenders.length - 3} lainnya...',
                    style: const TextStyle(color: _C.textDim, fontSize: 10)),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildSenderCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool isSelected,
    required int count,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: isSelected ? _C.primaryGrad : null,
        color: isSelected ? null : _C.cardAlt,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isSelected ? _C.ice : _C.borderMid,
          width: isSelected ? 1.5 : 1.0,
        ),
        boxShadow: isSelected ? _shPrimary : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected
                      ? Colors.white.withOpacity(0.25)
                      : _C.border.withOpacity(0.5),
                ),
                child: Icon(icon,
                  color: isSelected ? Colors.white : _C.textSub,
                  size: 16,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.white.withOpacity(0.25)
                      : (count == 0 ? _C.red.withOpacity(0.10) : _C.iceSoft),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  count == 0 ? 'KOSONG' : '$count',
                  style: TextStyle(
                    color: isSelected
                        ? Colors.white
                        : (count == 0 ? _C.red : _C.ice3),
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(title,
            style: TextStyle(
              color: isSelected ? Colors.white : _C.text,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 12,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 2),
          Text(subtitle,
            style: TextStyle(
              color: isSelected
                  ? Colors.white.withOpacity(0.7)
                  : _C.textDim,
              fontSize: 9,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ─── SEND BUTTON ────────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: Container(
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: _C.primaryGrad,
              border: Border.all(color: Colors.white.withOpacity(0.3), width: 1.5),
              boxShadow: [
                ..._shPrimary,
                BoxShadow(
                  color: _C.ice2.withOpacity(0.15 + _pulseController.value * 0.15),
                  blurRadius: 40,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: _isSending ? null : _sendBug,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.white.withOpacity(0.20), Colors.transparent],
                      stops: const [0.0, 0.5],
                    ),
                  ),
                  child: Center(
                    child: _isSending
                        ? const SizedBox(
                            width: 26, height: 26,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                              SizedBox(width: 12),
                              Text('SEND BUG',
                                style: TextStyle(
                                  color: Colors.white, fontWeight: FontWeight.w900,
                                  fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 3,
                                  shadows: [Shadow(color: Color(0x40000000), offset: Offset(0, 1), blurRadius: 2)],
                                )),
                            ],
                          ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── RESPONSE MESSAGE ───────────────────────────────────────────────────────
  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = _C.green; icon = Icons.check_circle_outline; title = 'Berhasil';
        break;
      case 'warning':
        color = _C.amber; icon = Icons.warning_rounded; title = 'Peringatan';
        break;
      default:
        color = _C.red; icon = Icons.error_outline; title = 'Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          margin: const EdgeInsets.only(top: 12),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.4), width: 1.2),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.15), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.18),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                      style: TextStyle(
                        color: color, fontFamily: 'Orbitron',
                        fontSize: 13, fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      )),
                    const SizedBox(height: 4),
                    Text(msg,
                      style: const TextStyle(
                        color: _C.textSub, fontFamily: 'ShareTechMono',
                        fontSize: 12, height: 1.4, fontWeight: FontWeight.w600,
                      )),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() => _responseMessage = null);
                  _resultCtrl.reset();
                },
                child: const Icon(Icons.close_rounded, color: _C.textDim, size: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.04)..strokeWidth = 0.6;
    const sp = 32.0;
    for (double x = 0; x < size.width; x += sp) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += sp) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _HeroOrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final dashPaint = Paint()
      ..color = _C.ice.withOpacity(0.30)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 32;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.08, false, dashPaint);
    }

    final arcPaint = Paint()
      ..color = _C.ice2.withOpacity(0.5)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const startAngles = [0.0, math.pi * 2 / 3, math.pi * 4 / 3];
    for (final start in startAngles) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius * 0.75),
        start, math.pi / 4, false, arcPaint,
      );
    }

    // Center dot
    canvas.drawCircle(center, 4, Paint()..color = _C.ice2.withOpacity(0.6));
    canvas.drawCircle(center, 8, Paint()..color = _C.ice2.withOpacity(0.2));
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}