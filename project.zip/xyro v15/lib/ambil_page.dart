// ═══════════════════════════════════════════════════════════════════════════
//  AMBIL PAGE — LINK GROUP TELEGRAM XYRO
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const greenSoft = Color(0xFFECFDF5);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);

  static const telegram  = Color(0xFF229ED9);
  static const telegramSoft = Color(0xFFE3F2FD);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shTelegram = [
  BoxShadow(color: _C.telegram.withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: _C.telegram.withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
];

const String _kGroupLink = 'https://t.me/+ZyJQWcgkiilkMzRl';

class AmbilPage extends StatefulWidget {
  const AmbilPage({super.key});

  @override
  State<AmbilPage> createState() => _AmbilPageState();
}

class _AmbilPageState extends State<AmbilPage>
    with TickerProviderStateMixin {
  bool _linkVisible = false;
  bool _copied = false;

  late AnimationController _pulseCtrl;
  late AnimationController _entryCtrl;
  late Animation<double> _entryFade;
  late Animation<Offset> _entrySlide;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);

    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _entryFade = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _entrySlide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entryCtrl, curve: Curves.easeOutCubic));

    _entryCtrl.forward();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  void _ambilLink() {
    HapticFeedback.mediumImpact();
    setState(() {
      _linkVisible = true;
      _copied = false;
    });
  }

  Future<void> _copyLink() async {
    await Clipboard.setData(const ClipboardData(text: _kGroupLink));
    HapticFeedback.lightImpact();
    if (!mounted) return;
    setState(() => _copied = true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(children: [
          Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
          SizedBox(width: 8),
          Text('Link berhasil di-copy!'),
        ]),
        backgroundColor: _C.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  Future<void> _openTelegram() async {
    HapticFeedback.mediumImpact();
    final uri = Uri.parse(_kGroupLink);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && mounted) {
        _showAlert('❌ Gagal Buka', 'Aplikasi Telegram tidak ditemukan.');
      }
    } catch (e) {
      if (mounted) {
        _showAlert('❌ Error', 'Gagal membuka Telegram:\n$e');
      }
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _C.ice.withOpacity(0.4), width: 1.5),
        ),
        title: Text(title,
            style: const TextStyle(
                color: _C.ice3,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("OK",
                style: TextStyle(
                    color: _C.ice2, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _entryFade,
            child: SlideTransition(
              position: _entrySlide,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildAppBar(),
                    const SizedBox(height: 24),
                    _buildHeroCard(),
                    const SizedBox(height: 20),
                    _buildLinkCard(),
                    const SizedBox(height: 16),
                    _buildActionButtons(),
                    const SizedBox(height: 16),
                    _buildInfoCard(),
                    const SizedBox(height: 20),
                    _buildFooter(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.surface,
              border: Border.all(color: _C.border),
              boxShadow: _sh1,
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: _C.text, size: 20),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('AMBIL LINK',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                      letterSpacing: 1.5)),
              Text('Link grup Telegram resmi',
                  style: TextStyle(
                      color: _C.textDim,
                      fontSize: 11,
                      fontWeight: FontWeight.w500)),
            ],
          ),
        ),
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [_C.ice, _C.ice2, _C.ice3],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: _shPrimary,
          ),
          child: ClipOval(
            child: Image.asset('assets/images/logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(
                  Icons.shield_rounded, color: Colors.white, size: 20)),
          ),
        ),
      ],
    );
  }

  Widget _buildHeroCard() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.surface, _C.cardAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: _sh2,
      ),
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => SizedBox(
              width: 140,
              height: 140,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 130, height: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.telegram.withOpacity(
                          0.06 + _pulseCtrl.value * 0.06),
                    ),
                  ),
                  Container(
                    width: 105, height: 105,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _C.telegram.withOpacity(
                            0.20 + _pulseCtrl.value * 0.20),
                        width: 2,
                      ),
                    ),
                  ),
                  Container(
                    width: 84, height: 84,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          _C.telegram,
                          _C.telegram.withOpacity(0.75),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: _shTelegram,
                      border: Border.all(
                          color: Colors.white.withOpacity(0.4),
                          width: 2),
                    ),
                    child: const Icon(
                      Icons.telegram_rounded,
                      color: Colors.white,
                      size: 44,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('XYRO ENGINE',
              style: TextStyle(
                  color: _C.text,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 22,
                  letterSpacing: 2)),
          const SizedBox(height: 6),
          Text('Official Telegram Group',
              style: TextStyle(
                  color: _C.telegram,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5)),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _C.telegramSoft,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.telegram.withOpacity(0.35)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8, height: 8,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.green,
                  ),
                ),
                const SizedBox(width: 6),
                const Text('JOIN GROUP',
                    style: TextStyle(
                        color: _C.telegram,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkCard() {
    return AnimatedSize(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      child: _linkVisible
          ? Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.telegramSoft, _C.surface],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: _C.telegram.withOpacity(0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _C.telegram.withOpacity(0.15),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.green.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: _C.green.withOpacity(0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.check_circle_rounded,
                                color: _C.green, size: 11),
                            SizedBox(width: 4),
                            Text('LINK SIAP',
                                style: TextStyle(
                                    color: _C.green,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 0.8)),
                          ],
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: _copyLink,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _copied ? _C.green : _C.telegram,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: _sh1,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _copied
                                    ? Icons.check_rounded
                                    : Icons.copy_rounded,
                                color: Colors.white,
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _copied ? 'COPIED' : 'COPY',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 0.5),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: _C.cardAlt,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.border),
                    ),
                    child: SelectableText(
                      _kGroupLink,
                      style: const TextStyle(
                          color: _C.ice3,
                          fontFamily: 'ShareTechMono',
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          height: 1.4),
                    ),
                  ),
                ],
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        GestureDetector(
          onTap: _ambilLink,
          child: Container(
            height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(
                colors: [_C.ice, _C.ice2, _C.ice3],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: _shPrimary,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.download_rounded,
                    color: Colors.white, size: 22),
                const SizedBox(width: 10),
                Text(
                  _linkVisible ? 'LINK DITAMPILKAN' : 'AMBIL LINK',
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _openTelegram,
          child: Container(
            height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                colors: [
                  _C.telegram,
                  _C.telegram.withOpacity(0.78),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: _shTelegram,
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.telegram_rounded,
                    color: Colors.white, size: 22),
                SizedBox(width: 10),
                Text(
                  'BUKA GROUP',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.surface, _C.cardAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: _sh1,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.info_outline_rounded,
                  color: _C.ice2, size: 18),
              SizedBox(width: 8),
              Text('INFORMASI',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 12),
          _infoRow(Icons.link_rounded, 'Link grup resmi XYRO ENGINE'),
          _infoRow(Icons.verified_rounded,
              'Bebas spam & berbagi bug terbaru'),
          _infoRow(Icons.update_rounded,
              'Update aplikasi & tips eksklusif'),
          _infoRow(Icons.support_agent_rounded,
              'Support 24 jam dari tim XYRO'),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26, height: 26,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.iceSoft,
              border: Border.all(color: _C.ice.withOpacity(0.4)),
            ),
            child: Icon(icon, color: _C.ice2, size: 13),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(text,
                  style: const TextStyle(
                      color: _C.textSub,
                      fontSize: 12,
                      height: 1.4,
                      fontWeight: FontWeight.w500)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Column(
        children: [
          Container(
            height: 2, width: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_C.ice, _C.ice2, _C.ice3],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'XYRO ENGINE · Powered by @ganang',
            style: TextStyle(
              color: _C.textDim,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}