// ═══════════════════════════════════════════════════════════════════════════
//  TIKTOK DOWNLOADER — GLASS BLACK + VIDEO BG + B/W/R
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

// ═══════════════════════════════════════════════════════════════════════════
class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage>
    with WidgetsBindingObserver {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  // ═══ DOWNLOAD — MULTI-FALLBACK ═══
  Future<void> _downloadTiktok() async {
    final raw = _urlController.text.trim();
    if (raw.isEmpty) {
      setState(() {
        _errorMessage = "URL TikTok tidak boleh kosong.";
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });
    HapticFeedback.mediumImpact();

    // Coba 3 API berurutan sampai ada yang berhasil
    final ok = await _tryApi1(raw) ||
        await _tryApi2(raw) ||
        await _tryApi3(raw);

    if (!ok) {
      setState(() {
        _errorMessage = "Gagal ambil video. Cek URL atau coba lagi.";
        _isLoading = false;
      });
      HapticFeedback.heavyImpact();
      return;
    }

    setState(() => _isLoading = false);
    _initializeVideoPlayer();
  }

  // API 1 — tikwm.com (paling stabil, tanpa auth)
  Future<bool> _tryApi1(String url) async {
    try {
      final apiUrl = Uri.parse(
          "https://www.tikwm.com/api/?url=${Uri.encodeComponent(url)}&hd=1");
      final res = await http.get(apiUrl).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return false;
      final json = jsonDecode(res.body);
      if (json['code'] != 0 || json['data'] == null) return false;
      final data = json['data'];
      final playUrl = data['play']?.toString();
      if (playUrl == null || playUrl.isEmpty) return false;

      // Extract info
      final title = data['title']?.toString() ?? 'TikTok Video';
      final author = data['author']?['unique_id']?.toString() ??
          data['author']?['nickname']?.toString() ??
          'Unknown';

      setState(() {
        _videoData = {
          'urls': [playUrl],
          'metadata': {
            'title': title,
            'creator': author,
          },
        };
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  // API 2 — siputzx (fallback)
  Future<bool> _tryApi2(String url) async {
    try {
      final apiUrl = Uri.parse(
          "https://api.siputzx.my.id/api/d/tiktok?url=${Uri.encodeComponent(url)}");
      final res = await http.get(apiUrl).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return false;
      final json = jsonDecode(res.body);
      if (json['status'] != true || json['data'] == null) return false;
      final data = json['data'];
      if (data['urls'] == null ||
          (data['urls'] as List).isEmpty) return false;
      setState(() {
        _videoData = Map<String, dynamic>.from(data);
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  // API 3 — tiklydown (fallback kedua)
  Future<bool> _tryApi3(String url) async {
    try {
      final apiUrl = Uri.parse(
          "https://api.tiklydown.eu.org/api/download?url=${Uri.encodeComponent(url)}");
      final res = await http.get(apiUrl).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return false;
      final json = jsonDecode(res.body);
      final videoUrl = json['video']?['noWatermark']?.toString() ??
          json['video']?['watermark']?.toString();
      if (videoUrl == null || videoUrl.isEmpty) return false;
      final title = json['title']?.toString() ?? 'TikTok Video';
      final author = json['author']?['name']?.toString() ?? 'Unknown';
      setState(() {
        _videoData = {
          'urls': [videoUrl],
          'metadata': {
            'title': title,
            'creator': author,
          },
        };
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  void _initializeVideoPlayer() {
    final urls = _videoData?['urls'];
    if (urls == null || (urls as List).isEmpty) return;

    final videoUrl = urls[0].toString();
    _videoController =
        VideoPlayerController.networkUrl(Uri.parse(videoUrl));
    _videoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          materialProgressColors: ChewieProgressColors(
            playedColor: _C.red,
            handleColor: _C.red,
            backgroundColor: Colors.white.withOpacity(0.2),
            bufferedColor: Colors.white.withOpacity(0.4),
          ),
        );
      });
    }).catchError((_) {
      if (!mounted) return;
      setState(() {
        _errorMessage = "Video tidak dapat diputar.";
      });
    });
  }

  Future<void> _shareVideo() async {
    final urls = _videoData?['urls'];
    if (urls == null || (urls as List).isEmpty) return;

    try {
      final videoUrl = urls[0].toString();
      final response = await http.get(Uri.parse(videoUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      final creator =
          _videoData!['metadata']?['creator']?.toString() ?? 'Unknown';

      await Share.shareXFiles([XFile(file.path)],
          text: 'Video TikTok dari: $creator');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error sharing: $e',
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold)),
          backgroundColor: _C.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildHeaderCard(),
                      const SizedBox(height: 16),
                      _buildInputCard(),
                      if (_errorMessage != null) ...[
                        const SizedBox(height: 14),
                        _buildErrorBox(),
                      ],
                      if (_videoData != null) ...[
                        const SizedBox(height: 16),
                        _buildVideoResult(),
                      ],
                      if (_videoData == null &&
                          !_isLoading &&
                          _errorMessage == null)
                        _buildEmptyState(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TIKTOK DOWNLOADER',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('NO WATERMARK • HD QUALITY',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ HEADER CARD ═══
  Widget _buildHeaderCard() {
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.red.withOpacity(0.15),
              border: Border.all(color: _C.red, width: 1.5),
            ),
            child: const Icon(Icons.music_video_rounded,
                color: _C.red, size: 26),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('FAST & FREE',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 4),
                Text('Download video TikTok tanpa watermark.',
                    style: TextStyle(fontSize: 11, color: _C.muted)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ INPUT CARD ═══
  Widget _buildInputCard() {
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.link_rounded,
                    color: _C.red, size: 18),
              ),
              const SizedBox(width: 10),
              const Text('MASUKKAN URL',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _urlController,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: 'https://vt.tiktok.com/...',
              hintStyle: const TextStyle(color: _C.muted, fontSize: 13),
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              prefixIcon: const Icon(Icons.public_rounded,
                  color: _C.muted, size: 20),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.12)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.12)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: _C.red, width: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _isLoading ? null : _downloadTiktok,
            child: Container(
              height: 54,
              decoration: BoxDecoration(
                color: _C.red,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                      color: _C.red.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4)),
                ],
              ),
              child: Center(
                child: _isLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                            color: Colors.black, strokeWidth: 2.5))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.download_rounded,
                              color: Colors.black, size: 22),
                          SizedBox(width: 8),
                          Text('DOWNLOAD VIDEO',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 14,
                                  letterSpacing: 1.5)),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ ERROR BOX ═══
  Widget _buildErrorBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.red.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.red.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: _C.red, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Text(_errorMessage!,
                style: const TextStyle(
                    color: _C.red,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  // ═══ VIDEO RESULT ═══
  Widget _buildVideoResult() {
    return _GlassCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _C.red.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.red.withOpacity(0.5)),
                  ),
                  child: const Icon(Icons.videocam_rounded,
                      color: _C.red, size: 16),
                ),
                const SizedBox(width: 10),
                const Text('VIDEO PREVIEW',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: Colors.white.withOpacity(0.12), width: 1.5),
                color: Colors.black,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10.5),
                child: _chewieController != null &&
                        _videoController!.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _videoController!.value.aspectRatio,
                        child: Chewie(controller: _chewieController!))
                    : const AspectRatio(
                        aspectRatio: 16 / 9,
                        child: Center(
                            child: CircularProgressIndicator(
                                color: _C.red, strokeWidth: 2))),
              ),
            ),
          ),
          if (_videoData?['metadata'] != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _videoData!['metadata']['title'] ?? 'No Title',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w800),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.person_rounded,
                            color: _C.red, size: 14),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            'Creator: ${_videoData!['metadata']['creator'] ?? 'Unknown'}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: _C.muted,
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: GestureDetector(
              onTap: _shareVideo,
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: _C.red,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: _C.red.withOpacity(0.4),
                        blurRadius: 12,
                        offset: const Offset(0, 4)),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.share_rounded,
                        color: Colors.black, size: 20),
                    SizedBox(width: 8),
                    Text('SHARE VIDEO',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 1)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══ EMPTY STATE ═══
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 50),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.red.withOpacity(0.1),
                border: Border.all(color: _C.red.withOpacity(0.4), width: 2),
              ),
              child: const Icon(Icons.video_library_rounded,
                  size: 44, color: _C.red),
            ),
            const SizedBox(height: 22),
            const Text('TikTok Downloader',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Text(
                'Masukkan URL TikTok di atas untuk mendownload video tanpa watermark.',
                style: TextStyle(
                    color: _C.muted, fontSize: 12, height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}