// ═══════════════════════════════════════════════════════════════════════════
//  XYROGRAM — ROMBAK TOTAL · 1 FILE
//  Feed · Explore · Upload · Chat · Profile · Story · PostDetail · VideoPlayer
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
const Color kBg        = Color(0xFFEEF3F9);
const Color kSurface   = Color(0xFFFFFFFF);
const Color kCardAlt   = Color(0xFFF5F9FF);
const Color kBorder    = Color(0xFFD6E2F0);
const Color kBorderMid = Color(0xFFC3D4E8);

const Color kIce       = Color(0xFF38BDF8);
const Color kIce2      = Color(0xFF0EA5E9);
const Color kIce3      = Color(0xFF0284C7);
const Color kIceSoft   = Color(0xFFE0F2FE);

const Color kPink      = Color(0xFFEC4899);
const Color kPurple    = Color(0xFF8B5CF6);
const Color kGreen     = Color(0xFF10B981);
const Color kRed       = Color(0xFFEF4444);
const Color kAmber     = Color(0xFFF59E0B);

const Color kText      = Color(0xFF0A2540);
const Color kTextSub   = Color(0xFF4A6582);
const Color kTextDim   = Color(0xFF8FA5BE);

final List<BoxShadow> sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
];

// ═══════════════════════════════════════════════════════════════════════════
//  ENTRY
// ═══════════════════════════════════════════════════════════════════════════
class XyrogramPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const XyrogramPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override
  State<XyrogramPage> createState() => _XyrogramPageState();
}

class _XyrogramPageState extends State<XyrogramPage> {
  int _tab = 0;
  int _feedKey = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: IndexedStack(
        index: _tab,
        children: [
          _FeedTab(
            key: ValueKey('feed-$_feedKey'),
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.role,
            onOpenProfile: _openProfile,
          ),
          _ExploreTab(sessionKey: widget.sessionKey, username: widget.username, onOpenProfile: _openProfile),
          _UploadTab(
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.role,
            onUploaded: () => setState(() { _tab = 0; _feedKey++; }),
          ),
          _ChatTab(sessionKey: widget.sessionKey, username: widget.username),
          _ProfileTab(
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.role,
            currentUsername: widget.username,
            isOwn: true,
          ),
        ],
      ),
      bottomNavigationBar: _buildNav(),
    );
  }

  void _openProfile(String u) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _ProfileTab(
        sessionKey: widget.sessionKey,
        username: u,
        role: 'user',
        currentUsername: widget.username,
        isOwn: u == widget.username,
      ),
    ));
  }

  Widget _buildNav() {
    final items = [
      {'i': Icons.home_rounded, 'l': 'Home'},
      {'i': Icons.explore_rounded, 'l': 'Explore'},
      {'i': Icons.add_box_rounded, 'l': 'Upload'},
      {'i': Icons.chat_bubble_rounded, 'l': 'Chat'},
      {'i': Icons.person_rounded, 'l': 'Profile'},
    ];
    return Container(
      decoration: BoxDecoration(color: kSurface, border: Border(top: BorderSide(color: kBorder)), boxShadow: sh1),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _tab == i;
              final isUp = i == 2;
              return Expanded(
                child: GestureDetector(
                  onTap: () { HapticFeedback.selectionClick(); setState(() => _tab = i); },
                  behavior: HitTestBehavior.opaque,
                  child: isUp
                      ? Center(
                          child: Container(
                            width: 46, height: 46,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(colors: [kIce, kIce2, kIce3]),
                              boxShadow: shPrimary,
                            ),
                            child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
                          ),
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(items[i]['i'] as IconData, color: active ? kIce2 : kTextDim, size: 24),
                            const SizedBox(height: 3),
                            Text(items[i]['l'] as String,
                              style: TextStyle(
                                color: active ? kIce2 : kTextDim,
                                fontSize: 9,
                                fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  FEED TAB
// ═══════════════════════════════════════════════════════════════════════════
class _FeedTab extends StatefulWidget {
  final String sessionKey, username, role;
  final Function(String) onOpenProfile;
  const _FeedTab({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.onOpenProfile,
  });
  @override
  State<_FeedTab> createState() => _FeedTabState();
}

class _FeedTabState extends State<_FeedTab> {
  List<Map<String, dynamic>> _posts = [];
  List<dynamic> _stories = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    if (mounted) setState(() => _loading = true);
    try {
      final f = await http.get(Uri.parse('$baseUrl/xyro/feed?limit=50')).timeout(const Duration(seconds: 15));
      final s = await http.get(Uri.parse('$baseUrl/xyro/story/list')).timeout(const Duration(seconds: 15));
      final fd = jsonDecode(f.body) as Map<String, dynamic>;
      final sd = jsonDecode(s.body) as Map<String, dynamic>;
      if (mounted) {
        setState(() {
          _posts = fd['valid'] == true
              ? (fd['posts'] as List).map((e) => Map<String, dynamic>.from(e)).toList()
              : [];
          _stories = sd['valid'] == true ? sd['users'] ?? [] : [];
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: kSurface,
            child: Row(
              children: [
                const Text('Xyrogram',
                  style: TextStyle(
                    color: kText, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: -0.5,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: _fetch,
                  icon: const Icon(Icons.refresh_rounded, color: kTextSub, size: 22),
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: kIce2, strokeWidth: 2))
                : RefreshIndicator(
                    onRefresh: _fetch,
                    color: kIce2,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                      children: [
                        _buildStoriesRow(),
                        const SizedBox(height: 8),
                        if (_posts.isEmpty)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 60),
                            child: Column(
                              children: [
                                Icon(Icons.photo_library_outlined, color: kTextDim, size: 64),
                                SizedBox(height: 12),
                                Text('Belum ada post', style: TextStyle(color: kTextDim, fontSize: 13)),
                              ],
                            ),
                          )
                        else
                          ..._posts.map((p) => _PostCard(
                                key: ValueKey('post-${p['id']}'),
                                post: p,
                                sessionKey: widget.sessionKey,
                                currentUsername: widget.username,
                                onOpenProfile: widget.onOpenProfile,
                              )),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoriesRow() {
    return SizedBox(
      height: 110,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        itemCount: _stories.length + 1,
        itemBuilder: (_, i) {
          if (i == 0) {
            return GestureDetector(
              onTap: _showCreateStory,
              child: Container(
                width: 80,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 72, height: 72,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(colors: [kIce, kIce2, kIce3]),
                            boxShadow: shPrimary,
                          ),
                          child: Center(
                            child: Text(
                              widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '?',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 26),
                            ),
                          ),
                        ),
                        Positioned(
                          right: 0, bottom: 0,
                          child: Container(
                            width: 24, height: 24,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: kIce2,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(Icons.add_rounded, color: Colors.white, size: 14),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Text('Cerita Saya',
                      style: TextStyle(color: kText, fontSize: 10, fontWeight: FontWeight.w700),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            );
          }
          final u = _stories[i - 1] as Map<String, dynamic>;
          final uname = u['username']?.toString() ?? '';
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => XyrogramStatusViewerPage(
                sessionKey: widget.sessionKey,
                currentUsername: widget.username,
                targetUsername: uname,
              ),
            )),
            child: Container(
              width: 80,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                children: [
                  Container(
                    width: 72, height: 72,
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [kIce, kIce2, kIce3]),
                    ),
                    child: Container(
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                      child: Center(
                        child: Text(
                          uname.isNotEmpty ? uname[0].toUpperCase() : '?',
                          style: const TextStyle(color: kIce3, fontSize: 26, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(uname,
                    style: const TextStyle(color: kText, fontSize: 10, fontWeight: FontWeight.w600),
                    maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _showCreateStory() async {
    final textCtrl = TextEditingController();
    String bgColor = '#0EA5E9';
    final colors = ['#0EA5E9', '#38BDF8', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B', '#EF4444', '#0F172A'];
    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: kSurface, borderRadius: BorderRadius.circular(24), boxShadow: sh2),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Buat Cerita',
                  style: TextStyle(color: kText, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 16),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(20),
                  height: 200,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      Color(int.parse(bgColor.replaceFirst('#', '0xFF'))),
                      Color(int.parse(bgColor.replaceFirst('#', '0xFF'))).withOpacity(0.75),
                    ]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Text(
                      textCtrl.text.isEmpty ? 'Preview...' : textCtrl.text,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white.withOpacity(textCtrl.text.isEmpty ? 0.5 : 1.0),
                        fontSize: 20, fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: textCtrl,
                  onChanged: (_) => setModal(() {}),
                  maxLines: 3,
                  style: const TextStyle(color: kText),
                  decoration: InputDecoration(
                    hintText: 'Apa yang kamu pikirkan?',
                    hintStyle: const TextStyle(color: kTextDim),
                    filled: true, fillColor: kCardAlt,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: kBorder),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  children: colors.map((c) => GestureDetector(
                    onTap: () => setModal(() => bgColor = c),
                    child: Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: Color(int.parse(c.replaceFirst('#', '0xFF'))),
                        shape: BoxShape.circle,
                        border: Border.all(color: bgColor == c ? kText : Colors.transparent, width: 3),
                      ),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(ctx),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: kCardAlt,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Center(
                            child: Text('BATAL', style: TextStyle(color: kTextSub, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final text = textCtrl.text.trim();
                          if (text.isEmpty) return;
                          Navigator.pop(ctx);
                          try {
                            await http.post(
                              Uri.parse('$baseUrl/xyro/story/upload'),
                              headers: {'Content-Type': 'application/json'},
                              body: jsonEncode({
                                'key': widget.sessionKey,
                                'username': widget.username,
                                'role': widget.role,
                                'text': text,
                                'type': 'text',
                                'bgColor': bgColor,
                              }),
                            );
                            _fetch();
                          } catch (_) {}
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [kIce, kIce2]),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: sh1,
                          ),
                          child: const Center(
                            child: Text('UPLOAD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  POST CARD
// ═══════════════════════════════════════════════════════════════════════════
class _PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final String sessionKey, currentUsername;
  final Function(String) onOpenProfile;
  const _PostCard({
    super.key,
    required this.post,
    required this.sessionKey,
    required this.currentUsername,
    required this.onOpenProfile,
  });
  @override
  State<_PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<_PostCard> {
  VideoPlayerController? _vid;
  bool _vidReady = false, _liked = false, _saved = false;
  int _likes = 0;

  @override
  void initState() {
    super.initState();
    _likes = (widget.post['likes'] as num?)?.toInt() ?? 0;
    _liked = widget.post['likedByMe'] == true;
    _saved = widget.post['bookmarkedByMe'] == true;
    if (widget.post['type'] == 'video') {
      _initVideo(widget.post['mediaUrl']?.toString() ?? '');
    }
  }

  void _initVideo(String url) {
    final full = url.startsWith('http') ? url : '$baseUrl$url';
    _vid = VideoPlayerController.networkUrl(Uri.parse(full));
    _vid!.initialize().then((_) {
      if (!mounted) { _vid?.dispose(); return; }
      setState(() => _vidReady = true);
      _vid!.setLooping(true);
      _vid!.setVolume(0);
      _vid!.play();
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _vid?.pause();
    _vid?.dispose();
    super.dispose();
  }

  Future<void> _like() async {
    setState(() { _liked = !_liked; _likes += _liked ? 1 : -1; });
    try {
      await http.post(
        Uri.parse('$baseUrl/xyro/like'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'username': widget.currentUsername, 'postId': widget.post['id']}),
      );
    } catch (_) {}
  }

  Future<void> _save() async {
    setState(() => _saved = !_saved);
    try {
      await http.post(
        Uri.parse('$baseUrl/xyro/bookmark'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'username': widget.currentUsername, 'postId': widget.post['id']}),
      );
    } catch (_) {}
  }

  void _openDetail() {
    _vid?.pause();
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _PostDetailPage(
        post: widget.post,
        sessionKey: widget.sessionKey,
        currentUsername: widget.currentUsername,
        onOpenProfile: widget.onOpenProfile,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final username = widget.post['username']?.toString() ?? '-';
    final caption = widget.post['caption']?.toString() ?? '';
    final type = widget.post['type']?.toString() ?? 'image';
    final url = widget.post['mediaUrl']?.toString() ?? '';
    final fullUrl = url.startsWith('http') ? url : '$baseUrl$url';

    return Container(
      margin: const EdgeInsets.only(bottom: 12, left: 12, right: 12),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBorder),
        boxShadow: sh1,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => widget.onOpenProfile(username),
                    child: Container(
                      width: 40, height: 40,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [kIce, kIce2]),
                      ),
                      child: Center(
                        child: Text(
                          username.isNotEmpty ? username[0].toUpperCase() : '?',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(username,
                      style: const TextStyle(color: kText, fontWeight: FontWeight.w800, fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _openDetail,
              child: type == 'video'
                  ? AspectRatio(
                      aspectRatio: _vidReady ? _vid!.value.aspectRatio : 16 / 9,
                      child: Container(
                        color: Colors.black,
                        child: _vidReady
                            ? Stack(
                                fit: StackFit.expand,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.cover,
                                    child: SizedBox(
                                      width: _vid!.value.size.width,
                                      height: _vid!.value.size.height,
                                      child: VideoPlayer(_vid!),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 10, right: 10,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.black54,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: const Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.videocam_rounded, color: Colors.white, size: 12),
                                          SizedBox(width: 4),
                                          Text('VIDEO', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : const Center(child: CircularProgressIndicator(color: kIce2)),
                      ),
                    )
                  : AspectRatio(
                      aspectRatio: 1,
                      child: Image.network(
                        fullUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: kCardAlt,
                          child: const Icon(Icons.broken_image, color: kTextDim, size: 48),
                        ),
                      ),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _like,
                    icon: Icon(
                      _liked ? Icons.favorite : Icons.favorite_border,
                      color: _liked ? kPink : kText, size: 28,
                    ),
                  ),
                  IconButton(
                    onPressed: _openDetail,
                    icon: const Icon(Icons.chat_bubble_outline, color: kText, size: 26),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: _save,
                    icon: Icon(
                      _saved ? Icons.bookmark : Icons.bookmark_border,
                      color: _saved ? kIce2 : kText, size: 28,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text('$_likes likes',
                style: const TextStyle(color: kText, fontWeight: FontWeight.w700, fontSize: 13),
              ),
            ),
            if (caption.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
                child: RichText(
                  text: TextSpan(children: [
                    TextSpan(text: '$username ', style: const TextStyle(color: kText, fontWeight: FontWeight.w800, fontSize: 13)),
                    TextSpan(text: caption, style: const TextStyle(color: kText, fontSize: 13)),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  POST DETAIL PAGE
// ═══════════════════════════════════════════════════════════════════════════
class _PostDetailPage extends StatefulWidget {
  final Map<String, dynamic> post;
  final String sessionKey, currentUsername;
  final Function(String) onOpenProfile;
  const _PostDetailPage({
    required this.post,
    required this.sessionKey,
    required this.currentUsername,
    required this.onOpenProfile,
  });
  @override
  State<_PostDetailPage> createState() => _PostDetailPageState();
}

class _PostDetailPageState extends State<_PostDetailPage> {
  final _ctrl = TextEditingController();
  List<Map<String, dynamic>> _comments = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/comments/${widget.post['id']}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _comments = (data['comments'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    _ctrl.clear();
    try {
      await http.post(
        Uri.parse('$baseUrl/xyro/comment'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.currentUsername,
          'role': 'user',
          'postId': widget.post['id'],
          'text': text,
        }),
      );
      _fetch();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kSurface,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back, color: kText),
        ),
        title: const Text('Comments',
          style: TextStyle(color: kText, fontWeight: FontWeight.w700, fontSize: 16),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: _PostCard(
                post: widget.post,
                sessionKey: widget.sessionKey,
                currentUsername: widget.currentUsername,
                onOpenProfile: widget.onOpenProfile,
              ),
            ),
          ),
          Container(
            constraints: const BoxConstraints(maxHeight: 300),
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              boxShadow: sh1,
            ),
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: kIce2))
                : _comments.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.all(30),
                        child: Center(child: Text('Belum ada komentar', style: TextStyle(color: kTextDim))),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(16),
                        itemCount: _comments.length,
                        itemBuilder: (ctx, i) {
                          final c = _comments[i];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              children: [
                                Container(
                                  width: 36, height: 36,
                                  decoration: const BoxDecoration(shape: BoxShape.circle, color: kIceSoft),
                                  child: Center(
                                    child: Text(
                                      (c['username']?.toString() ?? '?')[0].toUpperCase(),
                                      style: const TextStyle(color: kIce3, fontWeight: FontWeight.w900),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text('${c['username']}: ${c['text']}',
                                    style: const TextStyle(color: kText, fontSize: 13),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            color: kSurface,
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: kCardAlt,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: kBorder),
                      ),
                      child: TextField(
                        controller: _ctrl,
                        onSubmitted: (_) => _send(),
                        style: const TextStyle(color: kText, fontSize: 13),
                        decoration: const InputDecoration(
                          hintText: 'Tambah komentar...',
                          hintStyle: TextStyle(color: kTextDim),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _send,
                    child: Container(
                      width: 44, height: 44,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [kIce, kIce2]),
                      ),
                      child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  EXPLORE TAB
// ═══════════════════════════════════════════════════════════════════════════
class _ExploreTab extends StatefulWidget {
  final String sessionKey, username;
  final Function(String) onOpenProfile;
  const _ExploreTab({required this.sessionKey, required this.username, required this.onOpenProfile});
  @override
  State<_ExploreTab> createState() => _ExploreTabState();
}

class _ExploreTabState extends State<_ExploreTab> {
  List<Map<String, dynamic>> _posts = [], _users = [];
  bool _loading = true, _searching = false;
  final _ctrl = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _fetch();
    _ctrl.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), _search);
  }

  Future<void> _fetch() async {
    if (mounted) setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/explore')).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _posts = (data['posts'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) { if (mounted) setState(() => _searching = false); return; }
    if (mounted) setState(() => _searching = true);
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/search?q=${Uri.encodeComponent(q)}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _users = (data['users'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: kSurface,
            child: Container(
              decoration: BoxDecoration(
                color: kCardAlt,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: kBorder),
              ),
              child: TextField(
                controller: _ctrl,
                style: const TextStyle(color: kText, fontSize: 13),
                decoration: const InputDecoration(
                  hintText: 'Cari user...',
                  hintStyle: TextStyle(color: kTextDim),
                  prefixIcon: Icon(Icons.search_rounded, color: kTextSub, size: 20),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: _searching
                ? ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _users.length,
                    itemBuilder: (ctx, i) {
                      final u = _users[i];
                      return GestureDetector(
                        onTap: () => widget.onOpenProfile(u['username'].toString()),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: kSurface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: kBorder),
                          ),
                          child: Text(u['username'],
                            style: const TextStyle(color: kText, fontWeight: FontWeight.w700),
                          ),
                        ),
                      );
                    },
                  )
                : _loading
                    ? const Center(child: CircularProgressIndicator(color: kIce2))
                    : GridView.builder(
                        padding: const EdgeInsets.all(2),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2,
                        ),
                        itemCount: _posts.length,
                        itemBuilder: (ctx, i) {
                          final p = _posts[i];
                          final url = p['mediaUrl'] ?? '';
                          return GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(
                              builder: (_) => _PostDetailPage(
                                post: p,
                                sessionKey: widget.sessionKey,
                                currentUsername: widget.username,
                                onOpenProfile: widget.onOpenProfile,
                              ),
                            )),
                            child: Container(
                              color: Colors.black,
                              child: Image.network(
                                url.startsWith('http') ? url : '$baseUrl$url',
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  color: kCardAlt,
                                  child: const Icon(Icons.broken_image, color: kTextDim),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  UPLOAD TAB
// ═══════════════════════════════════════════════════════════════════════════
class _UploadTab extends StatefulWidget {
  final String sessionKey, username, role;
  final VoidCallback onUploaded;
  const _UploadTab({required this.sessionKey, required this.username, required this.role, required this.onUploaded});
  @override
  State<_UploadTab> createState() => _UploadTabState();
}

class _UploadTabState extends State<_UploadTab> {
  final _cap = TextEditingController();
  final _loc = TextEditingController();
  final _tags = TextEditingController();
  File? _file;
  String _type = 'image';
  bool _up = false;
  final _picker = ImagePicker();

  @override
  void dispose() {
    _cap.dispose();
    _loc.dispose();
    _tags.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource src, bool isVideo) async {
    try {
      final p = isVideo
          ? await _picker.pickVideo(source: src, maxDuration: const Duration(minutes: 3))
          : await _picker.pickImage(source: src, imageQuality: 85);
      if (p != null && mounted) {
        setState(() {
          _file = File(p.path);
          _type = isVideo ? 'video' : 'image';
        });
      }
    } catch (_) {}
  }

  Future<void> _upload() async {
    if (_file == null) return;
    setState(() => _up = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/xyro/upload'));
      req.fields.addAll({
        'key': widget.sessionKey,
        'username': widget.username,
        'role': widget.role,
        'caption': _cap.text,
        'location': _loc.text,
        'tags': _tags.text,
        'type': _type,
      });
      req.files.add(await http.MultipartFile.fromPath('media', _file!.path));
      final s = await req.send().timeout(const Duration(seconds: 120));
      final res = await http.Response.fromStream(s);
      if (jsonDecode(res.body)['valid'] == true && mounted) {
        _cap.clear(); _loc.clear(); _tags.clear();
        setState(() => _file = null);
        widget.onUploaded();
      }
    } catch (_) {}
    finally {
      if (mounted) setState(() => _up = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Upload Post',
              style: TextStyle(color: kText, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 22),
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => showModalBottomSheet(
                context: context,
                backgroundColor: Colors.transparent,
                builder: (ctx) => Container(
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ListTile(
                        leading: const Icon(Icons.photo_library, color: kIce2),
                        title: const Text('Galeri Foto'),
                        onTap: () { Navigator.pop(ctx); _pick(ImageSource.gallery, false); },
                      ),
                      ListTile(
                        leading: const Icon(Icons.video_library, color: kPink),
                        title: const Text('Galeri Video'),
                        onTap: () { Navigator.pop(ctx); _pick(ImageSource.gallery, true); },
                      ),
                      ListTile(
                        leading: const Icon(Icons.camera_alt, color: kGreen),
                        title: const Text('Kamera'),
                        onTap: () { Navigator.pop(ctx); _pick(ImageSource.camera, false); },
                      ),
                    ],
                  ),
                ),
              ),
              child: Container(
                height: 250,
                decoration: BoxDecoration(
                  color: kCardAlt,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kIce, width: 2),
                  boxShadow: sh1,
                ),
                child: _file == null
                    ? const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo_rounded, color: kIce2, size: 64),
                          SizedBox(height: 12),
                          Text('Tap untuk pilih media',
                            style: TextStyle(color: kText, fontWeight: FontWeight.w700),
                          ),
                        ],
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: _type == 'video'
                            ? Container(
                                color: Colors.black,
                                child: const Center(
                                  child: Icon(Icons.play_circle_fill, color: Colors.white, size: 64),
                                ),
                              )
                            : Image.file(_file!, fit: BoxFit.cover),
                      ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _cap,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Caption...',
                filled: true, fillColor: kSurface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: kBorder),
                ),
              ),
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: _up ? null : _upload,
              child: Container(
                height: 60,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kIce, kIce2, kIce3]),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: shPrimary,
                ),
                child: Center(
                  child: _up
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('UPLOAD NOW',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  CHAT TAB
// ═══════════════════════════════════════════════════════════════════════════
class _ChatTab extends StatefulWidget {
  final String sessionKey, username;
  const _ChatTab({required this.sessionKey, required this.username});
  @override
  State<_ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<_ChatTab> {
  List<Map<String, dynamic>> _chats = [];
  bool _loading = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetch();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _fetch());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/chat/list?username=${widget.username}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _chats = (data['chats'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: kSurface,
            child: Row(
              children: const [
                Text('Messages',
                  style: TextStyle(color: kText, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 22),
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: kIce2))
                : _chats.isEmpty
                    ? const Center(child: Text('Belum ada chat', style: TextStyle(color: kTextDim)))
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: _chats.length,
                        itemBuilder: (ctx, i) {
                          final c = _chats[i];
                          final other = c['other']?.toString() ?? '?';
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: kSurface,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: kBorder),
                              boxShadow: sh1,
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 50, height: 50,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(colors: [kIce, kIce2]),
                                  ),
                                  child: Center(
                                    child: Text(
                                      other.isNotEmpty ? other[0].toUpperCase() : '?',
                                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(other,
                                  style: const TextStyle(color: kText, fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PROFILE TAB
// ═══════════════════════════════════════════════════════════════════════════
class _ProfileTab extends StatefulWidget {
  final String sessionKey, username, role, currentUsername;
  final bool isOwn;
  const _ProfileTab({
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.currentUsername,
    required this.isOwn,
  });
  @override
  State<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<_ProfileTab> {
  Map<String, dynamic> _data = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/profile/${widget.username}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _data = data;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: kIce2));
    final posts = (_data['posts'] as List? ?? []).map((e) => Map<String, dynamic>.from(e)).toList();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [kIce, kIce2, kIce3]),
                  boxShadow: shPrimary,
                ),
                child: Center(
                  child: Text(
                    widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '?',
                    style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _stat(_data['totalPosts']?.toString() ?? '0', 'Posts'),
                    _stat(_data['followers']?.toString() ?? '0', 'Followers'),
                    _stat(_data['following']?.toString() ?? '0', 'Following'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(widget.username,
            style: const TextStyle(color: kText, fontWeight: FontWeight.w900, fontSize: 18),
          ),
          Text(widget.role.toUpperCase(),
            style: const TextStyle(color: kIce2, fontWeight: FontWeight.w700, fontSize: 12),
          ),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4,
            ),
            itemCount: posts.length,
            itemBuilder: (ctx, i) {
              final p = posts[i];
              final url = p['mediaUrl'] ?? '';
              return Container(
                color: Colors.black,
                child: Image.network(
                  url.startsWith('http') ? url : '$baseUrl$url',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: kCardAlt,
                    child: const Icon(Icons.broken_image, color: kTextDim),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _stat(String v, String l) => Column(
    children: [
      Text(v, style: const TextStyle(color: kText, fontSize: 18, fontWeight: FontWeight.w900)),
      Text(l, style: const TextStyle(color: kTextDim, fontSize: 11)),
    ],
  );
}

// ═══════════════════════════════════════════════════════════════════════════
//  STORY VIEWER PAGE
// ═══════════════════════════════════════════════════════════════════════════
class XyrogramStatusViewerPage extends StatefulWidget {
  final String sessionKey, currentUsername, targetUsername;
  const XyrogramStatusViewerPage({
    super.key,
    required this.sessionKey,
    required this.currentUsername,
    required this.targetUsername,
  });
  @override
  State<XyrogramStatusViewerPage> createState() => _XyrogramStatusViewerPageState();
}

class _XyrogramStatusViewerPageState extends State<XyrogramStatusViewerPage> {
  List<Map<String, dynamic>> _stories = [];
  int _idx = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/xyro/story/user/${widget.targetUsername}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        setState(() {
          _stories = (data['statuses'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator(color: kIce2)),
      );
    }
    if (_stories.isEmpty) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: Text('Tidak ada cerita', style: TextStyle(color: Colors.white70))),
      );
    }
    final s = _stories[_idx];
    final bgStr = (s['bgColor'] ?? '#0EA5E9').toString().replaceFirst('#', '0xFF');
    final bg = Color(int.parse(bgStr));
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapUp: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.localPosition.dx > w / 2) {
            if (_idx < _stories.length - 1) setState(() => _idx++);
            else Navigator.pop(context);
          } else {
            if (_idx > 0) setState(() => _idx--);
          }
        },
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [bg, bg.withOpacity(0.7)]),
                ),
              ),
            ),
            Positioned.fill(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(
                    s['text'] ?? '',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: kIce2,
                      child: Text(
                        widget.targetUsername.isNotEmpty ? widget.targetUsername[0].toUpperCase() : '?',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(widget.targetUsername,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}