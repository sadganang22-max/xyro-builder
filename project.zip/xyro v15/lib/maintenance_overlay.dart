// ═══════════════════════════════════════════════════════════════════════════
//  MAINTENANCE OVERLAY
//  ⚠️ HANYA ROLE "PEMULA" YANG BISA LEWAT SAAT MAINTENANCE AKTIF
//  Role lain (owner, admin, developer, vip, free, reseller, dll) → DIBLOK
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class MaintenanceOverlay extends StatefulWidget {
  final Widget child;
  final String? userRole; // null = belum login (selalu diblok saat maintenance on)

  const MaintenanceOverlay({
    super.key,
    required this.child,
    this.userRole,
  });

  @override
  State<MaintenanceOverlay> createState() => _MaintenanceOverlayState();
}

class _MaintenanceOverlayState extends State<MaintenanceOverlay>
    with TickerProviderStateMixin {
  bool _loading = true;
  bool _maintenance = false;
  Map<String, dynamic> _data = {};

  late AnimationController _pulseCtrl;
  late AnimationController _entryCtrl;

  // ⚠️ ONLY PEMULA dapat bypass maintenance
  bool get _canBypass {
    final r = (widget.userRole ?? '').toLowerCase().trim();
    return r == 'pemula';
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _fetchStatus();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchStatus() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/getMaintenance'))
          .timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true) {
        final m = data['maintenance'] as Map<String, dynamic>? ?? {};
        setState(() {
          _maintenance = m['active'] == true;
          _data = m;
          _loading = false;
        });
        if (_maintenance) _entryCtrl.forward();
        return;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    // Tampilkan child (screen normal) JIKA:
    //   - masih loading
    //   - maintenance OFF
    //   - role user = PEMULA
    if (_loading || !_maintenance || _canBypass) {
      return widget.child;
    }

    // Selain itu → tampilkan overlay maintenance
    return _buildMaintenanceScreen();
  }

  Widget _buildMaintenanceScreen() {
    return Scaffold(
      backgroundColor: const Color(0xFF0A2540),
      body: Stack(
        children: [
          // Dark gradient background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF0A2540),
                    Color(0xFF0369A1),
                    Color(0xFF0A2540),
                  ],
                ),
              ),
            ),
          ),
          // Radial glow pulse
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (_, __) => Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 0.8,
                    colors: [
                      const Color(0xFF38BDF8)
                          .withOpacity(0.10 + _pulseCtrl.value * 0.10),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          // Content
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(
                  parent: _entryCtrl, curve: Curves.easeOut),
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Icon animasi
                      AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => SizedBox(
                          width: 160, height: 160,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 155, height: 155,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: const Color(0xFF38BDF8)
                                        .withOpacity(0.15 + _pulseCtrl.value * 0.20),
                                    width: 2,
                                  ),
                                ),
                              ),
                              Container(
                                width: 120, height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0xFF38BDF8).withOpacity(0.10),
                                ),
                              ),
                              Container(
                                width: 96, height: 96,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xFF38BDF8),
                                      Color(0xFF0EA5E9),
                                      Color(0xFF0284C7),
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFF38BDF8)
                                          .withOpacity(0.5 + _pulseCtrl.value * 0.3),
                                      blurRadius: 40,
                                      spreadRadius: 6,
                                    ),
                                  ],
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.4),
                                    width: 2,
                                  ),
                                ),
                                child: const Icon(
                                  Icons.construction_rounded,
                                  color: Colors.white,
                                  size: 46,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),
                      const Text(
                        'MAINTENANCE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Color(0xFF38BDF8),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        width: 80,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [
                              Colors.transparent,
                              Color(0xFF38BDF8),
                              Colors.transparent,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Server sedang dalam perbaikan',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Kami akan segera kembali',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 32),
                      // Info card
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.15),
                            width: 1.5,
                          ),
                        ),
                        child: Column(
                          children: [
                            _infoItem(
                              Icons.info_outline_rounded,
                              'Alasan',
                              _data['alasan']?.toString().isNotEmpty == true
                                  ? _data['alasan'].toString()
                                  : '-',
                            ),
                            const SizedBox(height: 14),
                            _infoItem(
                              Icons.schedule_rounded,
                              'Estimasi Selesai',
                              _data['jamSelesai']?.toString().isNotEmpty == true
                                  ? _data['jamSelesai'].toString()
                                  : '-',
                            ),
                            if (_data['estimasi']?.toString().isNotEmpty == true) ...[
                              const SizedBox(height: 14),
                              _infoItem(
                                Icons.hourglass_bottom_rounded,
                                'Durasi',
                                _data['estimasi'].toString(),
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      // Info role
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.10)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.lock_rounded,
                                color: Colors.white54, size: 12),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                'Hanya role PEMULA yang bisa akses saat ini',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.7),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Terima kasih atas kesabaran Anda',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white60,
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoItem(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xFF38BDF8).withOpacity(0.20),
            border: Border.all(
                color: const Color(0xFF38BDF8).withOpacity(0.4)),
          ),
          child: Icon(icon,
              color: const Color(0xFF38BDF8), size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1)),
              const SizedBox(height: 4),
              Text(value,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      height: 1.3)),
            ],
          ),
        ),
      ],
    );
  }
}