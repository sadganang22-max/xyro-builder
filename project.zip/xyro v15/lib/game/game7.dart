// lib/game/game7.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game7 extends StatefulWidget {
  const Game7({super.key});
  @override
  State<Game7> createState() => _Game7State();
}

class _Game7State extends State<Game7> {
  List<int> _sequence = [];
  int _playerIndex = 0;
  bool _isPlaying = false;
  bool _isShowingSequence = false;
  int _activeButton = -1;
  int _round = 0;

  final List<Color> _baseColors = [
    const Color(0xFFEF4444), // Merah
    const Color(0xFF10B981), // Hijau
    const Color(0xFF3B82F6), // Biru
    const Color(0xFFF59E0B), // Kuning
  ];

  void _startGame() {
    setState(() {
      _sequence = [];
      _round = 0;
      _isPlaying = true;
      _isShowingSequence = false;
      _nextRound();
    });
  }

  void _nextRound() {
    _round++;
    _playerIndex = 0;
    _sequence.add(Random().nextInt(4));
    _playSequence();
  }

  Future<void> _playSequence() async {
    setState(() => _isShowingSequence = true);
    await Future.delayed(const Duration(milliseconds: 500));

    for (int i = 0; i < _sequence.length; i++) {
      if (!mounted) return;
      setState(() => _activeButton = _sequence[i]);
      await Future.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      setState(() => _activeButton = -1);
      await Future.delayed(const Duration(milliseconds: 200));
    }

    if (mounted) setState(() => _isShowingSequence = false);
  }

  void _handleTap(int index) {
    if (!_isPlaying || _isShowingSequence) return;

    setState(() => _activeButton = index);
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) setState(() => _activeButton = -1);
    });

    if (_sequence[_playerIndex] == index) {
      _playerIndex++;
      if (_playerIndex == _sequence.length) {
        _nextRound();
      }
    } else {
      _gameOver();
    }
  }

  void _gameOver() {
    setState(() {
      _isPlaying = false;
      _isShowingSequence = false;
    });
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('GAME OVER', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900)),
        content: Text('Kamu bertahan sampai Ronde $_round', textAlign: TextAlign.center),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          ElevatedButton(
            onPressed: () { Navigator.pop(ctx); _startGame(); },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0EA5E9), foregroundColor: Colors.white),
            child: const Text('MAIN LAGI'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E293B), // Dark theme untuk game ini
      appBar: AppBar(
        title: const Text('SIMON SAYS', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18, color: Colors.white)),
        backgroundColor: Colors.transparent, elevation: 0, iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _isPlaying ? 'RONDE $_round' : 'SIAP INGAT?',
              style: const TextStyle(color: Colors.white, fontSize: 24, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2),
            ),
            const SizedBox(height: 40),
            if (!_isPlaying)
              GestureDetector(
                onTap: _startGame,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF10B981), Color(0xFF047857)]),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Text('MULAI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2)),
                ),
              )
            else
              // Grid Tombol Simon
              SizedBox(
                width: 300, height: 300,
                child: Column(
                  children: [
                    Row(
                      children: [
                        _buildColorBtn(0, const BorderRadius.only(topLeft: Radius.circular(20))),
                        const SizedBox(width: 12),
                        _buildColorBtn(1, const BorderRadius.only(topRight: Radius.circular(20))),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _buildColorBtn(2, const BorderRadius.only(bottomLeft: Radius.circular(20))),
                        const SizedBox(width: 12),
                        _buildColorBtn(3, const BorderRadius.only(bottomRight: Radius.circular(20))),
                      ],
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 40),
            if (_isPlaying && _isShowingSequence)
              const Text('LIHAT URUTANNYA...', style: TextStyle(color: Color(0xFF38BDF8), fontWeight: FontWeight.bold, letterSpacing: 2)),
            if (_isPlaying && !_isShowingSequence)
              const Text('GILIRANMU!', style: TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold, letterSpacing: 2)),
          ],
        ),
      ),
    );
  }

  Widget _buildColorBtn(int index, BorderRadius radius) {
    final isActive = _activeButton == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => _handleTap(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 144,
          decoration: BoxDecoration(
            color: isActive ? Colors.white : _baseColors[index],
            borderRadius: radius,
            boxShadow: isActive ? [BoxShadow(color: _baseColors[index], blurRadius: 30, spreadRadius: 5)] : [],
          ),
        ),
      ),
    );
  }
}