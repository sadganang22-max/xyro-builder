// lib/game/game12.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game12 extends StatefulWidget {
  const Game12({super.key});
  @override
  State<Game12> createState() => _Game12State();
}

class _Game12State extends State<Game12> {
  int activeMole = -1;
  int score = 0;
  int timeLeft = 30;
  bool isPlaying = false;
  Timer? _moleTimer;
  Timer? _gameTimer;

  void _startGame() {
    setState(() {
      score = 0;
      timeLeft = 30;
      isPlaying = true;
      activeMole = -1;
    });

    _gameTimer?.cancel();
    _moleTimer?.cancel();

    // Timer Game
    _gameTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (timeLeft > 0) timeLeft--;
        else _endGame();
      });
    });

    // Timer Tikus Muncul
    _moleTimer = Timer.periodic(const Duration(milliseconds: 800), (t) {
      if (!mounted) return;
      setState(() => activeMole = Random().nextInt(9));
    });
  }

  void _hitMole(int index) {
    if (!isPlaying || index != activeMole) return;
    setState(() {
      score += 10;
      activeMole = -1;
    });
  }

  void _endGame() {
    _gameTimer?.cancel();
    _moleTimer?.cancel();
    setState(() => isPlaying = false);
  }

  @override
  void dispose() {
    _gameTimer?.cancel();
    _moleTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('WHACK-A-MOLE', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('SKOR: $score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('WAKTU: $timeLeft', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  margin: const EdgeInsets.all(20),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10),
                    itemCount: 9,
                    itemBuilder: (ctx, i) {
                      final isMole = activeMole == i;
                      return GestureDetector(
                        onTap: () => _hitMole(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          decoration: BoxDecoration(
                            color: isMole ? const Color(0xFFF59E0B) : const Color(0xFFCBD5E1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: isMole ? const Icon(Icons.pets, size: 50, color: Colors.white) : const SizedBox(),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
          if (!isPlaying)
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: GestureDetector(
                onTap: _startGame,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  decoration: BoxDecoration(color: const Color(0xFFF59E0B), borderRadius: BorderRadius.circular(20)),
                  child: Text(timeLeft == 0 ? 'MAIN LAGI' : 'MULAI', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}