// lib/game/game20.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game20 extends StatefulWidget {
  const Game20({super.key});
  @override
  State<Game20> createState() => _Game20State();
}

class _Game20State extends State<Game20> {
  final Map<String, Color> _colors = {
    'MERAH': Colors.red,
    'BIRU': Colors.blue,
    'HIJAU': Colors.green,
    'KUNING': Colors.yellow,
  };

  late String _textName;
  late Color _textColor;
  int _score = 0;
  int _timeLeft = 20;
  bool _isPlaying = false;
  bool _isGameOver = false;
  Timer? _timer;

  void _startGame() {
    setState(() {
      _score = 0;
      _timeLeft = 20;
      _isPlaying = true;
      _isGameOver = false;
      _generateQuestion();
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (mounted) {
        setState(() {
          if (_timeLeft > 0) _timeLeft--;
          else _endGame();
        });
      }
    });
  }

  void _endGame() {
    _timer?.cancel();
    setState(() { _isPlaying = false; _isGameOver = true; });
  }

  void _generateQuestion() {
    final rand = Random();
    final keys = _colors.keys.toList();
    _textName = keys[rand.nextInt(keys.length)];
    _textColor = _colors[keys[rand.nextInt(keys.length)]]!;
  }

  void _checkAnswer(String chosenColorName) {
    if (_colors[chosenColorName] == _textColor) {
      setState(() { _score += 10; _timeLeft = min(20, _timeLeft + 1); _generateQuestion(); });
    } else {
      setState(() { _timeLeft = max(0, _timeLeft - 2); });
    }
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('STROOP TEST', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: !_isPlaying
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.visibility, size: 80, color: Color(0xFF8B5CF6)),
                    const SizedBox(height: 20),
                    Text(_isGameOver ? 'SKOR AKHIR: $_score' : 'TEBAK WARNA', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    const Text('Pilih sesuai WARNA TULISAN, bukan katanya!', style: TextStyle(color: Color(0xFF8FA5BE))),
                    const SizedBox(height: 30),
                    GestureDetector(
                      onTap: _startGame,
                      child: Container(padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16), decoration: BoxDecoration(color: const Color(0xFF8B5CF6), borderRadius: BorderRadius.circular(16)), child: Text(_isGameOver ? 'MAIN LAGI' : 'MULAI', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                    ),
                  ],
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('SKOR: $_score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                        Text('WAKTU: $_timeLeft', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFEF4444))),
                      ],
                    ),
                    const SizedBox(height: 40),
                    Text(_textName, style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: _textColor, fontFamily: 'Orbitron')),
                    const SizedBox(height: 40),
                    Wrap(
                      spacing: 12, runSpacing: 12,
                      alignment: WrapAlignment.center,
                      children: _colors.keys.map((colorName) {
                        return GestureDetector(
                          onTap: () => _checkAnswer(colorName),
                          child: Container(
                            width: (MediaQuery.of(context).size.width - 60) / 2,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
                            child: Center(child: Text(colorName, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: _colors[colorName]))),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}