// lib/game/game11.dart
import 'dart:math';
import 'package:flutter/material.dart';

class Game11 extends StatefulWidget {
  const Game11({super.key});
  @override
  State<Game11> createState() => _Game11State();
}

class _Game11State extends State<Game11> {
  final int size = 8;
  List<List<String>> grid = [];
  List<String> words = ['FLUTTER', 'GAME', 'XYRO', 'DART', 'CODE'];
  List<String> foundWords = [];

  @override
  void initState() {
    super.initState();
    _generateGrid();
  }

  void _generateGrid() {
    grid = List.generate(size, (_) => List.filled(size, ''));
    // Isi dengan huruf random dulu
    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        grid[i][j] = String.fromCharCode(Random().nextInt(26) + 65);
      }
    }
    // Tanam kata-kata secara horizontal (simplifikasi)
    for (String word in words) {
      bool placed = false;
      int attempts = 0;
      while (!placed && attempts < 50) {
        int row = Random().nextInt(size);
        int startCol = Random().nextInt(size - word.length);
        bool canPlace = true;
        for (int k = 0; k < word.length; k++) {
          if (grid[row][startCol + k] != String.fromCharCode(Random().nextInt(26) + 65)) {
             // Bisa aja ketimpa huruf random sebelumnya, kita timpa aja gapapa buat simplifikasi
          }
        }
        if (canPlace) {
          for (int k = 0; k < word.length; k++) {
            grid[row][startCol + k] = word[k];
          }
          placed = true;
        }
        attempts++;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('WORD SEARCH', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        children: [
          // List Kata
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            color: Colors.white,
            child: Wrap(
              spacing: 10, runSpacing: 10,
              children: words.map((w) {
                final found = foundWords.contains(w);
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: found ? const Color(0xFF10B981) : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: found ? Colors.transparent : const Color(0xFFCBD5E1)),
                  ),
                  child: Text(w, style: TextStyle(fontWeight: FontWeight.bold, color: found ? Colors.white : const Color(0xFF0A2540))),
                );
              }).toList(),
            ),
          ),
          // Grid Huruf
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  margin: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10)]),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(10),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8, crossAxisSpacing: 4, mainAxisSpacing: 4),
                    itemCount: size * size,
                    itemBuilder: (ctx, index) {
                      int r = index ~/ size;
                      int c = index % size;
                      return GestureDetector(
                        onTap: () {
                          // Fitur pencarian kata bisa ditambahkan nanti
                        },
                        child: Container(
                          decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(4)),
                          child: Center(
                            child: Text(grid[r][c], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF0A2540))),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}