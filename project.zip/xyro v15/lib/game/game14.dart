// lib/game/game14.dart
import 'dart:async';
import 'package:flutter/material.dart';

class Game14 extends StatefulWidget {
  const Game14({super.key});
  @override
  State<Game14> createState() => _Game14State();
}

class _Game14State extends State<Game14> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  final String _targetText = 'Flutter adalah framework UI buatan Google untuk membuat aplikasi mobile yang keren dan cepat.';
  int _currentIndex = 0;
  int _mistakes = 0;
  int _seconds = 0;
  bool _isPlaying = false;
  bool _isFinished = false;
  Timer? _timer;
  int _wpm = 0;

  void _startGame() {
    setState(() {
      _controller.clear();
      _currentIndex = 0;
      _mistakes = 0;
      _seconds = 0;
      _isPlaying = true;
      _isFinished = false;
    });
    _focusNode.requestFocus();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (mounted) setState(() => _seconds++);
    });
  }

  void _onTextChanged(String value) {
    if (!_isPlaying) return;

    if (value.length > _targetText.length) {
      _controller.text = value.substring(0, _targetText.length);
      return;
    }

    setState(() {
      _currentIndex = value.length;
      
      // Cek mistake di huruf terakhir yang diketik
      if (value.isNotEmpty && value[value.length - 1] != _targetText[value.length - 1]) {
        _mistakes++;
      }

      if (value == _targetText) {
        _finishGame();
      }
    });
  }

  void _finishGame() {
    _timer?.cancel();
    // Hitung WPM (Words Per Minute)
    final words = _targetText.split(' ').length;
    final minutes = _seconds / 60;
    _wpm = minutes > 0 ? (words / minutes).round() : 0;

    setState(() {
      _isPlaying = false;
      _isFinished = true;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('TYPING SPEED', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Target Text
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(fontSize: 18, height: 1.6, fontFamily: 'monospace'),
                  children: [
                    TextSpan(text: _targetText.substring(0, _currentIndex), style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold)),
                    TextSpan(text: _targetText.substring(_currentIndex), style: const TextStyle(color: Color(0xFF8FA5BE))),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            
            // Input Field
            TextField(
              controller: _controller,
              focusNode: _focusNode,
              onChanged: _onTextChanged,
              enabled: _isPlaying,
              maxLines: null,
              style: const TextStyle(fontSize: 16),
              decoration: InputDecoration(
                hintText: 'Mulai ngetik di sini...',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.all(16),
              ),
            ),
            const SizedBox(height: 20),

            // Stats
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStat('WAKTU', '$_seconds s', const Color(0xFF0EA5E9)),
                _buildStat('SALAH', '$_mistakes', const Color(0xFFEF4444)),
                _buildStat('WPM', '$_wpm', const Color(0xFF8B5CF6)),
              ],
            ),
            
            const Spacer(),

            // Tombol
            if (!_isPlaying)
              GestureDetector(
                onTap: _startGame,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  decoration: BoxDecoration(color: const Color(0xFF0EA5E9), borderRadius: BorderRadius.circular(16)),
                  child: Center(child: Text(_isFinished ? 'COBA LAGI' : 'MULAI NGETIK', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF8FA5BE))),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color)),
      ],
    );
  }
}