// lib/game/game6.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Game6 extends StatefulWidget {
  const Game6({super.key});
  @override
  State<Game6> createState() => _Game6State();
}

class _Game6State extends State<Game6> {
  int _score = 0;
  int _highScore = 0;
  int _timeLeft = 30;
  bool _isPlaying = false;
  bool _isGameOver = false;
  Timer? _timer;

  int _num1 = 0;
  int _num2 = 0;
  String _operator = '+';
  int _correctAnswer = 0;
  List<int> _options = [];

  @override
  void initState() {
    super.initState();
    _loadHighScore();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _highScore = prefs.getInt('math_highscore') ?? 0);
  }

  Future<void> _saveHighScore() async {
    if (_score > _highScore) {
      setState(() => _highScore = _score);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('math_highscore', _score);
    }
  }

  void _startGame() {
    setState(() {
      _score = 0;
      _timeLeft = 30;
      _isPlaying = true;
      _isGameOver = false;
      _generateQuestion();
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (_timeLeft > 0) {
            _timeLeft--;
          } else {
            _gameOver();
          }
        });
      }
    });
  }

  void _gameOver() {
    _timer?.cancel();
    _saveHighScore();
    setState(() {
      _isPlaying = false;
      _isGameOver = true;
    });
  }

  void _generateQuestion() {
    final random = Random();
    _num1 = random.nextInt(20) + 5;
    _num2 = random.nextInt(20) + 5;
    final opType = random.nextInt(3);
    if (opType == 0) {
      _operator = '+';
      _correctAnswer = _num1 + _num2;
    } else if (opType == 1) {
      _operator = '-';
      _correctAnswer = _num1 - _num2;
    } else {
      _operator = 'x';
      _num1 = random.nextInt(10) + 2;
      _num2 = random.nextInt(10) + 2;
      _correctAnswer = _num1 * _num2;
    }

    Set<int> opts = {_correctAnswer};
    while (opts.length < 4) {
      int offset = random.nextInt(10) - 5;
      if (offset != 0) opts.add(_correctAnswer + offset);
    }
    _options = opts.toList()..shuffle();
  }

  void _checkAnswer(int answer) {
    if (answer == _correctAnswer) {
      setState(() {
        _score += 10;
        _timeLeft = min(30, _timeLeft + 2); // Bonus waktu
        _generateQuestion();
      });
    } else {
      setState(() {
        _timeLeft = max(0, _timeLeft - 3); // Penalti waktu
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('MATH QUIZ', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: !_isPlaying
              ? _buildStartScreen()
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildStat('SKOR', '$_score', const Color(0xFF10B981)),
                        _buildStat('WAKTU', '$_timeLeft', const Color(0xFFEF4444)),
                      ],
                    ),
                    const SizedBox(height: 40),
                    Text(
                      '$_num1 $_operator $_num2',
                      style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900, color: Color(0xFF0A2540), fontFamily: 'Orbitron'),
                    ),
                    const SizedBox(height: 40),
                    Column(
                      children: [
                        Row(
                          children: [
                            Expanded(child: _buildOption(_options[0])),
                            const SizedBox(width: 16),
                            Expanded(child: _buildOption(_options[1])),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(child: _buildOption(_options[2])),
                            const SizedBox(width: 16),
                            Expanded(child: _buildOption(_options[3])),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildStartScreen() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.all(40),
          decoration: BoxDecoration(
            color: Colors.white, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.3), blurRadius: 30, offset: const Offset(0, 15))],
          ),
          child: const Icon(Icons.calculate_rounded, size: 80, color: Color(0xFF0EA5E9)),
        ),
        const SizedBox(height: 30),
        Text(
          _isGameOver ? 'SKOR AKHIR: $_score' : 'TERBAIK: $_highScore',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0A2540)),
        ),
        const SizedBox(height: 30),
        GestureDetector(
          onTap: _startGame,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0EA5E9), Color(0xFF0284C7)]),
              borderRadius: BorderRadius.circular(30),
              boxShadow: [BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))],
            ),
            child: Text(
              _isGameOver ? 'MAIN LAGI' : 'MULAI',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF8FA5BE))),
        Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color, fontFamily: 'Orbitron')),
      ],
    );
  }

  Widget _buildOption(int value) {
    return GestureDetector(
      onTap: () => _checkAnswer(value),
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
        ),
        child: Center(
          child: Text('$value', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Color(0xFF0A2540))),
        ),
      ),
    );
  }
}