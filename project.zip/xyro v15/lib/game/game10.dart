// lib/game/game10.dart
import 'dart:math';
import 'package:flutter/material.dart';

class Game10 extends StatefulWidget {
  const Game10({super.key});
  @override
  State<Game10> createState() => _Game10State();
}

class _Game10State extends State<Game10> {
  final int size = 8;
  final int totalMines = 10;

  List<List<bool>> mines = [];
  List<List<bool>> revealed = [];
  List<List<bool>> flagged = [];
  bool isGameOver = false;
  bool isWin = false;

  @override
  void initState() {
    super.initState();
    _initGame();
  }

  void _initGame() {
    mines = List.generate(size, (_) => List.filled(size, false));
    revealed = List.generate(size, (_) => List.filled(size, false));
    flagged = List.generate(size, (_) => List.filled(size, false));
    isGameOver = false;
    isWin = false;

    int placed = 0;
    while (placed < totalMines) {
      int r = Random().nextInt(size);
      int c = Random().nextInt(size);
      if (!mines[r][c]) {
        mines[r][c] = true;
        placed++;
      }
    }
  }

  int _countAdjMines(int row, int col) {
    int count = 0;
    for (int i = -1; i <= 1; i++) {
      for (int j = -1; j <= 1; j++) {
        int nr = row + i, nc = col + j;
        if (nr >= 0 && nr < size && nc >= 0 && nc < size && mines[nr][nc]) {
          count++;
        }
      }
    }
    return count;
  }

  void _reveal(int row, int col) {
    if (isGameOver || isWin || revealed[row][col] || flagged[row][col]) return;

    setState(() {
      revealed[row][col] = true;
      if (mines[row][col]) {
        isGameOver = true;
        return;
      }
      // Auto-reveal kotak kosong
      if (_countAdjMines(row, col) == 0) {
        for (int i = -1; i <= 1; i++) {
          for (int j = -1; j <= 1; j++) {
            int nr = row + i, nc = col + j;
            if (nr >= 0 && nr < size && nc >= 0 && nc < size) {
              _reveal(nr, nc);
            }
          }
        }
      }
      _checkWin();
    });
  }

  void _toggleFlag(int row, int col) {
    if (isGameOver || isWin || revealed[row][col]) return;
    setState(() => flagged[row][col] = !flagged[row][col]);
  }

  void _checkWin() {
    int revealedCount = 0;
    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        if (revealed[i][j]) revealedCount++;
      }
    }
    if (revealedCount == size * size - totalMines) {
      setState(() => isWin = true);
    }
  }

  Color _getNumberColor(int count) {
    switch (count) {
      case 1: return Colors.blue;
      case 2: return Colors.green;
      case 3: return Colors.red;
      case 4: return Colors.purple;
      case 5: return Colors.orange;
      default: return Colors.black;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('MINESWEEPER', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
        actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => setState(_initGame))],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              isWin ? 'KAMU MENANG! 🎉' : (isGameOver ? 'BOOM! GAME OVER 💥' : 'Tandai ranjau, buka kotak aman'),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: isWin ? Colors.green : (isGameOver ? Colors.red : const Color(0xFF8FA5BE))),
            ),
          ),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  margin: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: const Color(0xFFCBD5E1), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF94A3B8), width: 3)),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
                    itemCount: size * size,
                    itemBuilder: (ctx, index) {
                      int r = index ~/ size;
                      int c = index % size;
                      bool rev = revealed[r][c];
                      bool mine = mines[r][c];
                      bool flag = flagged[r][c];
                      int count = _countAdjMines(r, c);

                      return GestureDetector(
                        onTap: () => _reveal(r, c),
                        onLongPress: () => _toggleFlag(r, c),
                        child: Container(
                          margin: const EdgeInsets.all(1.5),
                          decoration: BoxDecoration(
                            color: rev ? (mine ? Colors.red : const Color(0xFFE2E8F0)) : const Color(0xFF94A3B8),
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: rev ? [] : [BoxShadow(color: Colors.black.withOpacity(0.1), offset: const Offset(1, 1))],
                          ),
                          child: Center(
                            child: rev
                                ? (mine ? const Icon(Icons.dangerous, color: Colors.white, size: 20) : (count > 0 ? Text('$count', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _getNumberColor(count))) : const SizedBox()))
                                : (flag ? const Icon(Icons.flag_rounded, color: Colors.red, size: 18) : const SizedBox()),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}