// lib/game/game9.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game9 extends StatefulWidget {
  const Game9({super.key});
  @override
  State<Game9> createState() => _Game9State();
}

class _Game9State extends State<Game9> {
  double paddleX = 150;
  double ballX = 150;
  double ballY = 400;
  double ballSpeedX = 3;
  double ballSpeedY = -3;
  bool isPlaying = false;
  bool isGameOver = false;
  int score = 0;
  Timer? _gameLoop;

  final double paddleWidth = 100;
  final double paddleHeight = 15;
  final double ballRadius = 8;

  // Data Bata (Baris x Kolom)
  List<List<bool>> bricks = [];
  final int rows = 5;
  final int cols = 7;

  @override
  void initState() {
    super.initState();
    _initBricks();
  }

  void _initBricks() {
    bricks = List.generate(rows, (_) => List.filled(cols, true));
  }

  void _startGame() {
    setState(() {
      paddleX = 150;
      ballX = 150;
      ballY = 400;
      ballSpeedX = 3 * (Random().nextBool() ? 1 : -1);
      ballSpeedY = -3;
      score = 0;
      isPlaying = true;
      isGameOver = false;
      _initBricks();
    });
    _gameLoop?.cancel();
    _gameLoop = Timer.periodic(const Duration(milliseconds: 16), (_) => _updateGame());
  }

  void _updateGame() {
    if (!isPlaying) return;

    setState(() {
      ballX += ballSpeedX;
      ballY += ballSpeedY;

      // Pantul Dinding Kiri & Kanan
      if (ballX <= 0 || ballX >= 300 - ballRadius * 2) ballSpeedX = -ballSpeedX;
      // Pantul Atas
      if (ballY <= 0) ballSpeedY = -ballSpeedY;

      // Pantul Paddle
      if (ballY >= 500 - ballRadius && ballX >= paddleX && ballX <= paddleX + paddleWidth) {
        ballSpeedY = -ballSpeedY;
        ballY = 500 - ballRadius - 1;
        // Efek pantul berdasarkan posisi bola di paddle
        double hitPos = (ballX - paddleX) / paddleWidth - 0.5;
        ballSpeedX = hitPos * 8;
      }

      // Jatuh ke Bawah (Game Over)
      if (ballY > 500) {
        _gameLoop?.cancel();
        setState(() {
          isPlaying = false;
          isGameOver = true;
        });
      }

      // Deteksi Tabrakan Bata
      for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
          if (bricks[r][c]) {
            double brickX = c * 40 + 10;
            double brickY = r * 25 + 50;
            if (ballX > brickX - ballRadius && ballX < brickX + 40 &&
                ballY > brickY - ballRadius && ballY < brickY + 20) {
              bricks[r][c] = false;
              ballSpeedY = -ballSpeedY;
              score += 10;
            }
          }
        }
      }

      // Cek Menang
      if (bricks.every((row) => row.every((b) => !b))) {
        _gameLoop?.cancel();
        setState(() { isPlaying = false; isGameOver = true; });
      }
    });
  }

  @override
  void dispose() {
    _gameLoop?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: const Text('BREAKOUT', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18, color: Colors.white)),
        backgroundColor: Colors.transparent, elevation: 0, iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('SKOR: $score', style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Orbitron')),
          ),
          Expanded(
            child: GestureDetector(
              onHorizontalDragUpdate: (details) {
                if (!isPlaying) return;
                setState(() {
                  paddleX = (details.localPosition.dx - paddleWidth / 2).clamp(0.0, 300.0 - paddleWidth);
                });
              },
              child: Container(
                width: 300,
                margin: const EdgeInsets.only(bottom: 40),
                decoration: BoxDecoration(border: Border.all(color: Colors.white12), borderRadius: BorderRadius.circular(10)),
                child: Stack(
                  children: [
                    // Render Bata
                    for (int r = 0; r < rows; r++)
                      for (int c = 0; c < cols; c++)
                        if (bricks[r][c])
                          Positioned(
                            left: c * 40 + 10.0, top: r * 25 + 50.0,
                            child: Container(
                              width: 38, height: 20,
                              decoration: BoxDecoration(
                                color: [Colors.red, Colors.orange, Colors.yellow, Colors.green, Colors.blue][r % 5],
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                    // Paddle
                    Positioned(
                      left: paddleX, top: 500 - paddleHeight,
                      child: Container(
                        width: paddleWidth, height: paddleHeight,
                        decoration: BoxDecoration(color: const Color(0xFF38BDF8), borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                    // Bola
                    Positioned(
                      left: ballX, top: ballY,
                      child: Container(width: ballRadius * 2, height: ballRadius * 2, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
                    ),
                    // Overlay Start/End
                    if (!isPlaying)
                      Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(isGameOver ? (score == 700 ? 'KAMU MENANG!' : 'GAME OVER') : 'BREAKOUT',
                              style: const TextStyle(color: Colors.white, fontSize: 24, fontFamily: 'Orbitron', fontWeight: FontWeight.w900)),
                            const SizedBox(height: 20),
                            GestureDetector(
                              onTap: _startGame,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                                decoration: BoxDecoration(color: const Color(0xFF38BDF8), borderRadius: BorderRadius.circular(20)),
                                child: const Text('MAIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ),
                            )
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}