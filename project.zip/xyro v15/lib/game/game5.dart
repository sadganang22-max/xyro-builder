// lib/game/game5.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Game5 extends StatefulWidget {
  const Game5({super.key});
  @override
  State<Game5> createState() => _Game5State();
}

class _Game5State extends State<Game5> {
  List<List<int>> board = [];
  int score = 0;
  int highScore = 0;
  bool isGameOver = false;

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _initBoard();
  }

  Future<void> _loadHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => highScore = prefs.getInt('2048_highscore') ?? 0);
  }

  Future<void> _saveHighScore() async {
    if (score > highScore) {
      setState(() => highScore = score);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('2048_highscore', score);
    }
  }

  void _initBoard() {
    board = List.generate(4, (_) => List.filled(4, 0));
    score = 0;
    isGameOver = false;
    _addRandomTile();
    _addRandomTile();
  }

  void _addRandomTile() {
    List<Point<int>> emptyCells = [];
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (board[i][j] == 0) emptyCells.add(Point(i, j));
      }
    }
    if (emptyCells.isEmpty) return;
    final randomCell = emptyCells[Random().nextInt(emptyCells.length)];
    board[randomCell.x][randomCell.y] = Random().nextDouble() < 0.9 ? 2 : 4;
  }

  bool _move(Direction dir) {
    bool moved = false;
    List<List<int>> oldBoard = List.from(board.map((row) => List.from(row)));

    if (dir == Direction.left || dir == Direction.right) {
      for (int i = 0; i < 4; i++) {
        List<int> row = board[i].where((v) => v != 0).toList();
        List<int> newRow = [];
        for (int j = 0; j < row.length; j++) {
          if (j < row.length - 1 && row[j] == row[j + 1]) {
            newRow.add(row[j] * 2);
            score += row[j] * 2;
            j++;
          } else {
            newRow.add(row[j]);
          }
        }
        while (newRow.length < 4) newRow.add(0);
        if (dir == Direction.right) newRow = newRow.reversed.toList();
        board[i] = newRow;
      }
    } else {
      for (int j = 0; j < 4; j++) {
        List<int> col = [];
        for (int i = 0; i < 4; i++) col.add(board[i][j]);
        col = col.where((v) => v != 0).toList();
        List<int> newCol = [];
        for (int i = 0; i < col.length; i++) {
          if (i < col.length - 1 && col[i] == col[i + 1]) {
            newCol.add(col[i] * 2);
            score += col[i] * 2;
            i++;
          } else {
            newCol.add(col[i]);
          }
        }
        while (newCol.length < 4) newCol.add(0);
        if (dir == Direction.down) newCol = newCol.reversed.toList();
        for (int i = 0; i < 4; i++) board[i][j] = newCol[i];
      }
    }

    // Cek apakah ada perubahan
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (board[i][j] != oldBoard[i][j]) moved = true;
      }
    }

    if (moved) {
      _addRandomTile();
      if (_isGameOverCheck()) {
        _saveHighScore();
        setState(() => isGameOver = true);
      }
    }
    return moved;
  }

  bool _isGameOverCheck() {
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (board[i][j] == 0) return false;
        if (i < 3 && board[i][j] == board[i + 1][j]) return false;
        if (j < 3 && board[i][j] == board[i][j + 1]) return false;
      }
    }
    return true;
  }

  void _handleSwipe(DragEndDetails details) {
    if (isGameOver) return;
    final velocity = details.velocity.pixelsPerSecond;
    if (velocity.dx.abs() > velocity.dy.abs()) {
      if (velocity.dx > 0) setState(() => _move(Direction.right));
      else setState(() => _move(Direction.left));
    } else {
      if (velocity.dy > 0) setState(() => _move(Direction.down));
      else setState(() => _move(Direction.up));
    }
  }

  Color _getTileColor(int value) {
    switch (value) {
      case 2: return const Color(0xFFEEE4DA);
      case 4: return const Color(0xFFEDE0C8);
      case 8: return const Color(0xFFF2B179);
      case 16: return const Color(0xFFF59563);
      case 32: return const Color(0xFFF67C5F);
      case 64: return const Color(0xFFF65E3B);
      case 128: return const Color(0xFFEDCF72);
      case 256: return const Color(0xFFEDCC61);
      case 512: return const Color(0xFFEDC850);
      case 1024: return const Color(0xFFEDC53F);
      case 2048: return const Color(0xFFEDC22E);
      default: return const Color(0xFFCDC1B4);
    }
  }

  Color _getTextColor(int value) => value <= 4 ? const Color(0xFF776E65) : Colors.white;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF8EF),
      appBar: AppBar(
        title: const Text('2048', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF776E65),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => setState(_initBoard)),
        ],
      ),
      body: GestureDetector(
        onPanEnd: _handleSwipe,
        child: Column(
          children: [
            // Skor
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Row(
                children: [
                  _buildScoreBox('SKOR', score, const Color(0xFF8F7A66)),
                  const SizedBox(width: 12),
                  _buildScoreBox('TERBAIK', highScore, const Color(0xFF0EA5E9)),
                ],
              ),
            ),
            // Board 2048
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Container(
                    margin: const EdgeInsets.all(20),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFBBADA0),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Stack(
                      children: [
                        GridView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8),
                          itemCount: 16,
                          itemBuilder: (ctx, index) {
                            final i = index ~/ 4;
                            final j = index % 4;
                            final value = board[i][j];
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              decoration: BoxDecoration(
                                color: _getTileColor(value),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Center(
                                child: value == 0 ? const SizedBox() : Text(
                                  '$value',
                                  style: TextStyle(
                                    color: _getTextColor(value),
                                    fontSize: value >= 1000 ? 20 : (value >= 100 ? 26 : 32),
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                        // Game Over Overlay
                        if (isGameOver)
                          Container(
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.8), borderRadius: BorderRadius.circular(12)),
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text('GAME OVER', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF776E65), fontFamily: 'Orbitron')),
                                  const SizedBox(height: 16),
                                  GestureDetector(
                                    onTap: () => setState(_initBoard),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                                      decoration: BoxDecoration(color: const Color(0xFF8F7A66), borderRadius: BorderRadius.circular(12)),
                                      child: const Text('COBA LAGI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreBox(String label, int value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: const Color(0xFFBBADA0), borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFFEEE4DA), letterSpacing: 1)),
            const SizedBox(height: 4),
            Text('$value', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }
}

enum Direction { up, down, left, right }