// lib/game/game18.dart
import 'package:flutter/material.dart';

class Game18 extends StatefulWidget {
  const Game18({super.key});
  @override
  State<Game18> createState() => _Game18State();
}

class _Game18State extends State<Game18> {
  // 6 Baris, 7 Kolom. 0=Kosong, 1=Player, 2=AI
  List<List<int>> board = List.generate(6, (_) => List.filled(7, 0));
  int currentPlayer = 1;
  bool isGameOver = false;
  String winnerText = '';

  void _dropCoin(int col) {
    if (isGameOver) return;
    // Cari baris paling bawah yang kosong
    for (int r = 5; r >= 0; r--) {
      if (board[r][col] == 0) {
        setState(() {
          board[r][col] = currentPlayer;
          if (_checkWin(currentPlayer)) {
            winnerText = currentPlayer == 1 ? 'KAMU MENANG! 🎉' : 'AI MENANG! 🤖';
            isGameOver = true;
          } else if (board.every((row) => row.every((c) => c != 0))) {
            winnerText = 'SERI! 🤝';
            isGameOver = true;
          } else {
            currentPlayer = currentPlayer == 1 ? 2 : 1;
            if (currentPlayer == 2) _aiMove();
          }
        });
        return;
      }
    }
  }

  void _aiMove() {
    // AI Random Sederhana
    List<int> valid = [];
    for (int c = 0; c < 7; c++) { if (board[0][c] == 0) valid.add(c); }
    if (valid.isEmpty) return;
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _dropCoin(valid[(valid.length * 0.5).floor()]);
    });
  }

  bool _checkWin(int p) {
    // Horizontal, Vertikal, Diagonal
    for (int r = 0; r < 6; r++) {
      for (int c = 0; c < 7; c++) {
        if (c + 3 < 7 && board[r][c] == p && board[r][c+1] == p && board[r][c+2] == p && board[r][c+3] == p) return true;
        if (r + 3 < 6 && board[r][c] == p && board[r+1][c] == p && board[r+2][c] == p && board[r+3][c] == p) return true;
        if (r + 3 < 6 && c + 3 < 7 && board[r][c] == p && board[r+1][c+1] == p && board[r+2][c+2] == p && board[r+3][c+3] == p) return true;
        if (r + 3 < 6 && c - 3 >= 0 && board[r][c] == p && board[r+1][c-1] == p && board[r+2][c-2] == p && board[r+3][c-3] == p) return true;
      }
    }
    return false;
  }

  void _reset() => setState(() { board = List.generate(6, (_) => List.filled(7, 0)); currentPlayer = 1; isGameOver = false; winnerText = ''; });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('CONNECT FOUR', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: Column(
        children: [
          if (isGameOver) Text(winnerText, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF0A2540))),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 7 / 6,
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: const Color(0xFF0EA5E9), borderRadius: BorderRadius.circular(20)),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(8),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
                    itemCount: 42,
                    itemBuilder: (ctx, index) {
                      int r = index ~/ 7;
                      int c = index % 7;
                      return GestureDetector(
                        onTap: () => _dropCoin(c),
                        child: Container(
                          margin: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: board[r][c] == 0 ? Colors.white : (board[r][c] == 1 ? const Color(0xFFEF4444) : const Color(0xFFFBBF24)),
                            border: Border.all(color: Colors.black12, width: 1),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}