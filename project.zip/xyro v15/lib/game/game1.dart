// lib/game/game1.dart
import 'package:flutter/material.dart';
import 'dart:math';

class Game1 extends StatefulWidget {
  const Game1({super.key});
  @override
  State<Game1> createState() => _Game1State();
}

class _Game1State extends State<Game1> {
  List<String> board = List.filled(9, '');
  String currentPlayer = 'X'; // X = Player, O = AI
  bool isGameOver = false;
  String winner = '';

  void _handleTap(int index) {
    if (board[index] != '' || isGameOver) return;

    setState(() {
      board[index] = 'X';
    });

    if (_checkWinner('X')) {
      setState(() { winner = 'Kamu Menang! 🎉'; isGameOver = true; });
      return;
    }
    if (!board.contains('')) {
      setState(() { winner = 'Seri! 🤝'; isGameOver = true; });
      return;
    }

    // Giliran AI
    _aiMove();
  }

  void _aiMove() {
    // AI Sederhana: Cari kotak kosong secara acak (bisa di-upgrade jadi Minimax)
    List<int> emptySpots = [];
    for (int i = 0; i < 9; i++) {
      if (board[i] == '') emptySpots.add(i);
    }

    if (emptySpots.isNotEmpty) {
      int randomIndex = emptySpots[Random().nextInt(emptySpots.length)];
      board[randomIndex] = 'O';

      if (_checkWinner('O')) {
        setState(() { winner = 'Komputer Menang! 🤖'; isGameOver = true; });
        return;
      }
      if (!board.contains('')) {
        setState(() { winner = 'Seri! 🤝'; isGameOver = true; });
      }
    }
  }

  bool _checkWinner(String player) {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Baris
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Kolom
      [0, 4, 8], [2, 4, 6]             // Diagonal
    ];
    for (var line in lines) {
      if (board[line[0]] == player && board[line[1]] == player && board[line[2]] == player) {
        return true;
      }
    }
    return false;
  }

  void _reset() {
    setState(() { board = List.filled(9, ''); winner = ''; isGameOver = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('TIC TAC TOE', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2)),
        backgroundColor: Colors.transparent, elevation: 0,
        foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            isGameOver ? winner : 'Giliran Kamu (X)',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF0A2540)),
          ),
          const SizedBox(height: 40),
          // GRID 3x3
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemCount: 9,
              itemBuilder: (context, i) {
                return GestureDetector(
                  onTap: () => _handleTap(i),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white, borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))],
                    ),
                    child: Center(
                      child: Text(
                        board[i],
                        style: TextStyle(
                          fontSize: 50, fontWeight: FontWeight.w900,
                          color: board[i] == 'X' ? const Color(0xFF0EA5E9) : const Color(0xFFEF4444),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 40),
          if (isGameOver)
            GestureDetector(
              onTap: _reset,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF0EA5E9), Color(0xFF0284C7)]), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))]),
                child: const Text('MAIN LAGI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2)),
              ),
            ),
        ],
      ),
    );
  }
}