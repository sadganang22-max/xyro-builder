// lib/game/game19.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game19 extends StatefulWidget {
  const Game19({super.key});
  @override
  State<Game19> createState() => _Game19State();
}

class _Game19State extends State<Game19> {
  int _score = 0;
  int _timeLeft = 20;
  bool _isPlaying = false;
  bool _isGameOver = false;
  Timer? _timer;

  int _num1 = 0, _num2 = 0, _answer = 0;
  String _op = '+';
  List<int> _options = [];

  void _startGame() {
    setState(() {
      _score = 0;
      _timeLeft = 20;
      _isPlaying = true;
      _isGameOver = false;
      _generateQuestion();
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (mounted) {
        setState(() {
          if (_timeLeft > 0) _timeLeft--;
          else _endGame();
        });
      }
    });
  }

  void _endGame() {
    _timer?.cancel();
    setState(() { _isPlaying = false; _isGameOver = true; });
  }

  void _generateQuestion() {
    final rand = Random();
    _num1 = rand.nextInt(10) + 1;
    _num2 = rand.nextInt(10) + 1;
    _op = ['+', '-', 'x'][rand.nextInt(3)];
    if (_op == '+') _answer = _num1 + _num2;
    else if (_op == '-') _answer = _num1 - _num2;
    else _answer = _num1 * _num2;

    Set<int> opts = {_answer};
    while (opts.length < 4) {
      int offset = rand.nextInt(10) - 5;
      if (offset != 0) opts.add(_answer + offset);
    }
    _options = opts.toList()..shuffle();
  }

  void _checkAnswer(int ans) {
    if (ans == _answer) {
      setState(() { _score += 10; _timeLeft = min(20, _timeLeft + 1); _generateQuestion(); });
    } else {
      setState(() { _timeLeft = max(0, _timeLeft - 2); });
    }
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('MATH QUIZ', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: !_isPlaying
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_isGameOver ? Icons.emoji_events : Icons.calculate, size: 80, color: const Color(0xFFF59E0B)),
                    const SizedBox(height: 20),
                    Text(_isGameOver ? 'SKOR AKHIR: $_score' : 'KUIS MATEMATIKA', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 30),
                    GestureDetector(
                      onTap: _startGame,
                      child: Container(padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16), decoration: BoxDecoration(color: const Color(0xFFF59E0B), borderRadius: BorderRadius.circular(16)), child: Text(_isGameOver ? 'MAIN LAGI' : 'MULAI', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                    ),
                  ],
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('SKOR: $_score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                        Text('WAKTU: $_timeLeft', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFEF4444))),
                      ],
                    ),
                    const SizedBox(height: 40),
                    Text('$_num1 $_op $_num2', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900, fontFamily: 'Orbitron')),
                    const SizedBox(height: 40),
                    Column(
                      children: [
                        Row(children: [
                          Expanded(child: _buildOption(_options[0])),
                          const SizedBox(width: 12),
                          Expanded(child: _buildOption(_options[1])),
                        ]),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(child: _buildOption(_options[2])),
                          const SizedBox(width: 12),
                          Expanded(child: _buildOption(_options[3])),
                        ]),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildOption(int val) {
    return GestureDetector(
      onTap: () => _checkAnswer(val),
      child: Container(
        height: 70,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
        child: Center(child: Text('$val', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
      ),
    );
  }
}