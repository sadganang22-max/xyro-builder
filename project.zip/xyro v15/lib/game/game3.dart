// lib/game/game3.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Game3 extends StatefulWidget {
  const Game3({super.key});
  @override
  State<Game3> createState() => _Game3State();
}

class _Game3State extends State<Game3> {
  // Konfigurasi Grid
  static const int gridSize = 20; // 20x20 kotak
  static const int speedMs = 150; // Kecepatan ular (makin kecil makin cepat)

  // State Game
  List<Point<int>> snake = [];
  Point<int> food = const Point(0, 0);
  Direction direction = Direction.right;
  Direction nextDirection = Direction.right;
  Timer? _gameLoop;
  bool isPlaying = false;
  bool isGameOver = false;
  int score = 0;
  int highScore = 0;

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _resetGame();
  }

  @override
  void dispose() {
    _gameLoop?.cancel();
    super.dispose();
  }

  Future<void> _loadHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => highScore = prefs.getInt('snake_highscore') ?? 0);
  }

  Future<void> _saveHighScore() async {
    if (score > highScore) {
      setState(() => highScore = score);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('snake_highscore', score);
    }
  }

  void _resetGame() {
    _gameLoop?.cancel();
    setState(() {
      snake = [
        const Point(10, 10),
        const Point(9, 10),
        const Point(8, 10),
      ];
      direction = Direction.right;
      nextDirection = Direction.right;
      score = 0;
      isGameOver = false;
      isPlaying = false;
      _generateFood();
    });
  }

  void _startGame() {
    if (isGameOver) _resetGame();
    setState(() => isPlaying = true);
    _gameLoop?.cancel();
    _gameLoop = Timer.periodic(const Duration(milliseconds: speedMs), (_) => _updateGame());
  }

  void _pauseGame() {
    _gameLoop?.cancel();
    setState(() => isPlaying = false);
  }

  void _generateFood() {
    final random = Random();
    Point<int> newFood;
    do {
      newFood = Point(random.nextInt(gridSize), random.nextInt(gridSize));
    } while (snake.contains(newFood));
    food = newFood;
  }

  void _updateGame() {
    if (!isPlaying || isGameOver) return;

    setState(() {
      direction = nextDirection;
      Point<int> head = snake.first;
      Point<int> newHead = head;

      switch (direction) {
        case Direction.up: newHead = Point(head.x, head.y - 1); break;
        case Direction.down: newHead = Point(head.x, head.y + 1); break;
        case Direction.left: newHead = Point(head.x - 1, head.y); break;
        case Direction.right: newHead = Point(head.x + 1, head.y); break;
      }

      // Cek Tabrakan Dinding
      if (newHead.x < 0 || newHead.x >= gridSize || newHead.y < 0 || newHead.y >= gridSize) {
        _gameOver();
        return;
      }

      // Cek Tabrakan Badan Sendiri
      if (snake.contains(newHead)) {
        _gameOver();
        return;
      }

      snake.insert(0, newHead);

      // Cek Makan Buah
      if (newHead == food) {
        score += 10;
        _generateFood();
      } else {
        snake.removeLast();
      }
    });
  }

  void _gameOver() {
    _gameLoop?.cancel();
    _saveHighScore();
    setState(() {
      isPlaying = false;
      isGameOver = true;
    });
  }

  void _changeDirection(Direction newDir) {
    if (direction == Direction.up && newDir == Direction.down) return;
    if (direction == Direction.down && newDir == Direction.up) return;
    if (direction == Direction.left && newDir == Direction.right) return;
    if (direction == Direction.right && newDir == Direction.left) return;
    setState(() => nextDirection = newDir);
  }

  // ─── UI BUILDER ───
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('SNAKE CLASSIC', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF0A2540),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () { _pauseGame(); _resetGame(); })
        ],
      ),
      body: Column(
        children: [
          // SKOR BAR
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            child: Row(
              children: [
                _buildScoreBox('SKOR', '$score', const Color(0xFF10B981)),
                const SizedBox(width: 12),
                _buildScoreBox('TERBAIK', '$highScore', const Color(0xFFF59E0B)),
              ],
            ),
          ),

          // ARENA PERMAINAN
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: GestureDetector(
                  onVerticalDragEnd: (details) {
                    if (details.primaryVelocity! > 0) _changeDirection(Direction.down);
                    else if (details.primaryVelocity! < 0) _changeDirection(Direction.up);
                  },
                  onHorizontalDragEnd: (details) {
                    if (details.primaryVelocity! > 0) _changeDirection(Direction.right);
                    else if (details.primaryVelocity! < 0) _changeDirection(Direction.left);
                  },
                  child: Container(
                    margin: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F172A), // Arena gelap biar ularnya nyala
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 10))],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Stack(
                        children: [
                          // Render Grid & Ular
                          CustomPaint(
                            size: Size.infinite,
                            painter: SnakePainter(snake: snake, food: food, gridSize: gridSize),
                          ),

                          // OVERLAY START / PAUSE / GAME OVER
                          if (!isPlaying)
                            Container(
                              color: Colors.black54,
                              child: Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      isGameOver ? 'GAME OVER' : 'SIAP MAIN?',
                                      style: const TextStyle(color: Colors.white, fontSize: 24, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2),
                                    ),
                                    if (isGameOver) ...[
                                      const SizedBox(height: 10),
                                      Text('Skor Kamu: $score', style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 16, fontWeight: FontWeight.bold)),
                                    ],
                                    const SizedBox(height: 20),
                                    GestureDetector(
                                      onTap: _startGame,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                                        decoration: BoxDecoration(
                                          gradient: const LinearGradient(colors: [Color(0xFF10B981), Color(0xFF047857)]),
                                          borderRadius: BorderRadius.circular(30),
                                          boxShadow: [BoxShadow(color: const Color(0xFF10B981).withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))],
                                        ),
                                        child: Text(
                                          isGameOver ? 'MAIN LAGI' : 'MULAI',
                                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                          // TOMBOL PAUSE
                          if (isPlaying)
                            Positioned(
                              top: 10, right: 10,
                              child: IconButton(
                                icon: const Icon(Icons.pause_circle_filled_rounded, color: Colors.white70, size: 36),
                                onPressed: _pauseGame,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // KONTROL ARAH (D-PAD)
          Padding(
            padding: const EdgeInsets.only(bottom: 30, top: 10),
            child: Column(
              children: [
                _buildControlBtn(Icons.keyboard_arrow_up_rounded, Direction.up),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildControlBtn(Icons.keyboard_arrow_left_rounded, Direction.left),
                    const SizedBox(width: 60),
                    _buildControlBtn(Icons.keyboard_arrow_right_rounded, Direction.right),
                  ],
                ),
                _buildControlBtn(Icons.keyboard_arrow_down_rounded, Direction.down),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreBox(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 4))]),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF8FA5BE), letterSpacing: 1)),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color, fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }

  Widget _buildControlBtn(IconData icon, Direction dir) {
    return GestureDetector(
      onTap: () => _changeDirection(dir),
      child: Container(
        width: 60, height: 60,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Icon(icon, color: const Color(0xFF0EA5E9), size: 32),
      ),
    );
  }
}

enum Direction { up, down, left, right }

// ═══════════════════════════════════════════════════════════════════════════
// CUSTOM PAINTER UNTUK MENGGAMBAR ULAR & BUAH
// ═══════════════════════════════════════════════════════════════════════════
class SnakePainter extends CustomPainter {
  final List<Point<int>> snake;
  final Point<int> food;
  final int gridSize;

  SnakePainter({required this.snake, required this.food, required this.gridSize});

  @override
  void paint(Canvas canvas, Size size) {
    final cellSize = size.width / gridSize;

    // 1. Gambar Grid Halus (Opsional)
    final gridPaint = Paint()..color = Colors.white.withOpacity(0.03)..style = PaintingStyle.stroke..strokeWidth = 1;
    for (int i = 0; i <= gridSize; i++) {
      canvas.drawLine(Offset(i * cellSize, 0), Offset(i * cellSize, size.height), gridPaint);
      canvas.drawLine(Offset(0, i * cellSize), Offset(size.width, i * cellSize), gridPaint);
    }

    // 2. Gambar Buah (Apel)
    final foodPaint = Paint()..color = const Color(0xFFEF4444);
    canvas.drawCircle(
      Offset(food.x * cellSize + cellSize / 2, food.y * cellSize + cellSize / 2),
      cellSize / 2.5,
      foodPaint,
    );

    // 3. Gambar Ular
    for (int i = 0; i < snake.length; i++) {
      final point = snake[i];
      final rect = Rect.fromLTWH(point.x * cellSize, point.y * cellSize, cellSize, cellSize);
      final snakePaint = Paint()
        ..color = i == 0 ? const Color(0xFF38BDF8) : const Color(0xFF10B981) // Kepala biru, badan hijau
        ..style = PaintingStyle.fill;

      // Bikin sudut ular membulat
      canvas.drawRRect(RRect.fromRectAndRadius(rect.deflate(1), const Radius.circular(4)), snakePaint);
    }
  }

  @override
  bool shouldRepaint(covariant SnakePainter oldDelegate) => true;
}