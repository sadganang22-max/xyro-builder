// lib/game/game13.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game13 extends StatefulWidget {
  const Game13({super.key});
  @override
  State<Game13> createState() => _Game13State();
}

class _Game13State extends State<Game13> {
  int _activeBox = -1;
  int _score = 0;
  int _timeLeft = 30;
  bool _isPlaying = false;
  Timer? _timer;
  Timer? _boxTimer;
  final Random _random = Random();

  void _startGame() {
    setState(() {
      _score = 0;
      _timeLeft = 30;
      _isPlaying = true;
      _activeBox = _random.nextInt(9);
    });

    _timer?.cancel();
    _boxTimer?.cancel();

    // Timer Game
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (_timeLeft > 0) {
          _timeLeft--;
        } else {
          _endGame();
        }
      });
    });

    // Timer Box Pindah
    _boxTimer = Timer.periodic(const Duration(milliseconds: 700), (t) {
      if (!mounted) return;
      setState(() => _activeBox = _random.nextInt(9));
    });
  }

  void _endGame() {
    _timer?.cancel();
    _boxTimer?.cancel();
    setState(() {
      _isPlaying = false;
      _activeBox = -1;
    });
  }

  void _handleTap(int index) {
    if (!_isPlaying || index != _activeBox) return;
    setState(() {
      _score += 10;
      _activeBox = _random.nextInt(9); // Langsung pindah
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _boxTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('TAP REFLEX', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('SKOR: $_score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
                Text('WAKTU: $_timeLeft', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFEF4444))),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  margin: const EdgeInsets.all(20),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
                    itemCount: 9,
                    itemBuilder: (ctx, i) {
                      final isActive = _activeBox == i;
                      return GestureDetector(
                        onTap: () => _handleTap(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          decoration: BoxDecoration(
                            color: isActive ? const Color(0xFF0EA5E9) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: isActive ? [BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.5), blurRadius: 20, spreadRadius: 5)] : [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
          if (!_isPlaying)
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: GestureDetector(
                onTap: _startGame,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  decoration: BoxDecoration(color: const Color(0xFF0EA5E9), borderRadius: BorderRadius.circular(20)),
                  child: Text(_timeLeft == 0 ? 'MAIN LAGI' : 'MULAI', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}