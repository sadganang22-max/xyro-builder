// lib/game/game4.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Game4 extends StatefulWidget {
  const Game4({super.key});
  @override
  State<Game4> createState() => _Game4State();
}

class _Game4State extends State<Game4> {
  // Konfigurasi Fisika
  static const double gravity = 0.35;
  static const double jumpForce = -6.5;
  static const double pipeSpeed = 3.5;
  static const double pipeGap = 160.0;
  static const double pipeWidth = 60.0;

  // State
  double birdY = 250;
  double birdVelocity = 0;
  double birdX = 80; // Posisi horizontal burung tetap
  List<Map<String, double>> pipes = [];
  int score = 0;
  int highScore = 0;
  bool isPlaying = false;
  bool isGameOver = false;
  Timer? _gameLoop;
  double _scrollOffset = 0;

  @override
  void initState() {
    super.initState();
    _loadHighScore();
  }

  @override
  void dispose() {
    _gameLoop?.cancel();
    super.dispose();
  }

  Future<void> _loadHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => highScore = prefs.getInt('flappy_highscore') ?? 0);
  }

  Future<void> _saveHighScore() async {
    if (score > highScore) {
      setState(() => highScore = score);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('flappy_highscore', score);
    }
  }

  void _startGame() {
    setState(() {
      birdY = 250;
      birdVelocity = 0;
      pipes.clear();
      score = 0;
      isPlaying = true;
      isGameOver = false;
    });
    _gameLoop?.cancel();
    _gameLoop = Timer.periodic(const Duration(milliseconds: 16), (_) => _updateGame());
  }

  void _jump() {
    if (!isPlaying) return;
    setState(() => birdVelocity = jumpForce);
  }

  void _updateGame() {
    if (!isPlaying) return;

    setState(() {
      // Update Burung
      birdVelocity += gravity;
      birdY += birdVelocity;
      _scrollOffset += pipeSpeed;

      // Batas atas & bawah
      if (birdY < 0 || birdY > 600) { // 600 asumsi tinggi layar
        _gameOver();
        return;
      }

      // Generate Pipa Baru
      if (pipes.isEmpty || pipes.last['x']! < 300 - 200) {
        final random = Random();
        pipes.add({
          'x': 300, // Mulai dari kanan
          'topHeight': random.nextDouble() * 200 + 50,
          'passed': 0,
        });
      }

      // Update Posisi Pipa
      for (var pipe in pipes) {
        pipe['x'] = pipe['x']! - pipeSpeed;
      }

      // Hapus Pipa yang udah lewat
      pipes.removeWhere((p) => p['x']! < -pipeWidth);

      // Cek Tabrakan dengan Pipa
      for (var pipe in pipes) {
        final pipeLeft = pipe['x']!;
        final pipeRight = pipe['x']! + pipeWidth;
        final pipeTopGap = pipe['topHeight']!;
        final pipeBottomGap = pipeTopGap + pipeGap;

        if (birdX + 20 > pipeLeft && birdX - 20 < pipeRight) {
          if (birdY - 20 < pipeTopGap || birdY + 20 > pipeBottomGap) {
            _gameOver();
            return;
          }
        }

        // Skor Nambah Kalau Lelet
        if (pipe['x']! < birdX - 20 && pipe['passed'] == 0) {
          pipe['passed'] = 1;
          score++;
        }
      }
    });
  }

  void _gameOver() {
    _gameLoop?.cancel();
    _saveHighScore();
    setState(() {
      isPlaying = false;
      isGameOver = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF70C5CE), // Warna langit khas Flappy Bird
      appBar: AppBar(
        title: const Text('FLAPPY BIRD', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: Colors.white,
      ),
      body: GestureDetector(
        onTap: () {
          if (isPlaying) _jump();
          else if (isGameOver) _startGame();
        },
        child: Stack(
          children: [
            // Render Game
            CustomPaint(
              size: Size.infinite,
              painter: FlappyPainter(birdY: birdY, birdX: birdX, pipes: pipes, scrollOffset: _scrollOffset, isGameOver: isGameOver),
            ),

            // Score Overlay (Kiri Atas)
            if (isPlaying || isGameOver)
              Positioned(
                top: 40, left: 20,
                child: Text(
                  '$score',
                  style: const TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: Colors.white, shadows: [Shadow(offset: Offset(2, 2), blurRadius: 4, color: Colors.black45)]),
                ),
              ),

            // Start / Game Over Overlay
            if (!isPlaying)
              Center(
                child: Container(
                  padding: const EdgeInsets.all(30),
                  margin: const EdgeInsets.symmetric(horizontal: 30),
                  decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(24),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 10))],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(isGameOver ? Icons.sentiment_very_dissatisfied_rounded : Icons.flight_takeoff_rounded, size: 60, color: const Color(0xFF0EA5E9)),
                      const SizedBox(height: 16),
                      Text(isGameOver ? 'GAME OVER' : 'FLAPPY BIRD', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF0A2540))),
                      const SizedBox(height: 8),
                      if (isGameOver) ...[
                        Text('Skor: $score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        Text('Terbaik: $highScore', style: const TextStyle(fontSize: 14, color: Color(0xFF8FA5BE))),
                      ] else
                        const Text('Ketuk layar untuk terbang!', style: TextStyle(color: Color(0xFF8FA5BE), fontSize: 13)),
                      const SizedBox(height: 24),
                      GestureDetector(
                        onTap: _startGame,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9)]), borderRadius: BorderRadius.circular(30)),
                          child: const Text('MULAI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── PAINTER FLAPPY ───
class FlappyPainter extends CustomPainter {
  final double birdY;
  final double birdX;
  final List<Map<String, double>> pipes;
  final double scrollOffset;
  final bool isGameOver;

  FlappyPainter({required this.birdY, required this.birdX, required this.pipes, required this.scrollOffset, required this.isGameOver});

  @override
  void paint(Canvas canvas, Size size) {
    // 1. Gambar Background Awan / Bukit (Scrolling)
    final bgPaint = Paint()..color = const Color(0xFF4CAF50);
    canvas.drawRect(Rect.fromLTWH(0, size.height - 80, size.width, 80), bgPaint);

    // 2. Gambar Pipa
    final pipePaint = Paint()..color = const Color(0xFF388E3C);
    final pipeLightPaint = Paint()..color = const Color(0xFF4CAF50);
    final pipeBorder = Paint()..color = const Color(0xFF2E7D32)..style = PaintingStyle.stroke..strokeWidth = 2;

    for (var pipe in pipes) {
      double x = pipe['x']!;
      double topH = pipe['topHeight']!;
      double bottomY = topH + 160; // pipeGap

      // Pipa Atas
      Rect topRect = Rect.fromLTWH(x, 0, 60, topH);
      canvas.drawRect(topRect, pipePaint);
      canvas.drawRect(topRect, pipeBorder);
      canvas.drawRect(Rect.fromLTWH(x - 5, topH - 30, 70, 30), pipeLightPaint);
      canvas.drawRect(Rect.fromLTWH(x - 5, topH - 30, 70, 30), pipeBorder);

      // Pipa Bawah
      Rect bottomRect = Rect.fromLTWH(x, bottomY, 60, size.height - bottomY);
      canvas.drawRect(bottomRect, pipePaint);
      canvas.drawRect(bottomRect, pipeBorder);
      canvas.drawRect(Rect.fromLTWH(x - 5, bottomY, 70, 30), pipeLightPaint);
      canvas.drawRect(Rect.fromLTWH(x - 5, bottomY, 70, 30), pipeBorder);
    }

    // 3. Gambar Burung
    final birdPaint = Paint()..color = const Color(0xFFFBBF24);
    final birdBorder = Paint()..color = const Color(0xFFF59E0B)..style = PaintingStyle.stroke..strokeWidth = 2;
    canvas.drawCircle(Offset(birdX, birdY), 20, birdPaint);
    canvas.drawCircle(Offset(birdX, birdY), 20, birdBorder);

    // Mata
    canvas.drawCircle(Offset(birdX + 8, birdY - 5), 5, Paint()..color = Colors.white);
    canvas.drawCircle(Offset(birdX + 9, birdY - 5), 2, Paint()..color = Colors.black);

    // Paruh
    final beakPath = Path()
      ..moveTo(birdX + 20, birdY)
      ..lineTo(birdX + 35, birdY + 5)
      ..lineTo(birdX + 20, birdY + 10)
      ..close();
    canvas.drawPath(beakPath, Paint()..color = const Color(0xFFEF4444));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}