// lib/game/game2.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game2 extends StatefulWidget {
  const Game2({super.key});
  @override
  State<Game2> createState() => _Game2State();
}

class _Game2State extends State<Game2> {
  // Daftar Icon buat kartu (cuma 8, jadi 4 pasang per game)
  final List<IconData> _icons = [
    Icons.favorite_rounded,
    Icons.star_rounded,
    Icons.bolt_rounded,
    Icons.music_note_rounded,
    Icons.rocket_launch_rounded,
    Icons.pets_rounded,
    Icons.sunny_snowing,
    Icons.sports_esports_rounded,
  ];

  late List<Map<String, dynamic>> _cards;
  int? _firstCardIndex;
  int? _secondCardIndex;
  bool _isChecking = false;
  int _matchesFound = 0;
  int _moves = 0;
  int _seconds = 0;
  Timer? _timer;
  bool _isGameOver = false;

  @override
  void initState() {
    super.initState();
    _initGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _initGame() {
    _timer?.cancel();
    // Ambil 8 icon, duplikat jadi 16, lalu acak
    List<IconData> selectedIcons = List.from(_icons)..shuffle();
    List<Map<String, dynamic>> generatedCards = [];
    for (int i = 0; i < 8; i++) {
      generatedCards.add({'icon': selectedIcons[i], 'isFlipped': false, 'isMatched': false});
      generatedCards.add({'icon': selectedIcons[i], 'isFlipped': false, 'isMatched': false});
    }
    generatedCards.shuffle();

    setState(() {
      _cards = generatedCards;
      _firstCardIndex = null;
      _secondCardIndex = null;
      _isChecking = false;
      _matchesFound = 0;
      _moves = 0;
      _seconds = 0;
      _isGameOver = false;
    });

    // Mulai Timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && !_isGameOver) setState(() => _seconds++);
    });
  }

  void _handleCardTap(int index) {
    if (_isChecking || _cards[index]['isFlipped'] || _cards[index]['isMatched']) return;

    setState(() {
      _cards[index]['isFlipped'] = true;
    });

    if (_firstCardIndex == null) {
      _firstCardIndex = index;
    } else if (_secondCardIndex == null && index != _firstCardIndex) {
      _secondCardIndex = index;
      _moves++;
      _checkMatch();
    }
  }

  void _checkMatch() {
    setState(() => _isChecking = true);

    if (_cards[_firstCardIndex!]['icon'] == _cards[_secondCardIndex!]['icon']) {
      // Cocok!
      setState(() {
        _cards[_firstCardIndex!]['isMatched'] = true;
        _cards[_secondCardIndex!]['isMatched'] = true;
        _matchesFound++;
        _firstCardIndex = null;
        _secondCardIndex = null;
        _isChecking = false;
      });

      // Cek Menang
      if (_matchesFound == 8) {
        _timer?.cancel();
        setState(() => _isGameOver = true);
        _showWinDialog();
      }
    } else {
      // Gak cocok, tutup lagi setelah 800ms
      Timer(const Duration(milliseconds: 800), () {
        if (!mounted) return;
        setState(() {
          _cards[_firstCardIndex!]['isFlipped'] = false;
          _cards[_secondCardIndex!]['isFlipped'] = false;
          _firstCardIndex = null;
          _secondCardIndex = null;
          _isChecking = false;
        });
      });
    }
  }

  void _showWinDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('🎉 KAMU MENANG!', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Waktu: $_seconds detik', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Langkah: $_moves kali', style: const TextStyle(fontSize: 16)),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          ElevatedButton(
            onPressed: () { Navigator.pop(ctx); _initGame(); },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0EA5E9), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: const Text('MAIN LAGI'),
          ),
        ],
      ),
    );
  }

  String _formatTime(int sec) {
    int m = sec ~/ 60;
    int s = sec % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('MEMORY MATCH', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF0A2540),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _initGame,
          )
        ],
      ),
      body: Column(
        children: [
          // ─── STATS BAR ───
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatBox('WAKTU', _formatTime(_seconds), const Color(0xFF0EA5E9)),
                _buildStatBox('LANGKAH', '$_moves', const Color(0xFF8B5CF6)),
                _buildStatBox('SKOR', '$_matchesFound/8', const Color(0xFF10B981)),
              ],
            ),
          ),
          
          // ─── GRID KARTU ───
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: _cards.length,
                itemBuilder: (ctx, i) {
                  final card = _cards[i];
                  return GestureDetector(
                    onTap: () => _handleCardTap(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      decoration: BoxDecoration(
                        color: card['isFlipped'] || card['isMatched'] 
                            ? Colors.white 
                            : const Color(0xFF0EA5E9),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: card['isFlipped'] 
                                ? Colors.black.withOpacity(0.05) 
                                : const Color(0xFF0EA5E9).withOpacity(0.4),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                        border: card['isMatched'] ? Border.all(color: const Color(0xFF10B981), width: 2.5) : null,
                      ),
                      child: Center(
                        child: card['isFlipped'] || card['isMatched']
                            ? Icon(
                                card['icon'],
                                size: 32,
                                color: card['isMatched'] ? const Color(0xFF10B981) : const Color(0xFF0EA5E9),
                              )
                            : const Icon(Icons.help_outline_rounded, color: Colors.white54, size: 28),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatBox(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 4))],
      ),
      child: Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF8FA5BE), letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: color, fontFamily: 'Orbitron')),
        ],
      ),
    );
  }
}