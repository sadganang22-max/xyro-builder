// lib/game/game17.dart
import 'dart:math';
import 'package:flutter/material.dart';

class Game17 extends StatefulWidget {
  const Game17({super.key});
  @override
  State<Game17> createState() => _Game17State();
}

class _Game17State extends State<Game17> {
  List<String> _board = List.filled(9, '');
  String _currentPlayer = 'X'; // X = Player, O = AI
  bool _isGameOver = false;
  String _winner = '';

  void _handleTap(int index) {
    if (_board[index] != '' || _isGameOver) return;

    setState(() {
      _board[index] = 'X';
    });

    if (_checkWinner('X')) {
      setState(() { _winner = 'Kamu Menang! 🎉'; _isGameOver = true; });
      return;
    }
    if (!_board.contains('')) {
      setState(() { _winner = 'Seri! 🤝'; _isGameOver = true; });
      return;
    }

    _aiMove();
  }

  void _aiMove() {
    // 1. Coba Menang
    for (int i = 0; i < 9; i++) {
      if (_board[i] == '') {
        _board[i] = 'O';
        if (_checkWinner('O')) {
          setState(() { _winner = 'Komputer Menang! 🤖'; _isGameOver = true; });
          return;
        }
        _board[i] = '';
      }
    }
    // 2. Coba Block Player
    for (int i = 0; i < 9; i++) {
      if (_board[i] == '') {
        _board[i] = 'X';
        if (_checkWinner('X')) {
          _board[i] = 'O';
          setState(() {});
          return;
        }
        _board[i] = '';
      }
    }
    // 3. Gerak Random
    List<int> empty = [];
    for (int i = 0; i < 9; i++) { if (_board[i] == '') empty.add(i); }
    if (empty.isNotEmpty) {
      _board[empty[Random().nextInt(empty.length)]] = 'O';
      setState(() {});
      if (_checkWinner('O')) {
        setState(() { _winner = 'Komputer Menang! 🤖'; _isGameOver = true; });
      } else if (!_board.contains('')) {
        setState(() { _winner = 'Seri! 🤝'; _isGameOver = true; });
      }
    }
  }

  bool _checkWinner(String p) {
    const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (var l in lines) {
      if (_board[l[0]] == p && _board[l[1]] == p && _board[l[2]] == p) return true;
    }
    return false;
  }

  void _reset() => setState(() { _board = List.filled(9, ''); _winner = ''; _isGameOver = false; });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('TIC TAC TOE AI', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(_isGameOver ? _winner : 'Giliran Kamu (X)', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF0A2540))),
          const SizedBox(height: 40),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemCount: 9,
              itemBuilder: (context, i) => GestureDetector(
                onTap: () => _handleTap(i),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
                  child: Center(child: Text(_board[i], style: TextStyle(fontSize: 50, fontWeight: FontWeight.w900, color: _board[i] == 'X' ? const Color(0xFF0EA5E9) : const Color(0xFFEF4444)))),
                ),
              ),
            ),
          ),
          const SizedBox(height: 40),
          if (_isGameOver) GestureDetector(
            onTap: _reset,
            child: Container(padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF0EA5E9), Color(0xFF0284C7)]), borderRadius: BorderRadius.circular(16)), child: const Text('MAIN LAGI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
          ),
        ],
      ),
    );
  }
}