// lib/game/game15.dart
import 'dart:math';
import 'package:flutter/material.dart';

class Game15 extends StatefulWidget {
  const Game15({super.key});
  @override
  State<Game15> createState() => _Game15State();
}

class _Game15State extends State<Game15> {
  String _playerChoice = '';
  String _aiChoice = '';
  String _result = '';
  int _playerScore = 0;
  int _aiScore = 0;

  final List<String> _choices = ['Batu', 'Gunting', 'Kertas'];
  final Map<String, IconData> _icons = {
    'Batu': Icons.back_hand_rounded,
    'Gunting': Icons.content_cut_rounded,
    'Kertas': Icons.description_rounded,
  };

  void _play(String playerChoice) {
    final aiChoice = _choices[Random().nextInt(3)];
    String result;

    if (playerChoice == aiChoice) {
      result = 'SERI! 🤝';
    } else if (
      (playerChoice == 'Batu' && aiChoice == 'Gunting') ||
      (playerChoice == 'Gunting' && aiChoice == 'Kertas') ||
      (playerChoice == 'Kertas' && aiChoice == 'Batu')
    ) {
      result = 'KAMU MENANG! 🎉';
      _playerScore++;
    } else {
      result = 'AI MENANG! 🤖';
      _aiScore++;
    }

    setState(() {
      _playerChoice = playerChoice;
      _aiChoice = aiChoice;
      _result = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('ROCK PAPER SCISSORS', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 1.5, fontSize: 16)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          // Skor
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildScore('KAMU', _playerScore, const Color(0xFF10B981)),
              _buildScore('AI', _aiScore, const Color(0xFFEF4444)),
            ],
          ),
          const SizedBox(height: 40),

          // Area Pilihan
          if (_playerChoice.isNotEmpty)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildChoiceIcon(_playerChoice, const Color(0xFF10B981)),
                const Text('VS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF8FA5BE))),
                _buildChoiceIcon(_aiChoice, const Color(0xFFEF4444)),
              ],
            ),
          
          const SizedBox(height: 30),
          if (_result.isNotEmpty)
            Text(_result, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF0A2540))),

          const Spacer(),

          // Tombol Aksi
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: _choices.map((choice) {
                return Expanded(
                  child: GestureDetector(
                    onTap: () => _play(choice),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 6),
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))]),
                      child: Column(
                        children: [
                          Icon(_icons[choice], size: 36, color: const Color(0xFF0EA5E9)),
                          const SizedBox(height: 8),
                          Text(choice, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScore(String label, int score, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF8FA5BE), fontSize: 12)),
        Text('$score', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: color, fontFamily: 'Orbitron')),
      ],
    );
  }

  Widget _buildChoiceIcon(String choice, Color color) {
    return Container(
      width: 100, height: 100,
      decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
      child: Icon(_icons[choice], size: 50, color: color),
    );
  }
}