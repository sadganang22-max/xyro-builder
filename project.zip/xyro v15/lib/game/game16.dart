// lib/game/game16.dart
import 'package:flutter/material.dart';

class Game16 extends StatefulWidget {
  const Game16({super.key});
  @override
  State<Game16> createState() => _Game16State();
}

class _Game16State extends State<Game16> {
  // 6x6 Board. 0=Kosong, 1=Player, 2=AI
  List<List<int>> board = List.generate(6, (r) => List.generate(6, (c) => 0));
  int? selectedR, selectedC;

  @override
  void initState() {
    super.initState();
    _initBoard();
  }

  void _initBoard() {
    // Isi AI di atas (baris 0-1)
    for (int r = 0; r < 2; r++) {
      for (int c = 0; c < 6; c++) {
        if ((r + c) % 2 == 1) board[r][c] = 2;
      }
    }
    // Isi Player di bawah (baris 4-5)
    for (int r = 4; r < 6; r++) {
      for (int c = 0; c < 6; c++) {
        if ((r + c) % 2 == 1) board[r][c] = 1;
      }
    }
  }

  void _handleTap(int r, int c) {
    // Kalau klik pion sendiri
    if (board[r][c] == 1) {
      setState(() { selectedR = r; selectedC = c; });
      return;
    }

    // Kalau lagi milih pion & klik kotak kosong
    if (selectedR != null && selectedC != null && board[r][c] == 0) {
      // Validasi gerak (cuma boleh diagonal 1 langkah)
      int dr = (r - selectedR!).abs();
      int dc = (c - selectedC!).abs();
      
      if (dr == 1 && dc == 1) {
        setState(() {
          board[r][c] = 1;
          board[selectedR!][selectedC!] = 0;
          selectedR = null;
          selectedC = null;
        });
        _aiMove();
      }
    }
  }

  void _aiMove() {
    // AI Gerak Random Sederhana
    for (int r = 0; r < 6; r++) {
      for (int c = 0; c < 6; c++) {
        if (board[r][c] == 2) {
          // Coba gerak ke bawah kiri / kanan
          if (r + 1 < 6 && c - 1 >= 0 && board[r+1][c-1] == 0) {
            setState(() { board[r+1][c-1] = 2; board[r][c] = 0; });
            return;
          }
          if (r + 1 < 6 && c + 1 < 6 && board[r+1][c+1] == 0) {
            setState(() { board[r+1][c+1] = 2; board[r][c] = 0; });
            return;
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF3F9),
      appBar: AppBar(
        title: const Text('CHECKERS MINI', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: Colors.transparent, elevation: 0, foregroundColor: const Color(0xFF0A2540),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: () => setState(_initBoard))],
      ),
      body: Center(
        child: AspectRatio(
          aspectRatio: 1,
          child: Container(
            margin: const EdgeInsets.all(20),
            decoration: BoxDecoration(border: Border.all(color: const Color(0xFF0A2540), width: 4), borderRadius: BorderRadius.circular(8)),
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6),
              itemCount: 36,
              itemBuilder: (ctx, index) {
                int r = index ~/ 6;
                int c = index % 6;
                bool isDark = (r + c) % 2 == 1;
                bool isSelected = selectedR == r && selectedC == c;

                return GestureDetector(
                  onTap: () => _handleTap(r, c),
                  child: Container(
                    color: isDark ? const Color(0xFF64748B) : const Color(0xFFF1F5F9),
                    child: Center(
                      child: board[r][c] == 0 
                        ? (isSelected ? const Icon(Icons.circle, color: Colors.green, size: 20) : const SizedBox())
                        : Container(
                            width: 35, height: 35,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: board[r][c] == 1 ? const Color(0xFF38BDF8) : const Color(0xFFEF4444),
                              border: Border.all(color: Colors.white, width: 2),
                              boxShadow: isSelected ? [BoxShadow(color: Colors.green, blurRadius: 15, spreadRadius: 2)] : [],
                            ),
                          ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}