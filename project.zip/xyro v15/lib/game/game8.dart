// lib/game/game8.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Game8 extends StatefulWidget {
  const Game8({super.key});
  @override
  State<Game8> createState() => _Game8State();
}

class _Game8State extends State<Game8> {
  // Posisi & Kecepatan
  double playerY = 200;
  double aiY = 200;
  double ballX = 200;
  double ballY = 300;
  double ballSpeedX = 4;
  double ballSpeedY = 4;

  int playerScore = 0;
  int aiScore = 0;
  bool isPlaying = false;
  Timer? _gameLoop;

  final double paddleHeight = 80;
  final double paddleWidth = 12;

  void _startGame() {
    setState(() {
      playerScore = 0;
      aiScore = 0;
      ballX = 200;
      ballY = 300;
      playerY = 200;
      aiY = 200;
      isPlaying = true;
      _resetBall();
    });
    _gameLoop?.cancel();
    _gameLoop = Timer.periodic(const Duration(milliseconds: 16), (_) => _updateGame());
  }

  void _resetBall() {
    ballX = 200; // Tengah
    ballY = 300;
    ballSpeedX = Random().nextBool() ? 4 : -4;
    ballSpeedY = Random().nextBool() ? 4 : -4;
  }

  void _updateGame() {
    if (!isPlaying) return;

    setState(() {
      // Update Posisi Bola
      ballX += ballSpeedX;
      ballY += ballSpeedY;

      // Pantul Atas & Bawah
      if (ballY <= 0 || ballY >= 600) ballSpeedY = -ballSpeedY;

      // Pantul Player (Kiri)
      if (ballX <= 20 && ballY > playerY && ballY < playerY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
        ballX = 20;
      }
      
      // Pantul AI (Kanan)
      if (ballX >= 380 - paddleWidth && ballY > aiY && ballY < aiY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
        ballX = 380 - paddleWidth;
      }

      // Cek Skor
      if (ballX < 0) {
        aiScore++;
        _resetBall();
      } else if (ballX > 400) {
        playerScore++;
        _resetBall();
      }

      // AI Movement (Mengikuti bola dengan delay)
      if (aiY + paddleHeight / 2 < ballY) {
        aiY += 2.5;
      } else if (aiY + paddleHeight / 2 > ballY) {
        aiY -= 2.5;
      }
      // Batasi AI biar gak keluar layar
      aiY = aiY.clamp(0.0, 600.0 - paddleHeight);
    });
  }

  @override
  void dispose() {
    _gameLoop?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Dark theme
      appBar: AppBar(
        title: const Text('PONG CLASSIC', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18, color: Colors.white)),
        backgroundColor: Colors.transparent, elevation: 0, iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GestureDetector(
        onPanUpdate: (details) {
          if (!isPlaying) return;
          setState(() {
            playerY = (details.localPosition.dy - paddleHeight / 2).clamp(0.0, 600.0 - paddleHeight);
          });
        },
        child: Stack(
          children: [
            // Render Lapangan
            CustomPaint(
              size: Size.infinite,
              painter: PongPainter(
                playerY: playerY, aiY: aiY, ballX: ballX, ballY: ballY,
                paddleWidth: paddleWidth, paddleHeight: paddleHeight,
              ),
            ),

            // Skor
            Positioned(
              top: 20, left: 0, right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('$playerScore', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Color(0xFF38BDF8), fontFamily: 'Orbitron')),
                  Text('$aiScore', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Color(0xFFEF4444), fontFamily: 'Orbitron')),
                ],
              ),
            ),

            // Overlay Start
            if (!isPlaying)
              Center(
                child: GestureDetector(
                  onTap: _startGame,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9)]),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Text('MAIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── PAINTER PONG ───
class PongPainter extends CustomPainter {
  final double playerY;
  final double aiY;
  final double ballX;
  final double ballY;
  final double paddleWidth;
  final double paddleHeight;

  PongPainter({
    required this.playerY, required this.aiY,
    required this.ballX, required this.ballY,
    required this.paddleWidth, required this.paddleHeight,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Garis Putih Tengah Lapangan
    final linePaint = Paint()..color = Colors.white.withOpacity(0.2)..strokeWidth = 2;
    for (double y = 0; y < size.height; y += 20) {
      canvas.drawLine(Offset(size.width / 2, y), Offset(size.width / 2, y + 10), linePaint);
    }

    // Pemain (Kiri)
    final playerPaint = Paint()..color = const Color(0xFF38BDF8);
    canvas.drawRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(20, playerY, paddleWidth, paddleHeight), const Radius.circular(6)
    ), playerPaint);

    // AI (Kanan)
    final aiPaint = Paint()..color = const Color(0xFFEF4444);
    canvas.drawRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width - 20 - paddleWidth, aiY, paddleWidth, paddleHeight), const Radius.circular(6)
    ), aiPaint);

    // Bola
    final ballPaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(ballX, ballY), 10, ballPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}