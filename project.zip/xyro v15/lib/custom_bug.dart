// ═══════════════════════════════════════════════════════════════════════════
//  CUSTOM BUG PAGE — ROMBAK TOTAL
//  Tactical payload console · step flow · multi-select · live counter
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFF8B5CF6);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9), Color(0xFF0284C7), Color(0xFF0369A1)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class CustomBugPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const CustomBugPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.listBug,
  });

  @override
  State<CustomBugPage> createState() => _CustomBugPageState();
}

class _CustomBugPageState extends State<CustomBugPage> with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _orbitCtrl;

  late Animation<double> _entrance;

  final targetController = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final Set<String> _selectedBugIds = {};

  bool _isSending = false;
  String? _responseMessage;
  String? _responseType; // 'success' | 'error' | 'warning'

  final int _privateSenderCount = 1;

  List<Map<String, dynamic>> get _numberBugs => widget.listBug
      .where((b) => (b['type']?.toString().toLowerCase() ?? '') == 'number')
      .toList();

  bool get _allSelected =>
      _numberBugs.isNotEmpty && _selectedBugIds.length == _numberBugs.length;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _entranceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900),
    );
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 14),
    )..repeat();

    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _entranceCtrl.dispose();
    _orbitCtrl.dispose();
    targetController.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() {
      _responseMessage = msg;
      _responseType = type;
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  Future<void> _sendMulti() async {
    final rawInput = targetController.text.trim();

    if (formatPhoneNumber(rawInput) == null) {
      _showAlert("❌ Nomor Tidak Valid", "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
      return;
    }

    if (_selectedBugIds.isEmpty) {
      _showAlert("❌ Belum Pilih Bug", "Pilih minimal 1 bug untuk dikirim.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
      _responseType = null;
    });

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final bugList = _selectedBugIds.join(',');

      final res = await http.get(Uri.parse(
        '$baseUrl/sendBugMulti'
        '?key=${widget.sessionKey}'
        '&target=$encodedTarget'
        '&bugs=$bugList'
        '&senderMode=private',
      )).timeout(const Duration(seconds: 60));

      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', data['message'] ?? 'Server sibuk');
      } else if (data['sended'] == true) {
        _setResponse('success', '${data['success']} bug berhasil dikirim!');
        targetController.clear();
        setState(() => _selectedBugIds.clear());
      } else {
        _setResponse('error', 'Semua bug gagal terkirim.');
      }
    } catch (e) {
      _setResponse('warning', 'Server memproses terlalu lama. Coba kurangi bug atau tunggu 1 menit.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _C.border, width: 1.5),
        ),
        title: Text(title,
          style: const TextStyle(color: _C.text, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: _C.ice2, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // BG
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.white.withOpacity(0.75),
                    Colors.white.withOpacity(0.88),
                    Colors.white.withOpacity(0.72),
                  ],
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),

          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                _buildDivider(),
                Expanded(
                  child: FadeTransition(
                    opacity: _entrance,
                    child: SingleChildScrollView(
                      controller: _scrollCtrl,
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildHeroCommandCard(),
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '01',
                            title: 'TARGET NUMBER',
                            icon: Icons.phone_android_rounded,
                            color: _C.ice2,
                            child: _buildTargetInput(),
                          ),
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '02',
                            title: 'PAYLOAD SELECTION',
                            icon: Icons.bug_report_rounded,
                            color: _C.red,
                            child: _buildBugSelector(),
                          ),
                          const SizedBox(height: 20),
                          _buildSendButton(),
                          if (_responseMessage != null) ...[
                            const SizedBox(height: 14),
                            _buildResponseMessage(),
                          ],
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() => Container(
    height: 1,
    margin: const EdgeInsets.symmetric(horizontal: 14),
    color: _C.border.withOpacity(0.6),
  );

  // ─── TOP BAR ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded, color: _C.text, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('CUSTOM BUG',
                  style: TextStyle(
                    color: _C.text, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2,
                  ),
                ),
                Text('MULTI PAYLOAD · v1.0',
                  style: TextStyle(
                    color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w700,
                    letterSpacing: 2, fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.ice.withOpacity(0.5), width: 1.2),
              color: _C.iceSoft,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: _C.green,
                      boxShadow: [
                        BoxShadow(
                          color: _C.green.withOpacity(0.5 + _pulseCtrl.value * 0.5),
                          blurRadius: 4 + _pulseCtrl.value * 4,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                const Text('ARMED',
                  style: TextStyle(
                    color: _C.ice3, fontSize: 9,
                    fontWeight: FontWeight.w900, letterSpacing: 1.5,
                    fontFamily: 'Orbitron',
                  )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO COMMAND CARD ──────────────────────────────────────────────────────
  Widget _buildHeroCommandCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF0A2540), Color(0xFF0F3A5F), Color(0xFF0A2540)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: _C.ice2.withOpacity(0.35), blurRadius: 28, offset: const Offset(0, 12)),
          BoxShadow(color: _C.text.withOpacity(0.20), blurRadius: 48, offset: const Offset(0, 20)),
        ],
        border: Border.all(color: _C.ice2.withOpacity(0.4), width: 1.2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned(
              top: -50, right: -50,
              child: AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: _orbitCtrl.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(200, 200),
                    painter: _HeroOrbitPainter(),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.ice2.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.ice2.withOpacity(0.6)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.bolt_rounded, color: _C.ice, size: 11),
                            const SizedBox(width: 4),
                            const Text('MULTI EXECUTE',
                              style: TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 1.5,
                              )),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text('BYPASS',
                        style: TextStyle(
                          color: _C.ice.withOpacity(0.6),
                          fontSize: 10, fontWeight: FontWeight.w900,
                          letterSpacing: 2, fontFamily: 'Orbitron',
                        )),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _C.ice.withOpacity(0.6), width: 2),
                          boxShadow: [BoxShadow(color: _C.ice2.withOpacity(0.5), blurRadius: 16)],
                        ),
                        child: ClipOval(
                          child: Image.asset('assets/images/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                              const Icon(Icons.person, color: _C.ice, size: 30)),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.username.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1,
                              ),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.ice2.withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(widget.role.toUpperCase(),
                                    style: const TextStyle(
                                      color: _C.ice, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: 1,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.green.withOpacity(0.20),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text('PRIVATE',
                                    style: TextStyle(
                                      color: _C.green, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(height: 1, color: Colors.white.withOpacity(0.10)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      _miniStat(
                        '${_selectedBugIds.length}/${_numberBugs.length}',
                        'SELECTED',
                        _selectedBugIds.isEmpty ? _C.ice.withOpacity(0.5) : _C.green,
                      ),
                      const SizedBox(width: 20),
                      _miniStat('${_numberBugs.length}', 'PAYLOADS', _C.ice),
                      const SizedBox(width: 20),
                      _miniStat('$_privateSenderCount', 'SENDER', _C.green),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniStat(String value, String label, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value,
          style: TextStyle(
            color: color, fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 0.5,
          ),
        ),
        Text(label,
          style: TextStyle(
            color: _C.ice.withOpacity(0.6), fontSize: 9,
            fontWeight: FontWeight.w700, letterSpacing: 1.5,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  // ─── STEP PANEL WRAPPER ─────────────────────────────────────────────────────
  Widget _buildStepPanel({
    required String step,
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: _sh2,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [color, color.withOpacity(0.4)]),
                ),
              ),
            ),
            Positioned(
              top: -10, right: 8,
              child: Text(step,
                style: TextStyle(
                  color: color.withOpacity(0.06),
                  fontSize: 80, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron', height: 1.0,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: color.withOpacity(0.3)),
                        ),
                        child: Icon(icon, color: color, size: 16),
                      ),
                      const SizedBox(width: 10),
                      Text(title,
                        style: const TextStyle(
                          color: _C.text, fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(step,
                          style: TextStyle(
                            color: color, fontSize: 9,
                            fontWeight: FontWeight.w900, letterSpacing: 1,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  child,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── TARGET INPUT ───────────────────────────────────────────────────────────
  Widget _buildTargetInput() {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: _C.cardAlt,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.borderMid),
          ),
          child: TextField(
            controller: targetController,
            style: const TextStyle(
              color: _C.text, fontFamily: 'ShareTechMono',
              fontSize: 15, fontWeight: FontWeight.w600,
            ),
            cursorColor: _C.ice2,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              hintText: '+62812xxxxxxxx',
              hintStyle: TextStyle(
                color: _C.textDim.withOpacity(0.7),
                fontFamily: 'ShareTechMono', fontSize: 14,
              ),
              prefixIcon: const Icon(Icons.language_rounded, color: _C.textSub, size: 20),
              suffixIcon: GestureDetector(
                onTap: () => targetController.clear(),
                child: const Icon(Icons.close_rounded, color: _C.textDim, size: 18),
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        // Sender info
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: _C.iceSoft.withOpacity(0.6),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.ice.withOpacity(0.4), width: 1.2),
          ),
          child: Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.primaryGrad,
                  boxShadow: [
                    BoxShadow(color: _C.ice.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 4)),
                  ],
                ),
                child: const Icon(Icons.person_rounded, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Sender Private',
                      style: TextStyle(
                        color: _C.ice3, fontWeight: FontWeight.w900,
                        fontSize: 12, letterSpacing: 0.5,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text('1 sender aktif · Bypass mode',
                      style: TextStyle(
                        color: _C.textSub, fontFamily: 'ShareTechMono',
                        fontSize: 10, fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.green.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.green.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 5, height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: _C.green,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text('ACTIVE',
                      style: TextStyle(
                        color: _C.green, fontSize: 9,
                        fontWeight: FontWeight.w900, letterSpacing: 1,
                        fontFamily: 'Orbitron',
                      )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ─── BUG SELECTOR ───────────────────────────────────────────────────────────
  Widget _buildBugSelector() {
    final bugs = _numberBugs;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header with select all
        Row(
          children: [
            Text(
              '${_selectedBugIds.length} / ${bugs.length} DIPILIH',
              style: TextStyle(
                color: _selectedBugIds.isEmpty ? _C.textDim : _C.ice3,
                fontSize: 10, fontWeight: FontWeight.w900,
                letterSpacing: 1.5, fontFamily: 'Orbitron',
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() {
                  if (_allSelected) {
                    _selectedBugIds.clear();
                  } else {
                    _selectedBugIds
                      ..clear()
                      ..addAll(bugs.map((b) => b['bug_id'] as String));
                  }
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _allSelected ? _C.iceSoft : _C.cardAlt,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _allSelected ? _C.ice : _C.border,
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _allSelected ? Icons.clear_all_rounded : Icons.select_all_rounded,
                      color: _allSelected ? _C.ice3 : _C.textSub,
                      size: 12,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      _allSelected ? 'RESET' : 'PILIH SEMUA',
                      style: TextStyle(
                        color: _allSelected ? _C.ice3 : _C.textSub,
                        fontSize: 9, fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        if (bugs.isEmpty)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 30),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.border),
            ),
            child: const Center(
              child: Text('Tidak ada bug type "number"',
                style: TextStyle(color: _C.textDim, fontSize: 12)),
            ),
          )
        else
          ...bugs.map((bug) {
            final bugId = bug['bug_id'] as String? ?? '';
            final bugName = (bug['bug_name'] as String? ?? 'BUG').toString();
            final isSelected = _selectedBugIds.contains(bugId);
            final index = bugs.indexOf(bug);

            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() {
                    if (isSelected) {
                      _selectedBugIds.remove(bugId);
                    } else {
                      _selectedBugIds.add(bugId);
                    }
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? LinearGradient(
                            colors: [_C.iceSoft, _C.surface],
                            begin: Alignment.centerLeft, end: Alignment.centerRight,
                          )
                        : null,
                    color: isSelected ? null : _C.cardAlt,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isSelected ? _C.ice2 : _C.border,
                      width: isSelected ? 1.5 : 1.0,
                    ),
                    boxShadow: isSelected
                        ? [BoxShadow(color: _C.ice2.withOpacity(0.20), blurRadius: 12, offset: const Offset(0, 4))]
                        : null,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40, height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isSelected
                              ? _C.primaryGrad
                              : LinearGradient(
                                  colors: [_C.textDim.withOpacity(0.15), _C.textDim.withOpacity(0.05)],
                                ),
                          boxShadow: isSelected ? _shPrimary : null,
                        ),
                        child: Icon(
                          Icons.bug_report_rounded,
                          color: isSelected ? Colors.white : _C.textDim,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              bugName.toUpperCase(),
                              style: TextStyle(
                                color: isSelected ? _C.ice3 : _C.text,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? _C.ice2.withOpacity(0.15)
                                        : _C.border.withOpacity(0.5),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    bugId.toLowerCase(),
                                    style: TextStyle(
                                      color: isSelected ? _C.ice3 : _C.textDim,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  '#${(index + 1).toString().padLeft(2, '0')}',
                                  style: TextStyle(
                                    color: _C.textDim.withOpacity(0.6),
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 26, height: 26,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected ? _C.ice2 : Colors.transparent,
                          border: Border.all(
                            color: isSelected ? _C.ice2 : _C.borderMid,
                            width: 2,
                          ),
                        ),
                        child: isSelected
                            ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                            : null,
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
      ],
    );
  }

  // ─── SEND BUTTON ────────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    final enabled = !_isSending && _selectedBugIds.isNotEmpty;
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, child) {
        return GestureDetector(
          onTap: enabled ? _sendMulti : null,
          child: Container(
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: enabled ? _C.primaryGrad : null,
              color: enabled ? null : _C.border,
              border: Border.all(color: Colors.white.withOpacity(0.3), width: 1.5),
              boxShadow: enabled
                  ? [
                      ..._shPrimary,
                      BoxShadow(
                        color: _C.ice2.withOpacity(0.15 + _pulseCtrl.value * 0.15),
                        blurRadius: 40,
                        spreadRadius: 4,
                      ),
                    ]
                  : null,
            ),
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      width: 26, height: 26,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.rocket_launch_rounded,
                          color: enabled ? Colors.white : _C.textDim,
                          size: 22,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          _selectedBugIds.isEmpty
                              ? 'PILIH BUG DULU'
                              : 'EXECUTE ${_selectedBugIds.length} BUG',
                          style: TextStyle(
                            color: enabled ? Colors.white : _C.textDim,
                            fontWeight: FontWeight.w900,
                            fontSize: 15, fontFamily: 'Orbitron', letterSpacing: 2.5,
                            shadows: enabled
                                ? const [Shadow(color: Color(0x40000000), offset: Offset(0, 1), blurRadius: 2)]
                                : null,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  // ─── RESPONSE MESSAGE ───────────────────────────────────────────────────────
  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color color;
    IconData icon;
    String title;
    switch (_responseType) {
      case 'success':
        color = _C.green;
        icon = Icons.check_circle_outline_rounded;
        title = 'BERHASIL';
        break;
      case 'warning':
        color = _C.amber;
        icon = Icons.warning_amber_rounded;
        title = 'PERHATIAN';
        break;
      default:
        color = _C.red;
        icon = Icons.error_outline_rounded;
        title = 'GAGAL';
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.4), width: 1.2),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.15), blurRadius: 12, offset: const Offset(0, 4)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.18),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                  style: TextStyle(
                    color: color, fontFamily: 'Orbitron',
                    fontSize: 12, fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  )),
                const SizedBox(height: 4),
                Text(_responseMessage!,
                  style: const TextStyle(
                    color: _C.textSub, fontFamily: 'ShareTechMono',
                    fontSize: 11, height: 1.4, fontWeight: FontWeight.w600,
                  )),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => setState(() {
              _responseMessage = null;
              _responseType = null;
            }),
            child: const Icon(Icons.close_rounded, color: _C.textDim, size: 18),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.04)..strokeWidth = 0.6;
    const sp = 32.0;
    for (double x = 0; x < size.width; x += sp) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += sp) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _HeroOrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final dashPaint = Paint()
      ..color = _C.ice.withOpacity(0.30)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 36;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.08, false, dashPaint);
    }

    final arcPaint = Paint()
      ..color = _C.ice2.withOpacity(0.5)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const startAngles = [0.0, math.pi * 2 / 3, math.pi * 4 / 3];
    for (final start in startAngles) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius * 0.75),
        start, math.pi / 4, false, arcPaint,
      );
    }

    canvas.drawCircle(center, 4, Paint()..color = _C.ice2.withOpacity(0.6));
    canvas.drawCircle(center, 8, Paint()..color = _C.ice2.withOpacity(0.2));
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}