// ═══════════════════════════════════════════════════════════════════════════
//  INFO PAGE — ROMBAK TOTAL
//  Cinematic hero · horizontal rules pager · sticky status · sanction banner
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);
  static const blue      = Color(0xFF3B82F6);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFF8B5CF6);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [ice, ice2, ice3, iceDeep],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.08), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _sh3 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.18), blurRadius: 32, offset: const Offset(0, 16)),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc, required this.icon, required this.color});
}

const _rules = [
  _Rule(title: 'Larangan Barter Akun', desc: 'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.', icon: Icons.swap_horiz_rounded, color: Color(0xFFF59E0B)),
  _Rule(title: 'Larangan Membagikan Akun', desc: 'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.', icon: Icons.share_rounded, color: Color(0xFF3B82F6)),
  _Rule(title: 'Larangan Menjual Akun', desc: 'Member TIDAK diperbolehkan menjual akun. Penjualan hanya boleh dilakukan oleh role yang diizinkan secara resmi.', icon: Icons.sell_rounded, color: Color(0xFFEF4444)),
  _Rule(title: 'Larangan Jual Durasi Ilegal', desc: 'Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.', icon: Icons.timer_off_rounded, color: Color(0xFF6366F1)),
  _Rule(title: 'Larangan Banting Harga', desc: 'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan Xyro Engine.', icon: Icons.trending_down_rounded, color: Color(0xFF10B981)),
];

const _fallbackServerInfo = {'name': 'Xyro Server', 'version': '1.0', 'status': 'online'};

class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  Map<String, dynamic> serverInfo = _fallbackServerInfo;
  bool _apiOnline = false;
  int _pingMs = 0;
  Timer? _pingTimer;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _sanctionCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _scanCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sanctionGlow;

  late PageController _rulesCtrl;
  int _activeRule = 0;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _sanctionCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.2, end: 0.8).animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();

    _rulesCtrl = PageController(viewportFraction: 0.82, initialPage: 0);
    _rulesCtrl.addListener(() {
      final p = _rulesCtrl.page?.round() ?? 0;
      if (p != _activeRule && p >= 0 && p < _rules.length) {
        setState(() => _activeRule = p);
      }
    });

    _fetchServerInfo();
    _startPingLoop();
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _sanctionCtrl.dispose();
    _particleCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _rulesCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/getServerInfo?key=${widget.sessionKey}'));
      if (res.statusCode == 200 && mounted) {
        setState(() => serverInfo = jsonDecode(res.body));
      }
    } catch (_) {}
  }

  void _startPingLoop() {
    _checkPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkPing());
  }

  Future<void> _checkPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(Uri.parse('$baseUrl/ping?key=${widget.sessionKey}')).timeout(const Duration(seconds: 3));
      final ms = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() { _apiOnline = true; _pingMs = ms; });
      } else {
        throw Exception();
      }
    } catch (_) {
      if (mounted) setState(() { _apiOnline = false; _pingMs = 0; });
    }
  }

  Color get _pingColor {
    if (!_apiOnline) return _C.red;
    if (_pingMs < 200) return _C.green;
    if (_pingMs < 500) return _C.amber;
    return const Color(0xFFF97316);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // BG
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                ),
              ),
            ),
          ),
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _particleCtrl,
              builder: (_, __) => CustomPaint(painter: _ParticlePainter(_particleCtrl.value)),
            ),
          ),

          // CONTENT
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: Column(
                children: [
                  // STICKY TOP BAR
                  _buildTopBar(),
                  const SizedBox(height: 8),

                  // SCROLL AREA
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const SizedBox(height: 12),
                          _buildCinematicHero(),
                          const SizedBox(height: 20),
                          _buildLiveStatusStrip(),
                          const SizedBox(height: 24),
                          _buildRulesSection(),
                          const SizedBox(height: 24),
                          _buildSanctionBanner(),
                          const SizedBox(height: 24),
                          _buildFooterCard(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOP BAR ─────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _apiOnline ? _C.green : _C.red,
                boxShadow: [
                  BoxShadow(
                    color: (_apiOnline ? _C.green : _C.red).withOpacity(0.5 + _pulseCtrl.value * 0.5),
                    blurRadius: 10, spreadRadius: 2,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _apiOnline ? 'SYSTEM ONLINE' : 'SYSTEM OFFLINE',
            style: TextStyle(
              color: _apiOnline ? _C.ice3 : _C.red,
              fontSize: 10, fontWeight: FontWeight.w900,
              letterSpacing: 2, fontFamily: 'Orbitron',
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border),
              boxShadow: _sh1,
            ),
            child: Text(
              _apiOnline ? '${_pingMs}ms · PING' : 'NO SIGNAL',
              style: TextStyle(
                color: _pingColor,
                fontSize: 9, fontWeight: FontWeight.w900,
                letterSpacing: 1.5, fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CINEMATIC HERO ──────────────────────────────────────────────────────
  Widget _buildCinematicHero() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        height: 240,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            colors: [Color(0xFF0A2540), Color(0xFF0F3A5F), Color(0xFF0A2540)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          boxShadow: _sh3,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Orbit painter besar
              AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: _orbitCtrl.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(240, 240),
                    painter: _HeroOrbitPainter(),
                  ),
                ),
              ),
              // Scan line sweep
              AnimatedBuilder(
                animation: _scanCtrl,
                builder: (_, __) => Positioned(
                  top: 0, bottom: 0,
                  left: -100 + _scanCtrl.value * 400,
                  child: Container(
                    width: 60,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          _C.ice.withOpacity(0.12),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // Gradient overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.4),
                    ],
                    stops: const [0.4, 1.0],
                  ),
                ),
              ),
              // Content
              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: _C.ice2.withOpacity(0.20),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _C.ice2.withOpacity(0.6)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.shield_rounded, color: _C.ice, size: 11),
                              const SizedBox(width: 5),
                              const Text(
                                'SECURITY HUB',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        Text(
                          'V${serverInfo['version'] ?? '1.0'}',
                          style: TextStyle(
                            color: _C.ice.withOpacity(0.7),
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'PROTOCOL\nRULES',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            height: 1.0,
                            letterSpacing: -0.5,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Patuhi aturan untuk kenyamanan bersama.\nPelanggaran = tindakan tegas tanpa toleransi.',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.75),
                            fontSize: 11,
                            height: 1.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── LIVE STATUS STRIP ──────────────────────────────────────────────────
  Widget _buildLiveStatusStrip() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border, width: 1.2),
          boxShadow: _sh2,
        ),
        child: Row(
          children: [
            _statusCell(
              icon: Icons.speed_rounded,
              label: 'PING',
              value: _apiOnline ? '${_pingMs}ms' : '—',
              color: _pingColor,
            ),
            Container(width: 1, height: 40, color: _C.border),
            _statusCell(
              icon: Icons.dns_rounded,
              label: 'API',
              value: _apiOnline ? 'AKTIF' : 'MATI',
              color: _apiOnline ? _C.green : _C.red,
            ),
            Container(width: 1, height: 40, color: _C.border),
            _statusCell(
              icon: Icons.rule_rounded,
              label: 'ATURAN',
              value: '${_rules.length}',
              color: _C.ice2,
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusCell({required IconData icon, required String label, required String value, required Color color}) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 13, fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron', letterSpacing: 0.5,
            ),
          ),
          Text(
            label,
            style: const TextStyle(
              color: _C.textDim,
              fontSize: 8, fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── RULES SECTION (HORIZONTAL PAGER) ───────────────────────────────────
  Widget _buildRulesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            children: [
              Container(width: 20, height: 3, color: _C.ice2),
              const SizedBox(width: 10),
              const Text(
                'PERATURAN WAJIB',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 14, fontWeight: FontWeight.w900,
                  letterSpacing: 2, fontFamily: 'Orbitron',
                ),
              ),
              const Spacer(),
              Text(
                '${(_activeRule + 1).toString().padLeft(2, '0')} / ${_rules.length.toString().padLeft(2, '0')}',
                style: const TextStyle(
                  color: _C.ice3,
                  fontSize: 10, fontWeight: FontWeight.w900,
                  letterSpacing: 1.5, fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: AnimatedBuilder(
            animation: _rulesCtrl,
            builder: (context, _) {
              double page = 0;
              if (_rulesCtrl.hasClients && _rulesCtrl.position.haveDimensions) {
                page = _rulesCtrl.page ?? 0;
              }
              return PageView.builder(
                controller: _rulesCtrl,
                itemCount: _rules.length,
                physics: const BouncingScrollPhysics(),
                itemBuilder: (context, i) {
                  final diff = (page - i).abs().clamp(0.0, 1.0);
                  final scale = 1 - diff * 0.12;
                  final opacity = 1 - diff * 0.55;
                  return Transform.scale(
                    scale: scale,
                    child: Opacity(
                      opacity: opacity.clamp(0.4, 1.0),
                      child: _buildRuleCardItem(_rules[i], i + 1, i == _activeRule),
                    ),
                  );
                },
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        // Indicator dots
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_rules.length, (i) {
            final isActive = i == _activeRule;
            return GestureDetector(
              onTap: () => _rulesCtrl.animateToPage(
                i,
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOutCubic,
              ),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: isActive ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: isActive ? _rules[i].color : _C.borderMid,
                  boxShadow: isActive
                      ? [BoxShadow(color: _rules[i].color.withOpacity(0.5), blurRadius: 8)]
                      : null,
                ),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildRuleCardItem(_Rule rule, int number, bool isActive) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isActive ? rule.color.withOpacity(0.6) : _C.border,
            width: isActive ? 1.8 : 1.2,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(color: rule.color.withOpacity(0.35), blurRadius: 24, spreadRadius: 2, offset: const Offset(0, 12)),
                  BoxShadow(color: _C.text.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, 6)),
                ]
              : _sh1,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              // Corner accent
              Positioned(
                top: -30, right: -30,
                child: Container(
                  width: 120, height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        rule.color.withOpacity(isActive ? 0.20 : 0.10),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                rule.color.withOpacity(0.9),
                                rule.color.withOpacity(0.6),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(color: rule.color.withOpacity(0.45), blurRadius: 12, offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Icon(rule.icon, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            rule.title,
                            style: const TextStyle(
                              color: _C.text,
                              fontSize: 15, fontWeight: FontWeight.w900,
                              height: 1.2, letterSpacing: 0.2,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Container(
                      height: 2,
                      width: 30,
                      color: rule.color.withOpacity(0.4),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      rule.desc,
                      style: const TextStyle(
                        color: _C.textSub,
                        fontSize: 12, height: 1.55, fontWeight: FontWeight.w500,
                      ),
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: rule.color.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: rule.color.withOpacity(0.3)),
                          ),
                          child: Text(
                            'RULE ${number.toString().padLeft(2, '0')}',
                            style: TextStyle(
                              color: rule.color,
                              fontSize: 9, fontWeight: FontWeight.w900,
                              letterSpacing: 1.5, fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _C.red.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: _C.red.withOpacity(0.3)),
                          ),
                          child: const Text(
                            'WAJIB',
                            style: TextStyle(
                              color: _C.red,
                              fontSize: 9, fontWeight: FontWeight.w900,
                              letterSpacing: 1.5, fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SANCTION BANNER (BIG) ──────────────────────────────────────────────
  Widget _buildSanctionBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: AnimatedBuilder(
        animation: _sanctionCtrl,
        builder: (_, __) => Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              colors: [
                Color.lerp(_C.surface, _C.red.withOpacity(0.08), _sanctionGlow.value)!,
                _C.surface,
              ],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: _C.red.withOpacity(0.30 + _sanctionGlow.value * 0.30),
              width: 1.8,
            ),
            boxShadow: [
              BoxShadow(
                color: _C.red.withOpacity(0.15 + _sanctionGlow.value * 0.15),
                blurRadius: 24, offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Stack(
              children: [
                // Ornament gavel besar
                Positioned(
                  right: -20, bottom: -20,
                  child: Icon(
                    Icons.gavel_rounded,
                    size: 140,
                    color: _C.red.withOpacity(0.06),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: _C.red.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: _C.red.withOpacity(0.6)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 6, height: 6,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _C.red,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                const Text(
                                  'SANKSI TEGAS',
                                  style: TextStyle(
                                    color: _C.red,
                                    fontSize: 9, fontWeight: FontWeight.w900,
                                    letterSpacing: 2, fontFamily: 'Orbitron',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          Icon(Icons.warning_amber_rounded, color: _C.red.withOpacity(0.7), size: 20),
                        ],
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'Pelanggaran =\nAkun DIHAPUS.',
                        style: TextStyle(
                          color: _C.text,
                          fontSize: 22, fontWeight: FontWeight.w900,
                          height: 1.1, letterSpacing: -0.3,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Tidak ada toleransi. Tidak ada refund.\nTidak ada pengecualian.',
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 12, height: 1.5, fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8, runSpacing: 8,
                        children: [
                          _sanctionChip(Icons.account_balance_wallet_rounded, 'Tanpa refund'),
                          _sanctionChip(Icons.sync_disabled_rounded, 'Tanpa kompensasi'),
                          _sanctionChip(Icons.person_off_rounded, 'Permanent ban'),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sanctionChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _C.red.withOpacity(0.08),
        border: Border.all(color: _C.red.withOpacity(0.30)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.red, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: _C.textSub,
              fontSize: 10, fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // ─── FOOTER CARD ────────────────────────────────────────────────────────
  Widget _buildFooterCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: _sh1,
                  ),
                  child: const Icon(Icons.shield_rounded, color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                const Text(
                  'PERSETUJUAN',
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 12, fontWeight: FontWeight.w900,
                    letterSpacing: 1.5, fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan yang berlaku tanpa terkecuali.',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 11, height: 1.6, fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.ice2, Colors.transparent],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'XYRO ENGINE',
                  style: TextStyle(
                    color: _C.textDim,
                    fontSize: 9, fontWeight: FontWeight.w900,
                    letterSpacing: 3, fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.06)..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.ice.withOpacity(0.12 + math.sin(t * math.pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9).createShader(Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.15),
          radius: size.width * 0.7));
    canvas.drawCircle(Offset(size.width / 2, size.height * 0.15), size.width * 0.7, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _ParticlePainter extends CustomPainter {
  final double t;
  _ParticlePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(99);
    for (int i = 0; i < 25; i++) {
      final x = rand.nextDouble() * size.width;
      final y0 = rand.nextDouble() * size.height;
      final speed = 10 + rand.nextDouble() * 15;
      final y = (y0 + t * speed) % size.height;
      final radius = 1.0 + rand.nextDouble() * 2.0;
      final paint = Paint()..color = _C.ice.withOpacity(0.10 + rand.nextDouble() * 0.15);
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter old) => old.t != t;
}

class _HeroOrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    // Dashed outer ring
    final dashPaint = Paint()
      ..color = _C.ice.withOpacity(0.35)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 36;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.08, false, dashPaint);
    }

    // Solid arc segments
    final arcPaint = Paint()
      ..color = _C.ice2.withOpacity(0.6)
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const startAngles = [0.0, math.pi * 2 / 3, math.pi * 4 / 3];
    for (final start in startAngles) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius * 0.75),
        start, math.pi / 3, false, arcPaint,
      );
    }

    // Inner ring
    final innerPaint = Paint()
      ..color = _C.ice3.withOpacity(0.3)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius * 0.5, innerPaint);

    // Satellite dots
    final dotPaint = Paint()..color = _C.ice2;
    for (final start in startAngles) {
      final angle = start + math.pi / 6;
      final dx = center.dx + radius * math.cos(angle);
      final dy = center.dy + radius * math.sin(angle);
      canvas.drawCircle(Offset(dx, dy), 3.5, dotPaint);
      canvas.drawCircle(Offset(dx, dy), 8, Paint()..color = _C.ice2.withOpacity(0.25));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}