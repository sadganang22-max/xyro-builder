// ═══════════════════════════════════════════════════════════════════════════
//  LANDING PAGE — XYRO ENGINE · TRUE REBUILD
//  Split hero · horizontal feature rail · bold asymmetric · bottom CTA dock
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'login_page.dart';
import 'maintenance_overlay.dart';

class _C {
  static const bg       = Color(0xFFEEF3F9);
  static const bgGrad1  = Color(0xFFF5FAFF);
  static const bgGrad2  = Color(0xFFE6EEF8);
  static const surface  = Color(0xFFFFFFFF);
  static const cardAlt  = Color(0xFFF5F9FF);
  static const border   = Color(0xFFD6E2F0);
  static const borderMid= Color(0xFFC3D4E8);

  static const ice      = Color(0xFF38BDF8);
  static const ice2     = Color(0xFF0EA5E9);
  static const ice3     = Color(0xFF0284C7);
  static const iceDeep  = Color(0xFF0369A1);
  static const iceSoft  = Color(0xFFE0F2FE);
  static const blue     = Color(0xFF3B82F6);

  static const text     = Color(0xFF0A2540);
  static const textSub  = Color(0xFF4A6582);
  static const textDim  = Color(0xFF8FA5BE);

  static const telegram = Color(0xFF29B6F6);
  static const tiktok   = Color(0xFF475569);
  static const instagram= Color(0xFFE1306C);
}

final List<BoxShadow> _shSoft = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _shHero = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.20), blurRadius: 24, offset: const Offset(0, 12)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.20), blurRadius: 48, offset: const Offset(0, 24)),
];
final List<BoxShadow> _shBtn = [
  BoxShadow(color: const Color(0xFF0EA5E9).withOpacity(0.45), blurRadius: 20, offset: const Offset(0, 10)),
];

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _shineCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _shineCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 5))..repeat();
    WidgetsBinding.instance.addPostFrameCallback((_) => _fadeCtrl.forward());
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    _pulseCtrl.dispose();
    _shineCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaintenanceOverlay(
      userRole: null,
      child: Scaffold(
        backgroundColor: _C.bg,
        body: Stack(
          children: [
            // ── Background ──
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                ),
              ),
            ),
            // ── Big radial glow kiri atas ──
            Positioned(
              top: -180, left: -180,
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 460, height: 460,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          _C.ice.withOpacity(0.28 + _pulseCtrl.value * 0.08),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // ── Glow kecil kanan bawah ──
            Positioned(
              bottom: -100, right: -80,
              child: IgnorePointer(
                child: Container(
                  width: 300, height: 300,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [_C.blue.withOpacity(0.12), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),

            // ── CONTENT ──
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: Column(
                  children: [
                    // ─── TOP STATUS BAR ───
                    _buildTopBar(),
                    const SizedBox(height: 8),

                    // ─── SCROLLABLE HERO ───
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const SizedBox(height: 20),
                            _buildHeadline(),
                            const SizedBox(height: 24),
                            _buildHeroCard(),
                            const SizedBox(height: 24),
                            _buildFeatureRail(),
                            const SizedBox(height: 24),
                            _buildMarqueeStrip(),
                            const SizedBox(height: 24),
                            _buildInfoTile(),
                            const SizedBox(height: 24),
                            _buildSocialRow(),
                            const SizedBox(height: 30),
                            _buildFooter(),
                            const SizedBox(height: 120),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ─── BOTTOM CTA DOCK (FLOATING) ───
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: _buildBottomDock(),
            ),
          ],
        ),
      ),
    );
  }

  // ── Top bar ──
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 8, 22, 0),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.ice2,
                boxShadow: [
                  BoxShadow(
                    color: _C.ice2.withOpacity(0.5 + _pulseCtrl.value * 0.5),
                    blurRadius: 8, spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            'SYSTEM ONLINE',
            style: TextStyle(
              color: _C.ice3, fontSize: 10, fontWeight: FontWeight.w800,
              letterSpacing: 2, fontFamily: 'Orbitron',
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border),
              boxShadow: _shSoft,
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.verified_rounded, color: _C.ice2, size: 12),
                SizedBox(width: 5),
                Text(
                  'v1.0',
                  style: TextStyle(
                    color: _C.ice3, fontSize: 10, fontWeight: FontWeight.w800,
                    letterSpacing: 1.5, fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Headline besar kiri align + nomor ──
  Widget _buildHeadline() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.ice3,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    '#1 PLATFORM',
                    style: TextStyle(
                      color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900,
                      letterSpacing: 1.5, fontFamily: 'Orbitron',
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                RichText(
                  text: const TextSpan(
                    style: TextStyle(
                      fontSize: 38, fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron', height: 1.0, letterSpacing: -0.5,
                    ),
                    children: [
                      TextSpan(text: 'BUILD ', style: TextStyle(color: _C.text)),
                      TextSpan(text: 'FASTER\n', style: TextStyle(color: _C.ice2)),
                      TextSpan(text: 'WITH ', style: TextStyle(color: _C.text)),
                      TextSpan(text: 'XYRO.', style: TextStyle(color: _C.ice3)),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Platform premium untuk kebutuhan\ndigital kamu, dibuat oleh TEAM XYRO.',
                  style: TextStyle(
                    color: _C.textSub, fontSize: 12, height: 1.55,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // Angka besar vertikal
          Column(
            children: [
              Text(
                '∞',
                style: TextStyle(
                  color: _C.ice2.withOpacity(0.3),
                  fontSize: 72, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron', height: 0.8,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── HERO CARD dengan shine sweep ──
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: AnimatedBuilder(
        animation: _floatCtrl,
        builder: (context, child) => Transform.translate(
          offset: Offset(0, 5 * _floatCtrl.value),
          child: child,
        ),
        child: Container(
          height: 220,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            boxShadow: _shHero,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/images/login.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.ice, _C.ice2, _C.ice3, _C.iceDeep],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Center(
                      child: Icon(Icons.shield_rounded, color: Colors.white, size: 80),
                    ),
                  ),
                ),
                // Overlay gradient
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.transparent,
                        _C.text.withOpacity(0.75),
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
                // Shine sweep animation
                AnimatedBuilder(
                  animation: _shineCtrl,
                  builder: (_, __) => Positioned(
                    top: 0, bottom: 0,
                    left: -150 + _shineCtrl.value * 500,
                    child: Transform.rotate(
                      angle: math.pi / 8,
                      child: Container(
                        width: 80,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.white.withOpacity(0.0),
                              Colors.white.withOpacity(0.15),
                              Colors.white.withOpacity(0.0),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Label bawah
                Positioned(
                  left: 18, right: 18, bottom: 18,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withOpacity(0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6, height: 6,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              'LIVE',
                              style: TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 2,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'XYRO ENGINE',
                            style: TextStyle(
                              color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron', letterSpacing: 2,
                            ),
                          ),
                          Text(
                            'PREMIUM · STABLE · FAST',
                            style: TextStyle(
                              color: Colors.white, fontSize: 8, fontWeight: FontWeight.w700,
                              letterSpacing: 1.8,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Feature rail — HORIZONTAL SCROLL (bukan 3 kotak sejajar) ──
  Widget _buildFeatureRail() {
    final items = [
      _FeatureRailData(icon: Icons.speed_rounded, title: 'Cepat', desc: 'Zero lag', color: _C.ice2),
      _FeatureRailData(icon: Icons.shield_rounded, title: 'Aman', desc: 'Encrypted', color: _C.ice3),
      _FeatureRailData(icon: Icons.bolt_rounded, title: 'Stabil', desc: '24/7 uptime', color: _C.blue),
      _FeatureRailData(icon: Icons.auto_awesome_rounded, title: 'Premium', desc: 'Exclusive', color: _C.iceDeep),
    ];

    return SizedBox(
      height: 118,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        itemBuilder: (_, i) {
          final f = items[i];
          return Container(
            width: 160,
            margin: const EdgeInsets.symmetric(horizontal: 6),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border),
              boxShadow: _shSoft,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: f.color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: f.color.withOpacity(0.35)),
                  ),
                  child: Icon(f.icon, color: f.color, size: 20),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      f.title,
                      style: const TextStyle(
                        color: _C.text, fontSize: 14, fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron', letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      f.desc,
                      style: const TextStyle(
                        color: _C.textDim, fontSize: 11, fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ── Marquee strip "XYRO ENGINE · PREMIUM · STABLE" ──
  Widget _buildMarqueeStrip() {
    return Container(
      height: 48,
      margin: const EdgeInsets.symmetric(horizontal: 22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.ice, _C.ice2, _C.ice3],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: _shBtn,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Stack(
          children: [
            AnimatedBuilder(
              animation: _shineCtrl,
              builder: (_, __) => Transform.translate(
                offset: Offset(_shineCtrl.value * 400 - 100, 0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '· PREMIUM · STABLE · FAST · TRUSTED · XYRO ENGINE ',
                    maxLines: 1,
                    softWrap: false,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 11, fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron', letterSpacing: 3,
                    ),
                  ),
                ),
              ),
            ),
            // left fade
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.ice, _C.ice.withOpacity(0)],
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                width: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.ice3.withOpacity(0), _C.ice3],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Info tile asymmetric (kiri icon besar, kanan list) ──
  Widget _buildInfoTile() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.surface, _C.cardAlt],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.border, width: 1.5),
          boxShadow: _shSoft,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Kiri — icon besar gradient
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.ice, _C.ice2, _C.ice3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: _shBtn,
              ),
              child: const Icon(Icons.shield_outlined, color: Colors.white, size: 44),
            ),
            const SizedBox(width: 16),
            // Kanan — info list
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'TENTANG XYRO',
                    style: TextStyle(
                      color: _C.text, fontSize: 14, fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron', letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _miniInfo(Icons.check_circle_rounded, 'Design elegant & modern', _C.ice2),
                  const SizedBox(height: 6),
                  _miniInfo(Icons.check_circle_rounded, 'Fitur terbaru & stabil', _C.blue),
                  const SizedBox(height: 6),
                  _miniInfo(Icons.check_circle_rounded, 'Dikembangkan TEAM XYRO', _C.ice3),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniInfo(IconData icon, String text, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 14),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              color: _C.textSub, fontSize: 11, fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  // ── Social row ──
  Widget _buildSocialRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'HUBUNGI KAMI',
                style: TextStyle(
                  color: _C.text, fontSize: 12, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron', letterSpacing: 1.2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.border, Colors.transparent],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _socialChip(FontAwesomeIcons.telegram, 'Telegram', _C.telegram, () => _openUrl('https://t.me/makngemis'))),
              const SizedBox(width: 10),
              Expanded(child: _socialChip(FontAwesomeIcons.tiktok, 'TikTok', _C.tiktok, () => _openUrl('https://tiktok.m/@maklowh'))),
              const SizedBox(width: 10),
              Expanded(child: _socialChip(FontAwesomeIcons.instagram, 'Instagram', _C.instagram, () => _openUrl('https://instagram/z4mzzxz'))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _socialChip(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.4), width: 1.2),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.15), blurRadius: 8, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Center(child: FaIcon(icon, color: color, size: 15)),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(
                color: _C.textSub, fontSize: 10, fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Footer ──
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Column(
        children: [
          Row(
            children: [
              Container(width: 20, height: 2, color: _C.ice2),
              const SizedBox(width: 6),
              Container(width: 10, height: 2, color: _C.borderMid),
              const Spacer(),
              Text(
                '© ${DateTime.now().year} XYRO',
                style: TextStyle(
                  color: _C.text.withOpacity(0.35), fontSize: 9,
                  fontWeight: FontWeight.w700, letterSpacing: 1.5,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── BOTTOM CTA DOCK (floating) ──
  Widget _buildBottomDock() {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _C.bg.withOpacity(0.0),
            _C.bg.withOpacity(0.85),
            _C.bg,
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
      ),
      child: Row(
        children: [
          // Contact icon button
          Container(
            width: 58, height: 58,
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.border, width: 1.5),
              boxShadow: _shSoft,
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => _openUrl('https://t.me/maklgemis'),
                child: const Icon(Icons.headset_mic_rounded, color: _C.textSub, size: 24),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Login button besar
          Expanded(
            child: Container(
              height: 58,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.ice, _C.ice2, _C.ice3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                boxShadow: _shBtn,
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.white.withOpacity(0.22), Colors.transparent],
                        stops: const [0.0, 0.5],
                      ),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                        SizedBox(width: 10),
                        Text(
                          'LOGIN NOW',
                          style: TextStyle(
                            color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron', letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureRailData {
  final IconData icon;
  final String title;
  final String desc;
  final Color color;
  const _FeatureRailData({required this.icon, required this.title, required this.desc, required this.color});
}