// ═══════════════════════════════════════════════════════════════════════════
//  XYRO ARCADE — PREMIUM GAME HUB (V2 RIBET EDITION)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// IMPORT 20 GAME
import 'game/game1.dart';
import 'game/game2.dart';
import 'game/game3.dart';
import 'game/game4.dart';
import 'game/game5.dart';
import 'game/game6.dart';
import 'game/game7.dart';
import 'game/game8.dart';
import 'game/game9.dart';
import 'game/game10.dart';
import 'game/game11.dart';
import 'game/game12.dart';
import 'game/game13.dart';
import 'game/game14.dart';
import 'game/game15.dart';
import 'game/game16.dart';
import 'game/game17.dart';
import 'game/game18.dart';
import 'game/game19.dart';
import 'game/game20.dart';

// ─── PALETTE ───
const Color kBg      = Color(0xFFF0F4F8);
const Color kBgDark  = Color(0xFF0F172A);
const Color kCard    = Color(0xFFFFFFFF);
const Color kIce     = Color(0xFF38BDF8);
const Color kIce2    = Color(0xFF0EA5E9);
const Color kIce3    = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);
const Color kText    = Color(0xFF0A2540);
const Color kTextSub = Color(0xFF4A6582);
const Color kTextDim = Color(0xFF8FA5BE);
const Color kPink    = Color(0xFFEC4899);
const Color kPurple  = Color(0xFF8B5CF6);
const Color kGreen   = Color(0xFF10B981);
const Color kRed     = Color(0xFFEF4444);
const Color kAmber   = Color(0xFFF59E0B);

final List<BoxShadow> shPrimary = [
  BoxShadow(color: kIce2.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8)),
];

// ─── MODEL GAME ───
class GameItem {
  final String title, category, desc;
  final IconData icon;
  final List<Color> gradient;
  final String badge;
  final Widget gamePage;
  final bool isTrending;

  const GameItem({
    required this.title, required this.category, required this.desc,
    required this.icon, required this.gradient, required this.gamePage,
    this.badge = '', this.isTrending = false,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  MAIN PAGE
// ═══════════════════════════════════════════════════════════════════════════
class GameHubPage extends StatefulWidget {
  const GameHubPage({super.key});
  @override
  State<GameHubPage> createState() => _GameHubPageState();
}

class _GameHubPageState extends State<GameHubPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _floatCtrl;
  final TextEditingController _searchCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  String _searchQuery = '';
  String _selectedCategory = 'Semua';
  final List<String> _categories = ['Semua', 'Puzzle', 'Arcade', 'Board', 'Casual'];
  
  double _scrollOffset = 0;

  final List<GameItem> allGames = [
    // 1-5
    GameItem(title: 'Tic Tac Toe', category: 'Board', desc: 'Kalahkan AI 3x3', icon: Icons.grid_3x3_rounded, gradient: [kIce2, kIce3], badge: 'TOP', isTrending: true, gamePage: const Game1()),
    GameItem(title: 'Memory Match', category: 'Puzzle', desc: 'Cocokkan kartu', icon: Icons.grid_view_rounded, gradient: [kPink, kPurple], badge: 'NEW', gamePage: const Game2()),
    GameItem(title: 'Snake Classic', category: 'Arcade', desc: 'Ular makan buah', icon: Icons.gesture_rounded, gradient: [kGreen, const Color(0xFF047857)], badge: 'HOT', isTrending: true, gamePage: const Game3()),
    GameItem(title: 'Flappy Bird', category: 'Arcade', desc: 'Terbang lewati pipa', icon: Icons.flight_rounded, gradient: [kAmber, const Color(0xFFB45309)], gamePage: const Game4()),
    GameItem(title: '2048', category: 'Puzzle', desc: 'Gabung angka', icon: Icons.grid_on_rounded, gradient: [const Color(0xFF3B82F6), kIce3], isTrending: true, gamePage: const Game5()),
    // 6-10
    GameItem(title: 'Math Quiz', category: 'Puzzle', desc: 'Hitung cepat', icon: Icons.calculate_rounded, gradient: [kPurple, const Color(0xFF5B21B6)], gamePage: const Game6()),
    GameItem(title: 'Simon Says', category: 'Casual', desc: 'Ingat urutan warna', icon: Icons.psychology_rounded, gradient: [kPink, kRed], badge: 'NEW', gamePage: const Game7()),
    GameItem(title: 'Pong', category: 'Arcade', desc: 'Tenis meja lawan AI', icon: Icons.sports_tennis_rounded, gradient: [kRed, const Color(0xFF991B1B)], gamePage: const Game8()),
    GameItem(title: 'Breakout', category: 'Arcade', desc: 'Hancurkan bata', icon: Icons.border_all_rounded, gradient: [kIce3, kIce2], badge: 'HOT', isTrending: true, gamePage: const Game9()),
    GameItem(title: 'Minesweeper', category: 'Puzzle', desc: 'Hindari ranjau', icon: Icons.flag_rounded, gradient: [const Color(0xFF64748B), const Color(0xFF1E293B)], gamePage: const Game10()),
    // 11-15
    GameItem(title: 'Word Search', category: 'Puzzle', desc: 'Cari kata', icon: Icons.search_rounded, gradient: [kGreen, kIce3], gamePage: const Game11()),
    GameItem(title: 'Whack-A-Mole', category: 'Casual', desc: 'Pukul tikus', icon: Icons.touch_app_rounded, gradient: [kAmber, kRed], gamePage: const Game12()),
    GameItem(title: 'Tap Reflex', category: 'Casual', desc: 'Uji refleks', icon: Icons.bolt_rounded, gradient: [kIce, kIce2], gamePage: const Game13()),
    GameItem(title: 'Typing Speed', category: 'Casual', desc: 'Tes ngetik', icon: Icons.keyboard_rounded, gradient: [const Color(0xFF1E293B), const Color(0xFF334155)], gamePage: const Game14()),
    GameItem(title: 'Rock Paper', category: 'Casual', desc: 'Suwit AI', icon: Icons.front_hand_rounded, gradient: [kIce2, kGreen], gamePage: const Game15()),
    // 16-20
    GameItem(title: 'Checkers Mini', category: 'Board', desc: 'Dam-daman', icon: Icons.radio_button_checked_rounded, gradient: [kRed, const Color(0xFF7F1D1D)], gamePage: const Game16()),
    GameItem(title: 'Tic Tac Toe AI', category: 'Board', desc: 'AI Lebih pintar', icon: Icons.sports_esports_rounded, gradient: [const Color(0xFF1E293B), const Color(0xFF0F172A)], gamePage: const Game17()),
    GameItem(title: 'Connect Four', category: 'Board', desc: 'Sambung 4 koin', icon: Icons.view_column_rounded, gradient: [kIce2, kAmber], gamePage: const Game18()),
    GameItem(title: 'Math Quiz 2', category: 'Puzzle', desc: 'Tantangan hitung', icon: Icons.functions_rounded, gradient: [kPurple, kPink], gamePage: const Game19()),
    GameItem(title: 'Stroop Test', category: 'Casual', desc: 'Tebak warna tulisan', icon: Icons.visibility_rounded, gradient: [kPink, kAmber], gamePage: const Game20()),
  ];

  List<GameItem> get _filteredGames => allGames.where((g) {
    final matchCat = _selectedCategory == 'Semua' || g.category == _selectedCategory;
    final matchSearch = g.title.toLowerCase().contains(_searchQuery.toLowerCase());
    return matchCat && matchSearch;
  }).toList();

  List<GameItem> get _trendingGames => allGames.where((g) => g.isTrending).toList();

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 15))..repeat();
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _searchCtrl.addListener(() => setState(() => _searchQuery = _searchCtrl.text));
    _scrollCtrl.addListener(() => setState(() => _scrollOffset = _scrollCtrl.offset));
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _floatCtrl.dispose();
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          // Background Glow
          AnimatedBuilder(
            animation: _bgCtrl,
            builder: (_, __) => Positioned.fill(
              child: Transform.rotate(
                angle: _bgCtrl.value * 2 * math.pi,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: SweepGradient(
                      colors: [Colors.transparent, kIce.withOpacity(0.08), Colors.transparent, kIce2.withOpacity(0.05), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Konten Utama
          SafeArea(
            child: CustomScrollView(
              controller: _scrollCtrl,
              physics: const BouncingScrollPhysics(),
              slivers: [
                _buildAppBar(),
                _buildHeroBanner(),
                _buildStatsBar(),
                _buildSearchAndFilter(),
                _buildTrendingSection(),
                _buildCategoryTitle(),
                _buildGameGrid(),
                const SliverToBoxAdapter(child: SizedBox(height: 60)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── 1. APP BAR ───
  Widget _buildAppBar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: kText.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: const Icon(Icons.arrow_back_rounded, color: kText, size: 22),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('XYRO', style: TextStyle(color: kText, fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: kIce2, borderRadius: BorderRadius.circular(4)),
                        child: const Text('ARCADE', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
                      ),
                    ],
                  ),
                  const Text('20 Game Premium Siap Dimainkan', style: TextStyle(color: kTextDim, fontSize: 11, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            // Icon Orbit
            AnimatedBuilder(
              animation: _floatCtrl,
              builder: (_, __) => Transform.translate(
                offset: Offset(0, _floatCtrl.value * 5),
                child: Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kIce, kIce2]),
                    shape: BoxShape.circle,
                    boxShadow: shPrimary,
                  ),
                  child: const Icon(Icons.sports_esports_rounded, color: Colors.white, size: 24),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── 2. HERO BANNER ───
  Widget _buildHeroBanner() {
    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 24, 20, 16),
        height: 160,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          boxShadow: [BoxShadow(color: kText.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 10))],
        ),
        child: Stack(
          children: [
            // Ornamen
            Positioned(
              right: -20, bottom: -20,
              child: Icon(Icons.sports_esports_rounded, size: 150, color: Colors.white.withOpacity(0.05)),
            ),
            Positioned(
              left: -30, top: -30,
              child: Container(
                width: 100, height: 100,
                decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [kIce2.withOpacity(0.3), Colors.transparent])),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: kIce2.withOpacity(0.2), borderRadius: BorderRadius.circular(8), border: Border.all(color: kIce2.withOpacity(0.5))),
                    child: const Text('🔥 TRENDING NOW', style: TextStyle(color: kIce, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  ),
                  const SizedBox(height: 12),
                  const Text('Mainkan Game\nTerbaik Hari Ini!', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.w900, height: 1.2)),
                  const SizedBox(height: 8),
                  Text('Pilih dari 20 game seru tanpa batas.', style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── 3. STATS BAR ───
  Widget _buildStatsBar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            _buildMiniStat('20', 'GAMES', kIce2),
            const SizedBox(width: 12),
            _buildMiniStat('5', 'KATEGORI', kPurple),
            const SizedBox(width: 12),
            _buildMiniStat('FREE', 'AKSES', kGreen),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniStat(String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: kText.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(color: color, fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: kTextDim, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  // ─── 4. SEARCH & FILTER ───
  Widget _buildSearchAndFilter() {
    return SliverToBoxAdapter(
      child: Column(
        children: [
          // Search
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: kText.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))],
              ),
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: kText, fontWeight: FontWeight.w600, fontSize: 14),
                decoration: const InputDecoration(
                  hintText: 'Cari game favoritmu...', hintStyle: TextStyle(color: kTextDim, fontSize: 13),
                  prefixIcon: Icon(Icons.search_rounded, color: kIce2, size: 22),
                  border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
              ),
            ),
          ),
          // Filter Kategori
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _categories.length,
              itemBuilder: (ctx, i) {
                final isActive = _categories[i] == _selectedCategory;
                return GestureDetector(
                  onTap: () { HapticFeedback.selectionClick(); setState(() => _selectedCategory = _categories[i]); },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: isActive ? const LinearGradient(colors: [kIce2, kIce3]) : null,
                      color: isActive ? null : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: isActive ? shPrimary : null,
                    ),
                    child: Text(_categories[i].toUpperCase(), style: TextStyle(color: isActive ? Colors.white : kTextDim, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ─── 5. TRENDING SECTION ───
  Widget _buildTrendingSection() {
    if (_selectedCategory != 'Semua') return const SliverToBoxAdapter(child: SizedBox());
    
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 24, 20, 12),
            child: Row(
              children: [
                Icon(Icons.local_fire_department_rounded, color: kRed, size: 20),
                SizedBox(width: 8),
                Text('SEDANG TRENDING', style: TextStyle(color: kText, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
              ],
            ),
          ),
          SizedBox(
            height: 180,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _trendingGames.length,
              itemBuilder: (ctx, i) {
                final game = _trendingGames[i];
                return GestureDetector(
                  onTap: () => _openGameDetail(game),
                  child: Container(
                    width: 280,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: game.gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: game.gradient.first.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8))],
                    ),
                    child: Stack(
                      children: [
                        Positioned(right: -10, bottom: -10, child: Icon(game.icon, size: 120, color: Colors.white.withOpacity(0.15))),
                        Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6)),
                                child: Text(game.badge, style: TextStyle(color: game.gradient.first, fontSize: 9, fontWeight: FontWeight.w900)),
                              ),
                              const Spacer(),
                              Text(game.title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 20, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 4),
                              Text(game.desc, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ─── 6. CATEGORY TITLE ───
  Widget _buildCategoryTitle() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
        child: Row(
          children: [
            Container(width: 4, height: 20, decoration: BoxDecoration(color: kIce2, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Text(_selectedCategory == 'Semua' ? 'SEMUA GAME' : _selectedCategory.toUpperCase(), style: const TextStyle(color: kText, fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1)),
            const Spacer(),
            Text('${_filteredGames.length} Game', style: const TextStyle(color: kTextDim, fontSize: 12, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // ─── 7. GAME GRID ───
  Widget _buildGameGrid() {
    if (_filteredGames.isEmpty) {
      return const SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.all(40),
          child: Center(child: Text('Game Tidak Ditemukan', style: TextStyle(color: kTextDim, fontWeight: FontWeight.bold))),
        ),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 0.82),
        delegate: SliverChildBuilderDelegate(
          (ctx, i) => _buildGameCard(_filteredGames[i]),
          childCount: _filteredGames.length,
        ),
      ),
    );
  }

  Widget _buildGameCard(GameItem game) {
    return GestureDetector(
      onTap: () => _openGameDetail(game),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: game.gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: game.gradient.first.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 8))],
        ),
        child: Stack(
          children: [
            Positioned(right: -15, bottom: -15, child: Icon(game.icon, color: Colors.white.withOpacity(0.10), size: 100)),
            if (game.badge.isNotEmpty)
              Positioned(
                top: 12, right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
                  child: Text(game.badge, style: TextStyle(color: game.gradient.first, fontSize: 9, fontWeight: FontWeight.w900)),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.3))),
                    child: Icon(game.icon, color: Colors.white, size: 24),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(6)),
                    child: Text(game.category.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900)),
                  ),
                  const SizedBox(height: 6),
                  Text(game.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text(game.desc, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 10)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM SHEET DETAIL ───
  void _openGameDetail(GameItem game) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 24),
            Container(width: 90, height: 90, decoration: BoxDecoration(gradient: LinearGradient(colors: game.gradient), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: game.gradient.first.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 10))]), child: Icon(game.icon, color: Colors.white, size: 45)),
            const SizedBox(height: 20),
            Text(game.title, style: const TextStyle(color: kText, fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(game.desc, style: const TextStyle(color: kTextDim, fontSize: 13, fontWeight: FontWeight.w500)),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => game.gamePage)); },
              child: Container(
                height: 56, width: double.infinity,
                decoration: BoxDecoration(gradient: LinearGradient(colors: game.gradient), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: game.gradient.first.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))]),
                child: const Center(child: Text('MULAI MAIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2))),
              ),
            ),
          ],
        ),
      ),
    );
  }
}