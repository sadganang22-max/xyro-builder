// ═══════════════════════════════════════════════════════════════════════════
//  PROFILE PAGE — PREMIUM COMPLEX DESIGN · WHITE BLUE 3D
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'change_password_page.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE — WHITE BLUE 3D
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const cardInner = Color(0xFFF0F7FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);
  static const blue      = Color(0xFF3B82F6);
  static const blueSoft  = Color(0xFFEFF6FF);

  static const green     = Color(0xFF10B981);
  static const greenSoft = Color(0xFFECFDF5);
  static const amber     = Color(0xFFF59E0B);
  static const amberSoft = Color(0xFFFFFBEB);
  static const red       = Color(0xFFEF4444);
  static const redSoft   = Color(0xFFFFF1F2);
  static const purple    = Color(0xFF8B5CF6);
  static const purpleSoft= Color(0xFFF5F3FF);
  static const pink      = Color(0xFFEC4899);
  static const pinkSoft  = Color(0xFFFCE7F3);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
  static const white     = Color(0xFFFFFFFF);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _sh3 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.08), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.14), blurRadius: 32, offset: const Offset(0, 16)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 48, offset: const Offset(0, 24)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

// ═══════════════════════════════════════════════════════════════════════════
//  PROFILE PAGE
// ═══════════════════════════════════════════════════════════════════════════
class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..forward();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _loadProfileImage();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return 'N/A';
    if (isPassword) return '••••••••';
    if (text.length <= 2) return '${text.substring(0, 1)}••';
    return '${text.substring(0, 2)}${'•' * (text.length - 2)}';
  }

  String _getRoleBadge(String role) {
    switch (role.toLowerCase()) {
      case 'owner': return 'OWNER';
      case 'admin': return 'ADMIN';
      case 'pemula': return 'PEMULA';
      case 'reseller': return 'RESELLER';
      case 'vip': return 'VIP';
      default: return role.toUpperCase();
    }
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner': return _C.amber;
      case 'admin': return _C.red;
      case 'pemula': return _C.ice2;
      case 'reseller': return _C.green;
      case 'vip': return _C.purple;
      default: return _C.ice2;
    }
  }

  IconData _getRoleIcon(String role) {
    switch (role.toLowerCase()) {
      case 'owner': return Icons.workspace_premium_rounded;
      case 'admin': return Icons.admin_panel_settings_rounded;
      case 'pemula': return Icons.school_rounded;
      case 'reseller': return Icons.storefront_rounded;
      case 'vip': return Icons.star_rounded;
      default: return Icons.person_rounded;
    }
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.all(20),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: _C.borderMid,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              const Text('UBAH FOTO PROFIL',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.5)),
              const SizedBox(height: 20),
              _bottomSheetItem(
                icon: Icons.camera_alt_rounded,
                label: 'Kamera',
                subtitle: 'Ambil foto baru',
                color: _C.ice2,
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              const SizedBox(height: 10),
              _bottomSheetItem(
                icon: Icons.photo_library_rounded,
                label: 'Galeri',
                subtitle: 'Pilih dari galeri',
                color: _C.purple,
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              if (_profileImage != null) ...[
                const SizedBox(height: 10),
                _bottomSheetItem(
                  icon: Icons.delete_outline_rounded,
                  label: 'Hapus Foto',
                  subtitle: 'Kembali ke default',
                  color: _C.red,
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('profile_image_${widget.username}');
                    setState(() => _profileImage = null);
                  },
                ),
              ],
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomSheetItem({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _C.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: Row(
          children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: color.withOpacity(0.15),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          color: _C.text,
                          fontWeight: FontWeight.w700,
                          fontSize: 13)),
                  Text(subtitle,
                      style: const TextStyle(
                          color: _C.textDim, fontSize: 11)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                color: _C.textDim, size: 12),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() => _profileImage = imageFile);
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  void _copySessionKey() {
    Clipboard.setData(ClipboardData(text: widget.sessionKey));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(children: [
          Icon(Icons.check_circle_rounded, color: Colors.white, size: 16),
          SizedBox(width: 8),
          Text('Session key di-copy'),
        ]),
        backgroundColor: _C.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Background
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              color: Colors.white.withOpacity(0.85),
            ),
          ),

          // Content
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(
                  parent: _entryCtrl, curve: Curves.easeOut),
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    _buildAppBar(),
                    const SizedBox(height: 12),
                    _buildHeroBanner(),
                    const SizedBox(height: 16),
                    _buildProfileStats(),
                    const SizedBox(height: 16),
                    _buildInfoGrid(),
                    const SizedBox(height: 16),
                    _buildSessionKeyCard(),
                    const SizedBox(height: 16),
                    _buildAchievementCard(),
                    const SizedBox(height: 16),
                    _buildSecurityCard(),
                    const SizedBox(height: 16),
                    _buildQuickActions(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── APP BAR ─────────────────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: _C.text, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('PROFILE',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 17,
                        letterSpacing: 2)),
                Text('Akun & keamanan',
                    style: TextStyle(
                        color: _C.textDim,
                        fontSize: 11,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChangePasswordPage(
                    username: widget.username,
                    sessionKey: widget.sessionKey,
                  ),
                ),
              );
            },
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [_C.ice, _C.ice2, _C.ice3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: _shPrimary,
              ),
              child: const Icon(Icons.lock_reset_rounded,
                  color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO BANNER (Background gradient + avatar floating) ─────────────────
  Widget _buildHeroBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          boxShadow: _sh3,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // Gradient banner
              Container(
                height: 180,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.ice, _C.ice2, _C.ice3],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    // Decorative circles
                    Positioned(
                      top: -40, right: -40,
                      child: Container(
                        width: 160, height: 160,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.08),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 20, right: 40,
                      child: Container(
                        width: 80, height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: -30, left: -20,
                      child: Container(
                        width: 120, height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                    ),
                    // Role badge top left
                    Positioned(
                      top: 16, left: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.35)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(_getRoleIcon(widget.role),
                                color: Colors.white, size: 14),
                            const SizedBox(width: 6),
                            Text(_getRoleBadge(widget.role),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1)),
                          ],
                        ),
                      ),
                    ),
                    // Top right online status
                    Positioned(
                      top: 16, right: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.35)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 8, height: 8,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _C.green,
                                boxShadow: [
                                  BoxShadow(
                                    color: _C.green.withOpacity(0.6),
                                    blurRadius: 6,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Text('ONLINE',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Avatar floating
              Positioned(
                bottom: -40,
                left: 0, right: 0,
                child: Center(
                  child: GestureDetector(
                    onTap: _showImageSourceDialog,
                    child: Stack(
                      children: [
                        Container(
                          width: 100, height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [_C.ice, _C.ice2, _C.ice3],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            border: Border.all(color: Colors.white, width: 4),
                            boxShadow: _shPrimary,
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Container(
                                    color: _C.iceSoft,
                                    child: const Icon(
                                      FontAwesomeIcons.userAstronaut,
                                      size: 40,
                                      color: _C.ice3,
                                    ),
                                  ),
                          ),
                        ),
                        Positioned(
                          bottom: 0, right: 0,
                          child: Container(
                            width: 32, height: 32,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                colors: [_C.ice, _C.ice2],
                              ),
                              border: Border.all(color: Colors.white, width: 3),
                              boxShadow: _sh1,
                            ),
                            child: const Icon(Icons.camera_alt_rounded,
                                color: Colors.white, size: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── PROFILE STATS (Username card below avatar) ──────────────────────────
  Widget _buildProfileStats() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 50, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border),
          boxShadow: _sh2,
        ),
        child: Column(
          children: [
            Text(widget.username,
                style: const TextStyle(
                    color: _C.text,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1)),
            const SizedBox(height: 6),
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _getRoleColor(widget.role),
                      _getRoleColor(widget.role).withOpacity(0.7),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: _getRoleColor(widget.role)
                          .withOpacity(_pulseAnim.value * 0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_getRoleIcon(widget.role),
                        color: Colors.white, size: 12),
                    const SizedBox(width: 5),
                    Text(_getRoleBadge(widget.role),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.5)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Stats row
            Row(
              children: [
                _statItem(
                    icon: Icons.shield_rounded,
                    value: 'ACTIVE',
                    label: 'Status',
                    color: _C.green),
                _statDivider(),
                _statItem(
                    icon: Icons.verified_user_rounded,
                    value: widget.role.toUpperCase(),
                    label: 'Role',
                    color: _C.ice2),
                _statDivider(),
                _statItem(
                    icon: Icons.calendar_month_rounded,
                    value: widget.expiredDate.length > 10
                        ? widget.expiredDate.substring(0, 10)
                        : widget.expiredDate,
                    label: 'Expired',
                    color: _C.ice3),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.4), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.20),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: _C.text,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontFamily: 'Orbitron'),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: _C.textDim,
                  fontWeight: FontWeight.w600,
                  fontSize: 9)),
        ],
      ),
    );
  }

  Widget _statDivider() => Container(width: 1, height: 50, color: _C.border);

  // ─── INFO GRID (Detail akun) ─────────────────────────────────────────────
  Widget _buildInfoGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionLabel('INFORMASI AKUN', Icons.info_outline_rounded),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _infoCard(
                  icon: Icons.person_rounded,
                  label: 'USERNAME',
                  value: widget.username,
                  color: _C.ice2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _infoCard(
                  icon: Icons.lock_rounded,
                  label: 'PASSWORD',
                  value: _censorText(widget.password, isPassword: true),
                  color: _C.red,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _infoCard(
                  icon: Icons.verified_user_rounded,
                  label: 'ROLE',
                  value: widget.role.toUpperCase(),
                  color: _getRoleColor(widget.role),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _infoCard(
                  icon: Icons.calendar_today_rounded,
                  label: 'EXPIRED',
                  value: widget.expiredDate,
                  color: _C.ice3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(colors: [_C.ice, _C.ice2]),
            boxShadow: _sh1,
          ),
          child: Icon(icon, color: Colors.white, size: 16),
        ),
        const SizedBox(width: 10),
        Text(text,
            style: const TextStyle(
                color: _C.text,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 12,
                letterSpacing: 1.2)),
      ],
    );
  }

  Widget _infoCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
        boxShadow: _sh1,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.35)),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 10),
          Text(label,
              style: const TextStyle(
                  color: _C.textDim,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  color: _C.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  // ─── SESSION KEY CARD ────────────────────────────────────────────────────
  Widget _buildSessionKeyCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
          boxShadow: _sh2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(colors: [_C.ice, _C.ice2]),
                    boxShadow: _sh1,
                  ),
                  child: const Icon(Icons.vpn_key_rounded,
                      color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                const Text('SESSION KEY',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2)),
                const Spacer(),
                GestureDetector(
                  onTap: _copySessionKey,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: _C.iceSoft,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: _C.ice.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.copy_rounded,
                            color: _C.ice3, size: 12),
                        SizedBox(width: 4),
                        Text('COPY',
                            style: TextStyle(
                                color: _C.ice3,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.cardAlt,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
              ),
              child: SelectableText(
                widget.sessionKey,
                style: const TextStyle(
                  color: _C.ice3,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.5,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.warning_amber_rounded,
                    color: _C.amber, size: 12),
                const SizedBox(width: 6),
                const Expanded(
                  child: Text(
                    'Jangan bagikan session key ke siapapun',
                    style: TextStyle(
                        color: _C.amber,
                        fontSize: 10,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── ACHIEVEMENT CARD ────────────────────────────────────────────────────
  Widget _buildAchievementCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.iceSoft, _C.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.ice.withOpacity(0.3)),
          boxShadow: _sh2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(
                        colors: [_C.amber, Color(0xFFD97706)]),
                    boxShadow: _sh1,
                  ),
                  child: const Icon(Icons.emoji_events_rounded,
                      color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                const Text('ACHIEVEMENT',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.amber.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.amber.withOpacity(0.4)),
                  ),
                  child: const Text('3/10',
                      style: TextStyle(
                          color: _C.amber,
                          fontSize: 10,
                          fontWeight: FontWeight.w800)),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _achievementBadge(
                    icon: Icons.security_rounded,
                    label: 'Secure',
                    color: _C.green,
                    unlocked: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _achievementBadge(
                    icon: Icons.bolt_rounded,
                    label: 'Active',
                    color: _C.ice2,
                    unlocked: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _achievementBadge(
                    icon: Icons.verified_rounded,
                    label: 'Verified',
                    color: _C.purple,
                    unlocked: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _achievementBadge(
                    icon: Icons.lock_rounded,
                    label: 'Locked',
                    color: _C.textDim,
                    unlocked: false,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _achievementBadge({
    required IconData icon,
    required String label,
    required Color color,
    required bool unlocked,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: unlocked ? color.withOpacity(0.10) : _C.cardAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: unlocked ? color.withOpacity(0.4) : _C.border),
        boxShadow: unlocked
            ? [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ]
            : null,
      ),
      child: Column(
        children: [
          Icon(icon,
              color: unlocked ? color : _C.textDim, size: 18),
          const SizedBox(height: 4),
          Text(label,
              style: TextStyle(
                  color: unlocked ? color : _C.textDim,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.3),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  // ─── SECURITY CARD ───────────────────────────────────────────────────────
  Widget _buildSecurityCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
          boxShadow: _sh2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: const LinearGradient(
                        colors: [_C.red, Color(0xFFDC2626)]),
                    boxShadow: _sh1,
                  ),
                  child: const Icon(Icons.security_rounded,
                      color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                const Text('KEAMANAN',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2)),
              ],
            ),
            const SizedBox(height: 14),
            _securityItem(
              icon: Icons.lock_rounded,
              title: 'Password',
              subtitle: 'Ubah password secara berkala',
              status: 'AMAN',
              statusColor: _C.green,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            _securityItem(
              icon: Icons.fingerprint_rounded,
              title: 'Two-Factor Auth',
              subtitle: 'Belum diaktifkan',
              status: 'OFF',
              statusColor: _C.amber,
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Fitur 2FA segera hadir'),
                    backgroundColor: _C.ice2,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            _securityItem(
              icon: Icons.devices_rounded,
              title: 'Perangkat Terhubung',
              subtitle: '1 perangkat aktif',
              status: '1',
              statusColor: _C.ice2,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }

  Widget _securityItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required String status,
    required Color statusColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _C.cardAlt,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _C.iceSoft,
                border: Border.all(color: _C.ice.withOpacity(0.3)),
              ),
              child: Icon(icon, color: _C.ice2, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          color: _C.text,
                          fontWeight: FontWeight.w700,
                          fontSize: 12)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: const TextStyle(
                          color: _C.textDim, fontSize: 10)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: statusColor.withOpacity(0.4)),
              ),
              child: Text(status,
                  style: TextStyle(
                      color: statusColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5)),
            ),
          ],
        ),
      ),
    );
  }

  // ─── QUICK ACTIONS ───────────────────────────────────────────────────────
  Widget _buildQuickActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionLabel('QUICK ACTIONS', Icons.bolt_rounded),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _quickAction(
                  icon: Icons.lock_reset_rounded,
                  label: 'Ganti Password',
                  color: _C.ice2,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: widget.username,
                          sessionKey: widget.sessionKey,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _quickAction(
                  icon: Icons.copy_rounded,
                  label: 'Copy Key',
                  color: _C.purple,
                  onTap: _copySessionKey,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _quickAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: Column(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.12),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 10),
            Text(label,
                style: const TextStyle(
                    color: _C.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 11),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}