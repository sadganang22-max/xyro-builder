// lib/music_player_service.dart
import 'package:just_audio/just_audio.dart';

class MusicPlayerService {
  // Singleton biar musik gak mati pas pindah halaman
  static final MusicPlayerService _instance = MusicPlayerService._internal();
  factory MusicPlayerService() => _instance;
  MusicPlayerService._internal();

  final AudioPlayer _player = AudioPlayer();
  bool _isPlaying = false;

  bool get isPlaying => _isPlaying;

  Future<void> play() async {
    if (_isPlaying) return;
    try {
      // ✅ BENERIN DI SINI: Panggil file dari assets
      await _player.setAsset('assets/music/music.mp3');
      
      // Set biar muter terus (loop)
      await _player.setLoopMode(LoopMode.one);
      
      // ✅ NYALAKIN SUARA (Default just_audio volume 1.0)
      await _player.setVolume(1.0); 
      
      // Play!
      _player.play();
      _isPlaying = true;
    } catch (e) {
      print("Gagal muter musik: $e");
    }
  }

  Future<void> stop() async {
    await _player.stop();
    _isPlaying = false;
  }

  Future<void> pause() async {
    await _player.pause();
    _isPlaying = false;
  }

  Future<void> resume() async {
    if (_isPlaying) return;
    _player.play();
    _isPlaying = true;
  }
}