// ═══════════════════════════════════════════════════════════════════════════
//  ACC PAGE — WHITE BLUE 3D · Tampilkan Foto Bukti
//  FIX: force non-null String di closure (imageUrl!)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const amberSoft = Color(0xFFFFFBEB);
  static const red       = Color(0xFFEF4444);
  static const redSoft   = Color(0xFFFFF1F2);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class AccPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const AccPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<AccPage> createState() => _AccPageState();
}

class _AccPageState extends State<AccPage> {
  int _pageIndex = 0;

  List<Map<String, dynamic>> _pendingList = [];
  List<Map<String, dynamic>> _historyList = [];
  List<Map<String, dynamic>> _filteredPending = [];
  bool _loading = true;
  String? _error;
  String _searchQuery = '';

  final TextEditingController _searchCtrl = TextEditingController();
  Timer? _autoRefreshTimer;

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(() {
      setState(() {
        _searchQuery = _searchCtrl.text.toLowerCase();
        _applyFilter();
      });
    });
    _loadPending();
    _loadHistory();
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _loadPending();
        _loadHistory();
      }
    });
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      _filteredPending = List.from(_pendingList);
    } else {
      _filteredPending = _pendingList.where((u) {
        final name = (u['username'] ?? '').toString().toLowerCase();
        return name.contains(_searchQuery);
      }).toList();
    }
  }

  Future<void> _loadPending() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final url = Uri.parse('$baseUrl/pemula/pending?key=${widget.sessionKey}');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        if (!mounted) return;
        setState(() {
          _pendingList = List<Map<String, dynamic>>.from(data['pending'] ?? []);
          _loading = false;
        });
        _applyFilter();
      } else {
        if (!mounted) return;
        setState(() {
          _error = data['message'] ?? 'Gagal load pending';
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Koneksi error: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadHistory() async {
    try {
      final url = Uri.parse('$baseUrl/pemula/history?key=${widget.sessionKey}');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _historyList = List<Map<String, dynamic>>.from(data['history'] ?? []);
        });
      }
    } catch (_) {}
  }

  Future<void> _accUser(String username) async {
    HapticFeedback.mediumImpact();
    final ok = await _showConfirm(
      title: 'SETUJUI AKSES',
      subtitle: 'Setujui akun "$username"?',
      confirmLabel: 'SETUJUI',
      confirmColor: _C.green,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse('$baseUrl/pemula/acc?key=${widget.sessionKey}&username=$username');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('AKUN $username BERHASIL DISETUJUI', _C.green);
        _loadPending();
        _loadHistory();
      } else {
        _snack(data['message'] ?? 'Gagal menyetujui', _C.red);
      }
    } catch (e) {
      _snack('Error: $e', _C.red);
    }
  }

  Future<void> _rejectUser(String username) async {
    HapticFeedback.mediumImpact();
    final ok = await _showConfirm(
      title: 'TOLAK AKUN',
      subtitle: 'Hapus akun "$username" dari daftar?',
      confirmLabel: 'TOLAK',
      confirmColor: _C.red,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse('$baseUrl/pemula/reject?key=${widget.sessionKey}&username=$username');
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('AKUN $username DITOLAK', _C.red);
        _loadPending();
        _loadHistory();
      } else {
        _snack(data['message'] ?? 'Gagal menolak', _C.red);
      }
    } catch (e) {
      _snack('Error: $e', _C.red);
    }
  }

  Future<bool?> _showConfirm({
    required String title,
    required String subtitle,
    required String confirmLabel,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.border, width: 1.5),
            boxShadow: _sh2,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: confirmColor.withOpacity(0.12),
                  border: Border.all(
                      color: confirmColor.withOpacity(0.4), width: 2),
                ),
                child: Icon(
                  confirmColor == _C.green
                      ? Icons.check_circle_rounded
                      : Icons.cancel_rounded,
                  color: confirmColor,
                  size: 32,
                ),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: TextStyle(
                      color: confirmColor,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Text(subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _C.textSub,
                      fontSize: 12,
                      height: 1.4)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx, false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _C.cardAlt,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _C.borderMid),
                        ),
                        child: const Center(
                          child: Text('BATAL',
                              style: TextStyle(
                                  color: _C.textSub,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12,
                                  letterSpacing: 1)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx, true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [confirmColor, confirmColor.withOpacity(0.75)]),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: confirmColor.withOpacity(0.4),
                                blurRadius: 12,
                                offset: const Offset(0, 4)),
                          ],
                        ),
                        child: Center(
                          child: Text(confirmLabel,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 12,
                                  letterSpacing: 1.5)),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _C.surface,
        content: Row(children: [
          Icon(
            color == _C.green ? Icons.check_circle_outline : Icons.error_outline,
            color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
              child: Text(msg,
                  style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: color))),
        ]),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _C.border, width: 1.5),
        ),
        duration: const Duration(seconds: 2),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showFullImage(String imageUrl) {
    showDialog(
      context: context,
      barrierColor: Colors.black87,
      builder: (ctx) => GestureDetector(
        onTap: () => Navigator.pop(ctx),
        child: Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(12),
          child: Stack(
            children: [
              Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(ctx).size.height * 0.85,
                  maxWidth: MediaQuery.of(ctx).size.width - 24,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: _sh2,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: InteractiveViewer(
                    minScale: 1.0,
                    maxScale: 4.0,
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Container(
                        padding: const EdgeInsets.all(40),
                        color: _C.surface,
                        child: const Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.broken_image_rounded,
                                color: _C.textDim, size: 48),
                            SizedBox(height: 12),
                            Text('Gagal load gambar',
                                style: TextStyle(color: _C.textSub)),
                          ],
                        ),
                      ),
                      loadingBuilder: (_, child, progress) {
                        if (progress == null) return child;
                        return Container(
                          padding: const EdgeInsets.all(40),
                          color: _C.surface,
                          child: const Center(
                            child: CircularProgressIndicator(
                                color: _C.ice2, strokeWidth: 2),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10, right: 10,
                child: GestureDetector(
                  onTap: () => Navigator.pop(ctx),
                  child: Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.6),
                      border: Border.all(color: Colors.white.withOpacity(0.4)),
                    ),
                    child: const Icon(Icons.close_rounded,
                        color: Colors.white, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildAppBar(),
            _buildPageSwitcher(),
            if (_pageIndex == 0) _buildSearchBar(),
            Expanded(
              child: _pageIndex == 0
                  ? _buildPendingPage()
                  : _buildHistoryPage(),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: _C.text, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('ACCESS CONTROL',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        letterSpacing: 1.5)),
                Text('Setujui akun pemula',
                    style: TextStyle(
                        color: _C.textDim,
                        fontSize: 11,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              _loadPending();
              _loadHistory();
            },
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [_C.ice, _C.ice2, _C.ice3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: _shPrimary,
              ),
              child: const Icon(Icons.refresh_rounded,
                  color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageSwitcher() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(children: [
        Expanded(child: _pageBtn(0, 'PENDING', _pendingList.length, _C.amber)),
        const SizedBox(width: 10),
        Expanded(child: _pageBtn(1, 'HISTORY', _historyList.length, _C.green)),
      ]),
    );
  }

  Widget _pageBtn(int index, String label, int count, Color color) {
    final active = _pageIndex == index;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _pageIndex = index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(colors: [color, color.withOpacity(0.75)])
              : null,
          color: active ? null : _C.surface,
          border: Border.all(
              color: active ? color : _C.border, width: 1.5),
          borderRadius: BorderRadius.circular(14),
          boxShadow: active
              ? [
                  BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 14,
                      offset: const Offset(0, 4)),
                ]
              : _sh1,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label,
                style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: active ? Colors.white : color,
                    letterSpacing: 1.5)),
            if (count > 0) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: active ? Colors.white.withOpacity(0.3) : color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text('$count',
                    style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        color: active ? Colors.white : color)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(
              color: _C.text, fontSize: 13, fontWeight: FontWeight.w600),
          decoration: InputDecoration(
            hintText: 'Cari username...',
            hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
            prefixIcon: const Icon(Icons.search_rounded,
                color: _C.ice2, size: 20),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.close_rounded,
                        color: _C.textDim, size: 18),
                    onPressed: () => _searchCtrl.clear(),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 14),
          ),
        ),
      ),
    );
  }

  Widget _buildPendingPage() {
    if (_loading) return _buildLoader();
    if (_error != null) return _buildError();
    if (_filteredPending.isEmpty) {
      return _emptyState('TIDAK ADA PENGAJUAN', Icons.shield_outlined);
    }

    return RefreshIndicator(
      onRefresh: _loadPending,
      color: _C.ice2,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: _filteredPending.length,
        itemBuilder: (ctx, i) => _buildPendingCard(_filteredPending[i]),
      ),
    );
  }

  Widget _buildPendingCard(Map<String, dynamic> user) {
    final username = user['username']?.toString() ?? '-';
    final role = user['role']?.toString() ?? 'member';
    final expired = user['expiredDate']?.toString() ?? '-';
    final createdBy = user['createdBy']?.toString() ?? 'unknown';

    // Build image URL — PAKAI NON-NULLABLE
    final String rawImage = user['image']?.toString()
        ?? user['bukti']?.toString()
        ?? user['photo']?.toString()
        ?? user['imageUrl']?.toString()
        ?? user['buktiFoto']?.toString()
        ?? '';

    final String imageUrl = rawImage.isEmpty
        ? ''
        : (rawImage.startsWith('http')
            ? rawImage
            : '$baseUrl${rawImage.startsWith('/') ? rawImage : '/$rawImage'}');

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.surface,
        border: Border.all(color: _C.border),
        borderRadius: BorderRadius.circular(18),
        boxShadow: _sh2,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.amber, Color(0xFFD97706)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: _C.amber.withOpacity(0.4),
                      blurRadius: 10,
                      offset: const Offset(0, 3)),
                ],
              ),
              child: Center(
                child: Text(
                  username.isNotEmpty ? username[0].toUpperCase() : '?',
                  style: const TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Colors.white),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username,
                      style: const TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: _C.text)),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: _C.iceSoft,
                      borderRadius: BorderRadius.circular(8),
                      border:
                          Border.all(color: _C.ice.withOpacity(0.4)),
                    ),
                    child: Text('ROLE: ${role.toUpperCase()}',
                        style: const TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            color: _C.ice3,
                            letterSpacing: 0.5)),
                  ),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 14),

          _infoRow(Icons.calendar_month_rounded, 'EXPIRED', expired),
          const SizedBox(height: 6),
          _infoRow(Icons.person_rounded, 'CREATED BY', createdBy),
          const SizedBox(height: 14),

          // FOTO BUKTI — pakai `imageUrl` (String non-null, kosong kalau gak ada)
          if (imageUrl.isNotEmpty) ...[
            const Text('BUKTI FOTO',
                style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: _C.text,
                    letterSpacing: 1.2)),
            const SizedBox(height: 8),
            GestureDetector(
              // imageUrl sudah non-null String, jadi aman
              onTap: () => _showFullImage(imageUrl),
              child: Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: _C.cardAlt,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _C.border, width: 1.5),
                  boxShadow: _sh1,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        imageUrl,
                        fit: BoxFit.cover,
                        loadingBuilder: (_, child, progress) {
                          if (progress == null) return child;
                          return const Center(
                            child: SizedBox(
                              width: 24, height: 24,
                              child: CircularProgressIndicator(
                                  color: _C.ice2, strokeWidth: 2),
                            ),
                          );
                        },
                        errorBuilder: (_, __, ___) => Container(
                          color: _C.cardAlt,
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.broken_image_rounded,
                                  color: _C.textDim, size: 40),
                              SizedBox(height: 8),
                              Text('Gagal load foto',
                                  style: TextStyle(
                                      color: _C.textDim, fontSize: 11)),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 8, right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.3)),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.zoom_in_rounded,
                                  color: Colors.white, size: 12),
                              SizedBox(width: 4),
                              Text('TAP LIHAT',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.5)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
          ] else
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _C.amberSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.amber.withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: _C.amber, size: 16),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text('Tidak ada bukti foto',
                        style: TextStyle(
                            color: _C.amber,
                            fontSize: 11,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 14),
          Row(children: [
            Expanded(
                child: _actionBtn('TOLAK', _C.red,
                    () => _rejectUser(username))),
            const SizedBox(width: 10),
            Expanded(
                child: _actionBtn('SETUJUI', _C.green,
                    () => _accUser(username))),
          ]),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 14, color: _C.textDim),
        const SizedBox(width: 8),
        Text('$label: ',
            style: const TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: _C.textDim,
                letterSpacing: 0.5)),
        Expanded(
          child: Text(value,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: _C.text),
              overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  Widget _actionBtn(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [color, color.withOpacity(0.75)]),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Center(
            child: Text(label,
                style: const TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5))),
      ),
    );
  }

  Widget _buildHistoryPage() {
    if (_historyList.isEmpty) {
      return _emptyState('BELUM ADA RIWAYAT', Icons.history_rounded);
    }

    return RefreshIndicator(
      onRefresh: _loadHistory,
      color: _C.ice2,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: _historyList.length,
        itemBuilder: (ctx, i) {
          final item = _historyList[i];
          final isAcc = item['action'] == 'acc';

          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.surface,
              border: Border.all(color: _C.border),
              borderRadius: BorderRadius.circular(14),
              boxShadow: _sh1,
            ),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (isAcc ? _C.green : _C.red).withOpacity(0.12),
                  border: Border.all(
                      color: (isAcc ? _C.green : _C.red).withOpacity(0.4)),
                ),
                child: Icon(
                    isAcc ? Icons.check_circle_rounded : Icons.cancel_rounded,
                    color: isAcc ? _C.green : _C.red,
                    size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['username']?.toString() ?? '-',
                        style: const TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: _C.text)),
                    const SizedBox(height: 3),
                    Text(isAcc ? 'DISETUJUI' : 'DITOLAK',
                        style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: isAcc ? _C.green : _C.red,
                            letterSpacing: 0.5)),
                  ],
                ),
              ),
            ]),
          );
        },
      ),
    );
  }

  Widget _buildLoader() => const Center(
        child: CircularProgressIndicator(color: _C.ice2, strokeWidth: 2),
      );

  Widget _buildError() => Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.redSoft,
              border: Border.all(color: _C.red.withOpacity(0.4), width: 2),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: _C.red, size: 40),
          ),
          const SizedBox(height: 16),
          Text(_error ?? 'Unknown error',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: _C.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 13)),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: _loadPending,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [_C.ice, _C.ice2, _C.ice3]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: _shPrimary,
              ),
              child: const Text('COBA LAGI',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                      letterSpacing: 1.5)),
            ),
          ),
        ]),
      );

  Widget _emptyState(String title, IconData icon) => Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 100, height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.iceSoft,
              border: Border.all(
                  color: _C.ice.withOpacity(0.4), width: 2),
            ),
            child: Icon(icon, color: _C.ice2, size: 48),
          ),
          const SizedBox(height: 16),
          Text(title,
              style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: _C.text,
                  letterSpacing: 1.5)),
        ]),
      );
}