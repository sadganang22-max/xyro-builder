// ═══════════════════════════════════════════════════════════════════════════
//  MUSIC PAGE — PREMIUM 3D VINYL PLAYER (AUTO-PLAY + LANJUTKAN)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'music_player_service.dart';

// ── PALETTE PUTIH-BIRU 3D ──
const Color kBg = Color(0xFFEEF3F9);
const Color kCard = Color(0xFFFFFFFF);
const Color kCardAlt = Color(0xFFF5F9FF);
const Color kBorder = Color(0xFFD6E2F0);
const Color kIce = Color(0xFF38BDF8);
const Color kIce2 = Color(0xFF0EA5E9);
const Color kIce3 = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);
const Color kText = Color(0xFF0A2540);
const Color kTextSub = Color(0xFF4A6582);

class MusicPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const MusicPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  late AnimationController _rotateCtrl;
  late AnimationController _tonearmCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _marqueeCtrl;
  late AnimationController _fadeCtrl;

  bool _isPlaying = false;
  final _musicService = MusicPlayerService();

  @override
  void initState() {
    super.initState();

    _rotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _tonearmCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _marqueeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // AUTO START setelah frame pertama
    WidgetsBinding.instance.addPostFrameCallback((_) => _autoStart());
  }

  Future<void> _autoStart() async {
    // Fade-in teks LANJUTKAN
    _fadeCtrl.forward();

    // Mulai animasi vinyl
    setState(() => _isPlaying = true);
    _rotateCtrl.repeat();
    _tonearmCtrl.forward();

    // Putar musik
    try {
      await _musicService.play();
    } catch (_) {}

    // Delay sebelum pindah ke dashboard
    await Future.delayed(const Duration(milliseconds: 3500));
    if (mounted) _goToDashboard();
  }

  void _goToDashboard() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _rotateCtrl.dispose();
    _tonearmCtrl.dispose();
    _pulseCtrl.dispose();
    _marqueeCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          // ─── 1. BACKGROUND GRID & GLOW ───
          Positioned.fill(
            child: CustomPaint(painter: _GridPainter()),
          ),
          Positioned(
            top: -100, right: -100,
            child: AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (_, __) => Container(
                width: 300, height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      kIce.withOpacity(0.15 + _pulseCtrl.value * 0.05),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ─── 2. MAIN CONTENT ───
          SafeArea(
            child: Column(
              children: [
                // APP BAR MINIMALIS
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: kCard,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: kBorder),
                          boxShadow: [BoxShadow(color: kText.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))],
                        ),
                        child: Row(
                          children: [
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: kIce2, shape: BoxShape.circle)),
                            const SizedBox(width: 8),
                            const Text('XYRO AUDIO', style: TextStyle(color: kText, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                          ],
                        ),
                      ),
                      Icon(Icons.more_horiz_rounded, color: kTextSub),
                    ],
                  ),
                ),

                const Spacer(),

                // ─── 3. AREA VINYL & TONEARM ───
                SizedBox(
                  height: 340,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // A. PIRINGAN VINYL
                      AnimatedBuilder(
                        animation: _rotateCtrl,
                        builder: (context, child) {
                          return Transform.rotate(
                            angle: _rotateCtrl.value * 2 * math.pi,
                            child: child,
                          );
                        },
                        child: Container(
                          width: 280, height: 280,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: kCard,
                            boxShadow: [
                              BoxShadow(color: kText.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10)),
                              BoxShadow(color: kIce.withOpacity(0.2), blurRadius: 40, spreadRadius: 10),
                            ],
                            border: Border.all(color: kBorder, width: 8),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              ...List.generate(4, (i) => Container(
                                width: 240 - (i * 25), height: 240 - (i * 25),
                                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: kCardAlt, width: 2)),
                              )),
                              Container(
                                width: 120, height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(colors: [kIce, kIce2, kIce3], begin: Alignment.topLeft, end: Alignment.bottomRight),
                                  border: Border.all(color: Colors.white, width: 4),
                                  boxShadow: [BoxShadow(color: kIce2.withOpacity(0.5), blurRadius: 15)],
                                ),
                                child: Center(
                                  child: ClipOval(
                                    child: Image.asset('assets/images/logo.png', width: 80, height: 80, fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const Icon(Icons.music_note_rounded, color: Colors.white, size: 40)),
                                  ),
                                ),
                              ),
                              Container(width: 16, height: 16, decoration: const BoxDecoration(shape: BoxShape.circle, color: kBg)),
                            ],
                          ),
                        ),
                      ),

                      // B. TONEARM
                      Positioned(
                        top: 10, right: 30,
                        child: AnimatedBuilder(
                          animation: _tonearmCtrl,
                          builder: (context, child) {
                            return Transform.rotate(
                              angle: -0.4 + (_tonearmCtrl.value * 0.4),
                              alignment: Alignment.topCenter,
                              child: child,
                            );
                          },
                          child: SizedBox(
                            width: 60, height: 180,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                Container(
                                  width: 40, height: 40,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle, color: kCard,
                                    border: Border.all(color: kBorder, width: 4),
                                    boxShadow: [BoxShadow(color: kText.withOpacity(0.1), blurRadius: 8)],
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(top: 20),
                                  width: 8, height: 140,
                                  decoration: BoxDecoration(
                                    color: kCard,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: kBorder, width: 2),
                                  ),
                                ),
                                Positioned(
                                  bottom: 0,
                                  child: Container(
                                    width: 24, height: 40,
                                    decoration: BoxDecoration(
                                      color: kIce2,
                                      borderRadius: BorderRadius.circular(8),
                                      boxShadow: [BoxShadow(color: kIce2.withOpacity(0.5), blurRadius: 10)],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // ─── 4. NOW PLAYING INFO & EQUALIZER ───
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: List.generate(12, (index) {
                          return AnimatedBuilder(
                            animation: _pulseCtrl,
                            builder: (context, child) {
                              final h = _isPlaying
                                  ? 10.0 + (math.sin(_pulseCtrl.value * math.pi * 2 + index) * 15)
                                  : 4.0;
                              return Container(
                                width: 4,
                                height: h.clamp(4.0, 30.0),
                                margin: const EdgeInsets.symmetric(horizontal: 2),
                                decoration: BoxDecoration(
                                  color: _isPlaying ? kIce2 : kBorder,
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              );
                            },
                          );
                        }),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: 200,
                        child: ClipRect(
                          child: AnimatedBuilder(
                            animation: _marqueeCtrl,
                            builder: (context, child) {
                              return FractionalTranslation(
                                translation: Offset(_isPlaying ? -(_marqueeCtrl.value * 2 - 1) : 0, 0),
                                child: child,
                              );
                            },
                            child: const Text(
                              'XYRO ENGINE — BACKGROUND MUSIC THEME',
                              maxLines: 1,
                              softWrap: false,
                              style: TextStyle(color: kText, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 2),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text('Xerion App • System Audio', style: TextStyle(color: kTextSub, fontSize: 11)),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // ─── 5. TEKS "LANJUTKAN" (auto fade-in) ───
                Padding(
                  padding: const EdgeInsets.only(bottom: 60),
                  child: FadeTransition(
                    opacity: _fadeCtrl,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text(
                          'LANJUTKAN',
                          style: TextStyle(
                            color: kIce2,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 4,
                          ),
                        ),
                        SizedBox(width: 10),
                        SizedBox(
                          width: 14, height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(kIce2),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PAINTER UNTUK BACKGROUND GRID ───
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = kIce.withOpacity(0.05)..strokeWidth = 1;
    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}