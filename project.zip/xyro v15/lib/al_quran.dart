// ═══════════════════════════════════════════════════════════════════════════
//  AL-QURAN PAGE — PUTIH BIRU 3D (FIXED & RAPI)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);
  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceSoft   = Color(0xFFE0F2FE);
  static const red       = Color(0xFFEF4444);
  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

// ═══════════════════════════════════════════════════════════════════════════
//  MODELS
// ═══════════════════════════════════════════════════════════════════════════
class Ayat {
  final int nomor;
  final String arab;
  final String arti;
  const Ayat({required this.nomor, required this.arab, required this.arti});
}

class Surat {
  final int nomor;
  final String nama;
  final String latin;
  final List<Ayat> ayat;
  final int juz;
  const Surat({required this.nomor, required this.nama, required this.latin, required this.ayat, required this.juz});
}

class Juz {
  final int nomor;
  final List<Surat> suratList;
  final int suratMulai;
  final int suratAkhir;
  final int ayatMulai;
  final int ayatAkhir;
  const Juz({required this.nomor, required this.suratList, required this.suratMulai, required this.suratAkhir, required this.ayatMulai, required this.ayatAkhir});
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE
// ═══════════════════════════════════════════════════════════════════════════
class AlQuranPage extends StatefulWidget {
  const AlQuranPage({super.key});
  @override
  State<AlQuranPage> createState() => _AlQuranPageState();
}

class _AlQuranPageState extends State<AlQuranPage> with TickerProviderStateMixin {
  bool loading = true;
  List<Surat> allSuratList = [];
  List<Juz> juzList = [];
  List<Juz> filteredJuzList = [];
  final TextEditingController searchController = TextEditingController();
  bool showJuzList = true;
  Juz? selectedJuz;

  late AnimationController _pageController;
  late AnimationController _loadingController;
  late Animation<double> _fadeAnim;

  final List<Map<String, int>> juzBatas = [
    {'juz': 1, 'surat': 1, 'ayat': 1, 'suratAkhir': 2, 'ayatAkhir': 141},
    {'juz': 2, 'surat': 2, 'ayat': 142, 'suratAkhir': 2, 'ayatAkhir': 252},
    {'juz': 3, 'surat': 2, 'ayat': 253, 'suratAkhir': 3, 'ayatAkhir': 92},
    {'juz': 4, 'surat': 3, 'ayat': 93, 'suratAkhir': 4, 'ayatAkhir': 23},
    {'juz': 5, 'surat': 4, 'ayat': 24, 'suratAkhir': 4, 'ayatAkhir': 147},
    {'juz': 6, 'surat': 4, 'ayat': 148, 'suratAkhir': 5, 'ayatAkhir': 81},
    {'juz': 7, 'surat': 5, 'ayat': 82, 'suratAkhir': 6, 'ayatAkhir': 110},
    {'juz': 8, 'surat': 6, 'ayat': 111, 'suratAkhir': 7, 'ayatAkhir': 87},
    {'juz': 9, 'surat': 7, 'ayat': 88, 'suratAkhir': 8, 'ayatAkhir': 40},
    {'juz': 10, 'surat': 8, 'ayat': 41, 'suratAkhir': 9, 'ayatAkhir': 92},
    {'juz': 11, 'surat': 9, 'ayat': 93, 'suratAkhir': 11, 'ayatAkhir': 5},
    {'juz': 12, 'surat': 11, 'ayat': 6, 'suratAkhir': 12, 'ayatAkhir': 52},
    {'juz': 13, 'surat': 12, 'ayat': 53, 'suratAkhir': 14, 'ayatAkhir': 52},
    {'juz': 14, 'surat': 15, 'ayat': 1, 'suratAkhir': 16, 'ayatAkhir': 128},
    {'juz': 15, 'surat': 17, 'ayat': 1, 'suratAkhir': 18, 'ayatAkhir': 74},
    {'juz': 16, 'surat': 18, 'ayat': 75, 'suratAkhir': 20, 'ayatAkhir': 135},
    {'juz': 17, 'surat': 21, 'ayat': 1, 'suratAkhir': 22, 'ayatAkhir': 78},
    {'juz': 18, 'surat': 23, 'ayat': 1, 'suratAkhir': 25, 'ayatAkhir': 20},
    {'juz': 19, 'surat': 25, 'ayat': 21, 'suratAkhir': 27, 'ayatAkhir': 55},
    {'juz': 20, 'surat': 27, 'ayat': 56, 'suratAkhir': 29, 'ayatAkhir': 45},
    {'juz': 21, 'surat': 29, 'ayat': 46, 'suratAkhir': 33, 'ayatAkhir': 30},
    {'juz': 22, 'surat': 33, 'ayat': 31, 'suratAkhir': 36, 'ayatAkhir': 27},
    {'juz': 23, 'surat': 36, 'ayat': 28, 'suratAkhir': 39, 'ayatAkhir': 31},
    {'juz': 24, 'surat': 39, 'ayat': 32, 'suratAkhir': 41, 'ayatAkhir': 46},
    {'juz': 25, 'surat': 41, 'ayat': 47, 'suratAkhir': 45, 'ayatAkhir': 37},
    {'juz': 26, 'surat': 46, 'ayat': 1, 'suratAkhir': 51, 'ayatAkhir': 30},
    {'juz': 27, 'surat': 51, 'ayat': 31, 'suratAkhir': 57, 'ayatAkhir': 29},
    {'juz': 28, 'surat': 58, 'ayat': 1, 'suratAkhir': 66, 'ayatAkhir': 12},
    {'juz': 29, 'surat': 67, 'ayat': 1, 'suratAkhir': 77, 'ayatAkhir': 50},
    {'juz': 30, 'surat': 78, 'ayat': 1, 'suratAkhir': 114, 'ayatAkhir': 6},
  ];

  @override
  void initState() {
    super.initState();
    _pageController = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _loadingController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
    _fadeAnim = CurvedAnimation(parent: _pageController, curve: Curves.easeOutCubic);
    _pageController.forward();
    _loadQuran();
    searchController.addListener(_filterJuz);
  }

  @override
  void dispose() {
    _pageController.dispose();
    _loadingController.dispose();
    searchController.removeListener(_filterJuz);
    searchController.dispose();
    super.dispose();
  }

  void _filterJuz() {
    final q = searchController.text.toLowerCase().trim();
    setState(() {
      if (q.isEmpty) {
        filteredJuzList = List.from(juzList);
      } else {
        filteredJuzList = juzList.where((j) => j.nomor.toString().contains(q)).toList();
      }
    });
  }

  Future<void> _loadQuran() async {
    try {
      final arabRes = await http.get(Uri.parse('https://api.alquran.cloud/v1/quran/quran-uthmani')).timeout(const Duration(seconds: 30));
      final indoRes = await http.get(Uri.parse('https://api.alquran.cloud/v1/quran/id.indonesian')).timeout(const Duration(seconds: 30));

      if (arabRes.statusCode != 200 || indoRes.statusCode != 200) throw Exception('Failed to load data');

      final arabData = jsonDecode(arabRes.body) as Map<String, dynamic>;
      final indoData = jsonDecode(indoRes.body) as Map<String, dynamic>;
      final arabSurah = (arabData['data'] as Map<String, dynamic>)['surahs'] as List;
      final indoSurah = (indoData['data'] as Map<String, dynamic>)['surahs'] as List;

      List<Surat> result = [];
      for (int i = 0; i < arabSurah.length; i++) {
        final a = arabSurah[i] as Map<String, dynamic>;
        final b = indoSurah[i] as Map<String, dynamic>;
        final aAyat = a['ayahs'] as List;
        final bAyat = b['ayahs'] as List;

        List<Ayat> ayatList = [];
        for (int j = 0; j < aAyat.length; j++) {
          final aa = aAyat[j] as Map<String, dynamic>;
          final bb = bAyat[j] as Map<String, dynamic>;
          ayatList.add(Ayat(
            nomor: aa['numberInSurah'] as int,
            arab: aa['text'] as String? ?? '',
            arti: bb['text'] as String? ?? '',
          ));
        }
        result.add(Surat(
          nomor: a['number'] as int,
          nama: a['name'] as String? ?? '',
          latin: a['englishName'] as String? ?? '',
          ayat: ayatList,
          juz: _getJuzNumber(a['number'] as int, 1),
        ));
      }

      _loadingController.stop();
      if (!mounted) return;
      setState(() {
        allSuratList = result;
        _buildJuzList();
        loading = false;
      });
      _pageController.reset();
      _pageController.forward();
    } catch (e) {
      _loadingController.stop();
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal memuat data: ${e.toString()}'),
          backgroundColor: _C.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  int _getJuzNumber(int suratNumber, int ayatNumber) {
    for (var b in juzBatas) {
      if (suratNumber > b['surat']! || (suratNumber == b['surat']! && ayatNumber >= b['ayat']!)) {
        if (suratNumber < b['suratAkhir']! || (suratNumber == b['suratAkhir']! && ayatNumber <= b['ayatAkhir']!)) {
          return b['juz']!;
        }
      }
    }
    return 30;
  }

  void _buildJuzList() {
    juzList = [];
    for (int i = 1; i <= 30; i++) {
      List<Surat> suratInJuz = [];
      for (var surat in allSuratList) {
        bool isInJuz = false;
        for (var b in juzBatas) {
          if (b['juz'] == i) {
            if (surat.nomor >= b['surat']! && surat.nomor <= b['suratAkhir']!) {
              isInJuz = true;
              break;
            }
          }
        }
        if (isInJuz) suratInJuz.add(surat);
      }
      var batas = juzBatas.firstWhere((b) => b['juz'] == i);
      juzList.add(Juz(
        nomor: i,
        suratList: suratInJuz,
        suratMulai: batas['surat']!,
        suratAkhir: batas['suratAkhir']!,
        ayatMulai: batas['ayat']!,
        ayatAkhir: batas['ayatAkhir']!,
      ));
    }
    filteredJuzList = List.from(juzList);
  }

  void _navigateToJuz(Juz juz) {
    setState(() { selectedJuz = juz; showJuzList = false; });
    _pageController.reset();
    _pageController.forward();
  }

  void _navigateBack() {
    setState(() { showJuzList = true; selectedJuz = null; });
    _pageController.reset();
    _pageController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(child: loading ? _buildLoadingView() : _buildBody()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (!showJuzList) {
                _navigateBack();
              } else {
                Navigator.pop(context);
              }
            },
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded, color: _C.text, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Column(
                key: ValueKey(showJuzList),
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    showJuzList ? 'AL-QUR\'AN' : 'JUZ ${selectedJuz?.nomor ?? ""}',
                    style: const TextStyle(color: _C.text, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 17, letterSpacing: 1.5),
                  ),
                  Text(
                    showJuzList ? '30 Juz tersedia' : 'Surat ${selectedJuz?.suratMulai ?? ""} — ${selectedJuz?.suratAkhir ?? ""}',
                    style: const TextStyle(color: _C.textDim, fontSize: 11, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [_C.ice, _C.ice2, _C.ice3], begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: _shPrimary,
            ),
            child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 350),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        child: showJuzList ? _buildJuzListView(key: const ValueKey('juz')) : _buildSuratInJuzView(key: const ValueKey('surat')),
      ),
    );
  }

  Widget _buildLoadingView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 60, height: 60,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.surface,
              border: Border.all(color: _C.ice.withOpacity(0.4), width: 2),
              boxShadow: _shPrimary,
            ),
            child: const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(_C.ice2),
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 20),
          const Text('Memuat Al-Qur\'an...', style: TextStyle(color: _C.textSub, fontFamily: 'Orbitron', fontSize: 12, letterSpacing: 2)),
        ],
      ),
    );
  }

  Widget _buildJuzListView({Key? key}) {
    return Column(
      key: key,
      children: [
        _buildSearchBar(),
        if (searchController.text.isNotEmpty) _buildSearchInfo(),
        Expanded(
          child: filteredJuzList.isEmpty
              ? _buildEmptyState()
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.15),
                  itemCount: filteredJuzList.length,
                  itemBuilder: (context, index) => _juzCard(filteredJuzList[index], index),
                ),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: TextField(
          controller: searchController,
          style: const TextStyle(color: _C.text, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Cari nomor juz...',
            hintStyle: TextStyle(color: _C.textDim.withOpacity(0.7), fontSize: 13),
            prefixIcon: const Padding(
              padding: EdgeInsets.only(left: 14, right: 10),
              child: Icon(Icons.search_rounded, color: _C.ice2, size: 20),
            ),
            prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
            suffixIcon: searchController.text.isNotEmpty
                ? IconButton(icon: const Icon(Icons.close_rounded, color: _C.textDim, size: 18), onPressed: () => searchController.clear())
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchInfo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
      child: Row(
        children: [
          Text('${filteredJuzList.length} juz ditemukan', style: const TextStyle(color: _C.textSub, fontSize: 12)),
          const Spacer(),
          GestureDetector(
            onTap: () => searchController.clear(),
            child: const Text('Bersihkan', style: TextStyle(color: _C.ice2, fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle, color: _C.iceSoft, border: Border.all(color: _C.ice.withOpacity(0.4), width: 2)),
            child: const Icon(Icons.search_off_rounded, size: 32, color: _C.ice2),
          ),
          const SizedBox(height: 14),
          const Text('Juz tidak ditemukan', style: TextStyle(color: _C.textSub, fontSize: 14)),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: () => searchController.clear(),
            child: const Text('Coba kata kunci lain', style: TextStyle(color: _C.ice2, fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _juzCard(Juz juz, int index) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (index % 6) * 50),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(offset: Offset(0, 12 * (1 - value)), child: child),
      ),
      child: GestureDetector(
        onTap: () => _navigateToJuz(juz),
        child: Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _C.border),
            boxShadow: _sh2,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [_C.ice, _C.ice2], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  boxShadow: _shPrimary,
                ),
                child: Center(
                  child: Text('${juz.nomor}', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
              const SizedBox(height: 10),
              Text('Juz ${juz.nomor}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: 0.5)),
              const SizedBox(height: 3),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.bookmark_outline_rounded, size: 11, color: _C.textDim),
                  const SizedBox(width: 3),
                  Text('S${juz.suratMulai} – S${juz.suratAkhir}', style: const TextStyle(fontSize: 11, color: _C.textDim)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSuratInJuzView({Key? key}) {
    if (selectedJuz == null) return const SizedBox.shrink();

    return Column(
      key: key,
      children: [
        _buildJuzInfoCard(),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
            itemCount: selectedJuz!.suratList.length,
            itemBuilder: (context, index) {
              return TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: Duration(milliseconds: 250 + index * 40),
                curve: Curves.easeOutCubic,
                builder: (ctx, value, child) => Opacity(
                  opacity: value,
                  child: Transform.translate(offset: Offset(0, 10 * (1 - value)), child: child),
                ),
                child: _suratCard(selectedJuz!.suratList[index]),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildJuzInfoCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border),
        boxShadow: _sh2,
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: const LinearGradient(colors: [_C.ice, _C.ice2]), boxShadow: _shPrimary),
            child: Center(
              child: Text('${selectedJuz!.nomor}', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Juz ${selectedJuz!.nomor}', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.bold, color: _C.text, letterSpacing: 1)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    _infoChip(icon: Icons.chrome_reader_mode_outlined, label: 'Surat ${selectedJuz!.suratMulai}–${selectedJuz!.suratAkhir}'),
                    _infoChip(icon: Icons.format_list_numbered_rounded, label: 'Ayat ${selectedJuz!.ayatMulai}–${selectedJuz!.ayatAkhir}'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoChip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: _C.iceSoft, borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.ice.withOpacity(0.4))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: _C.ice3),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(fontSize: 11, color: _C.ice3)),
        ],
      ),
    );
  }

  Widget _suratCard(Surat surat) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
        boxShadow: _sh1,
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          iconColor: _C.ice2,
          collapsedIconColor: _C.textDim,
          collapsedTextColor: _C.text,
          textColor: _C.ice3,
          backgroundColor: Colors.transparent,
          collapsedBackgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          leading: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_C.iceSoft, _C.surface]),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.ice.withOpacity(0.4)),
            ),
            child: Center(
              child: Text('${surat.nomor}', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold, color: _C.ice3)),
            ),
          ),
          title: Text(surat.latin, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w700, fontSize: 15)),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(surat.nama, style: const TextStyle(fontSize: 13, color: _C.textSub)),
          ),
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          childrenPadding: const EdgeInsets.only(bottom: 6),
          children: surat.ayat.map(_ayatTile).toList(),
        ),
      ),
    );
  }

  Widget _ayatTile(Ayat ayat) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.iceSoft,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.ice.withOpacity(0.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.tag_rounded, size: 11, color: _C.ice3),
                      const SizedBox(width: 3),
                      Text('${ayat.nomor}', style: const TextStyle(fontFamily: 'Orbitron', color: _C.ice3, fontSize: 11, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // TEKS ARAB
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
            child: Text(
              ayat.arab,
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
              style: const TextStyle(fontSize: 24, height: 2.0, color: _C.text, fontWeight: FontWeight.w400),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Container(height: 1, color: _C.border),
          ),
          // TERJEMAHAN
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.translate_rounded, size: 13, color: _C.textDim),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    ayat.arti,
                    style: const TextStyle(fontSize: 13, color: _C.textSub, height: 1.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}