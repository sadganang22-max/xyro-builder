// lib/deploy.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ─── PALETTE ───
const Color kBg      = Color(0xFFEEF3F9);
const Color kCard    = Color(0xFFFFFFFF);
const Color kBorder  = Color(0xFFD6E2F0);
const Color kIce     = Color(0xFF38BDF8);
const Color kIce2    = Color(0xFF0EA5E9);
const Color kIce3    = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);
const Color kText    = Color(0xFF0A2540);
const Color kTextSub = Color(0xFF4A6582);
const Color kTextDim = Color(0xFF8FA5BE);
const Color kGreen   = Color(0xFF10B981);
const Color kRed     = Color(0xFFEF4444);

class DeployPage extends StatefulWidget {
  const DeployPage({super.key});

  @override
  State<DeployPage> createState() => _DeployPageState();
}

class _DeployPageState extends State<DeployPage> {
  final TextEditingController _htmlCtrl = TextEditingController();
  final TextEditingController _tokenCtrl = TextEditingController();
  
  bool _isLoading = false;
  String? _resultUrl;
  String? _errorMsg;
  bool _isNetlifyMode = false;

  // Contoh HTML Default
  final String _defaultHtml = '''<!DOCTYPE html>
<html>
<head>
  <title>My Xyro Page</title>
  <style>
    body { background: #0EA5E9; color: white; font-family: sans-serif; text-align: center; padding-top: 50px; }
    h1 { font-size: 40px; }
  </style>
</head>
<body>
  <h1>Hello World!</h1>
  <p>Website ini dibuat dari aplikasi Xyro.</p>
</body>
</html>''';

  @override
  void initState() {
    super.initState();
    _htmlCtrl.text = _defaultHtml;
  }

  @override
  void dispose() {
    _htmlCtrl.dispose();
    _tokenCtrl.dispose();
    super.dispose();
  }

  // ─── LOGIKA DEPLOY KE NETLIFY ───
  Future<void> _deployNetlify() async {
    if (_tokenCtrl.text.trim().isEmpty) {
      _showError('Token Netlify wajib diisi!');
      return;
    }
    if (_htmlCtrl.text.trim().isEmpty) {
      _showError('Kode HTML tidak boleh kosong!');
      return;
    }

    setState(() { _isLoading = true; _errorMsg = null; _resultUrl = null; });
    final token = _tokenCtrl.text.trim();

    try {
      // 1. Buat site baru di Netlify
      final createRes = await http.post(
        Uri.parse('https://api.netlify.com/api/v1/sites'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'name': 'xyro-${DateTime.now().millisecondsSinceEpoch}',
        }),
      ).timeout(const Duration(seconds: 20));

      if (createRes.statusCode != 200 && createRes.statusCode != 201) {
        throw Exception('Gagal buat site. Cek Token Netlify lu. (${createRes.statusCode})');
      }

      final siteData = jsonDecode(createRes.body);
      final siteId = siteData['id'];

      // 2. Buat file zip sederhana berisi index.html (simulasi)
      // (Netlify butuh upload zip atau file langsung via API deploys)
      final deployRes = await http.post(
        Uri.parse('https://api.netlify.com/api/v1/sites/$siteId/deploys'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'files': {
            '/index.html': _htmlCtrl.text,
          }
        }),
      ).timeout(const Duration(seconds: 30));

      if (deployRes.statusCode != 200 && deployRes.statusCode != 201) {
        throw Exception('Gagal deploy file. (${deployRes.statusCode})');
      }

      final deployData = jsonDecode(deployRes.body);
      // Ambil URL
      final url = deployData['ssl_url'] ?? deployData['url'] ?? 'https://${siteData['name']}.netlify.app';
      
      setState(() {
        _resultUrl = url;
      });
    } catch (e) {
      _showError(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ─── LOGIKA DEPLOY KE PASTE (Teks Biasa) ───
  Future<void> _deployPaste() async {
    if (_htmlCtrl.text.trim().isEmpty) {
      _showError('Kode HTML tidak boleh kosong!');
      return;
    }
    setState(() { _isLoading = true; _errorMsg = null; _resultUrl = null; });

    try {
      final res = await http.post(
        Uri.parse('https://dpaste.com/api/v2/'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'content': _htmlCtrl.text,
          'syntax': 'html',
          'expiry_days': '7',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200 || res.statusCode == 201) {
        setState(() {
          _resultUrl = res.body.trim(); // URL hasil paste
        });
      } else {
        throw Exception('Gagal upload ke server paste.');
      }
    } catch (e) {
      _showError(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String msg) {
    setState(() {
      _errorMsg = msg;
      _isLoading = false;
    });
  }

  Future<void> _copyToClipboard() async {
    if (_resultUrl == null) return;
    await Clipboard.setData(ClipboardData(text: _resultUrl!));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Link berhasil di-copy!'), backgroundColor: kGreen),
    );
  }

  Future<void> _openInBrowser() async {
    if (_resultUrl == null) return;
    final uri = Uri.parse(_resultUrl!);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('DEPLOY WEB', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
        backgroundColor: kCard,
        elevation: 0,
        foregroundColor: kText,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ─── TAB SWITCH (MODE) ───
            Container(
              decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder)),
              padding: const EdgeInsets.all(4),
              child: Row(
                children: [
                  _buildTab('Paste Server', !_isNetlifyMode, () => setState(() => _isNetlifyMode = false)),
                  _buildTab('Netlify App', _isNetlifyMode, () => setState(() => _isNetlifyMode = true)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // ─── INPUT TOKEN (KALO NETLIFY) ───
            if (_isNetlifyMode) ...[
              const Text('NETLIFY TOKEN', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: kTextSub, letterSpacing: 1)),
              const SizedBox(height: 6),
              TextField(
                controller: _tokenCtrl,
                style: const TextStyle(fontSize: 13, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: 'Masukkan Personal Access Token Netlify...',
                  hintStyle: const TextStyle(color: kTextDim, fontSize: 12),
                  filled: true, fillColor: kCard,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kBorder)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: kBorder)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
              const SizedBox(height: 6),
              const Text('*Dapetin token gratis di app.netlify.com/user/applications', style: TextStyle(fontSize: 10, color: kTextDim)),
              const SizedBox(height: 20),
            ],

            // ─── TEXT EDITOR HTML ───
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('KODE HTML', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: kTextSub, letterSpacing: 1)),
                TextButton(
                  onPressed: () => setState(() => _htmlCtrl.text = _defaultHtml),
                  child: const Text('Reset', style: TextStyle(color: kIce2, fontSize: 12)),
                )
              ],
            ),
            const SizedBox(height: 6),
            Container(
              height: 300,
              decoration: BoxDecoration(color: const Color(0xFF0F172A), borderRadius: BorderRadius.circular(16)),
              child: TextField(
                controller: _htmlCtrl,
                maxLines: null,
                expands: true,
                style: const TextStyle(color: Color(0xFFE2E8F0), fontSize: 12, fontFamily: 'monospace'),
                cursorColor: kIce,
                decoration: const InputDecoration(
                  hintText: '<h1>Hello World</h1>',
                  hintStyle: TextStyle(color: Colors.white24),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(16),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ─── ERROR BOX ───
            if (_errorMsg != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: kRed.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: kRed.withOpacity(0.3))),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: kRed),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_errorMsg!, style: const TextStyle(color: kRed, fontSize: 12, fontWeight: FontWeight.bold))),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // ─── RESULT BOX ───
            if (_resultUrl != null) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: kGreen.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: kGreen.withOpacity(0.3))),
                child: Column(
                  children: [
                    const Icon(Icons.check_circle, color: kGreen, size: 40),
                    const SizedBox(height: 10),
                    const Text('DEPLOY BERHASIL!', style: TextStyle(color: kGreen, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
                    const SizedBox(height: 10),
                    SelectableText(
                      _resultUrl!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: kText, fontSize: 13, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _openInBrowser,
                            icon: const Icon(Icons.open_in_new, size: 18),
                            label: const Text('BUKA'),
                            style: ElevatedButton.styleFrom(backgroundColor: kGreen, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _copyToClipboard,
                            icon: const Icon(Icons.copy, size: 18),
                            label: const Text('COPY'),
                            style: ElevatedButton.styleFrom(backgroundColor: kCard, foregroundColor: kGreen, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), side: BorderSide(color: kGreen.withOpacity(0.5))),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // ─── DEPLOY BUTTON ───
            GestureDetector(
              onTap: _isLoading ? null : (_isNetlifyMode ? _deployNetlify : _deployPaste),
              child: Container(
                height: 56,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kIce, kIce2, kIce3]),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: kIce2.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))],
                ),
                child: Center(
                  child: _isLoading
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                            const SizedBox(width: 10),
                            Text(_isNetlifyMode ? 'DEPLOY KE NETLIFY' : 'DEPLOY VIA PASTE', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                          ],
                        ),
                ),
              ),
            ),
            
            const SizedBox(height: 10),
            Text(
              _isNetlifyMode 
                ? 'Netlify akan menghasilkan link web asli (contoh: https://xyro-random.netlify.app)'
                : 'Paste server hanya menghasilkan link teks mentah (bukan web asli).',
              textAlign: TextAlign.center,
              style: const TextStyle(color: kTextDim, fontSize: 11, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label, bool isActive, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isActive ? kIce2 : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: isActive ? Colors.white : kTextSub,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ),
        ),
      ),
    );
  }
}