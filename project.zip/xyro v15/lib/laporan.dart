// ═══════════════════════════════════════════════════════════════════════════
//  LAPORAN PAGE — KIRIM LAPORAN MASALAH
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFF8B5CF6);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 32, offset: const Offset(0, 16)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

// ═══════════════════════════════════════════════════════════════════════════
//  KATEGORI LAPORAN
// ═══════════════════════════════════════════════════════════════════════════
class _Kategori {
  final String id;
  final String label;
  final IconData icon;
  final Color color;
  const _Kategori({
    required this.id,
    required this.label,
    required this.icon,
    required this.color,
  });
}

const List<_Kategori> _kategoriList = [
  _Kategori(
    id: 'bug',
    label: 'BUG',
    icon: Icons.bug_report_rounded,
    color: _C.red,
  ),
  _Kategori(
    id: 'error',
    label: 'ERROR',
    icon: Icons.error_rounded,
    color: _C.amber,
  ),
  _Kategori(
    id: 'saran',
    label: 'SARAN',
    icon: Icons.lightbulb_rounded,
    color: _C.purple,
  ),
  _Kategori(
    id: 'lainnya',
    label: 'LAINNYA',
    icon: Icons.more_horiz_rounded,
    color: _C.ice2,
  ),
];

// ═══════════════════════════════════════════════════════════════════════════
//  PAGE
// ═══════════════════════════════════════════════════════════════════════════
class LaporanPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const LaporanPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<LaporanPage> createState() => _LaporanPageState();
}

class _LaporanPageState extends State<LaporanPage>
    with TickerProviderStateMixin {
  final TextEditingController _judulCtrl = TextEditingController();
  final TextEditingController _pesanCtrl = TextEditingController();

  String _selectedKategori = 'bug';
  bool _isSending = false;
  bool _success = false;

  late AnimationController _entryCtrl;
  late AnimationController _successCtrl;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700))
      ..forward();
    _successCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
  }

  @override
  void dispose() {
    _judulCtrl.dispose();
    _pesanCtrl.dispose();
    _entryCtrl.dispose();
    _successCtrl.dispose();
    super.dispose();
  }

  Future<void> _kirimLaporan() async {
    final judul = _judulCtrl.text.trim();
    final pesan = _pesanCtrl.text.trim();

    if (judul.length < 3) {
      _showAlert('❌ Judul Kurang', 'Judul minimal 3 karakter.');
      return;
    }
    if (pesan.length < 10) {
      _showAlert('❌ Pesan Kurang', 'Detail laporan minimal 10 karakter.');
      return;
    }

    setState(() => _isSending = true);

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/kirimLaporan'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
          'role': widget.role,
          'kategori': _selectedKategori,
          'judul': judul,
          'pesan': pesan,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body) as Map<String, dynamic>;

      if (data['valid'] == true) {
        setState(() => _success = true);
        _successCtrl.forward(from: 0);
        _judulCtrl.clear();
        _pesanCtrl.clear();
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) setState(() => _success = false);
        });
      } else {
        _showAlert('❌ Gagal', data['message']?.toString() ?? 'Unknown error');
      }
    } catch (e) {
      _showAlert('❌ Koneksi Error', 'Gagal terhubung ke server.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _C.ice.withOpacity(0.4), width: 1.5),
        ),
        title: Text(title,
            style: const TextStyle(
                color: _C.ice3,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK",
                style: TextStyle(
                    color: _C.ice2, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(0.78),
                    Colors.white.withOpacity(0.88),
                    Colors.white.withOpacity(0.75),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(
                  parent: _entryCtrl, curve: Curves.easeOut),
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildAppBar(),
                    const SizedBox(height: 20),
                    _buildHeroCard(),
                    const SizedBox(height: 16),
                    _buildFormCard(),
                    const SizedBox(height: 20),
                    _buildSubmitButton(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.surface,
              border: Border.all(color: _C.border),
              boxShadow: _sh1,
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: _C.text, size: 20),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('KIRIM LAPORAN',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                      letterSpacing: 1.5)),
              Text('Laporkan bug atau masalah',
                  style: TextStyle(
                      color: _C.textDim,
                      fontSize: 11,
                      fontWeight: FontWeight.w500)),
            ],
          ),
        ),
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [_C.ice, _C.ice2, _C.ice3],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: _shPrimary,
          ),
          child: const Icon(Icons.report_rounded,
              color: Colors.white, size: 20),
        ),
      ],
    );
  }

  Widget _buildHeroCard() {
    return AnimatedBuilder(
      animation: _successCtrl,
      builder: (_, __) {
        final isSuccess = _success;
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isSuccess
                  ? [_C.green, _C.green.withOpacity(0.75)]
                  : [_C.ice, _C.ice2, _C.ice3],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: _shPrimary,
          ),
          child: Column(
            children: [
              Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.25),
                  border: Border.all(
                      color: Colors.white.withOpacity(0.4), width: 2),
                ),
                child: Icon(
                  isSuccess ? Icons.check_rounded : Icons.report_problem_rounded,
                  color: Colors.white,
                  size: 32,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                isSuccess ? 'LAPORAN TERKIRIM' : 'LAPOR MASALAH',
                style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                    letterSpacing: 1.5),
              ),
              const SizedBox(height: 6),
              Text(
                isSuccess
                    ? 'Terima kasih! Laporan kamu akan segera kami proses.'
                    : 'Bantuan kamu sangat berarti untuk kemajuan XYRO',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.92),
                    fontSize: 12,
                    height: 1.5,
                    fontWeight: FontWeight.w500),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFormCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.surface, _C.cardAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: _sh2,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Kategori selector
          Row(
            children: const [
              Icon(Icons.category_rounded, color: _C.ice2, size: 18),
              SizedBox(width: 8),
              Text('KATEGORI',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: _kategoriList.map((k) {
              final isActive = _selectedKategori == k.id;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedKategori = k.id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        gradient: isActive
                            ? LinearGradient(
                                colors: [k.color, k.color.withOpacity(0.75)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight)
                            : null,
                        color: isActive ? null : _C.cardAlt,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isActive
                              ? k.color
                              : _C.borderMid,
                          width: 1.5,
                        ),
                        boxShadow: isActive
                            ? [
                                BoxShadow(
                                    color: k.color.withOpacity(0.35),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4)),
                              ]
                            : null,
                      ),
                      child: Column(
                        children: [
                          Icon(k.icon,
                              color: isActive ? Colors.white : k.color,
                              size: 18),
                          const SizedBox(height: 4),
                          Text(k.label,
                              style: TextStyle(
                                  color: isActive ? Colors.white : _C.textSub,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5)),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          // Judul
          Row(
            children: const [
              Icon(Icons.title_rounded, color: _C.ice2, size: 18),
              SizedBox(width: 8),
              Text('JUDUL LAPORAN',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          _buildTextField(
            controller: _judulCtrl,
            hint: 'Contoh: Bug di menu sender',
            icon: Icons.short_text_rounded,
            maxLines: 1,
          ),
          const SizedBox(height: 16),
          // Pesan
          Row(
            children: const [
              Icon(Icons.description_rounded, color: _C.ice2, size: 18),
              SizedBox(width: 8),
              Text('DETAIL MASALAH',
                  style: TextStyle(
                      color: _C.text,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          _buildTextField(
            controller: _pesanCtrl,
            hint: 'Jelaskan detail masalah yang kamu alami...',
            icon: Icons.notes_rounded,
            maxLines: 6,
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    int maxLines = 1,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.borderMid),
        boxShadow: _sh1,
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        minLines: 1,
        style: const TextStyle(
            color: _C.text,
            fontFamily: 'ShareTechMono',
            fontSize: 13,
            height: 1.4),
        cursorColor: _C.ice2,
        textInputAction:
            maxLines > 1 ? TextInputAction.newline : TextInputAction.next,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
              color: _C.textDim.withOpacity(0.7),
              fontFamily: 'ShareTechMono',
              fontSize: 12),
          prefixIcon: maxLines == 1
              ? Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Icon(icon, color: _C.textSub, size: 18),
                )
              : null,
          prefixIconConstraints: maxLines == 1
              ? const BoxConstraints(minWidth: 50, minHeight: 50)
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
    );
  }

  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: _isSending ? null : _kirimLaporan,
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(
            colors: [_C.ice, _C.ice2, _C.ice3],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: _shPrimary,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isSending)
              const SizedBox(
                width: 24, height: 24,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 3),
              )
            else
              const Icon(Icons.send_rounded,
                  color: Colors.white, size: 22),
            const SizedBox(width: 10),
            Text(
              _isSending ? 'MENGIRIM...' : 'KIRIM LAPORAN',
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2),
            ),
          ],
        ),
      ),
    );
  }
}