// ═══════════════════════════════════════════════════════════════════════════
//  RIWAYAT LAPORAN — ADMIN / OWNER
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class RiwayatLaporanPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatLaporanPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatLaporanPage> createState() => _RiwayatLaporanPageState();
}

class _RiwayatLaporanPageState extends State<RiwayatLaporanPage> {
  List<Map<String, dynamic>> _laporan = [];
  bool _loading = true;
  String _filter = 'all';

  int _total = 0, _pending = 0, _diproses = 0, _selesai = 0;

  @override
  void initState() {
    super.initState();
    _fetchLaporan();
  }

  Future<void> _fetchLaporan() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/getLaporan?key=${widget.sessionKey}&role=${widget.role}&filter=$_filter',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body) as Map<String, dynamic>;

      if (data['valid'] == true) {
        setState(() {
          _laporan = (data['laporan'] as List)
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
          _total = (data['total'] as num?)?.toInt() ?? 0;
          _pending = (data['pending'] as num?)?.toInt() ?? 0;
          _diproses = (data['diproses'] as num?)?.toInt() ?? 0;
          _selesai = (data['selesai'] as num?)?.toInt() ?? 0;
        });
      } else {
        _showAlert('❌ Akses', data['message']?.toString() ?? 'Error');
      }
    } catch (e) {
      _showAlert('❌ Koneksi', 'Gagal memuat laporan.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _updateStatus(String id, String status, String? reply) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/updateLaporan'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'role': widget.role,
          'id': id,
          'status': status,
          if (reply != null) 'reply': reply,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true) {
        _fetchLaporan();
      } else {
        _showAlert('❌ Gagal', data['message']?.toString() ?? 'Error');
      }
    } catch (e) {
      _showAlert('❌ Koneksi', 'Gagal update status.');
    }
  }

  Future<void> _hapusLaporan(String id) async {
    try {
      final res = await http.delete(Uri.parse(
        '$baseUrl/hapusLaporan?id=$id&role=${widget.role}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true) {
        _fetchLaporan();
      }
    } catch (_) {}
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        title: Text(title,
            style: const TextStyle(
                color: _C.ice3,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("OK",
                style: TextStyle(
                    color: _C.ice2, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showDetail(Map<String, dynamic> l) {
    final replyCtrl =
        TextEditingController(text: l['reply']?.toString() ?? '');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        decoration: const BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    decoration: BoxDecoration(
                      color: _C.borderMid,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Text(l['judul'] ?? '-',
                          style: const TextStyle(
                              color: _C.text,
                              fontWeight: FontWeight.w900,
                              fontSize: 16)),
                    ),
                    _buildStatusChip(l['status']?.toString() ?? 'pending'),
                  ],
                ),
                const SizedBox(height: 10),
                _row(Icons.person_rounded, '${l['username']} · ${l['role']}'),
                _row(Icons.category_rounded,
                    'Kategori: ${l['kategori']}'),
                _row(Icons.access_time_rounded,
                    _formatDate(l['createdAt']?.toString() ?? '')),
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _C.cardAlt,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.border),
                  ),
                  child: Text(l['pesan'] ?? '-',
                      style: const TextStyle(
                          color: _C.textSub,
                          fontSize: 13,
                          height: 1.5)),
                ),
                const SizedBox(height: 16),
                const Text('Update Status:',
                    style: TextStyle(
                        color: _C.text,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _statusBtn('pending', 'Pending', _C.amber, l),
                    const SizedBox(width: 8),
                    _statusBtn('diproses', 'Diproses', _C.ice2, l),
                    const SizedBox(width: 8),
                    _statusBtn('selesai', 'Selesai', _C.green, l),
                  ],
                ),
                const SizedBox(height: 16),
                const Text('Balasan (opsional):',
                    style: TextStyle(
                        color: _C.text,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: _C.cardAlt,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.borderMid),
                  ),
                  child: TextField(
                    controller: replyCtrl,
                    maxLines: 3,
                    style: const TextStyle(
                        color: _C.text, fontSize: 13),
                    decoration: const InputDecoration(
                      hintText: 'Tulis balasan...',
                      hintStyle: TextStyle(
                          color: _C.textDim, fontSize: 12),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.all(12),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _confirmDelete(l['id']?.toString() ?? '');
                        },
                        icon: const Icon(Icons.delete_rounded,
                            color: _C.red, size: 16),
                        label: const Text('HAPUS',
                            style: TextStyle(
                                color: _C.red,
                                fontWeight: FontWeight.bold,
                                fontSize: 12)),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          side: BorderSide(color: _C.red.withOpacity(0.4)),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _updateStatus(
                            l['id']?.toString() ?? '',
                            l['status']?.toString() ?? 'pending',
                            replyCtrl.text.trim().isEmpty
                                ? null
                                : replyCtrl.text.trim(),
                          );
                        },
                        icon: const Icon(Icons.save_rounded,
                            color: Colors.white, size: 16),
                        label: const Text('SIMPAN',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _C.ice2,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _statusBtn(String status, String label, Color color,
      Map<String, dynamic> l) {
    final isActive = l['status'] == status;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          Navigator.pop(context);
          _updateStatus(l['id']?.toString() ?? '', status, null);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isActive ? color : _C.cardAlt,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
                color: isActive ? color : _C.borderMid, width: 1.5),
          ),
          child: Center(
            child: Text(label,
                style: TextStyle(
                    color: isActive ? Colors.white : color,
                    fontSize: 11,
                    fontWeight: FontWeight.w800)),
          ),
        ),
      ),
    );
  }

  void _confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        title: const Text('Hapus Laporan?',
            style: TextStyle(
                color: _C.red,
                fontWeight: FontWeight.bold,
                fontSize: 16)),
        content: const Text('Laporan akan dihapus permanen.',
            style: TextStyle(color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal',
                style: TextStyle(color: _C.textDim)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _hapusLaporan(id);
            },
            child: const Text('Hapus',
                style: TextStyle(
                    color: _C.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            Icon(icon, color: _C.textDim, size: 14),
            const SizedBox(width: 6),
            Expanded(
              child: Text(text,
                  style: const TextStyle(
                      color: _C.textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.w500)),
            ),
          ],
        ),
      );

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day}/${dt.month}/${dt.year} '
          '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  Widget _buildStatusChip(String status) {
    Color color;
    switch (status) {
      case 'diproses':
        color = _C.ice2;
        break;
      case 'selesai':
        color = _C.green;
        break;
      default:
        color = _C.amber;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(status.toUpperCase(),
          style: TextStyle(
              color: color, fontSize: 9, fontWeight: FontWeight.w800)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              const SizedBox(height: 12),
              _buildStatsRow(),
              const SizedBox(height: 12),
              _buildFilterRow(),
              const SizedBox(height: 8),
              Expanded(child: _buildLaporanList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: _C.text, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('RIWAYAT LAPORAN',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        letterSpacing: 1.2)),
                Text('Semua laporan user',
                    style: TextStyle(
                        color: _C.textDim,
                        fontSize: 11,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          GestureDetector(
            onTap: _fetchLaporan,
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [_C.ice, _C.ice2, _C.ice3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: _shPrimary,
              ),
              child: const Icon(Icons.refresh_rounded,
                  color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _statChip('TOTAL', '$_total', _C.ice2),
          const SizedBox(width: 8),
          _statChip('PENDING', '$_pending', _C.amber),
          const SizedBox(width: 8),
          _statChip('PROSES', '$_diproses', _C.ice3),
          const SizedBox(width: 8),
          _statChip('SELESAI', '$_selesai', _C.green),
        ],
      ),
    );
  }

  Widget _statChip(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: Column(
          children: [
            Text(value,
                style: TextStyle(
                    color: color,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 18)),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                    color: _C.textDim,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterRow() {
    final filters = [
      {'id': 'all', 'label': 'SEMUA', 'icon': Icons.list_rounded},
      {'id': 'pending', 'label': 'PENDING', 'icon': Icons.schedule_rounded},
      {'id': 'diproses', 'label': 'PROSES', 'icon': Icons.autorenew_rounded},
      {'id': 'selesai', 'label': 'SELESAI', 'icon': Icons.check_circle_rounded},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: filters.map((f) {
          final isActive = _filter == f['id'];
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                setState(() => _filter = f['id'] as String);
                _fetchLaporan();
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isActive
                      ? const LinearGradient(
                          colors: [_C.ice, _C.ice2],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight)
                      : null,
                  color: isActive ? null : _C.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: isActive ? _C.ice : _C.border, width: 1.5),
                  boxShadow: isActive ? _sh1 : null,
                ),
                child: Row(
                  children: [
                    Icon(f['icon'] as IconData,
                        color: isActive ? Colors.white : _C.textSub,
                        size: 13),
                    const SizedBox(width: 6),
                    Text(f['label'] as String,
                        style: TextStyle(
                            color: isActive ? Colors.white : _C.textSub,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5)),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildLaporanList() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(color: _C.ice2, strokeWidth: 2));
    }
    if (_laporan.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.iceSoft,
                border: Border.all(
                    color: _C.ice.withOpacity(0.4), width: 2),
              ),
              child: const Icon(Icons.inbox_rounded,
                  color: _C.ice2, size: 36),
            ),
            const SizedBox(height: 14),
            const Text('Belum ada laporan',
                style: TextStyle(
                    color: _C.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 14)),
            const SizedBox(height: 4),
            const Text('Laporan dari user akan muncul di sini',
                style: TextStyle(color: _C.textDim, fontSize: 11)),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _fetchLaporan,
      color: _C.ice2,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        itemCount: _laporan.length,
        itemBuilder: (ctx, i) {
          final l = _laporan[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GestureDetector(
              onTap: () => _showDetail(l),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _C.border),
                  boxShadow: _sh1,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(l['judul'] ?? '-',
                              style: const TextStyle(
                                  color: _C.text,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ),
                        _buildStatusChip(l['status']?.toString() ?? 'pending'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(l['pesan'] ?? '-',
                        style: const TextStyle(
                            color: _C.textSub,
                            fontSize: 11,
                            height: 1.4),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: _C.iceSoft,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(l['kategori'] ?? '-',
                              style: const TextStyle(
                                  color: _C.ice3,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 8),
                        Icon(Icons.person_rounded,
                            color: _C.textDim, size: 11),
                        const SizedBox(width: 3),
                        Text(l['username'] ?? '-',
                            style: const TextStyle(
                                color: _C.textDim, fontSize: 10)),
                        const Spacer(),
                        Icon(Icons.access_time_rounded,
                            color: _C.textDim, size: 11),
                        const SizedBox(width: 3),
                        Text(_formatDate(l['createdAt']?.toString() ?? ''),
                            style: const TextStyle(
                                color: _C.textDim, fontSize: 10)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}