// lib/tabungan.dart — 100% OFFLINE (NO BACKEND, NO API)
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── PALETTE ───
const Color kBg      = Color(0xFFEEF3F9);
const Color kCard    = Color(0xFFFFFFFF);
const Color kBorder  = Color(0xFFD6E2F0);
const Color kIce     = Color(0xFF38BDF8);
const Color kIce2    = Color(0xFF0EA5E9);
const Color kIce3    = Color(0xFF0284C7);
const Color kIceSoft = Color(0xFFE0F2FE);
const Color kText    = Color(0xFF0A2540);
const Color kTextSub = Color(0xFF4A6582);
const Color kTextDim = Color(0xFF8FA5BE);
const Color kGreen   = Color(0xFF10B981);
const Color kRed     = Color(0xFFEF4444);
const Color kAmber   = Color(0xFFF59E0B);

// ─── MODEL IMPIAN ───
class DreamTarget {
  String id;
  String name;
  int targetEdpoint;
  int savedEdpoint;
  String imagePath;

  DreamTarget({
    required this.id,
    required this.name,
    required this.targetEdpoint,
    required this.savedEdpoint,
    required this.imagePath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'targetEdpoint': targetEdpoint,
        'savedEdpoint': savedEdpoint,
        'imagePath': imagePath,
      };

  factory DreamTarget.fromJson(Map<String, dynamic> json) => DreamTarget(
        id: json['id'],
        name: json['name'],
        targetEdpoint: json['targetEdpoint'] ?? 0,
        savedEdpoint: json['savedEdpoint'] ?? 0,
        imagePath: json['imagePath'] ?? '',
      );
}

// ─── PAGE ───
class TabunganPage extends StatefulWidget {
  const TabunganPage({super.key});

  @override
  State<TabunganPage> createState() => _TabunganPageState();
}

class _TabunganPageState extends State<TabunganPage> {
  List<DreamTarget> _dreams = [];
  int _saldoEdpoint = 0;
  bool _isLoading = true;

  // Kunci SharedPreferences
  static const String _kSaldo = 'xyro_edpoint_saldo';
  static const String _kDreams = 'xyro_edpoint_dreams';

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  // ─── LOAD SEMUA DATA (SALDO + IMPIAN) ───
  Future<void> _loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    final int saldo = prefs.getInt(_kSaldo) ?? 0;
    final String? raw = prefs.getString(_kDreams);

    setState(() {
      _saldoEdpoint = saldo;
      if (raw != null) {
        final List decoded = jsonDecode(raw);
        _dreams = decoded.map((e) => DreamTarget.fromJson(e)).toList();
      }
      _isLoading = false;
    });
  }

  // ─── SIMPAN SALDO ───
  Future<void> _saveSaldo() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kSaldo, _saldoEdpoint);
  }

  // ─── SIMPAN IMPIAN ───
  Future<void> _saveDreams() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kDreams,
        jsonEncode(_dreams.map((e) => e.toJson()).toList()));
  }

  // ─── TOP UP EDPOINT (MANUAL, OFFLINE) ───
  void _showTopUpDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Top Up Edpoint',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Jumlah Edpoint',
            hintText: 'Contoh: 500',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('BATAL', style: TextStyle(color: kTextDim)),
          ),
          ElevatedButton(
            onPressed: () async {
              final amt = int.tryParse(ctrl.text);
              if (amt == null || amt <= 0) return;
              setState(() => _saldoEdpoint += amt);
              await _saveSaldo();
              if (mounted) Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: kAmber),
            child: const Text('TOP UP',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ─── TAMBAH IMPIAN ───
  void _showAddDreamDialog() {
    final nameCtrl = TextEditingController();
    final targetCtrl = TextEditingController();
    File? pickedImage;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return Padding(
            padding:
                EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('IMPian BARU',
                      style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: kText)),
                  const SizedBox(height: 20),

                  // FOTO
                  GestureDetector(
                    onTap: () async {
                      final picked = await ImagePicker().pickImage(
                          source: ImageSource.gallery, imageQuality: 80);
                      if (picked != null) {
                        setModalState(() => pickedImage = File(picked.path));
                      }
                    },
                    child: Container(
                      height: 140,
                      decoration: BoxDecoration(
                        color: kIceSoft,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: kBorder, width: 1.5),
                        image: pickedImage != null
                            ? DecorationImage(
                                image: FileImage(pickedImage!), fit: BoxFit.cover)
                            : null,
                      ),
                      child: pickedImage == null
                          ? const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_photo_alternate_rounded,
                                    size: 40, color: kIce2),
                                SizedBox(height: 8),
                                Text('Pilih Foto Impian',
                                    style: TextStyle(
                                        color: kIce2,
                                        fontWeight: FontWeight.bold)),
                              ],
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // NAMA
                  TextField(
                    controller: nameCtrl,
                    decoration: InputDecoration(
                      labelText: 'Nama Impian',
                      hintText: 'Contoh: Beli Headset',
                      filled: true,
                      fillColor: kBg,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // TARGET
                  TextField(
                    controller: targetCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                      labelText: 'Target Edpoint',
                      hintText: 'Contoh: 1000',
                      filled: true,
                      fillColor: kBg,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none),
                    ),
                  ),
                  const SizedBox(height: 24),

                  GestureDetector(
                    onTap: () async {
                      if (nameCtrl.text.isEmpty || targetCtrl.text.isEmpty) {
                        return;
                      }
                      setState(() {
                        _dreams.add(DreamTarget(
                          id: DateTime.now().millisecondsSinceEpoch.toString(),
                          name: nameCtrl.text,
                          targetEdpoint: int.parse(targetCtrl.text),
                          savedEdpoint: 0,
                          imagePath: pickedImage?.path ?? '',
                        ));
                      });
                      await _saveDreams();
                      if (mounted) Navigator.pop(ctx);
                    },
                    child: Container(
                      height: 54,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                            colors: [kIce, kIce2, kIce3]),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Center(
                        child: Text('SIMPAN IMPIAN',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── NABUNG (PAKAI SALDO OFFLINE) ───
  void _showSaveEdpointDialog(DreamTarget dream) {
    final amountCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Nabung untuk ${dream.name}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Saldo kamu: $_saldoEdpoint Edpoint',
                style: const TextStyle(color: kTextDim, fontSize: 12)),
            const SizedBox(height: 10),
            TextField(
              controller: amountCtrl,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                labelText: 'Jumlah Edpoint',
                hintText: 'Contoh: 100',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('BATAL', style: TextStyle(color: kTextDim)),
          ),
          ElevatedButton(
            onPressed: () async {
              final amt = int.tryParse(amountCtrl.text);
              if (amt == null || amt <= 0) return;
              if (amt > _saldoEdpoint) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Edpoint ga cukup asu!'),
                    backgroundColor: kRed,
                  ),
                );
                return;
              }
              setState(() {
                _saldoEdpoint -= amt;
                dream.savedEdpoint += amt;
              });
              await _saveSaldo();
              await _saveDreams();
              if (mounted) Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: kGreen),
            child: const Text('NABUNG',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ─── HAPUS IMPIAN (SWIPE / LONG PRESS) ───
  Future<void> _deleteDream(DreamTarget dream) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Hapus Impian?',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        content: Text('Yakin mau hapus "${dream.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('BATAL'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: kRed),
            child: const Text('HAPUS',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => _dreams.removeWhere((d) => d.id == dream.id));
      await _saveDreams();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('TABUNGAN EDPOINT',
            style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                fontSize: 16)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: kText,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: kIce2))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ─── KARTU SALDO ───
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                            color: kIce2.withOpacity(0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 10)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('SALDO EDPOINT',
                                style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5)),
                            GestureDetector(
                              onTap: _showTopUpDialog,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(20)),
                                child: const Row(children: [
                                  Icon(Icons.add_rounded,
                                      color: Colors.white, size: 14),
                                  SizedBox(width: 4),
                                  Text('Top Up',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold)),
                                ]),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.monetization_on_rounded,
                                color: kAmber, size: 36),
                            const SizedBox(width: 10),
                            Text('$_saldoEdpoint',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 40,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron')),
                          ],
                        ),
                        const SizedBox(height: 4),
                        const Text('Edpoint aktif di HP ini',
                            style: TextStyle(
                                color: Colors.white54, fontSize: 12)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ─── LIST IMPIAN ───
                  const Text('DAFTAR IMPIAN',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: kTextDim,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 12),

                  if (_dreams.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(40),
                      decoration: BoxDecoration(
                          color: kCard,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: kBorder)),
                      child: const Column(children: [
                        Icon(Icons.savings_rounded,
                            size: 60, color: kTextDim),
                        SizedBox(height: 10),
                        Text('Belum ada impian',
                            style: TextStyle(
                                color: kTextDim,
                                fontWeight: FontWeight.bold)),
                        Text('Yuk mulai tabung Edpoint!',
                            style: TextStyle(
                                color: kTextDim, fontSize: 12)),
                      ]),
                    )
                  else
                    ..._dreams.map((dream) {
                      final progress = dream.targetEdpoint == 0
                          ? 0.0
                          : (dream.savedEdpoint / dream.targetEdpoint)
                              .clamp(0.0, 1.0);
                      final isDone =
                          dream.savedEdpoint >= dream.targetEdpoint;

                      return GestureDetector(
                        onLongPress: () => _deleteDream(dream),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 14),
                          decoration: BoxDecoration(
                            color: kCard,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: kBorder),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black.withOpacity(0.03),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 70,
                                  height: 70,
                                  decoration: BoxDecoration(
                                    color: kIceSoft,
                                    borderRadius: BorderRadius.circular(14),
                                    image: dream.imagePath.isNotEmpty &&
                                            File(dream.imagePath).existsSync()
                                        ? DecorationImage(
                                            image: FileImage(
                                                File(dream.imagePath)),
                                            fit: BoxFit.cover)
                                        : null,
                                  ),
                                  child: dream.imagePath.isEmpty ||
                                          !File(dream.imagePath).existsSync()
                                      ? const Icon(Icons.image_rounded,
                                          color: kIce2)
                                      : null,
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [
                                        Expanded(
                                            child: Text(dream.name,
                                                style: const TextStyle(
                                                    fontWeight:
                                                        FontWeight.w900,
                                                    fontSize: 15,
                                                    color: kText))),
                                        if (isDone)
                                          const Icon(
                                              Icons.verified_rounded,
                                              color: kGreen,
                                              size: 20),
                                      ]),
                                      const SizedBox(height: 4),
                                      Text(
                                          '${dream.savedEdpoint} / ${dream.targetEdpoint} Edpoint',
                                          style: const TextStyle(
                                              fontSize: 11,
                                              color: kTextSub,
                                              fontWeight:
                                                  FontWeight.w600)),
                                      const SizedBox(height: 8),
                                      ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(10),
                                        child: LinearProgressIndicator(
                                          value: progress,
                                          minHeight: 8,
                                          backgroundColor: kBorder,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                  isDone ? kGreen : kIce2),
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      GestureDetector(
                                        onTap: () =>
                                            _showSaveEdpointDialog(dream),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 12, vertical: 6),
                                          decoration: BoxDecoration(
                                            color: kIceSoft,
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                                color: kIce.withOpacity(
                                                    0.3)),
                                          ),
                                          child: const Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(Icons.add_rounded,
                                                    size: 14,
                                                    color: kIce3),
                                                SizedBox(width: 4),
                                                Text('Nabung',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: kIce3)),
                                              ]),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddDreamDialog,
        backgroundColor: kIce2,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: const Text('IMPian',
            style:
                TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}