// ═══════════════════════════════════════════════════════════════════════════
//  TOOLS PAGE — ROMBAK TOTAL
//  Command dashboard · search + filter · bento grid · bottom sheet tools
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'anime_home.dart';
import 'hentai.dart';
import 'game.dart';
import 'deploy.dart';
import 'tabungan.dart';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardInner = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);
  static const blue      = Color(0xFF3B82F6);

  static const red       = Color(0xFFEF4444);
  static const amber     = Color(0xFFF59E0B);
  static const green     = Color(0xFF10B981);
  static const purple    = Color(0xFF8B5CF6);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9), Color(0xFF0284C7), Color(0xFF0369A1)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
];

class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final int count;
  final String tag;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.count,
    this.tag = '',
  });
}

const _categories = [
  _ToolCategory(id: 'tabungan', title: 'Tabungan', subtitle: 'Impian & Edpoint', icon: Icons.savings_rounded, accent: _C.green, count: 1, tag: 'NEW'),
  _ToolCategory(id: 'deploy', title: 'Deploy Web', subtitle: 'HTML to Link', icon: Icons.rocket_launch_rounded, accent: _C.ice3, count: 1, tag: 'NEW'),
  _ToolCategory(id: 'panel', title: 'Manage Server', subtitle: 'Server Control', icon: Icons.dns_rounded, accent: _C.ice2, count: 1),
  _ToolCategory(id: 'ddos', title: 'DDoS', subtitle: 'Take Down', icon: Icons.bolt_rounded, accent: _C.ice3, count: 1),
  _ToolCategory(id: 'network', title: 'Network', subtitle: 'WiFi Arsenal', icon: Icons.wifi_rounded, accent: _C.blue, count: 3),
  _ToolCategory(id: 'osint', title: 'OSiNT', subtitle: 'Deep Search', icon: Icons.search_rounded, accent: _C.iceDeep, count: 4),
  _ToolCategory(id: 'downloader', title: 'Downloader', subtitle: 'Media Saver', icon: Icons.download_rounded, accent: _C.green, count: 2),
  _ToolCategory(id: 'utilities', title: 'Utilities', subtitle: 'Extra Tools', icon: Icons.construction_rounded, accent: _C.amber, count: 3),
  _ToolCategory(id: 'watchs', title: 'Watch Video', subtitle: 'Stream & Watch', icon: Icons.play_circle_rounded, accent: _C.red, count: 2),
  _ToolCategory(id: 'adulthub', title: 'Adult Hub', subtitle: '18+ Only', icon: Icons.lock_rounded, accent: _C.purple, count: 1, tag: '18+'),
];

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;

  late Animation<double> _entrance;

  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _onCategoryTap(String id) {
    switch (id) {
      case 'tabungan':
        _push(const TabunganPage());
        break;
      case 'deploy':
        _push(const DeployPage());
        break;
      case 'panel':
        _showSheet('Manage Server', _C.ice2, _panelItems());
        break;
      case 'ddos':
        _showSheet('DDoS Attack', _C.ice3, _ddosItems());
        break;
      case 'network':
        _showSheet('Network Arsenal', _C.blue, _networkItems());
        break;
      case 'osint':
        _showSheet('OSiNT Tools', _C.iceDeep, _osintItems());
        break;
      case 'downloader':
        _showSheet('Media Downloader', _C.green, _downloaderItems());
        break;
      case 'utilities':
        _showSheet('Utilities', _C.amber, _utilityItems());
        break;
      case 'watchs':
        _showSheet('Watch Video', _C.red, _watchsItems());
        break;
      case 'adulthub':
        _showSheet('Adult Hub', _C.purple, _adulthubItems());
        break;
    }
  }

  List<_ToolItem> _panelItems() => [
    _ToolItem(icon: Icons.dns_rounded, label: 'Manage Server', accent: _C.ice2, onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey))),
  ];

  List<_ToolItem> _ddosItems() => [
    _ToolItem(icon: Icons.bolt_rounded, label: 'Attack Panel', accent: _C.ice3, onTap: () => _push(AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos))),
  ];

  List<_ToolItem> _networkItems() => [
    _ToolItem(icon: Icons.newspaper_outlined, label: 'Spam NGL', accent: _C.blue, onTap: () => _push(NglPage())),
    _ToolItem(icon: Icons.wifi_off_rounded, label: 'WiFi Killer (Internal)', accent: _C.blue, onTap: () => _push(WifiKillerPage())),
    if (widget.userRole == 'vip' || widget.userRole == 'owner')
      _ToolItem(icon: Icons.router_rounded, label: 'WiFi Killer (External)', accent: _C.blue, onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey))),
  ];

  List<_ToolItem> _osintItems() => [
    _ToolItem(icon: Icons.badge_outlined, label: 'NIK Detail', accent: _C.iceDeep, onTap: () => _push(const NikCheckerPage())),
    _ToolItem(icon: Icons.travel_explore_rounded, label: 'Domain OSINT', accent: _C.iceDeep, onTap: () => _push(const DomainOsintPage())),
    _ToolItem(icon: Icons.person_search_rounded, label: 'Phone Lookup', accent: _C.iceDeep, onTap: () => _push(const PhoneLookupPage())),
    _ToolItem(icon: Icons.alternate_email_rounded, label: 'Email OSINT', accent: _C.iceDeep, onTap: () => _push(const EmailOsintPage())),
  ];

  List<_ToolItem> _downloaderItems() => [
    _ToolItem(icon: Icons.video_library_rounded, label: 'TikTok Downloader', accent: _C.green, onTap: () => _push(const TiktokDownloaderPage())),
    _ToolItem(icon: Icons.camera_alt_rounded, label: 'Instagram Downloader', accent: _C.green, onTap: () => _push(const InstagramDownloaderPage())),
  ];

  List<_ToolItem> _utilityItems() => [
    _ToolItem(icon: Icons.qr_code_2_rounded, label: 'QR Generator', accent: _C.amber, onTap: () => _push(const QrGeneratorPage())),
    _ToolItem(icon: Icons.security_rounded, label: 'IP Scanner', accent: _C.amber, onTap: () => _push(const IpScannerPage())),
    _ToolItem(icon: Icons.network_check_rounded, label: 'Port Scanner', accent: _C.amber, onTap: () => _push(const PortScannerPage())),
  ];

  List<_ToolItem> _watchsItems() => [
    _ToolItem(icon: Icons.animation_rounded, label: 'Anime', accent: _C.red, onTap: () => _push(const HomeAnimePage())),
    _ToolItem(icon: Icons.play_circle_rounded, label: 'Dracin', accent: _C.red, onTap: () => _push(const DracinPage())),
  ];

  List<_ToolItem> _adulthubItems() => [
    _ToolItem(icon: Icons.favorite_rounded, label: 'Hentai', accent: _C.purple, onTap: () => _push(const HomeHentaiPage())),
  ];

  List<_ToolCategory> get _filtered {
    if (_query.isEmpty) return _categories;
    final q = _query.toLowerCase();
    return _categories.where((c) =>
      c.title.toLowerCase().contains(q) ||
      c.subtitle.toLowerCase().contains(q) ||
      c.id.toLowerCase().contains(q)
    ).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [_C.bgGrad1, _C.bg, _C.bgGrad2], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.white.withOpacity(0.75), Colors.white.withOpacity(0.88), Colors.white.withOpacity(0.72)],
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),

          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  // Header
                  SliverToBoxAdapter(child: _buildTopBar()),

                  // Hero card
                  SliverToBoxAdapter(child: _buildHeroCard()),

                  // Search bar
                  SliverToBoxAdapter(child: _buildSearchBar()),

                  // Section title
                  SliverToBoxAdapter(child: _buildSectionTitle()),

                  // Grid kategori
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
                    sliver: SliverGrid(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.88,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          return _StaggerItem(
                            index: index,
                            child: _CategoryCard(
                              category: _filtered[index],
                              onTap: () => _onCategoryTap(_filtered[index].id),
                            ),
                          );
                        },
                        childCount: _filtered.length,
                      ),
                    ),
                  ),

                  // Footer
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
                      child: Center(
                        child: Column(
                          children: [
                            Container(width: 40, height: 2, color: _C.borderMid),
                            const SizedBox(height: 14),
                            Text('XYRO ENGINE · TOOLS HUB',
                              style: TextStyle(color: _C.text.withOpacity(0.30), fontSize: 10, letterSpacing: 5, fontFamily: 'Orbitron', fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOP BAR ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _C.primaryGrad,
              boxShadow: _shPrimary,
            ),
            child: const Icon(Icons.shield_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('TOOLS HUB',
                  style: TextStyle(color: _C.text, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2),
                ),
                Text('XYRO ENGINE · GATEWAY',
                  style: TextStyle(color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 2, fontFamily: 'ShareTechMono'),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.ice.withOpacity(0.5), width: 1.2),
              color: _C.iceSoft,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: _C.green,
                      boxShadow: [
                        BoxShadow(
                          color: _C.green.withOpacity(0.5 + _pulseCtrl.value * 0.5),
                          blurRadius: 4 + _pulseCtrl.value * 4,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                const Text('USER',
                  style: TextStyle(color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'Orbitron'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO GAME CARD ─────────────────────────────────────────────────────────
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 16),
      child: GestureDetector(
        onTap: () => _push(const GameHubPage()),
        child: Container(
          height: 130,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF0A2540), Color(0xFF0F3A5F), Color(0xFF0A2540)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(color: _C.ice2.withOpacity(0.35), blurRadius: 24, offset: const Offset(0, 10)),
              BoxShadow(color: _C.text.withOpacity(0.20), blurRadius: 48, offset: const Offset(0, 20)),
            ],
            border: Border.all(color: _C.ice2.withOpacity(0.4), width: 1.2),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Stack(
              children: [
                Positioned(
                  top: -40, right: -40,
                  child: AnimatedBuilder(
                    animation: _orbitCtrl,
                    builder: (_, __) => Transform.rotate(
                      angle: _orbitCtrl.value * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(180, 180),
                        painter: _HeroOrbitPainter(),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 60, height: 60,
                        decoration: BoxDecoration(
                          gradient: _C.primaryGrad,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(color: _C.ice.withOpacity(0.5), blurRadius: 16, offset: const Offset(0, 6)),
                          ],
                        ),
                        child: const Icon(Icons.sports_esports_rounded, color: Colors.white, size: 30),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                const Text('XYRO ARCADE',
                                  style: TextStyle(
                                    color: Colors.white, fontFamily: 'Orbitron',
                                    fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.5,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.ice2, borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: const Text('20 GAMES',
                                    style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text('Mainkan 20 Game Premium Seru!',
                              style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _C.ice2.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.ice2.withOpacity(0.5)),
                        ),
                        child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 14),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── SEARCH BAR ─────────────────────────────────────────────────────────────
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: _sh1,
        ),
        child: TextField(
          controller: _searchCtrl,
          onChanged: (v) => setState(() => _query = v),
          style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w600),
          cursorColor: _C.ice2,
          decoration: InputDecoration(
            hintText: 'Cari tools...',
            hintStyle: TextStyle(color: _C.textDim.withOpacity(0.7), fontSize: 13, fontWeight: FontWeight.w500),
            prefixIcon: const Icon(Icons.search_rounded, color: _C.ice2, size: 20),
            suffixIcon: _query.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchCtrl.clear();
                      setState(() => _query = '');
                    },
                    child: const Icon(Icons.close_rounded, color: _C.textDim, size: 18),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          ),
        ),
      ),
    );
  }

  // ─── SECTION TITLE ──────────────────────────────────────────────────────────
  Widget _buildSectionTitle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Row(
        children: [
          Container(
            width: 4, height: 20,
            decoration: BoxDecoration(
              gradient: _C.primaryGrad,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          const Text('ALL TOOLS',
            style: TextStyle(color: _C.text, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1.5),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _C.iceSoft,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.ice.withOpacity(0.4)),
            ),
            child: Text('${_filtered.length} items',
              style: const TextStyle(color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w900, fontFamily: 'Orbitron'),
            ),
          ),
        ],
      ),
    );
  }

  void _showSheet(String title, Color accent, List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ToolSheet(title: title, accent: accent, items: items),
    );
  }
}

// ─── CATEGORY CARD ──────────────────────────────────────────────────────────
class _CategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final VoidCallback onTap;
  const _CategoryCard({required this.category, required this.onTap});

  @override
  State<_CategoryCard> createState() => _CategoryCardState();
}

class _CategoryCardState extends State<_CategoryCard> with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _glowCtrl;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: Container(
          decoration: BoxDecoration(
            color: _pressed ? _C.cardInner : _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _pressed ? cat.accent.withOpacity(0.6) : _C.border,
              width: _pressed ? 1.8 : 1.0,
            ),
            boxShadow: _pressed ? _sh1 : _sh2,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                // Top accent bar
                Positioned(
                  top: 0, left: 0, right: 0,
                  child: Container(
                    height: 3,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [cat.accent, cat.accent.withOpacity(0.4)]),
                    ),
                  ),
                ),
                // Corner glow
                Positioned(
                  top: -30, right: -30,
                  child: Container(
                    width: 100, height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [cat.accent.withOpacity(0.12), Colors.transparent],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header row
                      Row(
                        children: [
                          Container(
                            width: 46, height: 46,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [cat.accent, cat.accent.withOpacity(0.7)],
                                begin: Alignment.topLeft, end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [
                                BoxShadow(color: cat.accent.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 4)),
                              ],
                            ),
                            child: Icon(cat.icon, color: Colors.white, size: 24),
                          ),
                          const Spacer(),
                          if (cat.tag.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: cat.accent,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(cat.tag,
                                style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                              ),
                            )
                          else
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                              decoration: BoxDecoration(
                                color: cat.accent.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: cat.accent.withOpacity(0.3)),
                              ),
                              child: Text('${cat.count}',
                                style: TextStyle(color: cat.accent, fontSize: 11, fontWeight: FontWeight.w900, fontFamily: 'Orbitron'),
                              ),
                            ),
                        ],
                      ),
                      const Spacer(),
                      // Title
                      Text(cat.title,
                        style: const TextStyle(
                          color: _C.text, fontSize: 13, fontWeight: FontWeight.w900,
                          letterSpacing: 0.2, height: 1.2,
                        ),
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      // Subtitle
                      Text(cat.subtitle,
                        style: const TextStyle(color: _C.textSub, fontSize: 10, fontWeight: FontWeight.w500),
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 10),
                      // Footer
                      Row(
                        children: [
                          Text('${cat.count} tool${cat.count > 1 ? 's' : ''}',
                            style: TextStyle(color: cat.accent, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.3),
                          ),
                          const Spacer(),
                          Icon(Icons.arrow_forward_rounded, color: cat.accent, size: 14),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── TOOL SHEET ─────────────────────────────────────────────────────────────
class _ToolSheet extends StatelessWidget {
  final String title;
  final Color accent;
  final List<_ToolItem> items;
  const _ToolSheet({required this.title, required this.accent, required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
      decoration: const BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              width: 40, height: 4,
              decoration: BoxDecoration(color: _C.borderMid, borderRadius: BorderRadius.circular(100)),
            ),
          ),
          // Title
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            child: Row(
              children: [
                Container(
                  width: 4, height: 24,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [accent, accent.withOpacity(0.4)]),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Text(title,
                  style: const TextStyle(color: _C.text, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: accent.withOpacity(0.3)),
                  ),
                  child: Text('${items.length}',
                    style: TextStyle(color: accent, fontSize: 10, fontWeight: FontWeight.w900, fontFamily: 'Orbitron'),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: _C.border),
          // Items
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _ToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── TOOL ROW ───────────────────────────────────────────────────────────────
class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _pressed ? _C.iceSoft : _C.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _pressed ? item.accent.withOpacity(0.5) : _C.border,
            width: _pressed ? 1.5 : 1.0,
          ),
          boxShadow: _pressed ? null : _sh1,
        ),
        child: Row(
          children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [item.accent, item.accent.withOpacity(0.7)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: item.accent.withOpacity(0.35), blurRadius: 8, offset: const Offset(0, 3)),
                ],
              ),
              child: Icon(item.icon, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(item.label,
                style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w800),
              ),
            ),
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                color: item.accent.withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.arrow_forward_ios_rounded, color: item.accent, size: 12),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── STAGGER ────────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (index * 50).clamp(0, 400)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 16 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── BACKGROUNDS ────────────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.06)..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.ice.withOpacity(0.12 + math.sin(t * math.pi * 2) * 0.04),
        Colors.transparent,
      ], radius: 0.9).createShader(Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.04)..strokeWidth = 0.6;
    const sp = 32.0;
    for (double x = 0; x < size.width; x += sp) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += sp) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _HeroOrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final dashPaint = Paint()
      ..color = _C.ice.withOpacity(0.30)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 32;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.08, false, dashPaint);
    }

    final arcPaint = Paint()
      ..color = _C.ice2.withOpacity(0.5)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const startAngles = [0.0, math.pi * 2 / 3, math.pi * 4 / 3];
    for (final start in startAngles) {
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius * 0.75), start, math.pi / 4, false, arcPaint);
    }

    canvas.drawCircle(center, 4, Paint()..color = _C.ice2.withOpacity(0.6));
    canvas.drawCircle(center, 8, Paint()..color = _C.ice2.withOpacity(0.2));
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
  });
}