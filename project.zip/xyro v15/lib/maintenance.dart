// lib/acc.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ═══════════════════════════════════════════════════════════════
// PALET — KOMIK 3D (PUTIH + MERAH)
// ═══════════════════════════════════════════════════════════════
class Hx {
  static const bg = Color(0xFFF5F5F7);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceHi = Color(0xFFFFFFFF);
  static const surfaceHi2 = Color(0xFFF0F0F2);

  static const goldLight = Color(0xFFFF6B6B);
  static const gold = Color(0xFFE63946);
  static const goldMid = Color(0xFFB71C2C);
  static const goldDeep = Color(0xFF7A0F1A);

  static const jade = Color(0xFF2ECC71);
  static const jadeDeep = Color(0xFF1E8449);
  static const terra = Color(0xFFE63946);
  static const slate = Color(0xFF3B82F6);
  static const amber = Color(0xFFF59E0B);
  static const purple = Color(0xFF8B5CF6);

  static const ivory = Color(0xFF1A1A1A);
  static const ash = Color(0xFF6B6B6B);
  static const ash2 = Color(0xFFB0B0B0);

  static const line = Color(0x33E63946);
  static const lineSoft = Color(0x1AE63946);
}

// ═══════════════════════════════════════════════════════════════
// CONFIG — BASE URL SERVER
// ═══════════════════════════════════════════════════════════════
class AccConfig {
  static const String baseUrl = 'http://www.rexylegal.rxpedia.web.id:2060';
}

// ═══════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════
class AccPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const AccPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<AccPage> createState() => _AccPageState();
}

class _AccPageState extends State<AccPage>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _pulseCtrl;
  final TextEditingController _searchCtrl = TextEditingController();

  List<Map<String, dynamic>> _pendingList = [];
  List<Map<String, dynamic>> _historyList = [];
  List<Map<String, dynamic>> _filteredPending = [];
  bool _loading = true;
  String? _error;
  String _searchQuery = '';

  Timer? _autoRefreshTimer;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _searchCtrl.addListener(() {
      setState(() {
        _searchQuery = _searchCtrl.text.toLowerCase();
        _applyFilter();
      });
    });

    _loadPending();
    _loadHistory();

    _autoRefreshTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) {
        if (mounted) {
          _loadPending();
          _loadHistory();
        }
      },
    );
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _tabController.dispose();
    _pulseCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      _filteredPending = List.from(_pendingList);
    } else {
      _filteredPending = _pendingList.where((u) {
        final name = (u['username'] ?? '').toString().toLowerCase();
        return name.contains(_searchQuery);
      }).toList();
    }
  }

  // ══════════════════════════════════════════════════════
  // LOAD PENDING
  // ══════════════════════════════════════════════════════
  Future<void> _loadPending() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/pending?key=${widget.sessionKey}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        if (!mounted) return;
        setState(() {
          _pendingList =
              List<Map<String, dynamic>>.from(data['pending'] ?? []);
          _loading = false;
        });
        _applyFilter();
      } else {
        if (!mounted) return;
        setState(() {
          _error = data['message'] ?? 'Gagal load pending';
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Koneksi error: $e';
        _loading = false;
      });
    }
  }

  Future<void> _loadHistory() async {
    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/history?key=${widget.sessionKey}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _historyList =
              List<Map<String, dynamic>>.from(data['history'] ?? []);
        });
      }
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════
  // ACC
  // ══════════════════════════════════════════════════════
  Future<void> _accUser(String username) async {
    HapticFeedback.mediumImpact();

    final ok = await _showConfirm(
      title: 'PERMIT ACCESS',
      subtitle: 'Whitelist user "$username"?',
      confirmLabel: 'PERMIT',
      confirmColor: Hx.jade,
      icon: Icons.verified_user,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/acc'
        '?key=${widget.sessionKey}&username=$username',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('▸ ACCESS GRANTED :: $username', Hx.jade);
        _loadPending();
        _loadHistory();
      } else {
        _snack('▸ ${data['message'] ?? 'ACCESS DENIED'}', Hx.terra);
      }
    } catch (e) {
      _snack('▸ ERR :: $e', Hx.terra);
    }
  }

  Future<void> _rejectUser(String username) async {
    HapticFeedback.mediumImpact();

    final ok = await _showConfirm(
      title: 'TERMINATE',
      subtitle: 'Purge user "$username" from database?',
      confirmLabel: 'PURGE',
      confirmColor: Hx.terra,
      icon: Icons.gpp_bad,
    );
    if (ok != true) return;

    try {
      final url = Uri.parse(
        '${AccConfig.baseUrl}/pemula/reject'
        '?key=${widget.sessionKey}&username=$username',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _snack('▸ PURGED :: $username', Hx.terra);
        _loadPending();
        _loadHistory();
      } else {
        _snack('▸ ${data['message'] ?? 'FAILED'}', Hx.terra);
      }
    } catch (e) {
      _snack('▸ ERR :: $e', Hx.terra);
    }
  }

  Future<bool?> _showConfirm({
    required String title,
    required String subtitle,
    required String confirmLabel,
    required Color confirmColor,
    required IconData icon,
  }) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Hx.surfaceHi,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: confirmColor, width: 2.5),
            boxShadow: [
              BoxShadow(
                color: confirmColor.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: confirmColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: confirmColor, width: 2.5),
                ),
                child: Icon(icon, color: confirmColor, size: 32),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  color: confirmColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Hx.ivory,
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Hx.gold, width: 2),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        'ABORT',
                        style: TextStyle(
                          color: Hx.ash,
                          fontSize: 12,
                          letterSpacing: 2,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: confirmColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(
                            color: confirmColor == Hx.jade
                                ? Hx.jadeDeep
                                : Hx.goldDeep,
                            width: 2,
                          ),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        confirmLabel,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          fontFamily: 'monospace',
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 12,
            letterSpacing: 1.2,
            fontWeight: FontWeight.bold,
            color: Hx.ivory,
          ),
        ),
        backgroundColor: Hx.surfaceHi,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: color, width: 2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Hx.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildSearchBar(),
            _buildTabs(),
            Expanded(
              child: _loading
                  ? _buildLoader()
                  : _error != null
                      ? _buildError()
                      : TabBarView(
                          controller: _tabController,
                          children: [
                            _buildPendingTab(),
                            _buildHistoryTab(),
                          ],
                        ),
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // HEADER
  // ══════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: const BoxDecoration(
        color: Hx.surfaceHi,
        border: Border(bottom: BorderSide(color: Hx.gold, width: 2.5)),
      ),
      child: Row(
        children: [
          _IconBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            color: Hx.gold,
            onTap: () {
              HapticFeedback.selectionClick();
              Navigator.pop(context);
            },
          ),
          const SizedBox(width: 10),

          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              return Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Hx.jade.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Hx.jade, width: 2),
                ),
                child: const Icon(
                  Icons.terminal,
                  color: Hx.jade,
                  size: 20,
                ),
              );
            },
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ACCESS_CTRL',
                  style: TextStyle(
                    color: Hx.gold,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: Hx.jade,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'root@pemula :: ONLINE',
                      style: TextStyle(
                        color: Hx.ash,
                        fontSize: 10,
                        letterSpacing: 1.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          _IconBtn(
            icon: Icons.refresh,
            color: Hx.gold,
            onTap: () {
              HapticFeedback.selectionClick();
              _loadPending();
              _loadHistory();
            },
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // SEARCH BAR
  // ══════════════════════════════════════════════════════
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Container(
        decoration: BoxDecoration(
          color: Hx.surfaceHi,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Hx.gold, width: 2),
          boxShadow: [
            BoxShadow(
              color: Hx.gold.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(
            color: Hx.ivory,
            fontFamily: 'monospace',
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          cursorColor: Hx.gold,
          decoration: InputDecoration(
            hintText: '> grep username...',
            hintStyle: const TextStyle(
              color: Hx.ash2,
              fontFamily: 'monospace',
              fontSize: 13,
            ),
            prefixIcon: const Icon(Icons.search, color: Hx.gold, size: 18),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.close, color: Hx.gold, size: 16),
                    onPressed: () => _searchCtrl.clear(),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              vertical: 14,
              horizontal: 8,
            ),
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TABS
  // ══════════════════════════════════════════════════════
  Widget _buildTabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Hx.gold, width: 2),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: Hx.gold,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Hx.goldDeep, width: 2),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: Hx.ash,
        labelStyle: const TextStyle(
          fontSize: 11,
          letterSpacing: 1.5,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w900,
        ),
        unselectedLabelStyle: const TextStyle(
          fontSize: 11,
          letterSpacing: 1.5,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
        ),
        tabs: [
          Tab(
            height: 40,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.pending_actions, size: 14),
                const SizedBox(width: 6),
                Text('PENDING::${_pendingList.length}'),
              ],
            ),
          ),
          Tab(
            height: 40,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.history, size: 14),
                const SizedBox(width: 6),
                Text('LOG::${_historyList.length}'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // LOADER
  // ══════════════════════════════════════════════════════
  Widget _buildLoader() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              valueColor: const AlwaysStoppedAnimation(Hx.gold),
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            '> FETCHING PAYLOADS_',
            style: TextStyle(
              color: Hx.gold,
              fontFamily: 'monospace',
              fontSize: 12,
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Hx.terra.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: Hx.terra, width: 2.5),
              ),
              child: const Icon(
                Icons.warning_amber,
                color: Hx.terra,
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '> CONNECTION_ERROR',
              style: TextStyle(
                color: Hx.terra,
                fontFamily: 'monospace',
                fontSize: 13,
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _error ?? 'Unknown error',
              style: const TextStyle(
                color: Hx.ash,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _loadPending,
              icon: const Icon(Icons.refresh, size: 16, color: Colors.white),
              label: const Text(
                'RETRY',
                style: TextStyle(
                  fontFamily: 'monospace',
                  letterSpacing: 2,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Hx.gold,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Hx.goldDeep, width: 2),
                ),
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TAB 1 — PENDING
  // ══════════════════════════════════════════════════════
  Widget _buildPendingTab() {
    if (_filteredPending.isEmpty) {
      return _emptyState(
        icon: Icons.shield_outlined,
        title: _searchQuery.isEmpty ? 'NO PENDING TARGETS' : 'NO MATCH FOUND',
        subtitle: _searchQuery.isEmpty
            ? 'Semua akun sudah diproses'
            : 'Coba keyword lain',
      );
    }

    return RefreshIndicator(
      onRefresh: _loadPending,
      color: Hx.gold,
      backgroundColor: Hx.surfaceHi,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        itemCount: _filteredPending.length,
        itemBuilder: (ctx, i) => _buildPendingCard(_filteredPending[i], i),
      ),
    );
  }

  Widget _buildPendingCard(Map<String, dynamic> user, int index) {
    final username = user['username'] ?? '-';
    final role = user['role'] ?? 'member';
    final expired = user['expiredDate'] ?? '-';
    final createdBy = user['createdBy'] ?? 'unknown';
    final createdAt = user['createdAt'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Hx.gold, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: Hx.gold.withOpacity(0.25),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Hx.gold,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Hx.goldDeep, width: 2),
                ),
                child: Center(
                  child: Text(
                    username.toString().isNotEmpty
                        ? username[0].toString().toUpperCase()
                        : '?',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: const TextStyle(
                        color: Hx.ivory,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        _chip(role.toString().toUpperCase(), Hx.slate),
                        const SizedBox(width: 6),
                        _chip('PENDING', Hx.gold),
                      ],
                    ),
                  ],
                ),
              ),

              Text(
                '#${(index + 1).toString().padLeft(2, '0')}',
                style: const TextStyle(
                  color: Hx.ash2,
                  fontSize: 11,
                  fontFamily: 'monospace',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          _infoLine('EXP', expired, Icons.event, Hx.gold),
          _infoLine('BY', createdBy, Icons.person_outline, Hx.jade),
          if (createdAt.isNotEmpty)
            _infoLine(
              'AT',
              _formatDate(createdAt),
              Icons.access_time,
              Hx.ash,
            ),

          const SizedBox(height: 14),
          Container(height: 2, color: Hx.gold.withOpacity(0.2)),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: _actionBtn(
                  label: 'PURGE',
                  icon: Icons.close,
                  color: Hx.terra,
                  onTap: () => _rejectUser(username),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _actionBtn(
                  label: 'PERMIT',
                  icon: Icons.check,
                  color: Hx.jade,
                  onTap: () => _accUser(username),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: color == Hx.jade ? Hx.jadeDeep : Hx.goldDeep,
          width: 1.5,
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  Widget _infoLine(String label, String value, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        children: [
          SizedBox(
            width: 32,
            child: Text(
              label,
              style: const TextStyle(
                color: Hx.ash2,
                fontSize: 10,
                fontFamily: 'monospace',
                letterSpacing: 1,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Hx.ash,
                fontSize: 11,
                fontFamily: 'monospace',
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionBtn({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: color == Hx.jade ? Hx.jadeDeep : Hx.goldDeep,
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.35),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 15),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // TAB 2 — HISTORY
  // ══════════════════════════════════════════════════════
  Widget _buildHistoryTab() {
    if (_historyList.isEmpty) {
      return _emptyState(
        icon: Icons.history_toggle_off,
        title: 'NO LOGS',
        subtitle: 'Belum ada riwayat ACC/REJECT',
      );
    }

    return RefreshIndicator(
      onRefresh: _loadHistory,
      color: Hx.gold,
      backgroundColor: Hx.surfaceHi,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        itemCount: _historyList.length,
        itemBuilder: (ctx, i) => _buildHistoryCard(_historyList[i], i),
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> item, int index) {
    final username = item['username'] ?? '-';
    final action = item['action'] ?? '-';
    final timestamp = item['timestamp'] ?? '';
    final isAcc = action == 'acc';
    final color = isAcc ? Hx.jade : Hx.terra;
    final icon = isAcc ? Icons.check_circle : Icons.cancel;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
      decoration: BoxDecoration(
        color: Hx.surfaceHi,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.25),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: color, width: 2),
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: const TextStyle(
                    color: Hx.ivory,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(
                      isAcc ? 'PERMITTED' : 'PURGED',
                      style: TextStyle(
                        color: color,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                    if (timestamp.isNotEmpty) ...[
                      const Text(
                        '  ::  ',
                        style: TextStyle(color: Hx.ash2, fontSize: 10),
                      ),
                      Text(
                        _formatDate(timestamp),
                        style: const TextStyle(
                          color: Hx.ash,
                          fontSize: 10,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Text(
            '#${(index + 1).toString().padLeft(2, '0')}',
            style: const TextStyle(
              color: Hx.ash2,
              fontSize: 10,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  // EMPTY STATE
  // ══════════════════════════════════════════════════════
  Widget _emptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Hx.surfaceHi,
              shape: BoxShape.circle,
              border: Border.all(color: Hx.gold, width: 2.5),
            ),
            child: Icon(icon, color: Hx.gold, size: 40),
          ),
          const SizedBox(height: 16),
          Text(
            '> $title',
            style: const TextStyle(
              color: Hx.gold,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              color: Hx.ash2,
              fontSize: 11,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}/'
          '${dt.month.toString().padLeft(2, '0')} '
          '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// COMPONENT — Icon Button
// ═══════════════════════════════════════════════════════════════
class _IconBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _IconBtn({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Hx.surfaceHi,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Hx.gold, width: 2),
            boxShadow: [
              BoxShadow(
                color: Hx.gold.withOpacity(0.2),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      ),
    );
  }
}