// ═══════════════════════════════════════════════════════════════════════════
//  OWNER PAGE — GLASS BLACK + VIDEO BG + B/W/R
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

const String kBase = 'http://www.rexylegal.rxpedia.web.id:2060';

// ═══ PALET — HITAM / PUTIH / MERAH ═══
class _C {
  static const text = Color(0xFFFFFFFF);
  static const muted = Color(0xFF888888);
  static const red = Color(0xFFFF2E2E);
}

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage>
    with WidgetsBindingObserver {
  int _mode = 0;

  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _dayCtrl = TextEditingController();
  final _editUserCtrl = TextEditingController();
  final _editDayCtrl = TextEditingController();
  final _delUserCtrl = TextEditingController();

  String _newRole = 'member';
  final List<String> _roleOptions = ['member', 'vip', 'reseller', 'admin'];

  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  bool _isSubmitting = false;

  // VIDEO BG
  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _videoInitializing = false;
  int _retry = 0;
  final GlobalKey _videoKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
  }

  Future<void> _initVideo() async {
    if (_videoInitializing) return;
    _videoInitializing = true;
    try {
      final old = _vCtrl;
      _vCtrl = null;
      if (old != null) {
        try { await old.pause(); } catch (_) {}
        try { await old.dispose(); } catch (_) {}
      }
      final c = VideoPlayerController.asset('assets/videos/background.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      c.addListener(() {
        final v = c.value;
        if (v.isInitialized &&
            !v.isPlaying &&
            v.position >= v.duration &&
            v.duration > Duration.zero) {
          c.seekTo(Duration.zero).catchError((_) {});
          c.play().catchError((_) {});
        }
      });
      await c.play();
      if (!mounted) { await c.dispose(); _videoInitializing = false; return; }
      setState(() { _vCtrl = c; _videoReady = true; });
    } catch (_) {
      _videoInitializing = false;
      if (!mounted) return;
      if (_retry < 3) {
        _retry++;
        Future.delayed(Duration(milliseconds: 400 * _retry), () {
          if (mounted) _initVideo();
        });
      }
      return;
    }
    _videoInitializing = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _vCtrl;
    if (c == null || !c.value.isInitialized) return;
    if (state == AppLifecycleState.resumed) {
      if (!c.value.isPlaying) c.play().catchError((_) {});
    } else if (state == AppLifecycleState.paused) {
      c.pause().catchError((_) {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _userCtrl.dispose();
    _passCtrl.dispose();
    _dayCtrl.dispose();
    _editUserCtrl.dispose();
    _editDayCtrl.dispose();
    _delUserCtrl.dispose();
    final c = _vCtrl;
    _vCtrl = null;
    if (c != null) {
      try { c.pause(); } catch (_) {}
      try { c.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _pickImage() async {
    HapticFeedback.mediumImpact();
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1280,
      );
      if (picked == null) return;
      setState(() => _imageFile = File(picked.path));
    } catch (_) {}
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Colors.black.withOpacity(0.9),
      content: Row(children: [
        Icon(error ? Icons.error_outline : Icons.check_circle_outline,
            color: _C.red, size: 20),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 12))),
      ]),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: _C.red.withOpacity(0.5)),
      ),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  Future<void> _submitCreate() async {
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    final day = _dayCtrl.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }
    if (_imageFile == null) {
      _snack('Bukti foto wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final pendingRes = await http.get(Uri.parse(
        '$kBase/createAccountPending'
        '?key=${widget.sessionKey}'
        '&newUser=${Uri.encodeComponent(username)}'
        '&pass=${Uri.encodeComponent(password)}'
        '&day=${Uri.encodeComponent(day)}'
        '&role=${Uri.encodeComponent(_newRole)}',
      )).timeout(const Duration(seconds: 20));

      final pendingData = jsonDecode(pendingRes.body);
      if (pendingData['valid'] != true || pendingData['created'] != true) {
        _snack(pendingData['message'] ?? 'Gagal buat akun', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      final bytes = await _imageFile!.readAsBytes();
      final base64Image = base64Encode(bytes);

      final botRes = await http.post(
        Uri.parse('$kBase/sendPendingToBot'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': username,
          'password': password,
          'day': day,
          'role': _newRole,
          'image': base64Image,
        }),
      ).timeout(const Duration(seconds: 30));

      final botData = jsonDecode(botRes.body);
      if (botData['valid'] != true || botData['sent'] != true) {
        _snack(botData['message'] ?? 'Gagal kirim ke bot', error: true);
        if (mounted) setState(() => _isSubmitting = false);
        return;
      }

      HapticFeedback.heavyImpact();
      _snack('Bukti terkirim ke bot. Menunggu ACC.');

      _userCtrl.clear();
      _passCtrl.clear();
      _dayCtrl.clear();
      setState(() {
        _imageFile = null;
        _newRole = 'member';
        _isSubmitting = false;
      });
    } catch (e) {
      _snack('Error: $e', error: true);
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitAddDurasi() async {
    final u = _editUserCtrl.text.trim();
    final d = _editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _snack('Semua field wajib diisi', error: true);
      return;
    }

    HapticFeedback.mediumImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/editUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}'
        '&addDays=${Uri.encodeComponent(d)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        HapticFeedback.heavyImpact();
        _snack('Durasi berhasil ditambah $d hari');
        _editUserCtrl.clear();
        _editDayCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal tambah durasi', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitHapus() async {
    final u = _delUserCtrl.text.trim();
    if (u.isEmpty) {
      _snack('Username wajib diisi', error: true);
      return;
    }

    HapticFeedback.heavyImpact();
    setState(() => _isSubmitting = true);

    try {
      final res = await http.get(Uri.parse(
        '$kBase/deleteUser'
        '?key=${widget.sessionKey}'
        '&username=${Uri.encodeComponent(u)}',
      )).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        HapticFeedback.heavyImpact();
        _snack('User berhasil dihapus');
        _delUserCtrl.clear();
      } else {
        _snack(data['message'] ?? 'Gagal hapus', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  // ═══ BG VIDEO ═══
  Widget _bgVideo({required Widget child}) {
    final c = _vCtrl;
    final ready = _videoReady && c != null && c.value.isInitialized;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        if (!ready)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF141414),
                  Color(0xFF000000),
                ],
              ),
            ),
          ),
        if (ready)
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: _CoverVideo(key: _videoKey, controller: c),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.72)),
        child,
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _bgVideo(
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              const SizedBox(height: 12),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 16),
                      _buildTabsRow(),
                      const SizedBox(height: 16),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: _mode == 0
                            ? _formCreate()
                            : _mode == 1
                                ? _formAddDurasi()
                                : _formHapus(),
                      ),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══ TOP BAR ═══
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 24),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('OWNER PANEL',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                SizedBox(height: 2),
                Text('FULL ACCESS CONSOLE',
                    style: TextStyle(
                        fontSize: 10,
                        color: _C.muted,
                        letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ HEADER CARD ═══
  Widget _buildHeader() {
    return _GlassCard(
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.red.withOpacity(0.15),
              border: Border.all(color: _C.red, width: 1.5),
            ),
            child: const Icon(Icons.workspace_premium_rounded,
                color: _C.red, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('FULL ACCESS CONSOLE',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5)),
                const SizedBox(height: 5),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.red),
                    color: _C.red.withOpacity(0.1),
                  ),
                  child: const Text('OWNER',
                      style: TextStyle(
                          color: _C.red,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══ TABS ROW ═══
  Widget _buildTabsRow() {
    return Row(
      children: [
        Expanded(
            child: _tab('CREATE', Icons.person_add_rounded, 0)),
        const SizedBox(width: 10),
        Expanded(child: _tab('EXTEND', Icons.timer_rounded, 1)),
        const SizedBox(width: 10),
        Expanded(
            child:
                _tab('DELETE', Icons.person_remove_rounded, 2)),
      ],
    );
  }

  Widget _tab(String label, IconData icon, int index) {
    final active = _mode == index;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _mode = index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: active
              ? _C.red.withOpacity(0.18)
              : Colors.white.withOpacity(0.04),
          border: Border.all(
              color: active ? _C.red : Colors.white.withOpacity(0.1),
              width: active ? 1.5 : 1),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Icon(icon, color: active ? _C.red : _C.muted, size: 22),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                    letterSpacing: 1,
                    color: active ? _C.red : _C.muted)),
          ],
        ),
      ),
    );
  }

  // ═══ INPUT ═══
  Widget _input({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    bool obscure = false,
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w800,
                fontSize: 11,
                letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: type,
            style: const TextStyle(
                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: _C.muted, fontSize: 13),
              prefixIcon: Icon(icon, color: _C.muted, size: 18),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _card(Widget child) {
    return _GlassCard(padding: const EdgeInsets.all(20), child: child);
  }

  // ═══ FORM CREATE ═══
  Widget _formCreate() {
    return _card(
      Column(
        key: const ValueKey('create'),
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(
              label: 'USERNAME',
              hint: 'superuser',
              controller: _userCtrl,
              icon: Icons.person_rounded),
          _input(
              label: 'PASSWORD',
              hint: 'minimal 4 karakter',
              controller: _passCtrl,
              icon: Icons.lock_rounded,
              obscure: true),
          _input(
              label: 'DURASI (HARI)',
              hint: '30',
              controller: _dayCtrl,
              icon: Icons.calendar_month_rounded,
              type: TextInputType.number),
          const Text('ROLE',
              style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              border: Border.all(color: Colors.white.withOpacity(0.12)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _newRole,
                isExpanded: true,
                dropdownColor: const Color(0xFF0A0A0A),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
                icon: const Icon(Icons.arrow_drop_down,
                    color: _C.red, size: 24),
                items: _roleOptions.map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role.toUpperCase(),
                        style: const TextStyle(color: Colors.white)),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _newRole = val ?? 'member'),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('BUKTI FOTO',
              style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: 1.5)),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                border: Border.all(
                    color: _imageFile != null
                        ? _C.red.withOpacity(0.7)
                        : Colors.white.withOpacity(0.12),
                    width: 1.5),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                      _imageFile != null
                          ? Icons.check_circle_rounded
                          : Icons.image_rounded,
                      color: _C.red,
                      size: 24),
                  const SizedBox(width: 10),
                  Text(
                    _imageFile != null ? 'FOTO TERPILIH' : 'PILIH FOTO',
                    style: const TextStyle(
                        color: _C.red,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        letterSpacing: 1),
                  ),
                ],
              ),
            ),
          ),
          if (_imageFile != null) ...[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(_imageFile!, height: 150, fit: BoxFit.cover),
            ),
          ],
          const SizedBox(height: 24),
          _submitBtn('KIRIM KE BOT',
              _isSubmitting ? null : _submitCreate),
        ],
      ),
    );
  }

  // ═══ FORM EXTEND ═══
  Widget _formAddDurasi() {
    return _card(
      Column(
        key: const ValueKey('extend'),
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(
              label: 'USERNAME TARGET',
              hint: 'superuser',
              controller: _editUserCtrl,
              icon: Icons.person_search_rounded),
          _input(
              label: 'TAMBAH HARI',
              hint: '30',
              controller: _editDayCtrl,
              icon: Icons.calendar_month_rounded,
              type: TextInputType.number),
          const SizedBox(height: 24),
          _submitBtn('TAMBAH DURASI',
              _isSubmitting ? null : _submitAddDurasi),
        ],
      ),
    );
  }

  // ═══ FORM DELETE ═══
  Widget _formHapus() {
    return _card(
      Column(
        key: const ValueKey('delete'),
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _input(
              label: 'USERNAME TARGET',
              hint: 'superuser',
              controller: _delUserCtrl,
              icon: Icons.person_remove_rounded),
          const SizedBox(height: 24),
          _submitBtn('HAPUS AKUN', _isSubmitting ? null : _submitHapus),
        ],
      ),
    );
  }

  // ═══ SUBMIT BUTTON ═══
  Widget _submitBtn(String label, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: _C.red,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: _C.red.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Center(
          child: _isSubmitting
              ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                      color: Colors.black, strokeWidth: 2.5))
              : Text(label,
                  style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.5)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.42),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: Colors.white.withOpacity(0.1), width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COVER VIDEO
// ═══════════════════════════════════════════════════════════════════════════
class _CoverVideo extends StatelessWidget {
  final VideoPlayerController controller;
  const _CoverVideo({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final size = controller.value.size;
    if (size.width == 0 || size.height == 0) {
      return const SizedBox.shrink();
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;
        final scale = (screenW / size.width) > (screenH / size.height)
            ? (screenW / size.width)
            : (screenH / size.height);
        final w = size.width * scale;
        final h = size.height * scale;
        return OverflowBox(
          maxWidth: w,
          maxHeight: h,
          minWidth: w,
          minHeight: h,
          alignment: Alignment.center,
          child: SizedBox(
            width: w,
            height: h,
            child: VideoPlayer(controller),
          ),
        );
      },
    );
  }
}